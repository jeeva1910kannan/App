import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from './../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class WebService {
  uri:String = environment.base_url+'restapi/public/index.php/Webservices_new/';
  // uri:String = environment.base_url+'restapi/public/index.php/Webservices_jeeva/';
  // uri:String = environment.base_url+'restapi/public/index.php/webservices/';
  //uri:String = environment.base_url+'restapi/public/index.php/webservices_abi/';
  //uri:String = environment.base_url+'restapi/public/index.php/webservices_priya/';
  // uri:String = environment.base_url+'restapi/public/index.php/webservices_Assin/';
  public uri1 = environment.base_url+'newrestapi/index.php/webvideo';
  uri2:String = environment.base_url+'restapi/public/index.php/uploadservice/';
  uri3:String = environment.base_url+'restapi/public/index.php/';



  constructor( private _httpClient: HttpClient,private auth:AuthService) { }

  postData(controller:any, data: any): Promise<any> {

    
    return new Promise((resolve, reject) => {
      this._httpClient.post(`${this.uri}`+controller, {...data}, {
        headers:
            new HttpHeaders(
                {
                  'Content-Type': 'application/x-www-form-urlencoded',
                }
            )
      })
          .subscribe((response: any) => {
            resolve(response);
          }, reject);
    });
  }
  uploadWebsitePicture(uploadurl:any, body:any) {
    const url = uploadurl;
    const response = this._httpClient.post(url, body);
    return response;
  }
  getcategory(controller:any): Promise<any> {
    return new Promise((resolve, reject) => {
      this._httpClient.get(`${this.uri3}/`+controller, {
        headers:
            new HttpHeaders(
                {
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                }
            )
      }).subscribe((response: any) => {
        resolve(response);
        setTimeout(() => {

        }, 100);
      }, reject);
    });
  }
   getsubCategory(controller:any): Promise<any>{
    return new Promise((resolve, reject) => {
      this._httpClient.get(`${this.uri3}/`+controller, {
        headers:
            new HttpHeaders(
                {
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                }
            )
      }).subscribe((response: any) => {
        resolve(response);
        setTimeout(() => {

        }, 100);
      }, reject);
    });
}

uploadWebsiteVideo(uploadurl:any, body:any) {
  const url = uploadurl;

  return this._httpClient.post(url, body,)
   
 }

 Videoupload(params: any): Promise<any> {
  return new Promise((resolve, reject) => {
      this._httpClient.post(`${this.uri3}/addupdateuserVideo`, {...params}, {
          headers:
            new HttpHeaders(
              {
                  'Content-Type': 'application/x-www-form-urlencoded',
              }
            )
        })
          .subscribe((response: any) => {
              resolve(response);
      }, reject);
  });
}
videoimage(params: any): Promise<any> {
  console.log(params);
  return new Promise((resolve, reject) => {
      this._httpClient.post(`${this.uri2}/videoimage`, {params}, {
          headers:
            new HttpHeaders(
              {
                  'Content-Type': 'application/x-www-form-urlencoded',
              }
            )
        })
          .subscribe((response: any) => {
            console.log(response);
              resolve(response);
      }, reject);
  });
}
  postFormData(controller:any, data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      this._httpClient.post(`${this.uri2}`+controller, data)
          .subscribe((response: any) => {
            if(response.status=="authentication_error"){
              // this.auth.logout();
            }
            else{
              resolve(response);
            }
          },(response1: any) => {
            if(response1.error.status=="authentication_error"){
              // this.auth.logout();
            }
            else{
              reject(response1);
            }
          });
    });
  }
  // getData(controller:any): Promise<any> {
  //   return new Promise((resolve, reject) => {
  //     this._httpClient.get(`${this.uri}/`+controller, {
  //       headers:
  //           new HttpHeaders(
  //               {
  //                 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  //               }
  //           )
  //     }).subscribe((response: any) => {
  //       resolve(response);
  //       setTimeout(() => {

  //       }, 100);
  //     }, reject);
  //   });
  // }
  getData(controller:any): Promise<any> {
    return new Promise((resolve, reject) => {
      this._httpClient.get(`${this.uri}/`+controller, {
        headers:
            new HttpHeaders(
                {
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                }
            )}).subscribe((response: any) => {
              if(response.status=="authentication_error"){
                this.auth.logout();
              }
              else{
                resolve(response);
              }
      }, (response1: any) => {
        if(response1.error.status=="authentication_error"){
          this.auth.logout();
        }
        else{
          reject(response1);
        }
      });
    });
  }

  postDataService(service:any, controller:any, data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      this._httpClient.post(`${this.uri3}`+service+controller, {...data}, {
        headers:
            new HttpHeaders(
                {
                  'Content-Type': 'application/x-www-form-urlencoded',
                }
            )
      })
          .subscribe((response: any) => {
            if(response.status=="authentication_error"){
              // this.auth.logout();
            }
            else{
              resolve(response);
            }
          }, (response1: any) => {
            if(response1.error.status=="authentication_error"){
              // this.auth.logout();
            }
            else{
              reject(response1);
            }
          });
    });
  }

}
