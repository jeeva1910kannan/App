import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { CommonService } from 'src/app/providers/common.service';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  sitecontents:any;
  constructor(private web: WebService,
    public common: CommonService,) { }

  ngOnInit(): void {
    this.getsitesettings();
  }
  getsitesettings(){
    this.web.getData('getSiteSettings').then((res) => {
        if (res.status == '200') {
          this.sitecontents = res.data;

          console.log(this.sitecontents);
       
        } else {
        this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });
  }
}
