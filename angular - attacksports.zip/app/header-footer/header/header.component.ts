import { Component, OnInit,ViewChild } from '@angular/core';

import { Router, UrlMatcher } from '@angular/router';

import { WebService } from '../../providers/web.service';
import { MatMenuTrigger } from '@angular/material/menu';

declare let jQuery:any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent{
    @ViewChild(MatMenuTrigger) menuTrigger!: MatMenuTrigger;
    showTournamentDropdown = false;
    showAboutDropdown = false;
    showHockeyClubDropdown = false;
    showMultiSportsDropdown = false;
    showHockeyCampsDropdown = false;
    type:any;
    url: any;
    test:any;
userexist:boolean;
    tablist: any;

  constructor(private router: Router,private web:WebService) {
    console.log(this.router.url);
    this.url = this.router.url;

   }
   logout(): void {
    localStorage.removeItem('UserId');
    localStorage.removeItem('access_token');

    localStorage.removeItem('type');
    this.router.navigate(['/login']);
  }
  ngOnInit(): void {
    this.getPageData();
      console.log(localStorage.getItem('type'));
      this.type=localStorage.getItem('type')

      this.test =localStorage.getItem('UserId');
      console.log(this.test,"this.userexist");
    if( this.test!='null'){
        this.userexist=false;
    }else if( this.test=='null'){
        this.userexist=true;
    }
    else{
        this.userexist=true;
    }
    console.log(this.userexist,"boolean");
    if (jQuery(window).width() <= 991) {
      jQuery('.navbar-nav li:has(ul)').prepend('<span class="arrow"><i class="fal fa-angle-right"></i></span>');

          jQuery(".navbar-nav > li span.arrow").click(function() {
          jQuery(".navbar-nav > li span.arrow").parent().find("> ul").stop(true, true).slideToggle('slow')
          jQuery(".navbar-nav > li span.arrow").toggleClass( "active" ); 
      });
  }
  jQuery(document).ready(function () {
    jQuery(".navbar-toggler").click(function () {
        jQuery('html').toggleClass('show-menu');
    });

    function scrolling() {
        var sticky = jQuery('.navbar'),
            scroll = jQuery(window).scrollTop();

        if (scroll >= 15) sticky.addClass('fixed');
        else sticky.removeClass('fixed');
    };
    scrolling();
    jQuery(window).scroll(scrolling);

    // jQuery(".navbar-nav").on("click",function(){

    //     jQuery(".toggler").click();
    
    // });

    /*--------------------------------------------------
    * BACK TO TOP STARTS Here
    *--------------------------------------------------*/

    jQuery("#back-to-top").hide();
    jQuery(function () {
        jQuery(window).scroll(function () {
            if (jQuery("#back-to-top").scrollTop() > 100) {
                jQuery('#back-to-top').fadeIn();
            } else {
                jQuery('#back-to-top').fadeOut();
            }
        });

        // scroll body to 0px on click
        jQuery('#back-to-top').click(function () {
            jQuery('body,html').animate({
                scrollTop: 0
            }, 1000);
            return false;
        });
    });

    /*--------------------------------------------------
    * Header Menu Active
    *--------------------------------------------------*/

    jQuery(".navbar-nav li a").each(function () {
        var pathname1 = window.location.href.substr(window.location.href.lastIndexOf('/') + 1);
        var pathname = pathname1.replace("#/", "");
        if (jQuery(".navbar-nav li a").attr('href') == pathname) {
            jQuery(".navbar-nav li a").parent().addClass('current-menu-item');
        }
    });

    jQuery(".navbar-nav li ul.dropdown-menu li a").each(function () {
        var pathname1 = window.location.href.substr(window.location.href.lastIndexOf('/') + 1);
        // alert(pathname1);
        var pathname = pathname1.replace("#/", "");
        if (jQuery(".navbar-nav li ul.dropdown-menu li a").attr('href').indexOf(pathname1) > -1) {
            jQuery(".navbar-nav li ul.dropdown-menu li a").parent().addClass('current-menu-item');
            jQuery(".navbar-nav li ul.dropdown-menu li a").parent().parent().parent().addClass('current-menu-item');
        }
    });

    /* ========================================== 
    Header Mobile
    ========================================== */
    responsiveResize();
    jQuery(window).resize(responsiveResize);
    
});



jQuery(window).on('load', function(){
    /*--------------------------------------------------
    * Spinner Loader
    *--------------------------------------------------*/

    jQuery(".loader").fadeOut("1500");

    /*--------------------------------------------------
    * Development Tabs
    *--------------------------------------------------*/

    jQuery('.development-tabs').each(function() {
    jQuery('.development-tabs').find('.tabs-heading li').first().addClass('current');
    jQuery('.development-tabs').find('.tab-content').first().addClass('current');
    });
    jQuery('.tabs-heading li').on( 'click', function(){
        var tab_id = jQuery('.development-tabs').attr('data-tab');
        jQuery('.development-tabs').siblings().removeClass('current');
        jQuery('.development-tabs').parents('.development-tabs').find('.tab-content').removeClass('current');
        jQuery('.development-tabs').addClass('current');
        jQuery("#"+tab_id).addClass('current');
    });


});
function responsiveResize() {
    if (jQuery(window).width() <= 992) {
        jQuery('.navbar-nav li:has(ul)').prepend('<span class="arrow"><i class="fal fa-angle-right"></i></span>');

            jQuery(".navbar-nav > li span.arrow").click(function() {
            jQuery('.navbar-nav li:has(ul)').parent().find("> ul").stop(true, true).slideToggle('slow')
            jQuery('.navbar-nav li:has(ul)').toggleClass( "active" ); 
        });
    }
}
/* jQuery(window).load(function() { */
    //jQuery(window).on"load",(function(){
/*         jQuery(window).on('load', function(){
    jQuery('#loading-bar-spinner').show();
    jQuery("#loading-bar-spinner").hide();
}); */

    /* 14 Preloader
    ================================================== */
   
    jQuery('.spinner').fadeOut(); // will first fade out the loading animation
    jQuery('.loader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
    jQuery('body').delay(350).css({
        'overflow': 'visible'
    });
  }

  async getPageData(){
   
    await this.web.getData('getAllTab').then(res => {
      if(res.status=='200'){
        this.tablist =res.data;
        console.log("tab ==> ",this.tablist);
      }
      else{
       
      }
      },err=>{
      
  
      });
      // console.log('asd',this.tableSource);
  
  }

  routeTo(page){
    this.router.navigate([page])
  }

  
}

