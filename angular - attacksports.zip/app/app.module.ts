import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxDocViewerModule } from 'ngx-doc-viewer';
import { RecaptchaModule } from 'ng-recaptcha';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { WebService } from './providers/web.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonService } from '../app/pages/services/common.service';
import { ToastrModule } from 'ngx-toastr';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { PdfPreviewComponent } from './pages/common/components/pdf-preview/pdf-preview.component';
import { LightboxModule } from 'ngx-lightbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxPayPalModule } from 'ngx-paypal';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { JwtModule } from '@auth0/angular-jwt';
import { AuthService } from './providers/auth.service';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { CalenderComponent } from './my-account/calender/calender.component';

export function tokenGetter() {
  return localStorage.getItem('access_token');
}

@NgModule({
  declarations: [
    AppComponent,
    PdfPreviewComponent,
    CalenderComponent,
    
   
    
  
  ],
  imports: [
    // SpringhockeyModule,
    LightboxModule,
    NgxDocViewerModule,
    NgxSkeletonLoaderModule,
    MatSidenavModule,
    RecaptchaModule,
    MatSnackBarModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatDialogModule,
    MatButtonModule,
    MatDialogModule,
    NgxPayPalModule,
    BrowserModule,
    MatProgressSpinnerModule,
    FormsModule,
    NgbModule,
    MatSelectModule,

    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ['zerosoft.in']
      }
    }),
    ToastrModule.forRoot()
  ],
  providers: [
    CommonService,
    WebService,
    AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
