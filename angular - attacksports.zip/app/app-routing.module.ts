import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then(m => m.HomeModule)
  },
  // {
  //   path: 'report/:id',
  //   loadChildren: () => import('./pages/my-account/report/report.module').then(m => m.ReportModule)
  // },
  {
    path: 'instructor',
    loadChildren: () => import('./pages/instructor/instructor.module').then(m => m.InstructorModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'instructordetails/:id',
    loadChildren: () => import('./pages/instructordetails/instructordetails.module').then(m => m.InstructordetailsModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginModule),
  },

  {
    path: 'subscription',
    loadChildren: () => import('./pages/subscription/subscription.module').then(m => m.SubscriptionModule),
   
  }, {
    path: 'my-account',
    loadChildren: () => import('./pages/my-account/my-account.module').then(m => m.MyAccountModule),
   
  },
  {
    path: 'ourteam',
    loadChildren: () => import('./pages/ourteam/ourteam.module').then(m => m.OurteamModule),
  },
  {
    path: 'signup',
    loadChildren: () => import('./pages/signup/signup.module').then(m => m.SignupModule)
  },
  {
    path: 'template-page/:id',
    loadChildren: () => import('./pages/template-page/template-page.module').then(m => m.TemplatePageModule)
  },
  {
    path: 'contactus',
    loadChildren: () => import('./pages/contactus/contactus.module').then(m => m.ContactusModule),

  },
  {
    path: 'privacy-policy',
    loadChildren: () => import('./pages/privacy-policy/privacy-policy.module').then(m => m.privacyPolicyModule),
  },
  {
    path: 'terms',
    loadChildren: () => import('./pages/terms/terms.module').then(m => m.TermsModule),
  },
  {
    path: 'waiver',
    loadChildren: () => import('./pages/waiver/waiver.module').then(m => m.WaiverModule),
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./pages/password/forgotpassword/forgotpassword.module').then(m => m.ForgotPasswordModule)
  
  },
  {
    path: 'reset-password',
    loadChildren: () => import('./pages/password/reset-password/reset-password.module').then(m => m.ResetPasswordModule),
   
  },
  {
    path: 'faq',
    loadChildren: () => import('./pages/faq/faq.module').then(m => m.FaqModule),
  },
  {
    path: 'eventcontent/:id',
    loadChildren: () => import('./pages/eventcontent/eventcontent.module').then(m => m.EventContentModule),
  },
  {
    path: 'eventvideo/:id',
    loadChildren: () => import('./pages/eventvideo/eventvideo.module').then(m => m.EventvideoModule),
  },
  {
    path:'customer-videos/:id',
    loadChildren: () => import('./pages/customer-videos/customer-videos.module').then(m => m.CustomerVideosModule),
  },
  {
    path:'instructor-videos/:id',
    loadChildren: () => import('./pages/instructor-vidoes/instructor-vidoes.module').then(m => m.InstructorVidoesModule),
  },
  {
    path: 'eventlist',
    loadChildren: () => import('./pages/eventlist/eventlist.module').then(m => m.EventlistModule),
    canActivate: [AuthGuard]
  },  
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'team/:id', loadChildren: () => import('./pages/team-member/team-member.module').then(m => m.TeamMemberModule) },
  { path: 'register_user/:id', loadChildren: () => import('./pages/event-register-user/event-register-user.module').then(m => m.EventRegisterUserModule) },
  {
    path: 'campdetails/:id',
    loadChildren: () => import('./pages/campdetails/campdetails.module').then(m => m.CampdetailsModule)
  },
  {
    path: 'springhockey',
    loadChildren: () => import('./pages/springhockey/springhockey.module').then(m => m.SpringhockeyModule )
  },
  {
    path: 'summermultisportcamps',
    loadChildren: () => import('./pages/summermultisportcamps/summermultisportcamps.module').then(m => m.SummerMultiSportCampsModule )
  },
  {
    path: 'summercampsformconfo',
    loadChildren: () => import('./pages/summercampsformconfo/summercampsformconfo.module').then(m => m.SummercampsformconfosModule )
  },
  {
    path: 'summercampsrefform',
    loadChildren: () => import('./pages/summercampsrefform/summercampsrefform.module').then(m => m.SummerMultiSportCampsModule )
  },
  {
    path: 'attackshootingcamp',
    loadChildren: () => import('./pages/attackshootingcamp/attackshootingcamp.module').then(m => m.AttackshootingcampModule )
  },
  {
    path: 'winterbreakfastclub',
    loadChildren: () => import('./pages/winterbreakfastclub/winterbreakfastclub.module').then(m => m.WinterbreakfastclubModule )
  },
  {
    path: 'drylandconditioning',
    loadChildren: () => import('./pages/drylandconditioning/drylandconditioning.module').then(m => m.DrylandconditioningModule )
  },
  {
    path: 'summerelitecamp',
    loadChildren: () => import('./pages/summerelitecamp/summerelitecamp.module').then(m => m.SummerelitecampModule )
  },
  {
    path: 'summereliteregform',
    loadChildren: () => import('./pages/summereliteregform/summereliteregform.module').then(m => m.SummerEliteCampsModule )
  },
  {
    path: 'attackaughockeycamps',
    loadChildren: () => import('./pages/attackaughockeycamps/attackaughockeycamps.module').then(m => m.attackaughockeycampsModule )
  },

  {
    path: 'participation-waiver',
    loadChildren: () => import('./pages/participation-waiver/participation-waiver.module').then(m => m.ParticipationWaiverModule )
  },
  {
    path: 'medical-information',
    loadChildren: () => import('./pages/medical-information/medical-information.module').then(m => m.MedicalInformationModule )
  },
  {
    path : 'hockeycamps',
    loadChildren : () => import('./pages/hockeycamps/hockeycamps.module').then(m => m.HockeycampsModule)
  },
  {
    path: 'covid',
    loadChildren: () => import('./pages/covid/covid.module').then(m => m.CovidModule),
  },
  {
    path: 'ltad-stages',
    loadChildren: () => import('./pages/ltad-stages/ltad-stages.module').then(m => m.LtadStagesModule),
  },
  {
    path: 'ltad',
    loadChildren: () => import('./pages/ltad/ltad.module').then(m => m.LtadModule),
  },
  {
    path: 'teaching-game',
    loadChildren: () => import('./pages/teaching-game/teaching-game.module').then(m => m.TeachingGameModule),
  },
  {
    path: 'go-tournament',
    loadChildren: () => import('./pages/go-tournament/go-tournament.module').then(m => m.GoTournamentModule),
  },
  {
    path: 'go-registration',
    loadChildren: () => import('./pages/go-registration/go-registration.module').then(m => m.GoRegistrationModule),
  },
  // {
  //   path: 'register-form',
  //   loadChildren: () => import('./pages/register-form/register-form.module').then(m => m. RegisterFormModule),
  // },
  // {
  //   path: 'login',
  //   loadChildren: () => import('./pages/new-login/new-login.module').then(m => m. NewLoginModule),
  // },
  {
    path: 'tournament-confopage',
    loadChildren: () => import('./pages/tournament-confopage/tournament-confopage.module').then(m => m.TournamentConfopageModule),
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

