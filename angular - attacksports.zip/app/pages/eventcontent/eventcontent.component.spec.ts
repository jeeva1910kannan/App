import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventcontentComponent } from './eventcontent.component';

describe('EventcontentComponent', () => {
  let component: EventcontentComponent;
  let fixture: ComponentFixture<EventcontentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventcontentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventcontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
