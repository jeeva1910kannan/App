
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NgxPayPalModule } from 'ngx-paypal';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import {MatSelectModule} from '@angular/material/select';
import { CommonModule } from '@angular/common';
import { EventcontentComponent, Payment, Registerform, } from './eventcontent.component';
import { EventContentRoutingModule } from './eventcontent.routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatDialogModule} from '@angular/material/dialog';


import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
@NgModule({
  declarations: [
    EventcontentComponent,
    Registerform ,
    Payment
  ],
  imports: [MatDialogModule,    NgxPayPalModule,
    MatInputModule,
    HeaderFooterModule,
    RouterModule,
    EventContentRoutingModule,
    CommonModule,
    MatSelectModule,
    ReactiveFormsModule,
    FormsModule,MatFormFieldModule ,
    MatProgressSpinnerModule,
    NgxSkeletonLoaderModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class EventContentModule { }

