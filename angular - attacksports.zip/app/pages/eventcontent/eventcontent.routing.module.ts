import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { EventcontentComponent } from "./eventcontent.component";



const routes: Routes = [
  {
    path: "",
    component: EventcontentComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class EventContentRoutingModule { }