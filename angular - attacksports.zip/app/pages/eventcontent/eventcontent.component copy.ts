import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from './../../providers/web.service';
import { environment } from './../../../environments/environment';
import { CommonService } from '../services/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-eventcontent',
  templateUrl: './eventcontent.component.html',
  styleUrls: ['./eventcontent.component.scss']
})
export class EventcontentComponent implements OnInit {
  EventDetails: any;
  profile: string;
  newstart: Date;
  ggg: any
  newend: Date;
  eventid: any;
  currentDate: any;
  targetDate: any;
  cDateMillisecs: any;
  tDateMillisecs: any;
  difference: any;
  seconds: any;
  minutes: any;
  hours: any;
  days: any;
  year: number = 2023;
  month: number = 6;
  months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sept',
    'Oct',
    'Nov',
    'Dec',
  ];
  day: number = 31;
  showdrag:boolean;
  live: boolean;
  eventvid: string;
  eventvid1: string;
  video: any;
  loading: boolean = false;
  updated: boolean;
  event_id: any;
  recentvideos: any;
  constructor(private activateRoute: ActivatedRoute, private web: WebService,
    public common: CommonService, public dialog: MatDialog,private router:Router) {
    this.video = {

      image: "",
    };
  }
  base_url: string = environment.base_url;
  ngOnInit(): void {
    this.test(this.activateRoute.params['_value'].id)
  }
  onFileChange(event) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      console.log(files);
      if (files[0].type == "video/mp4" || files[0].type == "video/mkv") {
        this.onSubmit(files);
      }
      else {
        this.common.presentToast("Only videos can be uploaded");
      }
    }
  }

  onSubmit(file: any) {
    let d = new Date();
    let n: any = d.valueOf();
    let fname = file[0].name;

    this.loading = true;


    fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
    let filename = 'ATTACK_' + n + '.' + fname;
    const formDataevent = new FormData();
    formDataevent.append("video_upload_file", file[0]);

    this.eventvid = filename;
    this.web.uploadWebsiteVideo(this.base_url + `uploads/video/uploadeventvideos.php?filename=${filename}`, formDataevent).subscribe((Res: any) => {

      if (Res.status == 'success') {
        this.dialog.open(Videouploadedsuccessfully);
        let data = {

          instructor_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),
          event_id: this.event_id,
          filename: filename
        }
        this.web.postData('eventvideo', data).then((res) => {
          if (res.status == '200') {
            this.common.presentToast('Uploaded Successfully');
            this.ngOnInit();
          } else {
            this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
        this.loading = false;
        this.eventvid1 = this.base_url + "uploads/video/instructorvideos/" + filename;
        console.log("Uploaded video is", this.eventvid1);
      } else {
        console.log("failed");

      }
    }, (err) => {

      console.log(JSON.stringify(err));
    });
  }
  test(id) {
    this.event_id = id;
    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id: id
    }
    
    this.web.postData('geteventDetails', data).then((res) => {
      console.log(res);
      if (res.status == '200') {
        this.EventDetails = res.data;
        console.log(this.EventDetails,"EventDetails");
        this.eventid = this.EventDetails.event_id;
        this.newstart = new Date(this.EventDetails.start_time * 1000);
        this.newend = new Date(this.EventDetails.end_time * 1000);
        // this.EventDetails.reg  = this.EventDetails.event_active;
        const currentdate = new Date();
        console.log(this.newstart);
        console.log(currentdate);
        if (this.newstart.getTime() < currentdate.getTime()) {
          this.live = true;
        }
        else {
          this.live = false;
        }

        this.profile = this.base_url + 'uploads/Event/' + this.EventDetails.event_profile;
        if (this.newstart.getTime() > currentdate.getTime() && this.EventDetails.register == 1) {
          let x = setInterval(() => {
            this.showdrag=false;
            this.currentDate = new Date();
            this.targetDate = this.newstart;
            this.cDateMillisecs = this.currentDate.getTime();
            this.tDateMillisecs = this.targetDate.getTime();
            this.difference = this.tDateMillisecs - this.cDateMillisecs;
            this.seconds = Math.floor(this.difference / 1000);
            this.minutes = Math.floor(this.seconds / 60);
            this.hours = Math.floor(this.minutes / 60);
            this.days = Math.floor(this.hours / 24);
            this.hours %= 24;
            this.minutes %= 60;
            this.seconds %= 60;
            this.days = this.days < 10 ? '0' + this.days : this.days;
            this.hours = this.hours < 10 ? '0' + this.hours : this.hours;
            this.minutes = this.minutes < 10 ? '0' + this.minutes : this.minutes;
            this.seconds = this.seconds < 10 ? '0' + this.seconds : this.seconds;
            document.getElementById('days').innerText = this.days;
            document.getElementById('hours').innerText = this.hours;
            document.getElementById('mins').innerText = this.minutes;
            document.getElementById('seconds').innerText = this.seconds;
          });
        }
        else{
          this.showdrag=true;
        }
        this.web.postData('getrecentvideos', data).then((res) => {
          if (res.status == '200') {
            this.recentvideos = res.data;
            if (this.EventDetails) {
              this.updated = false;
              console.log("False works");
              
            }
          
          } else {
            this.updated = true;
            console.log(res.error);
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error.');
        });
      } else {
        
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });


  }
myaccount(){
  this.router.navigate(['/my-account']);

}
  openModal() {
    let id = this.event_id;
    this.openDialog(id);
  }

  openDialog(eventid: any): void {

    if (localStorage.getItem('type') == 'Instructor') {
      this.dialog.open(Registerform, {
        data: {
          user_id: localStorage.getItem('UserId'),
          event_id: eventid,
          type: localStorage.getItem('type'),
        },
      });

    }
    else {
      this.common.presentToast('Please contact your instructor to partipate in events');
    }
  }

} interface Food {
  value: string;
  viewValue: string;
} @Component({
  selector: 'registerform',
  templateUrl: 'registerform.html', styleUrls: ['./registerform.component.scss']
})
export class Registerform implements OnInit {
  base_url: string = environment.base_url;
  eventid: any;
  EventDetails: any;
  selectedValue: string;
  selectedCar: string;
  custominfo: any;
  cust_id: any;
  cust_det: any;
  email: any;
  phone: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Registerform,
    private web: WebService,
    public common: CommonService) {
    this.email = localStorage.getItem('email');
    this.phone = localStorage.getItem('phone');
    this.web.postData('geteventDetails', data).then((res) => {
      if (res.status == '200') {
        this.EventDetails = res.data;
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
    this.web.postData('allcustomers', data).then((res) => {
      if (res.status == '200') {
        this.custominfo = res.data;
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });

  }
  ngOnInit(): void {

  }
  getcust() {
    this.web.postData('', this.cust_id).then((res) => {
      if (res.status == '200') {
        this.cust_det = res.data;
        console.log(this.cust_det);

      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
  }
  onsubmit() {
    if (this.cust_id == null || this.cust_id == '') {
      this.common.presentToast('Please select your Customer')
    }
    else if (this.EventDetails.email == null || this.EventDetails.email == '') {
      this.common.presentToast('Enter your mail id');
    }
    else if (this.common.validateEmail(this.email) == false) {
      this.common.presentToast('Enter valid email Address');
    } else if (this.phone == null || this.phone == '') {
      this.common.presentToast('Enter your phone number');
    } else if (this.common.validateMobileNumber(this.EventDetails.phone) == false) {
      this.common.presentToast('Enter valid phone number');
    } else if (this.EventDetails.message == null || this.EventDetails.message == '') {
      this.common.presentToast('Please enter any message');
    } else {
      let data = {
        to_email: localStorage.getItem('email'),
        instructor_id: localStorage.getItem('UserId'),
        event_id: this.EventDetails.event_id,
        customer_id: this.cust_id,
        email: this.email,
        phone: this.phone,
        message: this.EventDetails.message
      }
      this.web.postData('eventregistration', data).then((res) => {

        if (res.status == '200') {
          // this.common.presentToast('Registered Successfully');

          window.location.reload();
          this.ngOnInit();
        } else {
          this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });
    }
  }

}

@Component({
  selector: 'videouploadedsuccessfully',
  templateUrl: 'videouploadedsuccessfully.html',
  styleUrls: ['./videouploadedsuccessfully.scss']
})
export class Videouploadedsuccessfully { }
