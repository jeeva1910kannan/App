import { Component, Inject, OnInit, AfterViewInit,  Renderer2, ElementRef , CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from './../../providers/web.service';
import { environment } from './../../../environments/environment';
import { CommonService } from '../services/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';


import {
  ICreateOrderRequest,
  IPayPalConfig,
  NgxPaypalComponent,
  PayPalScriptService,
} from 'ngx-paypal';

declare let jQuery: any;
declare var SqPaymentForm: any;
declare var Square: any;

@Component({
  selector: 'app-eventcontent',
  templateUrl: './eventcontent.component.html',
  styleUrls: ['./eventcontent.component.scss']
})
export class EventcontentComponent implements OnInit{
  EventDetails: any;
  profile1: string;
  eventprofile: any;
  newstart: Date;
  ggg: any
  newend: Date;
  eventid: any;
  currentDate: any;
  targetDate: any;
  cDateMillisecs: any;
  tDateMillisecs: any;
  difference: any;
  seconds: any;
  minutes: any;
  hours: any;
  days: any;
  year: number = 2023;
  month: number = 6;
  months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sept',
    'Oct',
    'Nov',
    'Dec',
  ];
  day: number = 31;
  showdrag: boolean;
  live: boolean;
  eventvid: string;
  eventvid1: string;
  video: any;
  loading: boolean = false;
  updated: boolean;
  event_id: any;
  recentvideos: any;
  event_price: any;
  type: string;
  Transaction: any;
  event:any;
  transevent:any;
  transactionevent: boolean = false;
  transaction1: any;
  EventDetails1: any;
  subscriptiondetails: any;
  constructor(private activateRoute: ActivatedRoute, private web: WebService,
    public common: CommonService, public dialog: MatDialog, private router: Router, private http: HttpClient, private renderer: Renderer2, private el: ElementRef) {
    this.video = {

      image: "",
    };
  }
  base_url: string = environment.base_url;
  
  ngOnInit(): void {
    this.loadScript1('https://sandbox.web.squarecdn.com/v1/square.js');
    const script = document.createElement('script');
    script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    document.head.appendChild(script);
    this.test(this.activateRoute.params['_value'].id)
    this.type = localStorage.getItem('type');
    this.geteventregister();
    this.geteventdetails1();
    this.getsubscriptiondetails();
    
  }

  private loadScript1(url: string) {
    this.http.get(url, { responseType: 'text' }).subscribe(data => {
      const script = this.renderer.createElement('script');
      script.text = data;
      this.renderer.appendChild(this.el.nativeElement, script);
    });
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      console.log(files);
      if (files[0].type == "video/mp4" || files[0].type == "video/mkv") {
        this.onSubmit(files);
      }
      else {
        this.common.presentToast("Only videos can be uploaded");
      }
    }
  }

  onSubmit(file: any) {
    let d = new Date();
    let n: any = d.valueOf();
    let fname = file[0].name;

    this.loading = true;


    fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
    let filename = 'ATTACK_' + n + '.' + fname;
    const formDataevent = new FormData();
    formDataevent.append("video_upload_file", file[0]);

    this.eventvid = filename;
    this.web.uploadWebsiteVideo(this.base_url + `uploads/video/uploadeventvideos.php?filename=${filename}`, formDataevent).subscribe((Res: any) => {

      if (Res.status == 'success') {
        this.dialog.open(Videouploadedsuccessfully);
        let data = {

          instructor_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),
          event_id: this.event_id,
          filename: filename
        }
        this.web.postData('eventvideo', data).then((res) => {
          if (res.status == '200') {
            this.common.presentToast('Uploaded Successfully');
            this.ngOnInit();
          } else {
            this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
        this.loading = false;
        this.eventvid1 = this.base_url + "uploads/video/instructorvideos/" + filename;
        console.log("Uploaded video is", this.eventvid1);
      } else {
        console.log("failed");

      }
    }, (err) => {

      console.log(JSON.stringify(err));
    });
  }


  onSubmit1(file: any) {
    let d = new Date();
    let n: any = d.valueOf();
    let fname = file[0].name;

    this.loading = true;


    fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
    let filename = 'ATTACK_' + n + '.' + fname;
    const formDataevent = new FormData();
    formDataevent.append("video_upload_file", file[0]);

    this.eventvid = filename;
    this.web.uploadWebsiteVideo(this.base_url + `uploads/video/uploadeventvideos.php?filename=${filename}`, formDataevent).subscribe((Res: any) => {

      if (Res.status == 'success') {
        this.dialog.open(Videouploadedsuccessfully);
        let data = {

          customer_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),
          event_id: this.event_id,
          filename: filename
        }
        this.web.postData('eventvideo1', data).then((res) => {
          if (res.status == '200') {
            this.common.presentToast('Uploaded Successfully');
            this.ngOnInit();
          } else {
            this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
        this.loading = false;
        this.eventvid1 = this.base_url + "uploads/video/instructorvideos/" + filename;
        console.log("Uploaded video is", this.eventvid1);
      } else {
        console.log("failed");

      }
    }, (err) => {

      console.log(JSON.stringify(err));
    });
  }



  test(id) {
    this.event_id = id;
    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id: id,
      customer_id: id
    }

    this.web.postData('geteventDetails', data).then((res) => {
      console.log(res);
      if (res.status == '200') {
        this.EventDetails = res.data;
        console.log(this.EventDetails, "EventDetails");
        this.eventid = this.EventDetails.event_id;
        this.event_price = this.EventDetails.price;
        this.newstart = new Date(this.EventDetails.start_time * 1000);
        this.newend = new Date(this.EventDetails.end_time * 1000);
        this.eventprofile =  this.EventDetails.event_profile;
        // this.EventDetails.reg  = this.EventDetails.event_active;
        const currentdate = new Date();
        console.log(this.newstart);
        console.log(currentdate);
        if (this.newstart.getTime() < currentdate.getTime()) {
          this.live = true;
        }
        else {
          this.live = false;
        }

        this.profile1 = this.base_url + 'uploads/Event/' + this.EventDetails.event_profile;
        if (this.newstart.getTime() > currentdate.getTime() && this.EventDetails.register == 1) {
          let x = setInterval(() => {
            this.showdrag = false;
            this.currentDate = new Date();
            this.targetDate = this.newstart;
            this.cDateMillisecs = this.currentDate.getTime();
            this.tDateMillisecs = this.targetDate.getTime();
            this.difference = this.tDateMillisecs - this.cDateMillisecs;
            this.seconds = Math.floor(this.difference / 1000);
            this.minutes = Math.floor(this.seconds / 60);
            this.hours = Math.floor(this.minutes / 60);
            this.days = Math.floor(this.hours / 24);
            this.hours %= 24;
            this.minutes %= 60;
            this.seconds %= 60;
            this.days = this.days < 10 ? '0' + this.days : this.days;
            this.hours = this.hours < 10 ? '0' + this.hours : this.hours;
            this.minutes = this.minutes < 10 ? '0' + this.minutes : this.minutes;
            this.seconds = this.seconds < 10 ? '0' + this.seconds : this.seconds;
            document.getElementById('days').innerText = this.days;
            document.getElementById('hours').innerText = this.hours;
            document.getElementById('mins').innerText = this.minutes;
            document.getElementById('seconds').innerText = this.seconds;
          });
        }
        else {
          this.showdrag = true;
        }
        this.web.postData('getrecentvideos', data).then((res) => {
          if (res.status == '200') {
            this.recentvideos = res.data;
            if (this.EventDetails) {
              this.updated = false;
              console.log("False works");

            }

          } else {
            this.updated = true;
            console.log(res.error);
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error.');
        });
      } else {

        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });


  }
geteventdetails1(): void {
 let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id: this.activateRoute.params['_value'].id,
      customer_id: localStorage.getItem('UserId')
    }

    this.web.postData('geteventDetails1', data).then((res) => {
      console.log(res);
      if (res.status == '200') {
        this.EventDetails1 = res.data;
        // console.log(this.EventDetails, "EventDetails");
        // this.eventid = this.EventDetails.event_id;
        // this.event_price = this.EventDetails.price;
        // this.newstart = new Date(this.EventDetails.start_time * 1000);
        // this.newend = new Date(this.EventDetails.end_time * 1000);
        // // this.EventDetails.reg  = this.EventDetails.event_active;
        const currentdate = new Date();
        console.log(this.newstart);
        console.log(currentdate);
        if (this.newstart.getTime() < currentdate.getTime()) {
          this.live = true;
        }
        else {
          this.live = false;
        }

         this.profile1 = this.base_url + 'uploads/Event/' + this.eventprofile;
        if (this.newstart.getTime() > currentdate.getTime() && this.EventDetails1.register == 1) {
          let x = setInterval(() => {
            this.showdrag = false;
            this.currentDate = new Date();
            this.targetDate = this.newstart;
            this.cDateMillisecs = this.currentDate.getTime();
            this.tDateMillisecs = this.targetDate.getTime();
            this.difference = this.tDateMillisecs - this.cDateMillisecs;
            this.seconds = Math.floor(this.difference / 1000);
            this.minutes = Math.floor(this.seconds / 60);
            this.hours = Math.floor(this.minutes / 60);
            this.days = Math.floor(this.hours / 24);
            this.hours %= 24;
            this.minutes %= 60;
            this.seconds %= 60;
            this.days = this.days < 10 ? '0' + this.days : this.days;
            this.hours = this.hours < 10 ? '0' + this.hours : this.hours;
            this.minutes = this.minutes < 10 ? '0' + this.minutes : this.minutes;
            this.seconds = this.seconds < 10 ? '0' + this.seconds : this.seconds;
            document.getElementById('days').innerText = this.days;
            document.getElementById('hours').innerText = this.hours;
            document.getElementById('mins').innerText = this.minutes;
            document.getElementById('seconds').innerText = this.seconds;
           });
        }
        else {
          this.showdrag = true;
        }
        this.web.postData('getrecentvideos', data).then((res) => {
          if (res.status == '200') {
            this.recentvideos = res.data;
            if (this.EventDetails1) {
              this.updated = false;
              console.log("False works");

            }

          } else {
            this.updated = true;
            console.log(res.error);
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error.');
        });
      } else {

        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });


  }

  
  myaccount() {
    this.router.navigate(['/my-account']);

  }
  openModal() {
    const script = document.createElement('script');
    script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    document.head.appendChild(script);


if(this.subscriptiondetails == null){
  this.common.presentToast('Please Register Event after Subscription.');
}else{



    let id = this.event_id;
    this.openDialog(id);
}
}

  openDialog(eventid: any): void {

    const script = document.createElement('script');
    script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    document.head.appendChild(script);
    if (localStorage.getItem('type') == 'Customer') {
      this.dialog.open(Registerform, {
        data: {
          user_id: localStorage.getItem('UserId'),
          event_id: eventid,
          type: localStorage.getItem('type'),
        },
      });

    }
    else {
      // this.common.presentToast('Please contact your instructor to partipate in events');
      this.common.presentToast('Please contact your admin');
    }
  }



  async getsubscriptiondetails() {
    let data={
      customer_id: localStorage.getItem('UserId')
      //email: this.email,
     
    }
   this.web.postData('subscriptiondetails',data).then((res) => {
          if (res.status == '200') {
            this.subscriptiondetails = res.data;

          } else {
            console.log(":(")
          }
        }, err => {
          console.log(err);
          console.log(":)")
        });
        //console.log(this.couponcode);
        console.log("fdjhgjdf");
  }
          



  geteventregister(): void {
    // const script = document.createElement('script');
    // script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    // document.head.appendChild(script);
    //console.log("coupon");
    let data={
      event_id: localStorage.getItem('eventid'),
      customer_id: localStorage.getItem('UserId'),
      email: localStorage.getItem('email')          //no
     
    }
    this.web.postData('eventregisterdetails',data).then((res) => {
      if (res.status == '200') {
        this.transactionevent = true;
        this.transaction1 = res.data;
        this.transevent = this.transaction1[0];
        console.log(this.transevent,'transevent');
        console.log(this.event,'event');
        localStorage.setItem('Transaction', JSON.stringify(res.data));
        //this.couponcode = res.data[0];
        //this.faqquiz = res.data.slice(1);
       
       // console.log(this.couponcode);
               } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
   // console.log(this.couponcode);
    console.log("fdjhgjdf");
} 
  

  
  

} interface Food {
  value: string;
  viewValue: string;
} @Component({
  selector: 'registerform',
  templateUrl: 'registerform.html', styleUrls: ['./registerform.component.scss']
})
export class Registerform implements OnInit {
  public payPalConfig: any;

  base_url: string = environment.base_url;
  eventid: any;
  EventDetails: any;
  selectedValue: string;
  selectedCar: string;
  custominfo: any;
  cust_id: any;
  cust_det: any;
  email: any;
  phone: string;
  payment: boolean = false;
  transactionevent = false;
  userDetailsTemp: any;
  percentage: any;
  couponcode: any;
  paymentForm: any; //this is our payment form object
  payments: any;
  card: any;
  Transaction: any;
  event:any;
  transevent:any;
  transaction1: any;
  
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEOKq3_JUA1xw1RCiov2mms1eJviBzaBrw1rM40aMSTdKXCpfJWnkIfJfwad-";
 applicationId1 = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  locationId1 = "LC2PEQFX591R6";
  // accesstoken = "EAAAEFUVZ_TzbVRH8SC4YQb2dI1IYNTTmwFYz2Pzff2DFdAYLS3tNohCHA3A6bnK";
  //  applicationId1 = "sandbox-sq0idb-N2D0zEBfzwuEIW8uNfVzZg";
  // locationId1 = "LC2PEQFX591R6";
  loading = true;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Registerform,
    private web: WebService,
    public common: CommonService, 
    private router: Router, 
    private payPalScriptService: PayPalScriptService,
    private http: HttpClient, 
    private renderer: Renderer2,
     private el: ElementRef,  
     public dialog: MatDialog,
  ) {
    


    this.email = localStorage.getItem('email');
    this.phone = localStorage.getItem('phone');
    this.web.postData('geteventDetails', data).then((res) => {
      if (res.status == '200') {
        this.EventDetails = res.data;
        // localStorage.setItem('EventDetails.instructor_id', this.EventDetails.instructor_id);
        // localStorage.setItem('EventDetails.event_id', this.EventDetails.event_id);
        // localStorage.setItem('EventDetails.message', this.EventDetails.message);
        // localStorage.setItem('EventDetails.price', this.EventDetails.price);
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
    this.web.postData('allcustomers', data).then((res) => {
      if (res.status == '200') {
        this.custominfo = res.data;
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });


    this.web.getData('getSiteSettings').then((res) => {
      if (res.status == '200') {
        this.percentage = res.data;
        console.log(this.percentage,"percentage");
        }
    
});


// getcoupon(coupondetails: any): void {
//   let data = {
//     this.cust_id:customer_id,
    
//   };
//   this.web.postData('getcouponcode', data).then(
//     (res) => {
//       if (res.status == '200') {
//         this.common.presentToast('Payment Successfully');

//         // this.common.presentToast('Registered Successfully');
//         setTimeout(() => {
//           window.location.reload();
//         }, 600);
//         this.ngOnInit();
//       } else {
//         this.common.presentToast(res.error);
//       }
//     }, err => {
//       console.log(err);
//       this.common.presentToast('Connection Error');
//     });

//}


  const script = this.renderer.createElement('script');
  script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
  script.onload = () => {
    console.log('Script loaded');
  };
  this.renderer.appendChild(this.el.nativeElement, script);
  

  

  }
  ngOnInit(): void {
    this.Transaction = localStorage.getItem('Transaction');
    this.event = localStorage.getItem('eventid');
    this.initConfig();
    this.getcouponcode();
    //this.loadScript();
    this.geteventregister();
    
  setTimeout(() => {
    this.loading = false;
  }, 2500);

  }

  

  ngAfterViewInit() {
   // this.loadScript();
  }

  

  // async  loadScript() {
  //   const script = document.createElement('script');
  //   script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
  //   document.head.appendChild(script);
  
    
  //   // Your SqPaymentForm script here
  
  //   var applicationId = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  
  //   // Set the location ID
  //   var locationId = "LQC04P5CAFGVD";
  
  //   this.payments = Square.payments(applicationId, locationId);
  
  //   this.card = await this.payments.card();
  
  //   await this.card.attach('#card-container');
  
  //   this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
  //   this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
  //   const form = document.querySelector('#card-payment') as HTMLFormElement;
  
  //   form.addEventListener('submit', async (event: Event) => {
  
  //      event.preventDefault();
  
  //      const result = await this.card.tokenize(); // the card nonce
  
  //   });
  //   console.log("result");
  //   // onCancel: () => {
  //   //   this.common.presentToast('Payment cancelled.');
  //   //   console.log("OnCancel");
  //   // }
  
    
  // }

  // // loadScript1() {
  // //   const script = this.renderer.createElement('script');
  // //   script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
  // //   script.onload = () => {
  // //     console.log('Script loaded');
  // //   };
  // //   this.renderer.appendChild(this.el.nativeElement, script);
  // //   };

  geteventregister(): void {
    const script = document.createElement('script');
    script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    document.head.appendChild(script);
    //console.log("coupon");
    let data={
      event_id: this.event,
      customer_id: localStorage.getItem('UserId'),
      email: localStorage.getItem('email')              //
     
    }
    this.web.postData('eventregisterdetails',data).then((res) => {
      if (res.status == '200') {
        this.transactionevent = true;
        this.transaction1 = res.data[0];
        this.transevent = this.transaction1[0];
        console.log(this.transevent,'transevent');
        console.log(this.event,'event');
        localStorage.setItem('Transaction', JSON.stringify(res.data));
        //this.couponcode = res.data[0];
        //this.faqquiz = res.data.slice(1);
       
        console.log(this.couponcode);
               } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
    console.log(this.couponcode);
    console.log("fdjhgjdf");
} 
  


  
  async makePayment() {
    
    const statusContainer = document.getElementById('payment-status-container');
    try {
      const result = await this.card.tokenize();
      if (result.status === 'OK') {

        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
        //console.log('Paypal id', details.id);
        let data = {
          to_email: localStorage.getItem('email'),
          instructor_id: this.EventDetails.instructor_id,
          customer_id: localStorage.getItem('UserId'),
          event_id: this.EventDetails.event_id,
         // customer_id: this.cust_id,
          email: this.email,
          phone: this.phone,
          message: this.EventDetails.message,
          //transaction_id: details.id,
          price: this.EventDetails.price,
          //transaction_response: details,
          transaction_method: 'card',
          payment_status: 'success',
          paymentToken: result.token,
          locationId: this.locationId1,
          accesstoken: this.accesstoken
        };
        this.web.postData('eventregistration1', data).then(
          (res) => {
            if (res.status == '200') {
              this.common.presentToast('Payment Successfully');
              //this.eventregister = 'true';
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              }, 600);
              this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
          });

        
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }


  
getcouponcode(): void {
  console.log("coupon");
  let data={
    
    email: this.email,
   
  }
 this.web.postData('getcouponcode',data).then((res) => {
        if (res.status == '200') {
          this.couponcode = res.data[0];
          //this.faqquiz = res.data.slice(1);
         
          console.log(this.couponcode);
                 } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
      console.log(this.couponcode);
      console.log("fdjhgjdf");
  } 

//  async getSiteSettings() {
//     await this.web.getData('getSiteSettings').then((res) => {
//       if (res.status == '200') {
//         this.percentage = res.data;
//         console.log(this.percentage,"percentage")
//         }
// });
// }



  private initConfig(): void {


    this.payPalConfig = {
      currency: "USD",
      clientId: environment.paypal_key,
      createOrder: data =>
        <ICreateOrderRequest>{
          intent: "CAPTURE",
          purchase_units: [
            {
              amount: {
                currency_code: "USD",
                value: this.EventDetails.price,
                breakdown: {
                  item_total: {
                    currency_code: "USD",
                    value: this.EventDetails.price
                  }
                }
              },
              items: [
                {
                  name: "Enterprise Subscription",
                  quantity: "1",
                  category: "DIGITAL_GOODS",
                  unit_amount: {
                    currency_code: "USD",
                    value: this.EventDetails.price
                  }
                }
              ]
            }
          ]
        },
      advanced: {
        commit: "true"
      },
      style: {
        label: "paypal",
        layout: "vertical"
      },
      onApprove: (data, actions) => {
        console.log('onApprove - transaction was approved, but not authorized', data, actions);

        console.log(
          "onApprove - transaction was approved, but not authorized",
          data,
          actions
        );
        actions.order.get().then(details => {
          console.log(
            "onApprove - you can get full order details inside onApprove: ",
            details
          );
          this.createTokenPaypal(details)

        });
      },
      onClientAuthorization: data => {
        console.log(
          "onClientAuthorization - you should probably inform your server about completed transaction at this point",
          data
        );
      },
      onCancel: (data, actions) => {
        this.common.presentToast('Payment cancelled.');
        console.log("OnCancel", data, actions);
      },
      onError: err => {
        this.common.presentToast('Service not available.');

        console.log("OnError", err);
      },
      onClick: (data, actions) => {
        console.log("onClick", data, actions);
      }
    };

  }
  // getcust() {
  //    // if (this.cust_id == null || this.cust_id == '') {
  //     //   this.common.presentToast('Please select your Customer')
  //     // }
  //     // else if (this.EventDetails.email == null || this.EventDetails.email == '') {
  //     //   this.common.presentToast('Enter your mail id');
  //     // }
  //     // else if (this.common.validateEmail(this.email) == false) {
  //     //   this.common.presentToast('Enter valid email Address');
  //     // } else if (this.phone == null || this.phone == '') {
  //     //   this.common.presentToast('Enter your phone number');
  //     // } else if (this.common.validateMobileNumber(this.EventDetails.phone) == false) {
  //     //   this.common.presentToast('Enter valid phone number');
  //     // } else if (this.EventDetails.message == null || this.EventDetails.message == '') {
  //     //   this.common.presentToast('Please enter any message');
  //     // } else {
  //     //   let data = {
  //     //     to_email: localStorage.getItem('email'),
  //     //     instructor_id: localStorage.getItem('UserId'),
  //     //     event_id: this.EventDetails.event_id,
  //     //     customer_id: this.cust_id, 
  //     //     email: this.email,
  //     //     phone: this.phone,
  //     //     message: this.EventDetails.message
  //     //   }
  //     //   this.web.postData('eventregistration', data).then((res) => {

  //     //     if (res.status == '200') {
  //     //       // this.common.presentToast('Registered Successfully');

  //     //       window.location.reload();
  //     //       this.ngOnInit();
  //     //     } else {
  //     //       this.common.presentToast(res.error);
  //     //     }
  //     //   }, err => {
  //     //     console.log(err);
  //     //     this.common.presentToast('Connection Error');
  //     //   });
  //     // }
  //   this.web.postData('', this.cust_id).then((res) => {
  //     if (res.status == '200') {
  //       this.cust_det = res.data;
  //       console.log(this.cust_det);

  //     } else {
  //       console.log(res.error);
  //     }
  //   }, err => {
  //     console.log(err);
  //     this.common.presentToast('Connection Error.');
  //   });
  // }
  createTokenPaypal(details: any): void {

    this.userDetailsTemp = JSON.parse(
      localStorage.getItem('UserDetails')
    );
    console.log("this.userDetailsTemp", this.userDetailsTemp);
    console.log('Paypal id', details.id);
    let data = {
      to_email: localStorage.getItem('email'),
      instructor_id: localStorage.getItem('UserId'),
      event_id: this.EventDetails.event_id,
      customer_id: this.cust_id,
      email: this.email,
      phone: this.phone,
      message: this.EventDetails.message,
      transaction_id: details.id,
      price: this.EventDetails.price,
      transaction_response: details,
      transaction_method: 'paypal',
      payment_status: 'success',
    };
    console.log(data,"data");
    this.web.postData('eventregistration', data).then(
      (res) => {
        if (res.status == '200') {
          this.common.presentToast('Payment Successfully');

          // this.common.presentToast('Registered Successfully');
          setTimeout(() => {
            window.location.reload();
          }, 600);
          this.ngOnInit();
        } else {
          this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });

  }
  onsubmit() {
    // const script1 = document.createElement('script');
    // script1.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    // document.head.appendChild(script1);



    const script = this.renderer.createElement('script');
    script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    script.onload = () => {
      console.log('Script loaded');
    };
    this.renderer.appendChild(this.el.nativeElement, script);

    // if (this.cust_id != null || this.cust_id != '') {
    //   this.common.presentToast('Please select your Customer')
    // }
    // if (this.cust_id == null || this.cust_id == '') {
    //   this.common.presentToast('Please select your Customer')
    // }
    // else 
    if (this.EventDetails.email == null || this.EventDetails.email == '') {
      this.common.presentToast('Enter your mail id');
    }
    else if (this.common.validateEmail(this.email) == false) {
      this.common.presentToast('Enter valid email Address');
    } else if (this.phone == null || this.phone == '') {
      this.common.presentToast('Enter your phone number');
    } else if (this.common.validateMobileNumber(this.EventDetails.phone) == false) {
      this.common.presentToast('Enter valid phone number');
    } else if (this.EventDetails.message == null || this.EventDetails.message == '') {
      this.common.presentToast('Please enter any message');
    } else {
       localStorage.setItem('EventDetails.instructor_id', this.EventDetails.instructor_id);
        localStorage.setItem('EventDetails.event_id', this.EventDetails.event_id);
        localStorage.setItem('EventDetails.message', this.EventDetails.message);
        localStorage.setItem('EventDetails.price', this.EventDetails.price);
      this.payment = true;
      this.dialog.open(Payment, {
        
        data: {
         user_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),
        },
      });
    }

  }

}

declare var Square: any;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
@Component({
  selector: 'Paymentcard',
  templateUrl: 'Paymentcard.html',
   styleUrls: ['Paymentcard.scss']
  // styleUrls: ['./withdraw.scss']
})

export class Payment{
 // campid:number = this.activateRoute.params['_value'].id;
//  formData = {
//   campid: this.activateRoute.params['_value'].id,
//  }
EventDetails: any;
  payments: any;
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEOKq3_JUA1xw1RCiov2mms1eJviBzaBrw1rM40aMSTdKXCpfJWnkIfJfwad-";
  applicationId1 = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  locationId1 = "LC2PEQFX591R6";
  paymentForm: any; 
  userDetailsTemp: any;
  campdetails1: any;
  phone: string;
  email: string;
  fetchingStatus: boolean = true;
  loading = true;
  isButtonDisabled = false;

  constructor(public common: CommonService,private web: WebService, public dialog: MatDialog,private activateRoute:ActivatedRoute) { 
  }
  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit(): void {
    this.email = localStorage.getItem('email');
    this.phone = localStorage.getItem('phone');
  this.loadScript();
  // setTimeout(() => {
  //   this.fetchingStatus = false;
  // }, 2500);

  setTimeout(() => {
    this.loading = false;
  }, 1000);
 
  }
oncancel(){
    this.dialog.closeAll();
  }
 

  async  loadScript() {
   
  
    // Your SqPaymentForm script here
  
    var applicationId = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  
    // Set the location ID
    var locationId = "LQC04P5CAFGVD";


    // var applicationId = "sandbox-sq0idb-N2D0zEBfzwuEIW8uNfVzZg";
  
    // // Set the location ID
    // var locationId = "LC2PEQFX591R6";
    this.fetchingStatus = true;
    this.payments = Square.payments(applicationId, locationId);
  
    this.card = await this.payments.card();
  
    await this.card.attach('#card-container');
    this.fetchingStatus = false;
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
    const form = document.querySelector('#card-payment') as HTMLFormElement;
  
    form.addEventListener('submit', async (event: Event) => {
  
       event.preventDefault();
  
       const result = await this.card.tokenize(); // the card nonce
  
    });
    console.log("result");
    // onCancel: () => {
    //   this.common.presentToast('Payment cancelled.');
    //   console.log("OnCancel");
    // }
    
  }
  async makePayment() {
    
    const statusContainer = document.getElementById('payment-status-container');
    
    try {
      const result = await this.card.tokenize();
      
      if (result.status === 'OK') {
        this.isButtonDisabled = true;
        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
        //console.log('Paypal id', details.id);
        let data = {
          to_email: localStorage.getItem('email'),
          instructor_id: localStorage.getItem('EventDetails.instructor_id'),
          customer_id: localStorage.getItem('UserId'),
          event_id: localStorage.getItem('EventDetails.event_id'),
         // customer_id: this.cust_id,
          email: this.email,
          phone: this.phone,
          message: localStorage.getItem('EventDetails.message'),
          //transaction_id: details.id,
          price: localStorage.getItem('EventDetails.price'),
          //transaction_response: details,
          transaction_method: 'card',
          payment_status: 'success',
          paymentToken: result.token,
          locationId: this.locationId1,
          accesstoken: this.accesstoken
        };
        this.web.postData('eventregistration1', data).then(
          
          (res) => {
            
            if (res.status == '200') {
              
              this.common.presentToast('Payment Successfully');
              this.isButtonDisabled = false;
              //this.eventregister = 'true';
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              }, 600);
              //this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
              this.isButtonDisabled = false;
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
            this.isButtonDisabled = false;
          });


        
    //this.processPayment(result)
        // this.http.post('http://your-api-endpoint.com/charge', {
        //   paymentToken: result.token,
        //   amount: this.EventDetails.price
        // }).subscribe(response => {
        //   console.log(response);
        //   statusContainer.innerHTML = "Payment Successful";
        // }, error => {
        //   console.error(error);
        //   statusContainer.innerHTML = "Payment Failed";
        // });
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }
  
  

}


@Component({
  selector: 'videouploadedsuccessfully',
  templateUrl: 'videouploadedsuccessfully.html',
  styleUrls: ['./videouploadedsuccessfully.scss']
})
export class Videouploadedsuccessfully { }
