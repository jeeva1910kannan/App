import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactusComponent } from './contactus.component';
import { ContactusRoutingModule } from './contactus.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { FormsModule } from '@angular/forms';
import { RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';

@NgModule({
  declarations: [
ContactusComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    RecaptchaModule, 
    ContactusRoutingModule,
    HeaderFooterModule,
    RecaptchaFormsModule
  ]
})
export class ContactusModule { }
