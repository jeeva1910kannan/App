import { Component, OnInit } from '@angular/core';
import { WebService } from '../../../../src/app/providers/web.service';
import { CommonService } from '../services/common.service';
import { DomSanitizer,SafeResourceUrl   } from '@angular/platform-browser';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.scss']
})
export class ContactusComponent implements OnInit {
sitecontents:any;
mappath:string = '';
safeUrl: any;
url: SafeResourceUrl ;
  ngOnInit(): void {
    this.getsitesettings();
  }
  contactDetails: any={};
  constructor(private web: WebService,
    public common: CommonService,private sanitizer: DomSanitizer

    ) { }
  grecaptcha_val:boolean = false;
  listSite: any;
  captchaResponse: any;
  grecaptcha: any;

  resolved(captchaResponse: any) {
    console.log(`Resolved response token: ${captchaResponse}`);
    // var captchaResponse = grecaptcha.getResponse();
    if(captchaResponse!=null){
      if(captchaResponse.length>0){
        this.grecaptcha_val=true;
      }
      else{
        this.grecaptcha_val=false;
      }
    }
    else{
      this.grecaptcha_val=false;
    }
  }
  async submitForm() {
    if (this.contactDetails.contact_name == null || this.contactDetails.contact_name == '') {
      this.common.presentToast('Enter your name');
     
    }
     else if (this.contactDetails.contact_email== null || this.contactDetails.contact_email == '') {
      this.common.presentToast('Enter your email');
  
    }  else if(this.common.validateEmail(this.contactDetails.contact_email)==false){
      this.common.presentToast('Enter valid email address');
    }
    else if (this.contactDetails.contact_sub== null || this.contactDetails.contact_sub == '') {
      this.common.presentToast('Enter your subject');
   
    }
  
   else if (this.contactDetails.contact_message== null || this.contactDetails.contact_message == '') {
      this.common.presentToast('Enter your message');
   
    }
    // else if(!this.grecaptcha_val){
    //   this.common.presentToast('Please verify that you are not a robot !')
    // }
    else{
      {

        this.web.postData('attack_contactform', this.contactDetails).then(res=>{
          if(res.status=='success'){
            
            this.contactDetails="";
            this.common.presentToast('Your message send successfully!!')

          //   console.log("FAillllll");
          //  this.common.presentToast(res.error);
          //   localStorage.setItem('divinkUserDetails', JSON.stringify(res.data));
          }else{
            console.log("FAillllll");
            this.common.presentToast(res.error);
          }
         },err=>{
          this.common.presentToast('Connection Error');
        })
      }
    }
    
  }
  getsitesettings(){
    this.web.getData('getSiteSettings').then((res) => {
        if (res.status == '200') {
          this.sitecontents = res.data;

          const parser = new DOMParser();
const doc = parser.parseFromString(res.data[0].site_settings_link, 'text/html');
const iframe = doc.querySelector('iframe');

if (iframe) {
  const src = new URL(iframe.src);
  const path = src.pathname;
 this.mappath = src.href;
 this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.mappath);

 console.log(this.url,"<=== htmlString ");
  console.log("map path ==>",this.mappath  ); // Output: /maps/embed
} else {
  console.log('No iframe found');
}
          console.log(this.sitecontents);
        } else {
        this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });
  }
}
