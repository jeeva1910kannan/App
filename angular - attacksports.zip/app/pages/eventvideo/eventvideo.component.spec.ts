import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventvideoComponent } from './eventvideo.component';

describe('EventvideoComponent', () => {
  let component: EventvideoComponent;
  let fixture: ComponentFixture<EventvideoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventvideoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
