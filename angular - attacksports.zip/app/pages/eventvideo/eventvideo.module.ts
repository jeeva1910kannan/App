
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import{ EventvideoRoutingModule} from './eventvideo.routing.module'
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { EventvideoComponent } from './eventvideo.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    EventvideoComponent
  ],
  imports: [
    HeaderFooterModule,
    RouterModule,
    EventvideoRoutingModule,
CommonModule,
FormsModule   
  ]
})
export class EventvideoModule { }

