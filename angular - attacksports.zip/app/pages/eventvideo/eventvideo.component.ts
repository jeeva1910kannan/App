import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from './../../providers/web.service';
import { environment } from './../../../environments/environment';
import { CommonService } from '../services/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
@Component({
  selector: 'app-eventvideo',
  templateUrl: './eventvideo.component.html',
  styleUrls: ['./eventvideo.component.scss']
})
export class EventvideoComponent implements OnInit {
  EventDetails: any;
  profile: string;
  newstart: Date;
  ggg: any
  newend: Date;
  events: any;

  eventid: any;
  currentDate: any;
  targetDate: any;
  cDateMillisecs: any;
  tDateMillisecs: any;
  difference: any;
  seconds: any;
  minutes: any;
  hours: any;
  days: any;
  year: number = 2023;
  month: number = 6;
  months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sept',
    'Oct',
    'Nov',
    'Dec',
  ];
  day: number = 31;
  showdrag:boolean;
  live: boolean;
  checkbox_on: boolean=false;
  eventvid: string;
  eventvid1: string;
  video: any;
  loading: boolean = false;
  updated: boolean;
  event_id: any;
  recentvideos: any;
  base_url: string = environment.base_url;
  participant: any;
  iswinner: boolean = false;


  constructor(private activateRoute: ActivatedRoute, private web: WebService,
    public common: CommonService, public dialog: MatDialog,private router:Router) { }

  ngOnInit(): void {
    this.get_user_winner(this.activateRoute.params['_value'].id);
    this.test(this.activateRoute.params['_value'].id);
    this.get_user(this.activateRoute.params['_value'].id);

  }
  
  onCheckboxChange(e) {
    // this.openDialog(e);

  // console.log(e,"bfe vk");
    if (e.target.checked) {
      console.log(e,"checked");
          this.openDialog(e.target.name);
          e.target.checked=false;
      // this.openDialog(e);

    } else {
    
    }
    
  }
  async get_user_winner(id){
    this.event_id = id;
    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id: id
    }
      this.web.postData('get_winner',data).then(res => {
        console.log(res,"assinn")
      if (res.status == '200') {
        this.iswinner=true;

        console.log( res.data,"email");
      
      }else if(res.status=="300"){
        // this.common.presentToast(res.error)
      }else if(res.status=="400"){
        this.iswinner=false;

        // this.common.presentToast(res.error)
      }
    })
   }
  async get_user(id){
    this.event_id = id;
    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id: id
    }
      this.web.postData('getparticipentvideos',data).then(res => {
        console.log(res,"assinn")
      if (res.status == '200') {
       
       this.participant=res.data;
        console.log( res.data,"email");
      
      }else if(res.status=="300"){
        // this.common.presentToast(res.error)
      }else if(res.status=="500"){
        // this.common.presentToast(res.error)
      }
    })
   }
  test(id) {
    this.event_id = id;
    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id: id
    }
    this.web.postData('geteventDetails', data).then((res) => {
      if (res.status == '200') {
        this.EventDetails = res.data;
        this.eventid = this.EventDetails.event_id;
        this.newstart = new Date(this.EventDetails.start_time * 1000);

        this.newend = new Date(this.EventDetails.end_time * 1000);
        const currentdate = new Date();
        console.log(this.newend,"startdate");
        console.log(currentdate);
        if (this.newend.getTime() < currentdate.getTime()) {
          this.live = true;
        }
        else {
          this.live = false;
        }

        this.profile = this.base_url + 'uploads/Event/' + this.EventDetails.event_profile;
        if (this.newstart.getTime() > currentdate.getTime() && this.EventDetails.reg == 1) {
          let x = setInterval(() => {
            this.showdrag=false;
            this.currentDate = new Date();
            this.targetDate = this.newstart;
            this.cDateMillisecs = this.currentDate.getTime();
            this.tDateMillisecs = this.targetDate.getTime();
            this.difference = this.tDateMillisecs - this.cDateMillisecs;
            this.seconds = Math.floor(this.difference / 1000);
            this.minutes = Math.floor(this.seconds / 60);
            this.hours = Math.floor(this.minutes / 60);
            this.days = Math.floor(this.hours / 24);
            this.hours %= 24;
            this.minutes %= 60;
            this.seconds %= 60;
            this.days = this.days < 10 ? '0' + this.days : this.days;
            this.hours = this.hours < 10 ? '0' + this.hours : this.hours;
            this.minutes = this.minutes < 10 ? '0' + this.minutes : this.minutes;
            this.seconds = this.seconds < 10 ? '0' + this.seconds : this.seconds;
            document.getElementById('days').innerText = this.days;
            document.getElementById('hours').innerText = this.hours;
            document.getElementById('mins').innerText = this.minutes;
            document.getElementById('seconds').innerText = this.seconds;
          });
        }
        else{
          this.showdrag=true;
        }
        this.web.postData('getrecentvideos', data).then((res) => {
          if (res.status == '200') {
            this.recentvideos = res.data;
            if (this.EventDetails) {
              this.updated = false;
              console.log("False works");
              
            }
          
          } else {
            this.updated = true;
            console.log(res.error);
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error.');
        });
      } else {
        
        console.log(res.error);
      }
      
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });


  }
  // async findstart(startdate: any) {
  //   this.events.newstart = new Date(startdate * 1000);
  //   const currentdate = new Date();
  //   console.log( this.events.newstart,"start_date");
  //   console.log(currentdate,"today");
  //   console.log(this.events.newend,"end");
  //   if(currentdate>=this.events.newstart && currentdate<=this.events.newend){
  //   this.live=true;
  //   // this.edit=true;
  //   // this.expire=false;
  //   // this.upcomming=false;
  //   }
  //   else{
  //     if(currentdate>this.events.newend){
  //     //  this.expire=true;
  //     }else{
  //       // this.expire=false;

  //     // this.upcomming=true;
  //     }
  //     this.live=false;
  //   }
  // }
  // async findend(enddate: any) {
  //   this.events.newend = new Date(enddate * 1000);

  // }
  openDialog(eventid: any): void {

      this.dialog.open(Dialog_pop, {
        data: {
          instructor_id: eventid,
          event_id: this.event_id,
          user_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),

        },
      });

  
  }
  check_boxon(){
    this.checkbox_on=true;
  }
}

@Component({
  selector: 'dialog_pop',
  templateUrl: 'dialog_pop.html',
})
export class Dialog_pop implements OnInit{
  event_id: any;
  EventDetails: any;
  custominfo: any;
  instructor_id: any;
  customer_id: any;
 
  constructor(
    public dialogRef: MatDialogRef<Dialog_pop>,
    @Inject(MAT_DIALOG_DATA) public data: Dialog_pop,
    private web: WebService,
    public common: CommonService,private router:Router) {
      
         
            this.web.postData('geteventDetails',data).then(res => {
              console.log(res,"assinn")
            if (res.status == '200') {
              this.EventDetails = res.data;
              this.event_id = this.EventDetails.event_id;

             
              console.log( res.data,"email");
            
            }else if(res.status=="300"){
              // this.common.presentToast(res.error)
            }else if(res.status=="500"){
              // this.common.presentToast(res.error)
            }
          });
          this.web.postData('selected_cus', data).then((res) => {
            if (res.status == '200') {
              this.custominfo = res.data;

              console.log(this.custominfo[0].instructor_id,"selected_instructor");
              console.log(this.custominfo,"selected_instructor");
              this.instructor_id = this.custominfo[0].instructor_id;
              this.customer_id = this.custominfo[0].customer_id;

            } else {
              console.log(res.error);
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error.');
          });
  

  }
  update_winner(){
    
    let data = {
      instructor_id: this.instructor_id,
      event_id: this.event_id,
      customer_id: this.customer_id
    
    }
    this.web.postData('getwinners',data).then(res => {
      this.dialogRef.close();   

      console.log(res,"assinn")
    if (res.status == '200') {
      console.log( res.data,"email");
             this.router.navigate(['/my-account']);


    }else if(res.status=="300"){
      // this.common.presentToast(res.error)
    }else if(res.status=="500"){
      // this.common.presentToast(res.error)
    }
  })
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {

  }
  
  }
