import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../services/common.service';
import { WebService } from '../../../../src/app/providers/web.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
  loginForm: any = {
    
  }

  constructor(
    private web: WebService,
    public common: CommonService,
    private router: Router,
  ) { }
  ngOnInit(
    
  ): void {
    //localStorage.setItem('UserId',null);
    
  }
  gotoforgotpassword(param: any) {
    localStorage.setItem('logintype', param);
    this.router.navigate(['/login/forgotpassword']);
  }
  async instructorLogin() {
    this.loginForm.type = "Instructor"
    if (this.loginForm.in_email == null || this.loginForm.in_email == '') {
      this.common.presentToast('Enter your mail id');
    }
    else if (this.common.validateEmail(this.loginForm.in_email) == false) {
      this.common.presentToast('Enter valid email Address');
    } else if (this.loginForm.in_password == null || this.loginForm.c_password == '') {
      this.common.presentToast('Enter your password');
    } else {
      this.web.postData('instructorlogin', this.loginForm).then(res => {
        if (res.status == '200') {
          let instructorDetails = res.data;
          console.log(res.data);
          localStorage.setItem('UserDetails', JSON.stringify(instructorDetails));
          localStorage.setItem('UserId', res.data.web_id);
          localStorage.setItem('type',res.data.type);
          localStorage.setItem('email',res.data.email);
          localStorage.setItem('phone',res.data.phone); 
          localStorage.setItem('access_token', res.data.token); 
          console.log(localStorage.getItem('access_token'),"ranjith");
              
          this.router.navigate(['/my-account']);        
          this.common.presentToast('Login Successfully');   
        }
        else if (res.status == '300'){
          this.common.presentToast(res.error);
        } else {
          this.common.presentToast("Please register before login");
        }
      }, err => {
        this.common.presentToast('Connection Error');
      })

    }
  }
  async customerLogin() {
    this.loginForm.type = "Customer"
    if (this.loginForm.c_email == null || this.loginForm.c_email == '') {
      this.common.presentToast('Enter your mail id');
    }
    else if (this.common.validateEmail(this.loginForm.c_email) == false) {
      this.common.presentToast('Enter valid email Address');
    }
    else if (this.loginForm.c_password == null || this.loginForm.c_password == '') {
      this.common.presentToast('Enter your password');
    }
    else{
      this.web.postData('customerlogin', this.loginForm).then(res=>{
        if (res.status == '200') {
          let instructorDetails = res.data;
          localStorage.setItem('UserDetails', JSON.stringify(instructorDetails));
          localStorage.setItem('UserId', res.data.web_id);
          localStorage.setItem('type',res.data.type);
          localStorage.setItem('email',res.data.email);
          localStorage.setItem('phone',res.data.phone);
          localStorage.setItem('access_token', res.data.token); 
          localStorage.setItem('Transaction', null); 
          this.router.navigate(['/my-account']);
          this.common.presentToast('Login Successfully')
   
        }
        else if (res.status == '300'){
          this.common.presentToast(res.error);
        }else{
          this.common.presentToast("Please register before login");
        }
       },err=>{
        this.common.presentToast('Connection Error');
      })
    }
  }
}
