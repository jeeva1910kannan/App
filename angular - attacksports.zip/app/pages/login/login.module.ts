import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
import { LoginRoutingModule } from './login.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { MatSliderModule } from '@angular/material/slider';
import { MatTabsModule } from '@angular/material/tabs';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatInputModule} from '@angular/material/input';

@NgModule({
  declarations: [
    LoginComponent,  
  ],

  imports: [
    CommonModule,
    LoginRoutingModule,
    HeaderFooterModule,
    MatSliderModule,
    MatTabsModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    RouterModule,
    ReactiveFormsModule
  ]
})
export class LoginModule { }
