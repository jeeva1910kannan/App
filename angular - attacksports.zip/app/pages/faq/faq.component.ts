import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {

  base_url: string = environment.base_url;

  faq: any;

  faqquiz: any;

  constructor(private web:WebService,private activateroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.getfaqContents();
    this.test(this.activateroute.params['_value'].id)
  }
  async getfaqContents(){
    await this.web.getData('getAllFaq').then((res) => {
        if (res.status == '200') {
          this.faq = res.data[0];
          //this.faqquiz = res.data.slice(1);
          this.faqquiz = res.data.slice(1,30);
          console.log(this.faqquiz);
          console.log("Hii");
          console.log(this.faq);
                 } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
      console.log(this.faq);
      console.log("fdjhgjdf");
  } 

  test(id){

  }

}





