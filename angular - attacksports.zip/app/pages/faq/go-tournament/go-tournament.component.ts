import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';


@Component({
  selector: 'app-go-tournament',
  templateUrl: './go-tournament.component.html',
  styleUrls: ['./go-tournament.component.scss']
})
export class GoTournamentComponent implements OnInit {

  base_url: string = environment.base_url

  // GoTournament: any;
  // Content: any;
  Local: any;
  Hockey: any;
  Weekend: any;

  constructor(private web:WebService,private activateroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.getgotournamentcontents();  
    this.test(this.activateroute.params['_value'].id)
  }

  async getgotournamentcontents(){
    await this.web.getData('getAllGoTournament').then((res) => {
        if (res.status == '200') {
          // this.GoTournament= res.data;
          // this.Content= res.data;
          this.Local= res.data[0];
          this.Hockey= res.data[1];
          this.Weekend= res.data[2];
          console.log("Output:",this.Local)
          console.log("Output:",this.Hockey)
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
      
      console.log("HELLO");
  }

  test(id){
  }
}