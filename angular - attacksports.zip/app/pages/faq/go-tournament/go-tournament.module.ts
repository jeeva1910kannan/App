import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GoTournamentComponent } from './go-tournament.component';
import { GoTournamentRoutingModule } from './go-tournament.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';

@NgModule({
  declarations: [
    GoTournamentComponent
  ],
  imports: [
    CommonModule,
    GoTournamentRoutingModule,
    HeaderFooterModule
  ]
})
export class GoTournamentModule { }
