import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { GoTournamentComponent } from './go-tournament.component';

const routes: Routes = [
  {
    path: "",
    component: GoTournamentComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class GoTournamentRoutingModule { }