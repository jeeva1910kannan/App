import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../services/common.service';

@Injectable({
  providedIn: 'root'
})
export class GoRegistrationFormService {

  private goregistrationform: FormGroup;

  constructor( private fb: FormBuilder, private toast: ToastrService,  private common:CommonService) { 

    this.goregistrationform = this.fb.group({


      registration_field: ['', {validators: Validators.compose([Validators.required])}],  
        player_fname: ['', {validators: Validators.compose([Validators.required])}],
        player_lname: ['', {validators: Validators.compose([Validators.required])}],
        dob_month: ['', {validators: Validators.compose([Validators.required])}],
        dob_day: ['', {validators: Validators.compose([Validators.required])}],
        dob_year: ['', {validators: Validators.compose([Validators.required])}],
        gender: ['', {validators: Validators.compose([Validators.required])}],
      shirtsize: ['', {validators: Validators.compose([Validators.required])}],
      preferred_position: ['', {validators: Validators.compose([Validators.required])}],
      current_association: ['', {validators: Validators.compose([Validators.required])}],
      season_division: ['', {validators: Validators.compose([Validators.required])}],
      parent_fname: ['', {validators: Validators.compose([Validators.required])}],
      parent_lname: ['', {validators: Validators.compose([Validators.required])}],
      parent_email: ['', {validators: Validators.compose([Validators.required])}],
      parent_phone: ['', {validators: Validators.compose([Validators.required])}],
      player_country: ['', {validators: Validators.compose([Validators.required])}],
      street_address: ['', {validators: Validators.compose([Validators.required])}],
      city: ['', {validators: Validators.compose([Validators.required])}],
      province: ['', {validators: Validators.compose([Validators.required])}],
      postal_code: ['', {validators: Validators.compose([Validators.required])}],
      jersey_size: ['', {validators: Validators.compose([Validators.required])}],
      jersey_choice1: ['', {validators: Validators.compose([Validators.required])}],
      jersey_choice2: ['', {validators: Validators.compose([Validators.required])}],
      jersey_choice3: ['', {validators: Validators.compose([Validators.required])}],
      friend_request1: ['', {validators: Validators.compose([Validators.required])}],
      friend_request2: ['', {validators: Validators.compose([Validators.required])}],
      friend_request3: ['', {validators: Validators.compose([Validators.required])}],
      volunteers: ['', {validators: Validators.compose([Validators.required])}],
      auction: ['', {validators: Validators.compose([Validators.required])}],
      sponsor: ['', {validators: Validators.compose([Validators.required])}],
      acceptTerms: ['', {validators: Validators.compose([Validators.required])}],
      bill_fname: ['', {validators: Validators.compose([Validators.required])}],  
      bill_lname: ['', {validators: Validators.compose([Validators.required])}],
      payment_method: ['', {validators: Validators.compose([Validators.required])}],
      bill_country: ['', {validators: Validators.compose([Validators.required])}],
      bill_address: ['', {validators: Validators.compose([Validators.required])}],
      bill_city: ['', {validators: Validators.compose([Validators.required])}],
      bill_province: ['', {validators: Validators.compose([Validators.required])}],
      bill_postalcode: ['', {validators: Validators.compose([Validators.required])}],
      bill_email: ['', {validators: Validators.compose([Validators.required])}],
      bill_phone: ['', {validators: Validators.compose([Validators.required])}],
    });
  }
  exportNewForm(){
    return this.goregistrationform;
  }

}
