import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoRegistrationComponent } from './go-registration.component';
import { GoRegistrationRoutingModule } from './go-registration.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import {MatRadioModule} from '@angular/material/radio';
import { ReactiveFormsModule } from '@angular/forms';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@NgModule({
  declarations: [
    GoRegistrationComponent
  ],
  imports: [
    CommonModule,
    GoRegistrationRoutingModule,
    HeaderFooterModule,
    FormsModule,
    MatCheckboxModule,
    MatInputModule,
    MatDatepickerModule,
    MatRadioModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
  ]
})
export class GoRegistrationModule { }