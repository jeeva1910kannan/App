import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../../providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../services/common.service';
import { CampdetailsService } from './campdetails.service';
import { countries } from 'src/app/pages/common/commonjson/country-data-store';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
//import  Square  from '@square/web-payments-sdk-types';


@Component({
  selector: 'app-campdetails',
  templateUrl: './campdetails.component.html',
  styleUrls: ['./campdetails.component.scss']
})
export class CampdetailsComponent implements OnInit {
  campid:number = this.activateRoute.params['_value'].id;
 
  formData  = {
    campid: this.activateRoute.params['_value'].id,
    firstname: '',
    lastname: '',
    date_of_birth: '',
    gender:'',
    parent_name:'',
    parent_email:'',
    altenate_parent_email:'',
    phone_number:'',
    country:'',
    address:'',
    city:'',
    postal_code:'',
   

  };
  
  public countries: any = countries;
  base_url: string = environment.base_url;
  campregisterform: FormGroup;
  campamount: any;
  campdetails1: any=[];
  regdetails:any;
  bookeddetails: any=[];
  book = false;  
  userid:any; 
  currentDate = new Date();
  heading: string;
  resultcontents: any=[];
  
  constructor(
    private activateRoute:ActivatedRoute,
    public common: CommonService,
    private web:WebService,
    private tableService: CampdetailsService, 
    private fb: FormBuilder, 
    public dialog: MatDialog,
    private router: Router
   
  ) {
    this.campregisterform = this.tableService.exportNewForm();
   }
  // campid:number = this.activateRoute.params['_value'].id;
  campdetails:any;
  ngOnInit(): void {
    localStorage.setItem('campid',this.activateRoute.params['_value'].id);
    console.log("jhsdfhdsjfh",this.campid);
    this.getcampdetails();
    this.getbookedcamp();
    this.userid=localStorage.getItem("UserId");
    this.heading=localStorage.getItem("heading");
    this.getresultContents();

  }

  submitForm() {
    if(this.userid=='null')
    {
      this.common.presentToast('Please Booking camp before login');
    }
    else{ 
    if(this.formData.firstname==null || this.formData.firstname==''|| this.formData.firstname.trim().length==0){
      this.common.presentToast('Enter first name');
    }
   

    else if(this.formData.lastname==null || this.formData.lastname=='' || this.formData.lastname.trim().length==0){
      this.common.presentToast('Enter Last name');
    }
    else if(this.formData.date_of_birth==null || this.formData.date_of_birth==''){
      this.common.presentToast('Enter DOB');
    }
    else if(this.formData.gender==null || this.formData.gender==''){
      this.common.presentToast('Please select gender');
    }
    else if(this.formData.parent_name==null || this.formData.parent_name=='' || this.formData.parent_name.trim().length==0){
      this.common.presentToast('Enter Parent Name');
    }
    
    else if(this.formData.parent_email==null || this.formData.parent_email=='' || this.formData.parent_email.trim().length==0){
      this.common.presentToast('Enter Parent Email');
    }
    else if(this.common.validateEmail(this.formData.parent_email)==false){
      this.common.presentToast('Enter valid Email');
    }
    // else if(this.formData.altenate_parent_email==null || this.formData.altenate_parent_email==''){
    //   this.common.presentToast('Enter Alternate Email');
    // }
    // else if(this.common.validateEmail(this.formData.altenate_parent_email)==false){
    //   this.common.presentToast('Enter Valid Alternate Email');
    // }
    else if(this.formData.phone_number==null || this.formData.phone_number=='' ||this.formData.phone_number.trim().length==0){
      this.common.presentToast('Enter Phone Number');
    }
    else if(this.common.validateMobileNumber(this.formData.phone_number)==false){
      this.common.presentToast('Enter Valid Phone Number');
    }
    else if(this.formData.country==null || this.formData.country==''){
      this.common.presentToast('Please select Country');
    }
    else if(this.formData.address==null || this.formData.address==null || this.formData.address.trim().length==0){
      this.common.presentToast('Enter Address');
    }
    else if(this.formData.city==null || this.formData.city==''||this.common.validatespace(this.formData.city)==false){
      this.common.presentToast('Enter City');
    }
    else if(this.formData.postal_code==null || this.formData.postal_code==''|| this.formData.postal_code.trim().length==0){
      this.common.presentToast('Enter postal code');
    }
    else if(this.common.validateNumber(this.formData.postal_code)==false){
      this.common.presentToast('Enter valid postal code');
    }
   
    
    else{ 
   // this.web.postData('addregistrationcamp', this.formData).then((res) => {
      localStorage.setItem('firstname',this.formData.firstname);
      localStorage.setItem('parent-email',this.formData.parent_email);
     // localStorage.setItem('campid',this.formData.campid);
      localStorage.setItem('lastname',this.formData.lastname);
      localStorage.setItem('gender',this.formData.gender);
      localStorage.setItem('phone_number',this.formData.phone_number);
      localStorage.setItem(' altenate_parent_email',this.formData. altenate_parent_email);
      localStorage.setItem('country',this.formData.country);
      localStorage.setItem(' address',this.formData. address);
      localStorage.setItem('city',this.formData.city);
      localStorage.setItem(' postal_code',this.formData. postal_code);
      localStorage.setItem('country',this.formData.country);
      localStorage.setItem('date_of_birth',this.formData.date_of_birth);
      localStorage.setItem('parent_name',this.formData.parent_name);
    
  
      // if (res.status == '200') {

      //   //this.regdetails=res.data;
      //   // console.log(this.regdetails,"regdetaiols")
      //   // this.common.presentToast('');  
      //   this.common.presentToast('Registered Successfully');
      
      this.dialog.open(payment, {
        
        data: {
         user_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),
         
          
        },
      });
      }
    }

//        // this.ngOnInit(); 
//        ;
//       } 
//     }, err => {

//       console.log(err,"error");
//       console.log(this.campid,"campp");
      
//     });
}

getbookedcamp(){
  let data={
    campid:localStorage.getItem('campid'),
    customer_id: localStorage.getItem('UserId'),
  }
  
  this.web.postData('getbookedcamp',data).then((res) => {
      if (res.status == '200') {
       this.book = true;
        this.bookeddetails = res.data;
       console.log(this.bookeddetails,"bookeddetails");
      
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
}


  getcampdetails(){
    let formData = {
      web_id:this.campid,
     
    }
    
    this.web.postData('getcampdetails',formData).then((res) => {
        if (res.status == '200') {
          this.campamount = res.data;
          this.campdetails = res.data;
         console.log(this.campdetails,"this.campdetails");
          this.campamount.map((res, i) => {
          console.log(res.result_price,'67667')
          localStorage.setItem('campamount',res.result_price);
          localStorage.setItem('camptitle',res.result_title);
         });
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }

  getresultContents(){
    this.web.getData('getResultContents').then((res) => {
        if (res.status == '200') {
          this.resultcontents = res.data;
        console.log("resultcontents",this.resultcontents);
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }
  
}

 
   

declare var Square: any;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
@Component({
  selector: 'campdetails',
  templateUrl: 'campdetails.html',
   styleUrls: ['campdetails.scss']
})
export class payment{
 // campid:number = this.activateRoute.params['_value'].id;
//  formData = {
//   campid: this.activateRoute.params['_value'].id,
//  }
  
  payments: any;
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEOKq3_JUA1xw1RCiov2mms1eJviBzaBrw1rM40aMSTdKXCpfJWnkIfJfwad-";
  applicationId1 = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  locationId1 = "LC2PEQFX591R6";
  paymentForm: any; 
  userDetailsTemp: any;
  campdetails1: any=[];
  isButtondisabled=false;
  resultcontents: any=[];
  


  constructor(public common: CommonService,private web: WebService, public dialog: MatDialog,private activateRoute:ActivatedRoute) { 
  }
  ngOnInit(): void {
    
  this.loadScript();
  this.getresultContents();
 
  }
oncancel(){
    this.dialog.closeAll();
  }
 

  async  loadScript() {
   
   
    // Your SqPaymentForm script here
  
    var applicationId = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  
    // Set the location ID
    var locationId = "LQC04P5CAFGVD";
  
    this.payments = Square.payments(applicationId, locationId);
  
    this.card = await this.payments.card();
  
    await this.card.attach('#card-container');
  
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
    const form = document.querySelector('#card-payment') as HTMLFormElement;
  
    form.addEventListener('submit', async (event: Event) => {
  
       event.preventDefault();
  
       const result = await this.card.tokenize(); // the card nonce
  
    });
    console.log("result");
    // onCancel: () => {
    //   this.common.presentToast('Payment cancelled.');
    //   console.log("OnCancel");
    // }
    
  }
  async makePayment() {
    
   
    const statusContainer = document.getElementById('payment-status-container');
    try {
      const result = await this.card.tokenize();
      if (result.status === 'OK') {
        this.isButtondisabled = true;

        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
        //console.log('Paypal id', details.id);
        let data = {
          //to_email: localStorage.getItem('email'),
          
          customer_id: localStorage.getItem('UserId'),
          amount: localStorage.getItem('campamount'),
          firstname:localStorage.getItem('firstname'),
          parent_email:localStorage.getItem('parent-email'),
          campid:localStorage.getItem('campid'),
          lastname:localStorage.getItem('lastname'),
          gender:localStorage.getItem('gender'),
          phone_number:localStorage.getItem('phone_number'),
          altenate_parent_email:localStorage.getItem(' altenate_parent_email'),
          country:localStorage.getItem('country'),
          address:localStorage.getItem(' address'),
          city:localStorage.getItem('city'),
          postal_code:localStorage.getItem(' postal_code'),
          date_of_birth:localStorage.getItem('date_of_birth'),
          parent_name:localStorage.getItem('parent_name'),
          email:localStorage.getItem('email'),
          result_title:localStorage.getItem('camptitle'),
         // customer_id:localStorage.getItem('UserId'),

      
          transaction_response: 'details',
          transaction_method: 'card',
          payment_status: 'success',
          paymentToken: result.token,
          locationId: this.locationId1,
          accesstoken: this.accesstoken
        };
        this.web.postData('addregistrationcamp', data).then(
         
          (res) => {
            if (res.status == '200') {
              this.common.presentToast('Payment Successfully');
             
              this.isButtondisabled = false;
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              });
              //this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
              this.isButtondisabled = false;
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
            this.isButtondisabled = false;
          });

        
    //this.processPayment(result)
        // this.http.post('http://your-api-endpoint.com/charge', {
        //   paymentToken: result.token,
        //   amount: this.EventDetails.price
        // }).subscribe(response => {
        //   console.log(response);
        //   statusContainer.innerHTML = "Payment Successful";
        // }, error => {
        //   console.error(error);
        //   statusContainer.innerHTML = "Payment Failed";
        // });
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }

  getresultContents(){
    this.web.getData('getResultContents').then((res) => {
        if (res.status == '200') {
          this.resultcontents = res.data;
        console.log("resultcontents",this.resultcontents);
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }
  
  

}