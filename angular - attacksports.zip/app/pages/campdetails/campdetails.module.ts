import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CampdetailsRoutingModule } from './campdetails-routing.module';
import { CampdetailsComponent } from './campdetails.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { MatSelectModule } from '@angular/material/select';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';




@NgModule({
  declarations: [
    CampdetailsComponent
  ],
  imports: [
    CommonModule,
    CampdetailsRoutingModule,
    HeaderFooterModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    CKEditorModule,
    MatSelectModule,
    NgxSkeletonLoaderModule
  
  ]
})
export class CampdetailsModule { }
