import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../services/common.service';

import  CampdetailsModel  from './campdetails.model';

@Injectable({
  providedIn: 'root'
})
export class CampdetailsService {

  private campregisterform: FormGroup;

  constructor( private fb: FormBuilder, private toast: ToastrService,  private common:CommonService) { 

    this.campregisterform = this.fb.group({

      firstname: ['', {validators: Validators.compose([Validators.required])}],
      lastname: ['', {validators: Validators.compose([Validators.required])}],
      date_of_birth: ['', {validators: Validators.compose([Validators.required])}],
      gender: ['', {validators: Validators.compose([Validators.required])}],
      parent_name: ['', {validators: Validators.compose([Validators.required])}],
      parent_email: ['', {validators: Validators.compose([Validators.required])}],
      altenate_parent_email: ['', {validators: Validators.compose([Validators.required])}],
      phone_number: ['', {validators: Validators.compose([Validators.required])}],
      country: ['', {validators: Validators.compose([Validators.required])}],
      address: ['', {validators: Validators.compose([Validators.required])}],
      city: ['', {validators: Validators.compose([Validators.required])}],
      postal_code: ['', {validators: Validators.compose([Validators.required])}],
     
     
    });
  }
  exportNewForm(){
    return this.campregisterform;
  }

  // async campFormValidation(val: CampdetailsModel):Promise<boolean> {
  //   let action = val.action;
  //   console.log(val);
  //   if( val.firstname== '' || this.common.validatespace(val.firstname)==false){
  //     this.toast.warning('Missing fields', 'Enter customer name without space');
  //     document.getElementById('customerid').focus();
  //     return false;
  //   }
  //   else if(val.lastname=='' || this.common.validatespace(val.lastname)==false){
  //     this.toast.warning('Missing fields', 'Enter coupon status without space');
  //     document.getElementById('couponcode').focus();
  //     return false;
  //   }else if(val.date=='' || this.common.validatespace(val.date)==false){
  //     this.toast.warning('Missing fields', 'Enter valid coupon code ');
  //     document.getElementById('couponstatus').focus();
  //     return false;
  //   }
  //   else {
  //     return true;
  //   }
  // }
}
