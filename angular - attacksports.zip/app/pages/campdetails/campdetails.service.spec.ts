import { TestBed } from '@angular/core/testing';

import { CampdetailsService } from './campdetails.service';

describe('CampdetailsService', () => {
  let service: CampdetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CampdetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
