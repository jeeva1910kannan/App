export default class campdetailsModel {
    public id: number;
    public firstname:any;
    public lastname:any;
    public date:any;
    public gender: any;
    public parent_name: any;
   
    public action: string;
  
    constructor(camp:any = {}){
  
    this.id = camp.id || '';
    this.firstname = camp.firstname || '';
    this.lastname = camp.lastname || '';
    this.date = camp.date|| '';
    this.gender = camp.gender || '';
    this.parent_name = camp.parent_name || '';
    
    }
  }