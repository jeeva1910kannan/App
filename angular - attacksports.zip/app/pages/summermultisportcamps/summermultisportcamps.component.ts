import { ChangeDetectorRef, Component, HostListener,Renderer2,OnInit, ViewChild, ElementRef } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { AuthService } from '../../providers/auth.service';


@Component({
  selector: 'app-summermultisportcamps',
  templateUrl: './summermultisportcamps.component.html',
  styleUrls: ['./summermultisportcamps.component.scss']
})
export class SummermultisportcampsComponent implements OnInit {
  [x: string]: any;

  isMobileView: boolean;
  selectedPaymentMethod: string;
  showHoldsSame = false;
  default_radio: string;
  selectedMonth: string;
  selectedDay: string;
  selectedYear: string;
  listradselect: any = [];
  formDetailsSubmitted: boolean = false;
  checkboxValues: string[] = [];
  otherInputValid = false;
  isChecked: boolean = false;
  
  base_url: string = environment.base_url;
  // springhockey: any;
  multisportcampscontents: any[] = [];
  myForm: any;
  submitted = false;
  userid:any; 
  
  constructor(private renderer: Renderer2, private router: Router,
    private toastr: ToastrService,private web: WebService,
     private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,
     private  common:CommonService,private formBuilder: FormBuilder,private authService: AuthService  ) 
  { 
    
  } 

  // updateCheckboxValue(value: string) {
  //   if (this.checkboxValues.includes(value)) {
  //     this.checkboxValues = this.checkboxValues.filter(item => item !== value);
  //   } else {
  //     this.checkboxValues.push(value);
  //   }
  //   this.otherInputValid = !this.formDetails.otherChecked || this.formDetails.otherText.trim() !== '';
  // }

  ngOnInit() {
    this.userid=localStorage.getItem("UserId");
    this.getSummerMultisportCampsCont();
  }
  showContents(): void {
    // if (this.userid == 'null') {
    //   this.common.presentToast('Please Booking camp before login');
    // }
    // if (this.authService.isLoggedIn()) {
    //   this.router.navigate(['/summercampsrefform']);
    // } else {
    
      // this.common.presentToast('Please login to register for summer camp.' );
      // this.router.navigate(['/login']);
    //}
    this.router.navigate(['/summercampsrefform']);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.isMobileView = window.innerWidth < 992;
  }
  
  getSummerMultisportCampsCont() {
    this.web.getData('getSummerMultisportCampsCont').then((res) => {
      if (res.status == '200') {
        this.multisportcampscontents = res.data;
       
        console.log(this.multisportcampscontents, "this.multisportcampscontents");
        

      }
      // else {
      // this.bannercontents[1].home_video=null;  
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }


  
}
