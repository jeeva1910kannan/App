import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SummermultisportcampsComponent } from './summermultisportcamps.component';
import { SummerMultiSportCampsRoutingModule } from './summermultisportcamps.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    SummermultisportcampsComponent
  ],
  imports: [
    CommonModule,
    SummerMultiSportCampsRoutingModule,
    HeaderFooterModule,
    ReactiveFormsModule,
    FormsModule,
   
  ],
})
export class SummerMultiSportCampsModule { }
