import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
declare let jQuery: any;

@Component({
  selector: 'app-ourteam',
  templateUrl: './ourteam.component.html',
  styleUrls: ['./ourteam.component.scss']
})
export class OurteamComponent implements OnInit {

  base_url: string = environment.base_url;
  bannercontents: any[] = [];

  Ourteam: any;
  content: any;

  constructor(private web:WebService,private activateroute:ActivatedRoute) { }


  ngOnInit(): void {
    jQuery(".loader").fadeOut("1500");
    this.getourteamcontents();  
    this.getbannercontents();
    this.test(this.activateroute.params['_value'].id)
  }
  async getourteamcontents(){
    await this.web.getData('getAllOurteam').then((res) => {
        if (res.status == '200') {
          this.Ourteam= res.data[0];
          this.content= res.data[1];
          
          console.log(this.Ourteam);
                 } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
      console.log(this.Ourteam);
      console.log("HELLO");
  }

  getbannercontents() {
    this.web.getData('getBannerContents').then((res) => {
      if (res.status == '200') {
        this.bannercontents = res.data;
        setTimeout(() => {
          jQuery('#banners').owlCarousel({
            margin: 10,
            loop: true,
            rewind: false,
            autoplay: true, //true if you want enable autoplay
            smartSpeed: 3000,
            responsiveClass: true,
            responsive: {
              0: {
                items: 1
              },
              481: {
                items: 1
              },
              576: {
                items: 2
              },
              768: {
                items: 2
              },
              992: {
                items: 3
              },
              1200: {
                items: 3
              },
              1430: {
                items: 3
              },
              1600: {
                items: 3
              }
            }
          });
        }, 1000);
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

  test(id){
  }
}