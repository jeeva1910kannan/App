import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OurteamComponent } from './ourteam.component';
import { OurteamRoutingModule } from './ourteam.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';

@NgModule({
  declarations: [
    OurteamComponent
  ],
  imports: [
    CommonModule,
    OurteamRoutingModule,
    HeaderFooterModule
  ]
})
export class OurteamModule { }