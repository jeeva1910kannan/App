import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SummerelitecampComponent } from './summerelitecamp.component';
import {SummerelitecampRoutingModule} from './summerelitecamp.routing.module';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'

@NgModule({
  declarations: [
    SummerelitecampComponent
  ],
  imports: [
    CommonModule,
    SummerelitecampRoutingModule,
    HeaderFooterModule
  ],
  exports: [
    SummerelitecampComponent
  ]
})
export class SummerelitecampModule { }

