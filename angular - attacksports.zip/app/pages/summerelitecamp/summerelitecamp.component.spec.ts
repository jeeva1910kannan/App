// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { SummerelitecampComponent } from './summerelitecamp.component';

// describe('SummerelitecampComponent', () => {
//   let component: SummerelitecampComponent;
//   let fixture: ComponentFixture<SummerelitecampComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ SummerelitecampComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SummerelitecampComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
