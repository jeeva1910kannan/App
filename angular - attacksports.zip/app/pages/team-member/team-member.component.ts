import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import {FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-team-member',
  templateUrl: './team-member.component.html',
  styleUrls: ['./team-member.component.scss']
})
export class TeamMemberComponent implements OnInit {
  team: any;
  team_members: any;
  // team_member: any;
  base_url: string = environment.base_url;
  team_name: any;

  constructor(private web: WebService,
    public common: CommonService,private router:Router,private activateRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.Editevent(this.activateRoute.params['_value'].id);
    
  }
    
  async Editevent(id){

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      web_id:id
    }
    this.web.postData('geteditteamDetails',data).then((res) => {
      if (res.status == '200') {
        this.team = res.team;  
        this.team_name = res.data.team_name;  
        this.team_mem(res.team);

        console.log( res.team ,"mem")
    //  this.profile=this.Eventforme.event_profile;
  
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    this.common.presentToast('Connection Error.');
    });
  
  
  
  }

  async team_mem(id:any){
    console.log(id,"team_mem")

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      team_member:id
    }
    this.web.postData('getteam',data).then((res) => {
      if (res.status == '200') {
        this.team_members = res.data;  
        // console.log( this.Eventform_mem ,"mem")
    //  this.profile=this.Eventforme.event_profile;
  
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    this.common.presentToast('Connection Error.');
    });
  
  
  
  }
}
