import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TeamMemberRoutingModule } from './team-member-routing.module';
import { TeamMemberComponent } from './team-member.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import {MatPaginatorModule} from '@angular/material/paginator';


@NgModule({
  declarations: [
    TeamMemberComponent
  ],
  imports: [
    CommonModule,
    TeamMemberRoutingModule,
    HeaderFooterModule,MatPaginatorModule
  ]
})
export class TeamMemberModule { }
