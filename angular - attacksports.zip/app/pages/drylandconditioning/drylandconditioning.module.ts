import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DrylandconditioningComponent } from './drylandconditioning.component';
import {DrylandconditioningRoutingModule} from './drylandconditioning.routing.module';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'

@NgModule({
  declarations: [
    DrylandconditioningComponent
  ],
  imports: [
    CommonModule,
    DrylandconditioningRoutingModule,
    HeaderFooterModule
  ],
  exports: [
    DrylandconditioningComponent
  ]
})
export class DrylandconditioningModule { }

