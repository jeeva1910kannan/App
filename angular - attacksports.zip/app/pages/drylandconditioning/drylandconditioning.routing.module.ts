import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { DrylandconditioningComponent } from './drylandconditioning.component';

const routes: Routes = [
  {
    path: "",
    component: DrylandconditioningComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class DrylandconditioningRoutingModule { }