import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrylandconditioningComponent } from './drylandconditioning.component';

describe('DrylandconditioningComponent', () => {
  let component: DrylandconditioningComponent;
  let fixture: ComponentFixture<DrylandconditioningComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrylandconditioningComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DrylandconditioningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
