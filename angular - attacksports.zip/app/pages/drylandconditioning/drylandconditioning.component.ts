import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
declare let jQuery: any;
@Component({
  selector: 'app-drylandconditioning',
  templateUrl: './drylandconditioning.component.html',
  styleUrls: ['./drylandconditioning.component.scss']
})
export class DrylandconditioningComponent implements OnInit {
  base_url: string = environment.base_url;
  // springhockey: any;
  drylandconditioningcontents: any[] = [];
  constructor(private web: WebService, private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,private  common:CommonService  ) { } 


  ngOnInit(): void {

    this.getdrylandconditioningCamps();
  }
  getdrylandconditioningCamps() {
    this.web.getData('getdrylandconditioningCamps').then((res) => {
      if (res.status == '200') {
        this.drylandconditioningcontents = res.data;
       
        console.log(this.drylandconditioningcontents, "this.drylandconditioningcontents");
       

      }
      // else {
      // this.bannercontents[1].home_video=null;  
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
 


}
