import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
import { MedicalInformationComponent } from './medical-information.component';
import { MedicalWaiverRoutingModule} from './medical-information.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import {MatRadioModule} from '@angular/material/radio';
import { HelloComponent } from './siognature-pad';

@NgModule({
  declarations: [
    MedicalInformationComponent,
    
  ],
  imports: [
    // CommonModule,
    MedicalWaiverRoutingModule,
    HeaderFooterModule,
    FormsModule,
    MatCheckboxModule,
    MatInputModule,
    MatDatepickerModule,
    MatRadioModule,
  ],
  bootstrap:    [ MedicalInformationComponent ]
})
export class MedicalInformationModule { }
