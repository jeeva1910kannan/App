import { AfterViewInit, Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { WebService } from '../../../../src/app/providers/web.service';
import { CommonService } from '../services/common.service';
import { medicalpopup } from './medical-popup';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-medical-information',
  templateUrl: './medical-information.component.html',
  styleUrls: ['./medical-information.component.scss']
})
export class MedicalInformationComponent implements AfterViewInit {

  other_value:any;
  @Input() name: 'Angular';
    
  @ViewChild('sigPad') sigPad: ElementRef;
  sigPadElement: HTMLCanvasElement;
  context: CanvasRenderingContext2D;
  isDrawing = false;
  img: string;
  

  ngAfterViewInit() {
    this.sigPadElement = this.sigPad.nativeElement;
    this.context = this.sigPadElement.getContext('2d');
    this.context.strokeStyle = '#3742fa';
  }

  @HostListener('document:mouseup', ['$event'])
  onMouseUp(e) {
    this.isDrawing = false;
  }

  onMouseDown(e) {
    this.isDrawing = true;
    const coords = this.relativeCoords(e);
    this.context.moveTo(coords.x, coords.y);
  }

  onMouseMove(e) {
    if (this.isDrawing) {
      const coords = this.relativeCoords(e);
      this.context.lineTo(coords.x, coords.y);
      this.context.stroke();
    }
  }

  private relativeCoords(event) {
    const bounds = event.target.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    return { x: x, y: y };
  }

  clear() {
    this.context.clearRect(0, 0, this.sigPadElement.width, this.sigPadElement.height);
    this.context.beginPath();
  }

  
  selectedOption: string;
  formDetails: any={
    
  }
  constructor(
    private web: WebService,
    public common: CommonService,
    public dialog: MatDialog
  ) { }
  private isSignatureEmpty() {
    const signatureData = this.context.getImageData(
      0,
      0,
      this.sigPadElement.width,
      this.sigPadElement.height
    ).data;

    // Loop through the signature data and check if any non-transparent pixel exists.
    for (let i = 0; i < signatureData.length; i += 4) {
      const alpha = signatureData[i + 3];
      if (alpha !== 0) {
        return false; // Signature is not empty.
      }
    }

    return true; // Signature is empty.
  }

  setOtherPurpose() {
    this.formDetails.purpose = 'Others';
  }
  generateReferenceCode(): string {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
  
    let referenceCode = '';
    
    // Generate the first 8 characters using uppercase letters
    for (let i = 0; i < 8; i++) {
      const randomIndex = Math.floor(Math.random() * alphabet.length);
      referenceCode += alphabet.charAt(randomIndex);
    }
    
    // Append 'IS' to the reference code
    referenceCode += 'IS';
    
    // Generate the last 2 characters using numbers
    for (let i = 0; i < 2; i++) {
      const randomIndex = Math.floor(Math.random() * numbers.length);
      referenceCode += numbers.charAt(randomIndex);
    }
    
    return referenceCode;
  }
  

  async submitForm() {
    console.log(this.formDetails,"form");
    
    this.img = this.sigPadElement.toDataURL("");
 
    console.log(this.formDetails.other,"this.formDetails.other");
    if(this.formDetails.purpose==''){
        this.other_value=this.formDetails.other;
    }
    else{
      this.other_value=this.formDetails.purpose;
    }

   
    if (this.formDetails.first_name == null || this.formDetails.first_name == '') {
      this.common.presentToast('Enter your First name');
    }
    else if(this.formDetails.last_name == null || this.formDetails.last_name == '') {
      this.common.presentToast('Enter your Last name');
    }
   else if (this.formDetails.birthday == null || this.formDetails.birthday == '') {
    this.common.presentToast('Enter your Birthdate');
    }
  else if (this.formDetails.first_line == null || this.formDetails.first_line == '') {
    this.common.presentToast('Enter your First line in address');
  }
  else if (this.formDetails.second_line == null || this.formDetails.second_line == '') {
    this.common.presentToast('Enter your Second line in address');
  }
  else if (this.formDetails.city == null || this.formDetails.city == '') {
    this.common.presentToast('Enter your City');
  }
  else if (this.formDetails.province == null || this.formDetails.province == '') {
    this.common.presentToast('Enter your Province');
  }
  else if (this.formDetails.postcode == null || this.formDetails.postcode == '') {
    this.common.presentToast('Enter your Postal code');
  }
  else if (this.formDetails.phone == null || this.formDetails.phone == '') {
    this.common.presentToast('Enter your Phone Number');
  }
  else if (this.formDetails.health_care == null || this.formDetails.health_care == '') {
    this.common.presentToast('Enter your health care');
  }
  
  else if(this.common.validateEmail(this.formDetails.mail)==false){
    this.common.presentToast('Enter valid Email address');
  }
  else if (this.formDetails.mother_fname == null || this.formDetails.mother_fname == '') {
    this.common.presentToast('Enter your Mother First Name');
  }
  else if (this.formDetails.mother_lname == null || this.formDetails.mother_lname == '') {
    this.common.presentToast('Enter your Mother last Name');
  }
  else if (this.formDetails.father_fname == null || this.formDetails.father_fname == '') {
    this.common.presentToast('Enter your Father First Name');
  }
  else if (this.formDetails.father_lname == null || this.formDetails.father_lname == '') {
    this.common.presentToast('Enter your father last name');
  }
  else if (this.formDetails.m_phone == null || this.formDetails.m_phone == '') {
    this.common.presentToast('Enter your Mother Phone number');
  }
  else if (this.formDetails.m_phone == null || this.formDetails.m_phone== '') {
    this.common.presentToast('Enter your Father Phone number');
  }
  else if (this.formDetails.emergency_fname == null || this.formDetails.emergency_fname == '') {
    this.common.presentToast('Enter your Emergency');
  }
  else if (this.formDetails.emergency_lname == null || this.formDetails.emergency_lname == '') {
    this.common.presentToast('Enter your Emergency last Name');
  }
  else if (this.formDetails.emergency_phone == null || this.formDetails.emergency_phone == '') {
    this.common.presentToast('Enter your Emergency Phone Number');
  }
  else if (this.formDetails.physician_fname == null || this.formDetails.physician_fname == '') {
    this.common.presentToast('Enter your physician first name');
  }
  else if (this.formDetails.physician_lname == null || this.formDetails.physician_lname == '') {
    this.common.presentToast('Enter your physician last name');
  }
  else if (this.formDetails.physician_clinic== null || this.formDetails.physician_clinic == '') {
    this.common.presentToast('Enter your physician clinic');
  }
  else if (this.formDetails. clinic_phone== null || this.formDetails. clinic_phone == '') {
    this.common.presentToast('Enter your clinic phone');
  }
  else if (this.formDetails.dentist_fname== null || this.formDetails.dentist_fname == '') {
    this.common.presentToast('Enter your dentist first name');
  }
  else if (this.formDetails.dentist_lname== null || this.formDetails.dentist_lname == '') {
    this.common.presentToast('Enter your dentist last name');
  }
  else if (this.formDetails.dental_phone== null || this.formDetails.dental_phone == '') {
    this.common.presentToast('Enter your dental phone number');
  }
  else if (this.formDetails.Previous_history== null || this.formDetails.Previous_history== '') {
    this.common.presentToast('Choose the Previous History');
  }
  else if (this.formDetails.Fainting_episodes== null || this.formDetails.Fainting_episodes== '') {
    this.common.presentToast('Choose Fainting Episodes');
  }
  else if (this.formDetails.epileptic== null || this.formDetails.epileptic== '') {
    this.common.presentToast('Choose epileptic ');
  }
  else if (this.formDetails.lenses_shatter== null || this.formDetails.lenses_shatter== '') {
    this.common.presentToast('choose lenses shatter');
  }
  else if (this.formDetails.wears_contact== null || this.formDetails.wears_contact== '') {
    this.common.presentToast('Enter Wears contact lenses');
  }
  else if (this.formDetails.wears_dental== null || this.formDetails.wears_dental== '') {
    this.common.presentToast('Enter wears_dental');
  }
  else if (this.formDetails.hearing_problem== null || this.formDetails.hearing_problem== '') {
    this.common.presentToast('Enter hearing_problem');
  }
  else if (this.formDetails.asthma== null || this.formDetails.asthma== '') {
    this.common.presentToast('Enter asthma');
  }
  else if (this.formDetails.trouble_breathing== null || this.formDetails.trouble_breathing== '') {
    this.common.presentToast('Enter trouble_breathing');
  }
  else if (this.formDetails.heart_condition== null || this.formDetails.heart_condition== '') {
    this.common.presentToast('Enter heart_condition');
  }
  else if (this.formDetails.diabetic== null || this.formDetails.diabetic== '') {
    this.common.presentToast('Enter diabetic');
  }
  else if (this.formDetails.diabetic_type== null || this.formDetails.diabetic_type== '') {
    this.common.presentToast('Enter diabetic_type');
  }
  else if (this.formDetails.current_medications== null || this.formDetails.current_medications== '') {
    this.common.presentToast('Enter current_medications');
  }
  else if (this.formDetails.allergies== null || this.formDetails.allergies== '') {
    this.common.presentToast('Enter allergies');
  }
  else if (this.formDetails.medical_information== null || this.formDetails.medical_information== '') {
    this.common.presentToast('Enter medical_information');
  }
  else if (this.other_value== null || this.other_value.purpose== '') {
    this.common.presentToast('Enter purpose');
  }
  else if (this.formDetails.unlisted_health== null || this.formDetails.unlisted_health== '') {
    this.common.presentToast('Enter unlisted_health');
  }
  else if (this.formDetails.heart_conditionrequired_medical== null || this.formDetails.heart_conditionrequired_medical== '') {
    this.common.presentToast('Enter heart_conditionrequired_medical');
  }
  else if (this.formDetails.injuries== null || this.formDetails.injuries== '') {
    this.common.presentToast('Enter injuries');
  }
  else if (this.formDetails.admitted_to_hospital== null || this.formDetails.admitted_to_hospital== '') {
    this.common.presentToast('Enter admitted_to_hospital');
  }
  else if (this.formDetails.surgery== null || this.formDetails.surgery== '') {
    this.common.presentToast('Enter your surgery');
  }
  else if (this.formDetails.list_the_body== null || this.formDetails.list_the_body== '') {
    this.common.presentToast('Enter list_the_body');
  }
  else if (this.formDetails.vaccinations== null || this.formDetails.vaccinations== '') {
    this.common.presentToast('Enter vaccinations');
  }
  else if (this.formDetails.tetanus== null || this.formDetails.tetanus== '') {
    this.common.presentToast('Enter tetanus');
  }
  else if (this.formDetails.hepatitis== null || this.formDetails.hepatitis== '') {
    this.common.presentToast('Enter hepatitis');
  }
  else if (this.formDetails.medications== null || this.formDetails.medications== '') {
    this.common.presentToast('Enter medications');
  }
  else if (this.formDetails.allergies_list== null || this.formDetails.allergies_list== '') {
    this.common.presentToast('Enter allergies_list');
  }
  else if (this.formDetails.medical_conditions== null || this.formDetails.medical_conditions== '') {
    this.common.presentToast('Enter medical_conditions');
  }
  else if (this.formDetails.current_injuries== null || this.formDetails.current_injuries== '') {
    this.common.presentToast('Enter current_injuries');
  }
  else if (this.formDetails.info_questions== null || this.formDetails.info_questions== '') {
    this.common.presentToast('Enter info_questions');
  }
  else if (this.formDetails.legal_fname== null || this.formDetails.legal_fname== '') {
    this.common.presentToast('Enter legal_fname');
  }
  else if (this.formDetails.legal_lname== null || this.formDetails.legal_lname== '') {
    this.common.presentToast('Enter legal_lname');
  }
  else if (this.isSignatureEmpty()) {
    this.common.presentToast('Enter your Sign');
    return;
  }

 
    else{
     
      {
        const formData = {
          first_name: this.formDetails.first_name,
          last_name: this.formDetails.last_name,
          birthday: this.formDetails.birthday,
          first_line: this.formDetails.first_line,
          second_line: this.formDetails.second_line,
          city: this.formDetails.city,
          province: this.formDetails.province,
          postcode: this.formDetails.postcode,
          phone: this.formDetails.phone,
          health_care: this.formDetails.health_care,
          mail: this.formDetails.mail,
          mother_fname: this.formDetails.mother_fname,
          mother_lname: this.formDetails.mother_lname,
          father_fname: this.formDetails.father_fname,
          father_lname: this.formDetails.father_lname,
          m_phone: this.formDetails.m_phone,
          f_phone: this.formDetails.f_phone,
          emergency_fname: this.formDetails.emergency_fname,
          emergency_lname: this.formDetails.emergency_lname,
          emergency_phone: this.formDetails.emergency_phone,
          physician_fname: this.formDetails.physician_fname,
          physician_lname: this.formDetails.physician_lname,
          physician_clinic: this.formDetails.physician_clinic,
          clinic_phone: this.formDetails.clinic_phone,
          dentist_fname: this.formDetails.dentist_fname,
          dentist_lname: this.formDetails.dentist_lname,
          dental_clinic: this.formDetails.dental_clinic,
          dental_phone: this.formDetails.dental_phone,
          Previous_history: this.formDetails.Previous_history,
          Fainting_episodes: this.formDetails.Fainting_episodes,
          epileptic: this.formDetails.epileptic,
          wears_glasses: this.formDetails.wears_glasses,
          lenses_shatter: this.formDetails.lenses_shatter,
          wears_contact: this.formDetails.wears_contact,
          wears_dental: this.formDetails.wears_dental,
          hearing_problem: this.formDetails.hearing_problem,
          asthma: this.formDetails.asthma,
          trouble_breathing: this.formDetails.trouble_breathing,
          heart_condition: this.formDetails.heart_condition,
          diabetic: this.formDetails.diabetic,
          diabetic_type: this.formDetails.diabetic_type,
          current_medications: this.formDetails.current_medications,
          allergies: this.formDetails.allergies,
          medical_information: this.formDetails.medical_information,
          purpose: this.other_value,
          unlisted_health: this.formDetails.unlisted_health,
          required_medical: this.formDetails.heart_conditionrequired_medical,
          injuries: this.formDetails.injuries,
          admitted_to_hospital: this.formDetails.admitted_to_hospital,
          surgery: this.formDetails.surgery,
          list_the_body: this.formDetails.list_the_body,
          vaccinations: this.formDetails.vaccinations,
          tetanus: this.formDetails.tetanus,
          hepatitis: this.formDetails.hepatitis,
          medications: this.formDetails.medications,
          allergies_list: this.formDetails.allergies_list,
          medical_conditions: this.formDetails.medical_conditions,
          current_injuries: this.formDetails.current_injuries,
          info_questions: this.formDetails.info_questions,
          legal_fname: this.formDetails.legal_fname,
          legal_lname: this.formDetails.legal_lname,
          signing: this.formDetails.signing,
          sign:this.img,
          referencecode:this.generateReferenceCode()
          
        
          
        };
        console.log(formData,"formdata");
       const medical_deatails = JSON.stringify(formData);
       console.log(medical_deatails,"data");
        
        this.web.postData('medical_form', {medical_deatails} ).then(res=>{
          if(res.status=='200'){
            
            const myCompDialog = this.dialog.open(medicalpopup, { data: { referencecode: formData.referencecode } });

          
              myCompDialog.afterClosed().subscribe((res) => {
                this.formDetails="";
                this.clear();
                // Data back from dialog
                console.log(formData.referencecode, "formmmmm");
              });

            console.log("FAillllll");
          //  this.common.presentToast(res.error);
          //   localStorage.setItem('divinkUserDetails', JSON.stringify(res.data));
          }else{
            console.log("FAillllll");
            this.common.presentToast(res.error);
          }
         },err=>{
          this.common.presentToast('Connection Error');
        })
      }
    }
    
  }
  

  ngOnInit(): void {
   
  }
}