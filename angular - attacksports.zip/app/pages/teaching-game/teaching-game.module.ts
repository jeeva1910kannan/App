import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TeachingGameRoutingModule } from './teaching-game-routing.module';
import { TeachingGameComponent } from './teaching-game.component';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'


@NgModule({
  declarations: [TeachingGameComponent],
  imports: [
    CommonModule,
    TeachingGameRoutingModule,
    HeaderFooterModule
  ]
})
export class TeachingGameModule { }
