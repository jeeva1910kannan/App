import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeachingGameComponent } from './teaching-game.component';

describe('TeachingGameComponent', () => {
  let component: TeachingGameComponent;
  let fixture: ComponentFixture<TeachingGameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeachingGameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeachingGameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
