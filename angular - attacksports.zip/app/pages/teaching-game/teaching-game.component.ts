import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-teaching-game',
  templateUrl: './teaching-game.component.html',
  styleUrls: ['./teaching-game.component.scss']
})
export class TeachingGameComponent implements OnInit {

  games: any;
  base_url: string = environment.base_url;
  constructor(private web: WebService,private  common:CommonService  ) { }

  ngOnInit(): void {
    this.getcovidcontent();
  }
  getcovidcontent() {
    this.web.getData('getAllTeachingGames').then((res) => {
      if (res.status == '200') {
        this.games = res.data;
       
        console.log(this.games, "this.covidcontentgames");
       

      }
      
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

}
