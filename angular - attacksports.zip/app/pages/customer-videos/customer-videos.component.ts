import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { CommonService } from '../services/common.service';
import { environment } from 'src/environments/environment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';

@Component({
  selector: 'app-customer-videos',
  templateUrl: './customer-videos.component.html',
  styleUrls: ['./customer-videos.component.scss']
})
export class CustomerVideosComponent implements OnInit {

  base_url: string = environment.base_url;
  customervideo: any = [];
  litedesc: string;
  videodate: any;
  currentPlayingVideo: HTMLVideoElement;
  more: any = [];
  my_account:boolean;
  trainee:boolean;

  constructor(private activatedroute: ActivatedRoute,
    private web: WebService,
    private common: CommonService,
    public dialog: MatDialog,
    public location:Location) { }

  ngOnInit(): void {
    this.getselectedCustomerVideos(this.activatedroute.params['_value'].id);
  }

  async getselectedCustomerVideos(cust_id) {
    let data = {
      customer_id: cust_id,
      instructor_id: localStorage.getItem("UserId"),
    }
    await this.web.postData("getselectedCustomerVideos", data).then((res) => {
      if (res.status == "200") {
        this.customervideo = res.data;
        console.log(this.customervideo);
      } else {
        this.customervideo = [];
        console.log(this.customervideo);
      }
    }, err => {
      this.common.presentToast(err);
    })
  }

  async finddesc(desc: any) {
    this.litedesc = desc.substring(0, 170) + '....';
  }

  async findstart(startdate: any) {
    this.videodate = new Date(startdate * 1000);
  }

  onPlayingVideo(event) {
    console.log("this" + event);
    event.preventDefault();
    // play the first video that is chosen by the user
    if (this.currentPlayingVideo === undefined) {
      this.currentPlayingVideo = event.target;
      this.currentPlayingVideo.play();
    } else {
      // if the user plays a new video, pause the last one and play the new one
      if (event.target !== this.currentPlayingVideo) {
        this.currentPlayingVideo.pause();
        this.currentPlayingVideo = event.target;
        this.currentPlayingVideo.play();
      }
    }
  }

  readmore(val) {
    this.more = [];
    this.more[val] = true;
  }
  readless(val) {
    this.more = [];
    this.more[val] = false;
  }

  openModal(current_id) {
    this.dialog.open(comment, {
      data: {
        sender_id: localStorage.getItem("UserId"),
        receiver_id: current_id
      }
    })
  }

  back(){
  this.location.back();
  }

}

@Component({
  selector: 'comment',
  templateUrl: 'comment.html',
  styleUrls: ['./comment.component.scss']
})
export class comment implements OnInit {

  video_details: any;
  alldetais: any;
  fetchingStatus: boolean;
  title: string;
  type: boolean | undefined;
  message_enable: boolean = true;
  CustomersForm: any = {};
  messagelist: any = [];
  base_url:string = environment.base_url;
  replymsg:any = [];
  message = []; 
  sender_id:any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: comment,
    public common: CommonService,
    public web: WebService,
    public datePipe: DatePipe,
    public dialog: MatDialog) {

    this.fetchingStatus = true;
    this.alldetais = this.data;
    this.video_details = this.alldetais.receiver_id;
    this.web.postData('getvideocomment', this.video_details).then((res) => {
      if (res.status == '200') {
        this.messagelist = res.data;
       
      } else {
        console.log(res.error);
      }
      setTimeout(() => {
        this.fetchingStatus = false;
        // this.continueregister = true;
      }, Math.random() * 2000 + 2000);
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
  }

  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  
  ngOnInit(): void {
    this.alldetais = this.data;
    this.video_details = this.alldetais.receiver_id;
    this.title = this.video_details.title;
    this.sender_id=localStorage.getItem("UserId")
    // this.fetchingStatus = false;
  }

  messagecount() {
    console.log('ewr');
    this.message_enable = true;
    let str = this.CustomersForm.message.trim();
    console.log(str);
    if (str) {
      this.message_enable = false;
      console.log(this.message_enable);
    }

  }
  close(){
    this.dialog.closeAll();
  }

  getdate(date)
  {
  
    return this.datePipe.transform(new Date(date*1000),'short');
  
  }

  onAddMessage() {

    if(this.CustomersForm.message == "" || this.CustomersForm.message == undefined){
      console.log("Type something...");
    }else{

    let data = {
      video_id: this.video_details.web_id,
      sender_id: localStorage.getItem('UserId'),
      receiver_id: this.video_details.customer_id,
      message: this.CustomersForm.message,
      date: Math.round(new Date().getTime()/1000)
    }
    console.log(data);
  
    this.messagelist.push(data);
    this.CustomersForm.message = "";
    this.web.postData("postinstructorVideocomments", data).then((res) => {
      if (res.status == '200') {
        this.CustomersForm.message = "";

      } else {

      }
    }, err => {
      console.log(err);
      console.log(":)")
    }) 
  }
  }

}
