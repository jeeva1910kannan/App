import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerVideosComponent } from './customer-videos.component';

describe('CustomerVideosComponent', () => {
  let component: CustomerVideosComponent;
  let fixture: ComponentFixture<CustomerVideosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerVideosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerVideosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
