import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerVideosComponent } from './customer-videos.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { CustomerVideosRoutingModule } from './customer-videos.routing.module';
import {MatPaginatorModule} from '@angular/material/paginator';
import { comment } from './customer-videos.component';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";


@NgModule({
  declarations: [
    CustomerVideosComponent,
    comment,
  
  ],
  imports: [
    CommonModule,
    HeaderFooterModule,
    CustomerVideosRoutingModule,
    MatPaginatorModule,
    NgxSkeletonLoaderModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class CustomerVideosModule { }
