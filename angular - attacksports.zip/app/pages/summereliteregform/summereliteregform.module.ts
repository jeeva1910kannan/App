import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SummereliteregformComponent } from './summereliteregform.component';
import { SummereliteregformRoutingModule } from './summereliteregform.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CurrencyPipe } from '@angular/common';


@NgModule({
  declarations: [
    SummereliteregformComponent
  ],
  imports: [
    CommonModule,
    SummereliteregformRoutingModule,
    HeaderFooterModule,
    ReactiveFormsModule,
    FormsModule,
    MatRadioModule,
    MatCheckboxModule
   
  ],
  providers: [CurrencyPipe],
})
export class SummerEliteCampsModule { }
