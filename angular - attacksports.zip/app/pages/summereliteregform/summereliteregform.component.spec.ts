import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SummereliteregformComponent } from './summereliteregform.component';

describe('SummereliteregformComponent', () => {
  let component: SummereliteregformComponent;
  let fixture: ComponentFixture<SummereliteregformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SummereliteregformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SummereliteregformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
