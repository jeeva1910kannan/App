import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../services/common.service';

@Injectable({
  providedIn: 'root'
})
export class SummereliteRegistrationService {
  private campregisterform: FormGroup;

  constructor(private fb: FormBuilder, private toast: ToastrService,  private common:CommonService) { 
    this.campregisterform = this.fb.group({

      radiobtn1 : ['', {validators: Validators.compose([Validators.required])}],
      U17M: ['', {validators: Validators.compose([Validators.required])}],
      U15M: ['', {validators: Validators.compose([Validators.required])}],
      U13M : ['', {validators: Validators.compose([Validators.required])}],
      U11M: ['', {validators: Validators.compose([Validators.required])}],
      U15F: ['', {validators: Validators.compose([Validators.required])}],
      U13F: ['', {validators: Validators.compose([Validators.required])}],
      ath_fname: ['', {validators: Validators.compose([Validators.required])}],
      ath_lname: ['', {validators: Validators.compose([Validators.required])}],
      ath_phno: ['', {validators: Validators.compose([Validators.required])}],
      ath_add: ['', {validators: Validators.compose([Validators.required])}],
      month: ['', {validators: Validators.compose([Validators.required])}],
      day: ['', {validators: Validators.compose([Validators.required])}],
      year: ['', {validators: Validators.compose([Validators.required])}],
      gender: ['', {validators: Validators.compose([Validators.required])}],
      jsize: ['', {validators: Validators.compose([Validators.required])}],
      cur_ass: ['', {validators: Validators.compose([Validators.required])}],
      exp_div: ['', {validators: Validators.compose([Validators.required])}],
      par_fname: ['', {validators: Validators.compose([Validators.required])}],
      par_lname: ['', {validators: Validators.compose([Validators.required])}],
      par_firstemail: ['', {validators: Validators.compose([Validators.required])}],
      par_secondemail: ['', {validators: Validators.compose([Validators.required])}],
      par_phno: ['', {validators: Validators.compose([Validators.required])}],
      country: ['', {validators: Validators.compose([Validators.required])}],
      par_address: ['', {validators: Validators.compose([Validators.required])}],
      par_city: ['', {validators: Validators.compose([Validators.required])}],
      province: ['', {validators: Validators.compose([Validators.required])}],
      par_postalcode: ['', {validators: Validators.compose([Validators.required])}],
      totalAmount: ['', {validators: Validators.compose([Validators.required])}],
      totalGst: ['', {validators: Validators.compose([Validators.required])}],
      payment_method: ['', {validators: Validators.compose([Validators.required])}],
      billing_fname: ['', {validators: Validators.compose([Validators.required])}],
      billing_lname: ['', {validators: Validators.compose([Validators.required])}],
      billing_country: ['', {validators: Validators.compose([Validators.required])}],
      billing_address: ['', {validators: Validators.compose([Validators.required])}],
      billing_city: ['', {validators: Validators.compose([Validators.required])}],
      billing_province: ['', {validators: Validators.compose([Validators.required])}],
      billing_postalcode: ['', {validators: Validators.compose([Validators.required])}],
      billing_email: ['', {validators: Validators.compose([Validators.required])}],
      status: ['', {validators: Validators.compose([Validators.required])}],
      curbilled_date: ['', {validators: Validators.compose([Validators.required])}],
      Ordernumber: ['', {validators: Validators.compose([Validators.required])}],
     
     
  });

}
exportNewForm(){
  return this.campregisterform;
}
}
