import { ChangeDetectorRef, Component, Renderer2, OnInit, ViewChild, ElementRef } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormBuilder, NgForm } from '@angular/forms';
import { SummereliteRegistrationService } from './summerelite-registration.service';
import { MatDialog } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms';
declare var Square: any;
@Component({
  selector: 'app-summereliteregform',
  templateUrl: './summereliteregform.component.html',
  styleUrls: ['./summereliteregform.component.scss']
})

export class SummereliteregformComponent implements OnInit {
  @ViewChild('myForm', { static: true }) form: NgForm;
  card: any;
  myForm: any;
  payments: any;
  campregisterform: FormGroup;
  accesstoken = "EAAAEPJJiem4rJOB_n6eW84Imj-Ypyf_qr37M7gFzeQ0-lDOmbjrKrgCmOuTGDzw";
  applicationId1 = "sandbox-sq0idb-O6e2c7juXuf9P0_gSYn32A";
  locationId1 = "LBWZSZWVJFF4M";
  formDetails: any = {
    customer_id: localStorage.getItem('UserId'),
    
    'radiobtn1 ': '',
    'U17M': '',
    'U15M': '',
    'U13M': '',
    'U11M': '',
    'U15F': '',
    'U13F': '',
    'ath_fname': '',
    'ath_lname': '',
    'ath_phno': '',
    'ath_add': '',
    'month': '',
    'day': '',
    'year': '',
    'gender': '',
    'jsize': '',
    'cur_ass': '',
    'exp_div': '',
    'par_fname': '',
    'par_lname': '',
    'par_firstemail': '',
    'par_secondemail': '',
    'par_phno' : '',
    'country': '',
    'par_address': '',
    'par_city': '',
    'province': '',
    'par_postalcode': '',
    'totalAmount': '',
    'totalGst': '',
    'payment_method': '',
    'billing_fname': '',
    'billing_lname': '',
    'billing_country': '',
     'billing_address':'',
     'billing_city': '',
    'billing_province': '',
    'billing_postalcode': '',
    'billing_email': '',
    'status':''
    
  };
  orderNumber: string;
  paymentContainerVisible: boolean;
  bookeddetails: any;
  isButtondisabled = false;
  isRadioSelected1: boolean;
  isRadioSelected2: boolean;
  isRadioSelected3: boolean;
  isRadioSelected4: boolean;
  isRadioSelected5: boolean;
  isRadioSelected6: boolean;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  eliteamount: any;
  resultcontents: any;
  acceptTerms: boolean;
  userDetailsTemp: any;

  constructor(private renderer: Renderer2, private router: Router,
    private toastr: ToastrService, private web: WebService,
    private sanitizer: DomSanitizer, private cdr: ChangeDetectorRef,
    private common: CommonService, private formBuilder: FormBuilder,
    private tableService: SummereliteRegistrationService,
    public dialog: MatDialog) { 
      this.campregisterform = this.tableService.exportNewForm();
    }

  ngOnInit(): void {
    this.getbookedelite();
    this.getsummerelitedetails();
    this.getResultContentofelite();
    this.generateOrderNumber();
  }

  getRadio1(){
    this.isRadioSelected1 =true;
  }
  getRadio2(){
    this.isRadioSelected2 =true;
  }
  getRadio3(){
    this.isRadioSelected3 =true;
  }
  getRadio4(){
    this.isRadioSelected4 =true;
  }
  getRadio5(){
    this.isRadioSelected5 =true;
  }
  getRadio6(){
    this.isRadioSelected6 =true;
  }

  getClear1(){
    this.formDetails.U17M='';
    this.isRadioSelected1 =false;
  }
  getClear2(){
    this.formDetails.U15M='';
    this.isRadioSelected2 =false;
  }
  getClear3(){
    this.formDetails.U13M='';
    this.isRadioSelected3 =false;
  }
  getClear4(){
    this.formDetails.U11M='';
    this.isRadioSelected4 =false;
  }
  getClear5(){
    this.formDetails.U15F='';
    this.isRadioSelected5 =false;
  }
  getClear6(){
    this.formDetails.U13F='';
    this.isRadioSelected6 =false;
  }
  getbookedelite() {
    let data = {

      customer_id: localStorage.getItem('UserId'),
    }

    this.web.postData('getbookedelite', data).then((res) => {
      if (res.status == '200') {
       
        this.bookeddetails = res.data;
        console.log(this.bookeddetails, "bookeddetails");
        console.log("this.formDetailsssssssssssss",this.formDetails);
        

      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

  getsummerelitedetails(){
    // let formData = {
    //   web_id:this.userid,
     
    // }
    
    this.web.postData('getsummerelitedetails',this.formDetails).then((res) => {
        if (res.status == '200') {
          this.eliteamount = res.data;
         
         console.log(this.eliteamount,"eliteeeamounttttttttttttt");
          this.eliteamount.map((res, i) => {
          console.log(res.totalAmount,'67667')
          localStorage.setItem('eliteamount',res.totalAmount);
          localStorage.setItem('gstamount',res.billing_cvv);
          localStorage.getItem('UserId')
          
         });
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }

  getResultContentofelite() {
    this.web.getData('getResultContentofelite').then((res) => {
      if (res.status == '200') {
        this.resultcontents = res.data;
        console.log("resultcontents", this.resultcontents);
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }



  onPaymentMethodChange(event:any): void {
    console.log("Selected Payment Method:", event);
    this.formDetails.payment_method = event.value;
    if (this.formDetails.payment_method === 'Credit Card') {
      this.loadScript();
      this.formDetails.status = 'Active'; // Initialize the billing_cardno for Credit Card
    // Set billing as active for Credit Card
  } else if (this.formDetails.payment_method === 'E-Transfer (or Cash)') {
    this.paymentContainerVisible = false;
    console.log("E-Transfer (or Cash) selected");
    this.formDetails.status = 'InActive'; // Set billing_cardno to 'InActive' for E-Transfer (or Cash)
    // Set billing as inactive for E-Transfer (or Cash)
  }
  }

  generateOrderNumber() {
    console.log("HIOIIIIIIIIIIIIIIIIII")
    const randomNumber = Math.floor(Math.random() * 1000000).toString();
    const timestamp = Date.now().toString();
    this.orderNumber = randomNumber + timestamp;
    
    // Get the current date and format it to "date-month-year" format
    const currentDate = new Date();
    const dateFormatted = currentDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    this.formDetails.curbilled_date = dateFormatted;
  
    this.formDetails.Ordernumber = this.orderNumber;
    console.log('orderNumber', this.orderNumber);
  }

  async  loadScript() {
   
   
    // Your SqPaymentForm script here
  
    var applicationId = "sandbox-sq0idb-O6e2c7juXuf9P0_gSYn32A";
  
    // Set the location ID
    var locationId = "LQC04P5CAFGVD";
  
    this.payments = Square.payments(applicationId, locationId);
  
    this.card = await this.payments.card();
  
    await this.card.attach('#card-container');
  
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
    const form = document.querySelector('#card-payment') as HTMLFormElement;
  
    form.addEventListener('submit', async (event: Event) => {
  
       event.preventDefault();
  
       const result = await this.card.tokenize(); // the card nonce
  
    });
    console.log("result");
    // onCancel: () => {
    //   this.common.presentToast('Payment cancelled.');
    //   console.log("OnCancel");
    // }
    
  }

  
  
  // Call the method to generate and assign orderNumber before sending the formDetails in the API request
  
  async makePayment() {
    
   
    const statusContainer = document.getElementById('payment-status-container');
    try {
      const result = await this.card.tokenize();
      if (result.status === 'OK') {
        this.isButtondisabled = true;

        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
       
        let data = {
        
          
          customer_id: localStorage.getItem('UserId'),
          amount:localStorage.getItem('eliteamount'),
          gstamount:localStorage.getItem('gstamount'),
          ath_fname:localStorage.getItem('ath_fname'),
          ath_lname:localStorage.getItem('ath_lname'),
          par_fname:localStorage.getItem('par_fname'),
          par_lname:localStorage.getItem('par_lname'),
          par_firstemail:localStorage.getItem('par_firstemail'),
          par_secondemail:localStorage.getItem('par_secondemail'),
          par_address:localStorage.getItem('par_address'),
          par_city:localStorage.getItem('par_city'),
          par_phno:localStorage.getItem('par_phno'),
          par_postalcode:localStorage.getItem('par_postalcode'),
          ath_desiredsports:localStorage.getItem('ath_desiredsports'),
          ath_careno:localStorage.getItem('ath_careno'),
          ath_allergiesandfood:localStorage.getItem('ath_allergiesandfood'),
          ath_withpermission:localStorage.getItem('ath_withpermission'),
          ath_otherinfo:localStorage.getItem('ath_otherinfo'),
          radiobtn1:localStorage.getItem('radiobtn1'),
          month:localStorage.getItem('month'),
          day:localStorage.getItem('day'),
          year:localStorage.getItem('year'),
          tsize:localStorage.getItem('tsize'),
          country:localStorage.getItem('country'),
          province:localStorage.getItem('province'),
          billing_fname:localStorage.getItem('billing_fname'),
          billing_lname:localStorage.getItem('billing_lname'),
          payment_method:localStorage.getItem('payment_method'),
          billing_country:localStorage.getItem('billing_country'),
          billing_address:localStorage.getItem('billing_address'),
          billing_city:localStorage.getItem('billing_city'),
          billing_province:localStorage.getItem('billing_province'),
          billing_postalcode:localStorage.getItem('billing_postalcode'),
          billing_email:localStorage.getItem('billing_email'),
          totalAmount:localStorage.getItem('totalAmount'),
        
        
     
     

      
          transaction_response: 'details',
          transaction_method: 'card',
          payment_status: 'success',
          paymentToken: result.token,
          locationId: this.locationId1,
          accesstoken: this.accesstoken
          
        };
       
        this.web.postData('addregistrationelitecamps', data).then(
         
          (res) => {
            if (res.status == '200') {
              this.common.presentToast('Payment Successfully');
             
              this.isButtondisabled = false;
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              });
              //this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
              this.isButtondisabled = false;
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
            this.isButtondisabled = false;
          });

        
    
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }
 
  async submitForm(form: any) {

   
    if (this.formDetails.radiobtn1 == null || this.formDetails.radiobtn1 == '') {
      this.common.presentToast('Enter your Registration Option');
    }
    else if (this.formDetails.ath_fname == null || this.formDetails.ath_fname == '') {
      this.common.presentToast('Enter your First name');
    }
    else if (this.formDetails.ath_lname == null || this.formDetails.ath_lname == '') {
      this.common.presentToast('Enter your last name');

     } 
      //===============
    else if(this.formDetails.ath_phno==null || this.formDetails.ath_phno=='' ||this.formDetails.ath_phno.trim().length==0){
      this.common.presentToast('Enter your Phone Number');
     }
     else if(this.common.validateMobileNumber(this.formDetails.ath_phno)== false){
      this.common.presentToast('Enter Valid Phone Number');
     }
    //=================
     else if (this.formDetails.ath_add == null || this.formDetails.ath_add == '') {
      this.common.presentToast('Enter your last name');

     } 
    else if (this.formDetails.month == null || this.formDetails.month == '') {
      this.common.presentToast('Enter your Birthday Month')
    }
    else if (this.formDetails.day == null || this.formDetails.day == '') {
      this.common.presentToast('Enter your Birthday Date')
    }
    else if (this.formDetails.year == null || this.formDetails.year == '') {
      this.common.presentToast('Enter your Birthday Year')
    }
    else if (!this.formDetails.gender || this.formDetails.gender === '') {
      this.common.presentToast('Enter your T-size');
    }
    else if (!this.formDetails.jsize || this.formDetails.jsize === '') {
      this.common.presentToast('Enter your Jersey Size');
    }
    else if (!this.formDetails.cur_ass || this.formDetails.cur_ass === '') {
      this.common.presentToast('Enter your Current QUADRANT Association');
    }
    else if (!this.formDetails.exp_div || this.formDetails.exp_div === '') {
      this.common.presentToast('Enter your Expected Division');
    }
    else if (this.formDetails.par_fname == null || this.formDetails.par_fname == '') {
      this.common.presentToast('Enter your Parent First name');
    }
    else if (this.formDetails.par_lname == null || this.formDetails.par_lname == '') {
      this.common.presentToast('Enter your Parent Last name');
    }
    

    else if (this.formDetails.par_firstemail == null || this.formDetails.par_firstemail == '') {
      this.common.presentToast('Enter your parent first mail');
    }
    else if (this.formDetails.par_secondemail == null || this.formDetails.par_secondemail == '') {
      this.common.presentToast('Enter your parent second mail');
    }
    //===============
    else if(this.formDetails.par_phno==null || this.formDetails.par_phno=='' ||this.formDetails.par_phno.trim().length==0){
        this.common.presentToast('Enter Parent Phone Number');
       }
       else if(this.common.validateMobileNumber(this.formDetails.par_phno)== false){
        this.common.presentToast('Enter Valid Phone Number');
       }
      //=================
    else if (this.formDetails.country == null || this.formDetails.country == '') {
      this.common.presentToast('Enter your Parent Country');
    }
    else if (this.formDetails.par_address == null || this.formDetails.par_address == '') {
      this.common.presentToast('Enter your parent address');
    }
    else if (this.formDetails.par_city == null || this.formDetails.par_city == '') {
      this.common.presentToast('Enter your parent city');
    }
    else if (this.formDetails.province == null || this.formDetails.par_city == '') {
      this.common.presentToast('Enter your parent province');
    }
    //===============
    else if (this.formDetails.par_postalcode == null || this.formDetails.par_postalcode == '') {
        this.common.presentToast('Enter the Postal code');
       }
       else if(this.common.validateNumber(this.formDetails.par_postalcode)==false){
        this.common.presentToast('Enter valid postal code');
       }
   
    else if (this.formDetails.payment_method == null || this.formDetails.payment_method == '') {
      this.common.presentToast('Payment is Required');
    }
    
    else if (this.formDetails.billing_fname == null || this.formDetails.billing_fname == '') {
      this.common.presentToast('Enter your Billing First Name ')
    }
    else if (this.formDetails.billing_lname == null || this.formDetails.billing_lname == '') {
      this.common.presentToast('Enter your billing Last Name ')
    }

    else if (this.formDetails.billing_country == null || this.formDetails.billing_country == '') {
      this.common.presentToast('Enter your   Billing Country ')
    }
    else if (this.formDetails.billing_address == null || this.formDetails.billing_address == '') {
      this.common.presentToast('Enter your Billing Address  ')
    }
    else if (this.formDetails.billing_city == null || this.formDetails.billing_city == '') {
      this.common.presentToast('Enter your Billing City   ')
    }
    else if (this.formDetails.billing_province == null || this.formDetails.billing_province == '') {
      this.common.presentToast('Enter your Billing Province  ')
    }
  
   
    else if (this.formDetails.billing_postalcode == null || this.formDetails.billing_postalcode == '') {
        this.common.presentToast('Enter the  Billing Postal code');
       }
       else if(this.common.validateNumber(this.formDetails.billing_postalcode)==false){
        this.common.presentToast('Enter valid postal code');
       }
     
    else if (this.formDetails.billing_email == null || this.formDetails.billing_email == '') {
      this.common.presentToast('Enter your Billing Email ')
    }
    else if (this.common.validateEmail(this.formDetails.par_secondemail) == false) {
      this.common.presentToast('Enter valid Email address');
    }
   
    else if (this.acceptTerms == false) {
         this.common.presentToast('Accept the Terms and Conditions');
      }
      

  else{
    localStorage.setItem('ath_fname', this.formDetails.ath_fname);
    localStorage.setItem('ath_lname', this.formDetails.ath_lname);
    localStorage.setItem('par_fname', this.formDetails.par_fname);
    localStorage.setItem('par_lname', this.formDetails.par_lname);
    localStorage.setItem('par_firstemail', this.formDetails.par_firstemail);
    localStorage.setItem(' par_secondemail', this.formDetails.par_secondemail);
    localStorage.setItem('par_address', this.formDetails.par_address);
    localStorage.setItem(' par_city', this.formDetails.par_city);
    localStorage.setItem('par_phno', this.formDetails.par_phno);
    localStorage.setItem(' par_postalcode', this.formDetails.par_postalcode);
    localStorage.setItem('ath_desiredsports', this.formDetails.ath_desiredsports);
    localStorage.setItem('ath_careno', this.formDetails.ath_careno);
    localStorage.setItem('ath_allergiesandfood', this.formDetails.ath_allergiesandfood);
    localStorage.setItem('ath_withpermission', this.formDetails.ath_withpermission);
    localStorage.setItem('ath_otherinfo', this.formDetails.ath_otherinfo);
    localStorage.setItem('radiobtn1', this.formDetails.radiobtn1);
    localStorage.setItem('month', this.formDetails.month);
    localStorage.setItem('day', this.formDetails.day);
    localStorage.setItem('year', this.formDetails.year);
    localStorage.setItem('tsize', this.formDetails.tsize);
    localStorage.setItem('country', this.formDetails.country);
    localStorage.setItem('province', this.formDetails.province);
    localStorage.setItem('billing_fname', this.formDetails.billing_fname);
    localStorage.setItem('billing_lname', this.formDetails.billing_lname);
    localStorage.setItem('payment_method', this.formDetails.payment_method);
    localStorage.setItem('billing_cardno', this.formDetails.billing_cardno);
    localStorage.setItem('billing_country', this.formDetails.billing_country);
    localStorage.setItem('billing_address', this.formDetails.billing_address);
    localStorage.setItem('billing_city', this.formDetails.billing_city);
    localStorage.setItem('billing_province', this.formDetails.billing_province);
    localStorage.setItem('billing_postalcode', this.formDetails.billing_postalcode);
    localStorage.setItem('billing_email', this.formDetails.billing_email);
    
    localStorage.setItem('exp_month', this.formDetails.exp_month);
    localStorage.setItem('billing_cvv', this.formDetails.billing_cvv);
    localStorage.setItem('session1Option', this.formDetails.session1Option);
    localStorage.setItem('session2Option', this.formDetails.session2Option);
    localStorage.setItem('session3Option', this.formDetails.session3Option);
    

    this.web.postData('summereliteregform', this.formDetails).then(async res => {

      
      if (res.status == '200') {
        console.log("statusssssssss",res.status);
        console.log("APIIIIIIthis.formDetailsssssssssssss",this.formDetails);
      
        this.formDetails = {
        
     
         
     'radiobtn1 ': '',
     'U17M': '',
     'U15M': '',
     'U13M': '',
     'U11M': '',
     'U15F': '',
     'U13F': '',
     'ath_fname': '',
     'ath_lname': '',
     'ath_phno': '',
     'ath_add': '',
     'month': '',
     'day': '',
     'year': '',
     'gender': '',
     'jsize': '',
     'cur_ass': '',
     'exp_div': '',
     'par_fname': '',
     'par_lname': '',
     'par_firstemail': '',
     'par_secondemail': '',
     'par_phno' : '',
     'country': '',
     'par_address': '',
     'par_city': '',
     'province': '',
     'par_postalcode': '',
     'totalAmount': '',
     'totalGst': '',
     'payment_method': '',
     'billing_fname': '',
     'billing_lname': '',
     'billing_country': '',
      'billing_address':'',
      'billing_city': '',
     'billing_province': '',
     'billing_postalcode': '',
     'billing_email': '',
     'status':''
     

         
          };
          this.common.presentToast('Updated Sucessfully');
         
                    this.makePayment();  
         console.log("res.data",res.data);
         
        //  this.router.navigate(['/summercampsformconfo'], {
        //          queryParams: { webId: res.data}
        //         }); 
        
        
      }
      else{
        
       this.common.presentToast('Connection Error')
      }
     
    }
   
    )
   // form.resetForm();
  
  }

}
}
