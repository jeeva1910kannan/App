import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SummereliteregformComponent } from './summereliteregform.component';
//import { SummercampsformconfoComponent } from '../summercampsformconfo/summercampsformconfo.component';

const routes: Routes = [
  {
    path: '',
    component: SummereliteregformComponent
  },
//   {
//       path: "summercampsformconfo/ + webId",
//       component: SummercampsformconfoComponent
//      },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SummereliteregformRoutingModule { }
