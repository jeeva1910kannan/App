// import { TestBed } from '@angular/core/testing';

// import { SummereliteRegistrationService } from './summerelite-registration.service';

// describe('SummereliteRegistrationService', () => {
//   let service: SummereliteRegistrationService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(SummereliteRegistrationService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
