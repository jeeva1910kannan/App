import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-waiver',
  templateUrl: './waiver.component.html',
  styleUrls: ['./waiver.component.scss']
})
export class WaiverComponent implements OnInit {
  userid=localStorage.getItem('UserId');
  

  constructor(private router: Router) {}

redirectToLogin() {
  if(this.userid == 'null'){
  this.router.navigate(['/login']);
  }
  else{
    this.router.navigate(['/participation-waiver']);
  }
}
redirect(){
  if(this.userid == 'null'){
    this.router.navigate(['/login']);
    }
    else{
      this.router.navigate(['/medical-information']);
    }
  }

  
 
  ngOnInit(
    
  ): void {
    console.log(this.userid,"userid");
  }

}
