import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WaiverComponent } from './waiver.component';
import { WaiverRoutingModule } from './waiver.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';

@NgModule({
  declarations: [
    WaiverComponent
  ],
  imports: [
    CommonModule,
    WaiverRoutingModule,
    HeaderFooterModule
  ]
})
export class WaiverModule { }
