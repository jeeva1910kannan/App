import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-attackaughockeycamps',
  templateUrl: './attackaughockeycamps.component.html',
  styleUrls: ['./attackaughockeycamps.component.scss']
})
export class AttackaughockeycampsComponent implements OnInit {
  augusthockeycontents: any[] = [];
  constructor(private web: WebService, private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,private  common:CommonService ) { }

  ngOnInit(): void {
this.getAugustHockeyContents();
  }
  getAugustHockeyContents() {
    this.web.getData('getAugustHockeyContents').then((res) => {
      if (res.status == '200') {
        this.augusthockeycontents = res.data;
       
        console.log(this.augusthockeycontents, "this.augusthockeycontents");
       

      }
      // else {
      // this.bannercontents[1].home_video=null;  
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
}
