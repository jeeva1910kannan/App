// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { AttackaughockeycampsComponent } from './attackaughockeycamps.component';

// describe('AttackaughockeycampsComponent', () => {
//   let component: AttackaughockeycampsComponent;
//   let fixture: ComponentFixture<AttackaughockeycampsComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ AttackaughockeycampsComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AttackaughockeycampsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
