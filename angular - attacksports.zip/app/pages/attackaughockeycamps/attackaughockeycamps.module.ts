import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttackaughockeycampsComponent } from './attackaughockeycamps.component';
import {AttackaughockeycampsRoutingModule} from '../attackaughockeycamps/attackaughockeycamps.routing.module';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'

@NgModule({
  declarations: [
    AttackaughockeycampsComponent
  ],
  imports: [
    CommonModule,
    AttackaughockeycampsRoutingModule,
    HeaderFooterModule
  ],
  exports: [
    AttackaughockeycampsComponent
  ]
})
export class attackaughockeycampsModule { }

