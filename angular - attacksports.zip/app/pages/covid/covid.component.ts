import { Component, OnInit } from '@angular/core';

import { CommonService } from '../services/common.service';
import { WebService } from '../../providers/web.service';

@Component({
  selector: 'app-covid',
  templateUrl: './covid.component.html',
  styleUrls: ['./covid.component.scss']
})
export class CovidComponent implements OnInit {
  covidcontent: any;

  constructor(private web: WebService,private  common:CommonService  ) { }

  ngOnInit(): void {
    this.getcovidcontent();
  }
  getcovidcontent() {
    this.web.getData('getcovidcontent').then((res) => {
      if (res.status == '200') {
        this.covidcontent = res.data;
       
        console.log(this.covidcontent, "this.covidcontent");
       

      }
      
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

}
