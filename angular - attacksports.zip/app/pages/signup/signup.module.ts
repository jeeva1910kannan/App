import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignupComponent } from './signup.component';
import { SignupRoutingModule } from './signup-routing.module';
import { FormsModule } from '@angular/forms';
import {MatTabsModule} from '@angular/material/tabs';
import {MatDialogModule} from '@angular/material/dialog';
import {MatRadioModule} from '@angular/material/radio';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import {MatSelectModule} from '@angular/material/select';
import { RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  declarations: [
    SignupComponent,

  ],
  imports: [
    RecaptchaModule,
    RecaptchaFormsModule,
    CommonModule,
    SignupRoutingModule,
    FormsModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    HeaderFooterModule,
    MatSelectModule,
    MatButtonModule,
  ],
 
})
export class SignupModule { }
