import { Component, OnInit } from '@angular/core';
import { countries } from 'src/app/pages/common/commonjson/country-data-store';
import { languages } from 'src/app/pages/common/commonjson/language';
import { currencies } from 'src/app/pages/common/commonjson/currencies';
import { CommonService } from '../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import {MatDialog} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  public countries: any = countries
  public languages: any = languages
  public currencies: any = currencies
  base_url: string = environment.base_url;
  ententionName: string | undefined;

  loading: boolean;
  profile: string;
  certificate: string;
  constructor(
    private router: Router,
    private web: WebService,
    public common: CommonService,
    public dialog: MatDialog
  ) { }
  userDetails: any = {
  };
  userValidation: any = {
  };
  grecaptcha_val: boolean = false;
  listSite: any;
  captchaResponse: any;
  grecaptcha: any;
  ngOnInit(): void {
  }
  onFileChange(event: any) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      this.onSubmit(files);
    }
  }

  onSubmit(files: any) {
    let d = new Date();
    let n: any = d.valueOf();
    let filename = 'Attack_'+n.toString().substring(4, 8)+files[0].name;

    const formData = new FormData();
    formData.append("file", files[0]);
    formData.append("filename", filename);

    console.log(formData, "formdata")
    console.log(files[0].name, "filename")

    this.loading = true;

    this.web.uploadWebsitePicture(`${this.base_url}restapi/upload_instructor_certificate_file.php?filename=` + filename, formData).subscribe((res: any) => {
      
      if (res.status == '200') {
          this.certificate = filename;

        let data = {
          document: this.base_url+'restapi/uploads/'+filename,
          // type: this.docType,
          // file:this.files[0].name
        }
      } else {
        this.loading = false;
        this.common.presentToast(res.message);
      }
    }, (err) => {
      this.loading = false;
      this.common.presentToast('Connection Error');
    });

  }

  //   let d = new Date();
  //   let n: any = d.valueOf();
  //   let fname = file[0].name;
  //   fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
  //   let filename = 'Attack_' + n.toString().substring(4, 8) + file[0].name;
  //   const formData = new FormData();
  //   formData.append("image", file[0]);
  //   formData.append("image", filename);
  //   formData.append("profile", filename);
  //   this.loading = true;
  //   this.web.uploadWebsitePicture(`${this.base_url}restapi/upload_instructor_certificate_file.php?filename=` + filename, formData).subscribe((Res: any) => {
  //     this.loading = false;
  //     this.ententionName = filename.split('.').pop();
  //     // console.log('filename', this.name)
  //     if (this.ententionName == 'png' || this.ententionName == 'jpg' || this.ententionName == 'jpeg' || this.ententionName == 'pdf') {
  //       if (Res.status == '200') {
  //         // this.common.presentToast(Res.error);
  //         this.certificate = filename;

  //         console.log('the img is---<>', filename);
  //       } else {
  //         this.certificate = '';
  //         this.common.presentToast(Res.error);
  //       }
  //     } else {
  //       this.common.presentToast('Please upload valid images');
  //     }
  //   }, (err) => {
  //     this.common.presentToast('Connection Error');
  //     this.loading = false;
  //   });
  // }
  resolved(captchaResponse: any) {
    console.log(`Resolved response token: ${captchaResponse}`);
    // var captchaResponse = grecaptcha.getResponse();
    if (captchaResponse != null) {
      if (captchaResponse.length > 0) {
        this.grecaptcha_val = true;
      }
      else {
        this.grecaptcha_val = false;
      }
    }
    else {
      this.grecaptcha_val = false;
    }
  }

  async validation() {


  }
  async submitcustomer(param: any) {
    this.userValidation.email = this.userDetails.c_email
    this.userValidation.phoneno = this.userDetails.c_phoneno
    this.userValidation.password = this.userDetails.c_password
    this.userValidation.confirmpassword = this.userDetails.c_confirmpassword
    this.userValidation.confirmpassword = this.userDetails.c_confirmpassword
    this.userValidation.type = "Customer";

    if (this.userDetails.c_email == null || this.userDetails.c_email == '') {
      this.common.presentToast('Enter your mail id');
    }
    else if (this.common.validateEmail(this.userValidation.email) == false) {
      this.common.presentToast('Enter valid email Address');
    }
    else if (this.userDetails.c_phoneno == null || this.userDetails.c_phoneno == '') {
      this.common.presentToast('Enter your phone number');
    } else if (this.common.validateMobileNumber(this.userDetails.c_phoneno) == false) {
      this.common.presentToast('Enter valid phone number');
    } else if (this.userValidation.password == null || this.userValidation.password == '') {
      this.common.presentToast('Enter your password');
    } else if (this.userValidation.password.length < 6) {
      this.common.presentToast('Password should have 6 characters');
    } else if (this.userValidation.confirmpassword == null || this.userValidation.confirmpassword == '') {
      this.common.presentToast('Enter confirm password');
    } else if (this.userValidation.password != this.userValidation.confirmpassword) {
      this.common.presentToast('Confirm password is mismatched')
    
     }
    else if (!this.grecaptcha_val) {
      this.common.presentToast('Please verify that you are not a robot !')
    }
  
    else {
      this.web.postData('customerregistration', this.userValidation).then(res => {
        console.log(this.userValidation);
        
        this.userValidation = {
          'email': '',
          'phoneno': '',
          'password': '',
          'type': ''
        };
        if (res.status == '200') {
          this.dialog.open(ConfirmationpopupComponent);
          console.log(res);
        }
        else {
          this.common.presentToast('Oops.. Email id already exists');
        }
      }, err => {
        console.log(err);
      })
    }

  }


  async submitForm(param: any) {
    if (param == 'Instructor') {
      this.userValidation.certificate = this.certificate
      this.userValidation.email = this.userDetails.in_email;
      this.userValidation.phoneno = this.userDetails.in_phoneno;
      this.userValidation.password = this.userDetails.in_password;
      this.userValidation.confirmpassword = this.userDetails.in_confirmpassword;
      this.userValidation.type = "Instructor";
      if (this.userValidation.email == null || this.userValidation.email == '') {
        this.common.presentToast('Enter your mail id');
      }
      else if (this.common.validateEmail(this.userValidation.email) == false) {
        this.common.presentToast('Enter valid email Address');
      }
      else if (this.userValidation.phoneno == null || this.userValidation.phoneno == '') {
        this.common.presentToast('Enter your phone number');
      } else if (this.common.validateMobileNumber(this.userValidation.phoneno) == false) {
        this.common.presentToast('Enter valid phone number');
      }
      else if (this.userValidation.password == null || this.userValidation.password == '') {
        this.common.presentToast('Enter your password');
      } else if (this.userValidation.password.length < 6) {
        this.common.presentToast('Password should have 6 characters');
      } else if (this.userValidation.confirmpassword == null || this.userValidation.confirmpassword == '') {
        this.common.presentToast('Enter confirm password');
      } else if (this.userValidation.password != this.userValidation.confirmpassword) {
        this.common.presentToast('Confirm password is mismatched')
      } 
      else if (this.userValidation.certificate == null || this.userValidation.certificate == '') {
        this.common.presentToast('Please choose certificate')
      } 
      else if (!this.grecaptcha_val) {
        this.common.presentToast('Please verify that you are not a robot !')
      }

      else {
        this.web.postData('intructorregistration', this.userValidation).then(res => {
          this.userValidation = {
            'email': '',
            'phoneno': '',
            'password': '',
            'type': ''
          };
          if (res.status == '200') {
            this.dialog.open(InstructorConfirmationpopupComponent);       
            console.log(res);
          }
          else {
            this.common.presentToast('Oops.. Email id already exists');
          }
        }, err => {
          console.log(err);
        })
      }


    }



  }


}
@Component({
  selector: 'app-confirmationpopup',
  templateUrl: 'confirmationpopup.component.html',
  styleUrls: ['confirmationpopup.component.scss']
})
export class ConfirmationpopupComponent  {
  pop:boolean=true;
  display: string;

  constructor(
    private router: Router,
    private web: WebService,
    public common: CommonService,
    public dialog: MatDialog
  ) { }
  redirectlogin(){
    this.dialog.closeAll();   
     this.router.navigate(['/login']);      
  }
}



@Component({
  selector: 'app-instructorconformation',
  templateUrl: 'instructorconformation.component.html',
  styleUrls: ['instructorconformation.component.scss']
})
export class InstructorConfirmationpopupComponent  {
  pop:boolean=true;
  display: string;

  constructor(
    private router: Router,
    private web: WebService,
    public common: CommonService,
    public dialog: MatDialog
  ) { }
  redirectlogin1(){
    this.dialog.closeAll();   
     this.router.navigate(['/login']);      
  }
}

