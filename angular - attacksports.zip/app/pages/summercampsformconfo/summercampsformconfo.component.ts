import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,ParamMap, Params} from '@angular/router';
import { ChangeDetectorRef} from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-summercampsformconfo',
  templateUrl: './summercampsformconfo.component.html',
  styleUrls: ['./summercampsformconfo.component.scss']
})
export class SummercampsformconfoComponent implements OnInit {
  base_url: string = environment.base_url;
  webId: string;
  summerconfocontents: any;
  orderNumber: any;
  constructor(private web: WebService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params: Params) => {
      this.webId = params['webId'];
      
      console.log('webId:', this.webId);
     
      this.getSummerConfoContents(); // You can move the code that depends on this.orderNumber here
    });
  }

  shouldHidePaymentMethod(): boolean {
      return this.summerconfocontents?.totalAmount === 0 || !this.summerconfocontents?.payment_method;
     }
     shouldShowPaymentInstructions(): boolean {
      const paymentMethod = this.summerconfocontents?.payment_method;
      return paymentMethod === 'E-Transfer (or Cash)';
     }
getSummerConfoContents() {
  this.web.getData('getSummerConfoContents').then((res) => {
    if (res.status == '200') {
      // Assuming the API response contains an array of objects
      const summerconfocontentsArray = res.data;
      console.log("summerconfocontentsArray",summerconfocontentsArray)
      // Find the object with the matching webId
      this.summerconfocontents = summerconfocontentsArray.find(item => item.web_id === this.webId);
      console.log("this.summerconfocontents.radiobtn1", this.summerconfocontents?.radiobtn1);
      console.log(this.summerconfocontents, "this.summerconfocontents");
    }
  }, err => {
    console.log(err);
    console.log(":)")
  });
}
}

