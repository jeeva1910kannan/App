import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SummercampsformconfoComponent } from './summercampsformconfo.component';
import { SummercampsformconfoRoutingModule } from './summercampsformconfo.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    SummercampsformconfoComponent
  ],
  imports: [
    CommonModule,
    SummercampsformconfoRoutingModule,
    HeaderFooterModule,
    ReactiveFormsModule,
    FormsModule,
   
  ],
})
export class SummercampsformconfosModule { }
