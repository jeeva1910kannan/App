import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LtadRoutingModule } from './ltad-routing.module';
import { LtadComponent } from './ltad.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';

@NgModule({
  declarations: [LtadComponent],
  imports: [
    CommonModule,
    LtadRoutingModule,
    HeaderFooterModule
  ]
})
export class LtadModule { }
