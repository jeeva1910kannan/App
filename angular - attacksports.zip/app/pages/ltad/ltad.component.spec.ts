import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LtadComponent } from './ltad.component';

describe('LtadComponent', () => {
  let component: LtadComponent;
  let fixture: ComponentFixture<LtadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LtadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LtadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
