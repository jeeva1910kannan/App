import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { WebService } from '../../providers/web.service';


@Component({
  selector: 'app-ltad',
  templateUrl: './ltad.component.html',
  styleUrls: ['./ltad.component.scss']
})
export class LtadComponent implements OnInit {
  ltad: any;


  constructor(private web: WebService,private  common:CommonService  ) { }

  ngOnInit(): void {
    this.getcovidcontent();
  }
  getcovidcontent() {
    this.web.getData('getltadcontent').then((res) => {
      if (res.status == '200') {
        this.ltad = res.data;
       
        console.log(this.ltad, "ltad");
       

      }
      
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

}
