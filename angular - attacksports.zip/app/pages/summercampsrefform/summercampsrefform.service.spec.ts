// import { TestBed } from '@angular/core/testing';

// import { SummercampsrefformService } from './summercampsrefform.service';

// describe('SummercampsrefformService', () => {
//   let service: SummercampsrefformService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(SummercampsrefformService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
