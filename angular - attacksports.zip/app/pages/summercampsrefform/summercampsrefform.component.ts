import { ChangeDetectorRef, Component, Renderer2, OnInit, ViewChild, ElementRef } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormBuilder, NgForm } from '@angular/forms';
import { SummercampsrefformService } from './summercampsrefform.service';
import { MatDialog } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms';





declare var Square: any;
@Component({
  selector: 'app-summercampsrefform',
  templateUrl: './summercampsrefform.component.html',
  styleUrls: ['./summercampsrefform.component.scss']
})
export class SummercampsrefformComponent implements OnInit {
  @ViewChild('myForm', { static: true }) form: NgForm;
  //summercampsbillingform = '/summercampsbillingform';
  selectedPaymentMethod: string;
  currentDate = new Date();
  couponCode: string = '';
  gstAmount: number = 0;
  acceptTerms: boolean = false;
  subtotal: number = 0;
  Square: any;
  showHoldsSame = false;
  default_radio: string;
  selectedMonth: string;
  selectedDay: string;
  selectedYear: string;
  listradselect: any = [];
  campregisterform: FormGroup;
  campamount: any;
  campdetails1: any = [];
  campdetails: any;
  regdetails: any;
  bookeddetails: any = [];
  book = false;
  userid: any;
  heading: string;
  resultcontents: any = [];
  formDetailsSubmitted: boolean = false;
  payments: any;
  isClearSelectionVisible = false
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEPJJiem4rJOB_n6eW84Imj-Ypyf_qr37M7gFzeQ0-lDOmbjrKrgCmOuTGDzw";
  applicationId1 = "sandbox-sq0idb-O6e2c7juXuf9P0_gSYn32A";
  locationId1 = "LBWZSZWVJFF4M";
  paymentForm: any;
  userDetailsTemp: any;
  selectedSession1Option: string = '';
selectedSession2Option: string = '';
selectedSession3Option: string = '';
selectedSession1: string[] = [];
selectedSession2: string[] = [];
selectedSession3: string[] = [];
selectedSession4: string[] = [];
totalAmount: number = 0;
selectedSession5: string;
  isButtondisabled = false;
  resultcontents1: any = [];
  userId: string = '';
  isRadioSelected1= false;
  isRadioSelected2= false;
  isRadioSelected3= false;
  isRadioSelected4= false;
  

 
  // subTotal: number = 0;
 
  formDetails: any = {
    customer_id: localStorage.getItem('UserId'),
    'web_id':'',
    'ath_fname': '',
    'ath_lname': '',
    'par_fname': '',
    'par_lname': '',
    'par_firstemail': '',
    'par_secondemail': '',
    'par_address': '',
    'par_city': '',
    'par_phno': '',
    'par_postalcode': '',
    'ath_desiredsports': '',
    'ath_careno': '',
    'ath_allergiesandfood': '',
    'ath_withpermission': '',
    'ath_otherinfo': '',
    'radiobtn1': '',
    'month': '',
    'day': '',
    'year': '',
    'tsize': '',
    'country': '',
    'province': '',
    'totalAmount' : '',
    'billing_fname': '',
    'billing_lname': '',
    'payment_method': '',
    'billing_country': '',
    'billing_address': '',
    'billing_city': '',
    'billing_cardno': '',
    'billing_province': '',
    'billing_postalcode': '',
    'billing_email': '',
    'coupon_code': '',
     'coupon_desp':'',
    'value_1': {
      'date': this.currentDate.getDate(),
      'month': this.currentDate.getMonth() + 1, // Adding 1 to get the month in the range 1-12
      'year': this.currentDate.getFullYear(),
    },
   
   
   
  };
  checkboxValues: string[] = [];
  otherInputValid = false;
  isChecked: boolean = false;

  base_url: string = environment.base_url;
  // springhockey: any;
  multisportcampscontents: any[] = [];
  myForm: any;
  submitted = false;
  paymentContainerVisible = false;
  http: any;
  EventDetails: any;
  discountedAmount: number = 0;
  
  prices: any;
  value_1: any;
  value_2: any;
  value_3: any;
  value_4: any;
  value_5: any;
  value_6: any;
  value_7: any;
  value_8: any;
  value_9: any;
  gst_1:any;
  gst_2:any;
  gst_3:any;
  gst_4:any;
  gst_5:any;
  gst_6:any;
  gst_7:any;
  gst_8:any;
  gst_9:any;
  orderNumber: any;
  orderDate: string;


  constructor(private renderer: Renderer2, private router: Router,
    private toastr: ToastrService, private web: WebService,
    private sanitizer: DomSanitizer, private cdr: ChangeDetectorRef,
    private common: CommonService, private formBuilder: FormBuilder,
    private tableService: SummercampsrefformService,
    public dialog: MatDialog
  ) {
    this.campregisterform = this.tableService.exportNewForm();
   
  }

  ngOnInit(): void {
    this.userid = localStorage.getItem("UserId");
     this.getcampdetails();
    this.getbookedcamp();
    this.calculateInitialTotalAmount();

   
    this.getresultContents();

    this.generateOrderNumber();
  
  }

  getRadio1(){
    this.isRadioSelected1 =true;
  }
  getRadio2(){
    this.isRadioSelected2 =true;
  }
  getRadio3(){
    this.isRadioSelected3 =true;
  }
  getRadio4(){
    this.isRadioSelected4 =true;
  }

  // getClear1(){
  //   this.formDetails.session2Option='';
  //   this.isRadioSelected1 =false;
  // }
  getClear1(){
     this.formDetails.session2Option='';
     this.isRadioSelected1 =false;
     const numericPrices = {};
     const numericGstRates = {};
    
    this.selectedSession1 = this.formDetails.session1Option ? [this.formDetails.session1Option] : [];
    this.selectedSession2 = this.formDetails.session2Option ? [this.formDetails.session2Option] : [];
    this.selectedSession3 = this.formDetails.session3Option ? [this.formDetails.session3Option] : [];
    this.selectedSession4 = this.formDetails.session4Option ? [this.formDetails.session4Option] : [];
    
    
    this.value_1 = this.prices.value_1;
    this.value_2 = this.prices.value_2;
    this.value_3 = this.prices.value_3;
    this.value_4 = this.prices.value_4;
    this.value_5 = this.prices.value_5;
    this.value_6 = this.prices.value_6;
    this.value_7 = this.prices.value_7;
    this.value_8 = this.prices.value_8;
    this.value_9 = this.prices.value_9;
    
    this.gst_1 = this.prices.gst_1;
    this.gst_2 = this.prices.gst_2;
    this.gst_3 = this.prices.gst_3;
    this.gst_4 = this.prices.gst_4;
    this.gst_5 = this.prices.gst_5;
    this.gst_6 = this.prices.gst_6;
    this.gst_7 = this.prices.gst_7;
    this.gst_8 = this.prices.gst_8;
    this.gst_9 = this.prices.gst_9;
    console.log("prices amount",this.prices);
    
    // Calculate subtotal based on selected values from all three radio groups
    const prices = {
    'Week #3 (July 17 to 21)': this.value_1,
    'Week #5 (August 28 to Sept 1)':this.value_2,
    'Day Drop in (Day Only)':  this.value_3,
    'Day Drop in (Excursion Day)':  this.value_4,
    'Before Care (8am) All Week': this.value_5,
    'Before Care (8am) 1 Day': this.value_6,
    'After Care (4:30pm pick-up) All Week': this.value_7,
    'After Care (4:30pm pick-up) 1 Day': this.value_8,
    'Before and After Care (8am to 4:30pm) All Week': this.value_9 ,
    };
    const gstRates = {
    'Week #3 (July 17 to 21)': this.gst_1,
    'Week #5 (August 28 to Sept 1)': this.gst_2,
    'Day Drop in (Day Only)': this.gst_3,
    'Day Drop in (Excursion Day)':this.gst_4,
    'Before Care (8am) All Week': this.gst_5,
    'Before Care (8am) 1 Day':this.gst_6,
    'After Care (4:30pm pick-up) All Week':this.gst_7,
    'After Care (4:30pm pick-up) 1 Day':this.gst_8,
    'Before and After Care (8am to 4:30pm) All Week':this.gst_1,
    };
    Object.keys(prices).forEach((key) => {
    numericPrices[key] = parseFloat(prices[key]);
    });
    
    Object.keys(gstRates).forEach((key) => {
    numericGstRates[key] = parseFloat(gstRates[key]);
    });
    
    // Calculate GST based on selected values from each radio group
    const gst =
    (this.formDetails.session1Option ? numericGstRates[this.formDetails.session1Option] : 0) -
    (this.formDetails.session2Option ? numericGstRates[this.formDetails.session2Option] : 0) -
    (this.formDetails.session3Option ? numericGstRates[this.formDetails.session3Option] : 0) -
    (this.formDetails.session4Option ? numericGstRates[this.formDetails.session4Option] : 0) ;
    
    
    this.gstAmount = gst;
    
    this.subtotal =
    (this.formDetails.session1Option ? numericPrices[this.formDetails.session1Option] : 0) -
    (this.formDetails.session2Option ? numericPrices[this.formDetails.session2Option] : 0) -
    (this.formDetails.session3Option ? numericPrices[this.formDetails.session3Option] : 0) -
    (this.formDetails.session4Option ? numericPrices[this.formDetails.session4Option] : 0);
    
    this.totalAmount = this.subtotal + this.gstAmount;
    this.totalAmount = +this.totalAmount.toFixed(2);
    // this.totalAmount = parseFloat(this.subtotal) + parseFloat(this.gstAmount);
    // this.totalAmount = this.subtotal + this.gstAmount;
    // console.log("After recalculating:");
    //   console.log("New totalAmount:", this.totalAmount);
    //   console.log("New subtotal:", this.subtotal);
    //   console.log("New GST:", this.gstAmount);
    //   console.log("numericPrices",numericPrices);
    //   console.log("this.value_2",this.value_2);
     
    }
  getClear2(){
      this.formDetails.session4Option='';
      this.isRadioSelected2 =false;
      const numericPrices = {};
      const numericGstRates = {};
     
     this.selectedSession1 = this.formDetails.session1Option ? [this.formDetails.session1Option] : [];
     this.selectedSession2 = this.formDetails.session2Option ? [this.formDetails.session2Option] : [];
     this.selectedSession3 = this.formDetails.session3Option ? [this.formDetails.session3Option] : [];
     this.selectedSession4 = this.formDetails.session4Option ? [this.formDetails.session4Option] : [];
     
     
     this.value_1 = this.prices.value_1;
     this.value_2 = this.prices.value_2;
     this.value_3 = this.prices.value_3;
     this.value_4 = this.prices.value_4;
     this.value_5 = this.prices.value_5;
     this.value_6 = this.prices.value_6;
     this.value_7 = this.prices.value_7;
     this.value_8 = this.prices.value_8;
     this.value_9 = this.prices.value_9;
     
     this.gst_1 = this.prices.gst_1;
     this.gst_2 = this.prices.gst_2;
     this.gst_3 = this.prices.gst_3;
     this.gst_4 = this.prices.gst_4;
     this.gst_5 = this.prices.gst_5;
     this.gst_6 = this.prices.gst_6;
     this.gst_7 = this.prices.gst_7;
     this.gst_8 = this.prices.gst_8;
     this.gst_9 = this.prices.gst_9;
     console.log("prices amount",this.prices);
     
     // Calculate subtotal based on selected values from all three radio groups
     const prices = {
     'Week #3 (July 17 to 21)': this.value_1,
     'Week #5 (August 28 to Sept 1)':this.value_2,
     'Day Drop in (Day Only)':  this.value_3,
     'Day Drop in (Excursion Day)':  this.value_4,
     'Before Care (8am) All Week': this.value_5,
     'Before Care (8am) 1 Day': this.value_6,
     'After Care (4:30pm pick-up) All Week': this.value_7,
     'After Care (4:30pm pick-up) 1 Day': this.value_8,
     'Before and After Care (8am to 4:30pm) All Week': this.value_9 ,
     };
     const gstRates = {
     'Week #3 (July 17 to 21)': this.gst_1,
     'Week #5 (August 28 to Sept 1)': this.gst_2,
     'Day Drop in (Day Only)': this.gst_3,
     'Day Drop in (Excursion Day)':this.gst_4,
     'Before Care (8am) All Week': this.gst_5,
     'Before Care (8am) 1 Day':this.gst_6,
     'After Care (4:30pm pick-up) All Week':this.gst_7,
     'After Care (4:30pm pick-up) 1 Day':this.gst_8,
     'Before and After Care (8am to 4:30pm) All Week':this.gst_1,
     };
     Object.keys(prices).forEach((key) => {
     numericPrices[key] = parseFloat(prices[key]);
     });
     
     Object.keys(gstRates).forEach((key) => {
     numericGstRates[key] = parseFloat(gstRates[key]);
     });
     
     // Calculate GST based on selected values from each radio group
     const gst =
     (this.formDetails.session1Option ? numericGstRates[this.formDetails.session1Option] : 0) -
     (this.formDetails.session2Option ? numericGstRates[this.formDetails.session2Option] : 0) -
     (this.formDetails.session3Option ? numericGstRates[this.formDetails.session3Option] : 0) -
     (this.formDetails.session4Option ? numericGstRates[this.formDetails.session4Option] : 0) ;
     
     
     this.gstAmount = gst;
     
     this.subtotal =
     (this.formDetails.session1Option ? numericPrices[this.formDetails.session1Option] : 0) -
     (this.formDetails.session2Option ? numericPrices[this.formDetails.session2Option] : 0) -
     (this.formDetails.session3Option ? numericPrices[this.formDetails.session3Option] : 0) -
     (this.formDetails.session4Option ? numericPrices[this.formDetails.session4Option] : 0);
     
     this.totalAmount = this.subtotal + this.gstAmount;
     this.totalAmount = +this.totalAmount.toFixed(2);
     // this.totalAmount = parseFloat(this.subtotal) + parseFloat(this.gstAmount);
     // this.totalAmount = this.subtotal + this.gstAmount;
     console.log("After recalculating:");
       console.log("New totalAmount:", this.totalAmount);
       console.log("New subtotal:", this.subtotal);
       console.log("New GST:", this.gstAmount);
       console.log("numericPrices",numericPrices);
       console.log("this.value_2",this.value_2);
      
     }
    
    
     getClear3(){
        this.formDetails.session1Option='';
        this.isRadioSelected3 =false;
        const numericPrices = {};
        const numericGstRates = {};
       
       this.selectedSession1 = this.formDetails.session1Option ? [this.formDetails.session1Option] : [];
       this.selectedSession2 = this.formDetails.session2Option ? [this.formDetails.session2Option] : [];
       this.selectedSession3 = this.formDetails.session3Option ? [this.formDetails.session3Option] : [];
       this.selectedSession4 = this.formDetails.session4Option ? [this.formDetails.session4Option] : [];
       
       
       this.value_1 = this.prices.value_1;
       this.value_2 = this.prices.value_2;
       this.value_3 = this.prices.value_3;
       this.value_4 = this.prices.value_4;
       this.value_5 = this.prices.value_5;
       this.value_6 = this.prices.value_6;
       this.value_7 = this.prices.value_7;
       this.value_8 = this.prices.value_8;
       this.value_9 = this.prices.value_9;
       
       this.gst_1 = this.prices.gst_1;
       this.gst_2 = this.prices.gst_2;
       this.gst_3 = this.prices.gst_3;
       this.gst_4 = this.prices.gst_4;
       this.gst_5 = this.prices.gst_5;
       this.gst_6 = this.prices.gst_6;
       this.gst_7 = this.prices.gst_7;
       this.gst_8 = this.prices.gst_8;
       this.gst_9 = this.prices.gst_9;
       console.log("prices amount",this.prices);
       
       // Calculate subtotal based on selected values from all three radio groups
       const prices = {
       'Week #3 (July 17 to 21)': this.value_1,
       'Week #5 (August 28 to Sept 1)':this.value_2,
       'Day Drop in (Day Only)':  this.value_3,
       'Day Drop in (Excursion Day)':  this.value_4,
       'Before Care (8am) All Week': this.value_5,
       'Before Care (8am) 1 Day': this.value_6,
       'After Care (4:30pm pick-up) All Week': this.value_7,
       'After Care (4:30pm pick-up) 1 Day': this.value_8,
       'Before and After Care (8am to 4:30pm) All Week': this.value_9 ,
       };
       const gstRates = {
       'Week #3 (July 17 to 21)': this.gst_1,
       'Week #5 (August 28 to Sept 1)': this.gst_2,
       'Day Drop in (Day Only)': this.gst_3,
       'Day Drop in (Excursion Day)':this.gst_4,
       'Before Care (8am) All Week': this.gst_5,
       'Before Care (8am) 1 Day':this.gst_6,
       'After Care (4:30pm pick-up) All Week':this.gst_7,
       'After Care (4:30pm pick-up) 1 Day':this.gst_8,
       'Before and After Care (8am to 4:30pm) All Week':this.gst_1,
       };
       Object.keys(prices).forEach((key) => {
       numericPrices[key] = parseFloat(prices[key]);
       });
       
       Object.keys(gstRates).forEach((key) => {
       numericGstRates[key] = parseFloat(gstRates[key]);
       });
       
       // Calculate GST based on selected values from each radio group
       const gst =
       (this.formDetails.session1Option ? numericGstRates[this.formDetails.session1Option] : 0) -
       (this.formDetails.session2Option ? numericGstRates[this.formDetails.session2Option] : 0) -
       (this.formDetails.session3Option ? numericGstRates[this.formDetails.session3Option] : 0) -
       (this.formDetails.session4Option ? numericGstRates[this.formDetails.session4Option] : 0) ;
       
       
       this.gstAmount = gst;
       
       this.subtotal =
       (this.formDetails.session1Option ? numericPrices[this.formDetails.session1Option] : 0) -
       (this.formDetails.session2Option ? numericPrices[this.formDetails.session2Option] : 0) -
       (this.formDetails.session3Option ? numericPrices[this.formDetails.session3Option] : 0) -
       (this.formDetails.session4Option ? numericPrices[this.formDetails.session4Option] : 0);
       
       this.totalAmount = this.subtotal + this.gstAmount;
       this.totalAmount = +this.totalAmount.toFixed(2);
       // this.totalAmount = parseFloat(this.subtotal) + parseFloat(this.gstAmount);
       // this.totalAmount = this.subtotal + this.gstAmount;
       console.log("After recalculating:");
         console.log("New totalAmount:", this.totalAmount);
         console.log("New subtotal:", this.subtotal);
         console.log("New GST:", this.gstAmount);
         console.log("numericPrices",numericPrices);
         console.log("this.value_2",this.value_2);
        
       }
       getClear4(){
          this.formDetails.session3Option='';
          this.isRadioSelected4 =false;
          const numericPrices = {};
          const numericGstRates = {};
         
         this.selectedSession1 = this.formDetails.session1Option ? [this.formDetails.session1Option] : [];
         this.selectedSession2 = this.formDetails.session2Option ? [this.formDetails.session2Option] : [];
         this.selectedSession3 = this.formDetails.session3Option ? [this.formDetails.session3Option] : [];
         this.selectedSession4 = this.formDetails.session4Option ? [this.formDetails.session4Option] : [];
         
         
         this.value_1 = this.prices.value_1;
         this.value_2 = this.prices.value_2;
         this.value_3 = this.prices.value_3;
         this.value_4 = this.prices.value_4;
         this.value_5 = this.prices.value_5;
         this.value_6 = this.prices.value_6;
         this.value_7 = this.prices.value_7;
         this.value_8 = this.prices.value_8;
         this.value_9 = this.prices.value_9;
         
         this.gst_1 = this.prices.gst_1;
         this.gst_2 = this.prices.gst_2;
         this.gst_3 = this.prices.gst_3;
         this.gst_4 = this.prices.gst_4;
         this.gst_5 = this.prices.gst_5;
         this.gst_6 = this.prices.gst_6;
         this.gst_7 = this.prices.gst_7;
         this.gst_8 = this.prices.gst_8;
         this.gst_9 = this.prices.gst_9;
         console.log("prices amount",this.prices);
         
         // Calculate subtotal based on selected values from all three radio groups
         const prices = {
         'Week #3 (July 17 to 21)': this.value_1,
         'Week #5 (August 28 to Sept 1)':this.value_2,
         'Day Drop in (Day Only)':  this.value_3,
         'Day Drop in (Excursion Day)':  this.value_4,
         'Before Care (8am) All Week': this.value_5,
         'Before Care (8am) 1 Day': this.value_6,
         'After Care (4:30pm pick-up) All Week': this.value_7,
         'After Care (4:30pm pick-up) 1 Day': this.value_8,
         'Before and After Care (8am to 4:30pm) All Week': this.value_9 ,
         };
         const gstRates = {
         'Week #3 (July 17 to 21)': this.gst_1,
         'Week #5 (August 28 to Sept 1)': this.gst_2,
         'Day Drop in (Day Only)': this.gst_3,
         'Day Drop in (Excursion Day)':this.gst_4,
         'Before Care (8am) All Week': this.gst_5,
         'Before Care (8am) 1 Day':this.gst_6,
         'After Care (4:30pm pick-up) All Week':this.gst_7,
         'After Care (4:30pm pick-up) 1 Day':this.gst_8,
         'Before and After Care (8am to 4:30pm) All Week':this.gst_1,
         };
         Object.keys(prices).forEach((key) => {
         numericPrices[key] = parseFloat(prices[key]);
         });
         
         Object.keys(gstRates).forEach((key) => {
         numericGstRates[key] = parseFloat(gstRates[key]);
         });
         
         // Calculate GST based on selected values from each radio group
         const gst =
         (this.formDetails.session1Option ? numericGstRates[this.formDetails.session1Option] : 0) -
         (this.formDetails.session2Option ? numericGstRates[this.formDetails.session2Option] : 0) -
         (this.formDetails.session3Option ? numericGstRates[this.formDetails.session3Option] : 0) -
         (this.formDetails.session4Option ? numericGstRates[this.formDetails.session4Option] : 0) ;
         
         
         this.gstAmount = gst;
         
         this.subtotal =
         (this.formDetails.session1Option ? numericPrices[this.formDetails.session1Option] : 0) -
         (this.formDetails.session2Option ? numericPrices[this.formDetails.session2Option] : 0) -
         (this.formDetails.session3Option ? numericPrices[this.formDetails.session3Option] : 0) -
         (this.formDetails.session4Option ? numericPrices[this.formDetails.session4Option] : 0);
         
         this.totalAmount = this.subtotal + this.gstAmount;
         this.totalAmount = +this.totalAmount.toFixed(2);
        
         // this.totalAmount = parseFloat(this.subtotal) + parseFloat(this.gstAmount);
         // this.totalAmount = this.subtotal + this.gstAmount;
         console.log("After recalculating:");
           console.log("New totalAmount:", this.totalAmount);
           console.log("New subtotal:", this.subtotal);
           console.log("New GST:", this.gstAmount);
           console.log("numericPrices",numericPrices);
           console.log("this.value_2",this.value_2);
          
         }
  // updateSubtotal() {
  //   if (this.formDetails.session2Option === 'Week #3 (July 17 to 21) ($349.00)' ||
  //       this.formDetails.session2Option === 'Week #5 (August 28 to Sept 1) ($349.00)') {
  //     this.subtotal = 349.0;
  //   } else {
  //     this.subtotal = 0;
  //   }
  // }
  
 
  getbookedcamp() {
    let data = {

      customer_id: localStorage.getItem('UserId'),
    }

    this.web.postData('getbookedcamps', data).then((res) => {
      if (res.status == '200') {
        this.book = true;
        this.bookeddetails = res.data;
        console.log(this.bookeddetails, "bookeddetails");
        console.log("this.formDetailsssssssssssss",this.formDetails);
        

      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

  getcampdetails(){
    // let formData = {
    //   web_id:this.userid,
     
    // }
    
    this.web.postData('getcampsummerdetails',this.formDetails).then((res) => {
        if (res.status == '200') {
          this.campamount = res.data;
          this.campdetails = res.data;
         console.log(this.campamount,"campamounttttttttttttt");
          this.campamount.map((res, i) => {
          console.log(res.totalAmount,'67667')
          localStorage.setItem('campamount',res.totalAmount);
          localStorage.setItem('gstamount',res.billing_cvv);
          localStorage.getItem('UserId')
          
         });
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }
  getresultContents() {
    this.web.getData('getResultContent').then((res) => {
      if (res.status == '200') {
        this.resultcontents = res.data;
        console.log("resultcontents", this.resultcontents);
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

  updatePaymentMethod() {
    if (this.selectedPaymentMethod === 'E-Transfer (or Cash)') {
      this.formDetails.billing_cardno = ''; // Clear the billing card number
    }
  }

  

  async applyCoupon() {
    
    try {
    
      const requestData = {
        coupon_code: this.couponCode,
        userId: localStorage.getItem('UserId'),
        totalAmount: this.totalAmount
        
      };
      console.log("this.userId",this.userId);
      this.formDetails.coupon_code=this.couponCode
      // if (!this.userId) {
      //   this.common.presentToast('User ID is required.');
      //   return;
      // }
      
      const response: any = await this.web.postData('getOverallCouponCode', requestData);
      console.log("Response :", response);
      if (response.status === '200') {
        console.log("Response Status:", response.status);
        this.discountedAmount = response.discountedAmount;
        this.formDetails.totalAmount=this.discountedAmount
        console.log("final discount amount",this.formDetails.totalAmount);
        console.log("final amount in this.formDetails",this.formDetails);
        
        
      } else if (response.status === '404') {
        this.toastr.error('Invalid coupon code.', 'Error');
      } else if (response.status === '403') {
        this.toastr.error('Coupon code has expired.', 'Error');
      } else if (response.status === '405') {
        this.toastr.error('You have reached the usage limit for this coupon code.', 'Error');
      } else {
        this.toastr.error('An unknown error occurred.', 'Error');
      }
    } catch (error) {
      console.error(error);
      this.toastr.error('An error occurred while processing the request.', 'Error');
    }
  }
  
  
  toggleHoldsSame() {
    this.showHoldsSame = !this.showHoldsSame;
  }


  onProvinceChange() {

    const selectedProvince = this.formDetails.province;
    console.log('Selected province:', selectedProvince);


  }
  onPaymentMethodChange(event:any): void {
    console.log("Selected Payment Method:", event);
    this.formDetails.payment_method = event.value;
    if (this.formDetails.payment_method === 'Credit Card') {
      this.loadScript();
      this.formDetails.billing_cardno = 'Active'; // Initialize the billing_cardno for Credit Card
    // Set billing as active for Credit Card
  } else if (this.formDetails.payment_method === 'E-Transfer (or Cash)') {
    this.paymentContainerVisible = false;
    console.log("E-Transfer (or Cash) selected");
    this.formDetails.billing_cardno = 'InActive'; // Set billing_cardno to 'InActive' for E-Transfer (or Cash)
    // Set billing as inactive for E-Transfer (or Cash)
  }
  }

  // generateOrderNumber() {
  //   console.log("HIOIIIIIIIIIIIIIIIIII")
  //     const randomNumber = Math.floor(Math.random() * 1000000).toString();
  //     const timestamp = Date.now().toString();
  //     this.formDetails.coupon_desp = this.orderNumber = randomNumber + timestamp;
  //     this.formDetails.value_1 = this.orderDate= new Date().toISOString().split('T')[0];
  //     console.log('orderNumber', this.orderNumber);
  //    }

  generateOrderNumber() {
    console.log("HIOIIIIIIIIIIIIIIIIII")
    const randomNumber = Math.floor(Math.random() * 1000000).toString();
    const timestamp = Date.now().toString();
    this.orderNumber = randomNumber + timestamp;
    
    // Get the current date and format it to "date-month-year" format
    const currentDate = new Date();
    const dateFormatted = currentDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    this.formDetails.value_1 = dateFormatted;
  
    this.formDetails.coupon_desp = this.orderNumber;
    console.log('orderNumber', this.orderNumber);
  }
  
  
  
 async  updateSubTotal() {

    const requestData = {web_id:1};

    const response: any = await this.web.postData('getsummercampsradio', requestData);
      console.log("Response :", response);
      if (response.status === '200') {
        const numericPrices = {};
        const numericGstRates = {};

    this.selectedSession1 = this.formDetails.session1Option ? [this.formDetails.session1Option] : [];
    this.selectedSession2 = this.formDetails.session2Option ? [this.formDetails.session2Option] : [];
    this.selectedSession3 = this.formDetails.session3Option ? [this.formDetails.session3Option] : [];
    this.selectedSession4 = this.formDetails.session4Option ? [this.formDetails.session4Option] : [];
  
    this.prices = response.data[0];
    this.value_1 = this.prices.value_1;
    this.value_2 = this.prices.value_2;
    this.value_3 = this.prices.value_3;
    this.value_4 = this.prices.value_4;
    this.value_5 = this.prices.value_5;
    this.value_6 = this.prices.value_6;
    this.value_7 = this.prices.value_7;
    this.value_8 = this.prices.value_8;
    this.value_9 = this.prices.value_9;

    this.gst_1 = this.prices.gst_1;
    this.gst_2 = this.prices.gst_2;
    this.gst_3 = this.prices.gst_3;
    this.gst_4 = this.prices.gst_4;
    this.gst_5 = this.prices.gst_5;
    this.gst_6 = this.prices.gst_6;
    this.gst_7 = this.prices.gst_7;
    this.gst_8 = this.prices.gst_8;
    this.gst_9 = this.prices.gst_9;
    console.log("prices amount",this.prices);
    
    // Calculate subtotal based on selected values from all three radio groups
    const prices = {
      'Week #3 (July 17 to 21)': this.value_1,
      'Week #5 (August 28 to Sept 1)':this.value_2,
      'Day Drop in (Day Only)':   this.value_3,
      'Day Drop in (Excursion Day)':   this.value_4,
      'Before Care (8am) All Week':  this.value_5,
      'Before Care (8am) 1 Day':  this.value_6,
      'After Care (4:30pm pick-up) All Week':  this.value_7,
      'After Care (4:30pm pick-up) 1 Day':  this.value_8,
      'Before and After Care (8am to 4:30pm) All Week': this.value_9 ,
    };
    const gstRates = {
      'Week #3 (July 17 to 21)': this.gst_1,
      'Week #5 (August 28 to Sept 1)': this.gst_2,
      'Day Drop in (Day Only)': this.gst_3,
      'Day Drop in (Excursion Day)':this.gst_4,
      'Before Care (8am) All Week': this.gst_5,
      'Before Care (8am) 1 Day':this.gst_6,
      'After Care (4:30pm pick-up) All Week':this.gst_7,
      'After Care (4:30pm pick-up) 1 Day':this.gst_8,
      'Before and After Care (8am to 4:30pm) All Week':this.gst_1,
    };
    Object.keys(prices).forEach((key) => {
      numericPrices[key] = parseFloat(prices[key]);
    });

    Object.keys(gstRates).forEach((key) => {
      numericGstRates[key] = parseFloat(gstRates[key]);
    });

    // Calculate GST based on selected values from each radio group
    const gst =
    (this.formDetails.session1Option ? numericGstRates[this.formDetails.session1Option] : 0) +
    (this.formDetails.session2Option ? numericGstRates[this.formDetails.session2Option] : 0) +
    (this.formDetails.session3Option ? numericGstRates[this.formDetails.session3Option] : 0) +
    (this.formDetails.session4Option ? numericGstRates[this.formDetails.session4Option] : 0) ;

    
    this.gstAmount = gst;
    
    this.subtotal =
    (this.formDetails.session1Option ? numericPrices[this.formDetails.session1Option] : 0) +
    (this.formDetails.session2Option ? numericPrices[this.formDetails.session2Option] : 0) +
    (this.formDetails.session3Option ? numericPrices[this.formDetails.session3Option] : 0) +
    (this.formDetails.session4Option ? numericPrices[this.formDetails.session4Option] : 0);
    
    this.totalAmount = this.subtotal + this.gstAmount;
    this.totalAmount = +this.totalAmount.toFixed(2);
    this.formDetails.totalAmount = this.totalAmount;
    // this.totalAmount = parseFloat(this.subtotal) + parseFloat(this.gstAmount);
//  this.totalAmount = this.subtotal + this.gstAmount;
    console.log("alertttttttttttttttt", this.subtotal);
    console.log("GSTTTTTTTTTTTTTTTTTTT",this.gstAmount);
    console.log("totaldueeeeeeeeeee", this.totalAmount);
    console.log("this.prices.value_1", this.prices.value_1);
    console.log("this.value_1",this.value_1);
    console.log("prices",prices);
    console.log("this.formDetailssssssssssss",this.formDetails);
    
    
    
    
   
  }

  else{
    this.common.presentToast('Total Amount is not calculated properly');
  }
}
    
  async  loadScript() {
   
   
    // Your SqPaymentForm script here
  
    var applicationId = "sandbox-sq0idb-O6e2c7juXuf9P0_gSYn32A";
  
    // Set the location ID
    var locationId = "LQC04P5CAFGVD";
  
    this.payments = Square.payments(applicationId, locationId);
  
    this.card = await this.payments.card();
  
    await this.card.attach('#card-container');
  
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
    const form = document.querySelector('#card-payment') as HTMLFormElement;
  
    form.addEventListener('submit', async (event: Event) => {
  
       event.preventDefault();
  
       const result = await this.card.tokenize(); // the card nonce
  
    });
    console.log("result");
    // onCancel: () => {
    //   this.common.presentToast('Payment cancelled.');
    //   console.log("OnCancel");
    // }
    
  }

  
  
  // Call the method to generate and assign orderNumber before sending the formDetails in the API request
  
  async makePayment() {
    
   
    const statusContainer = document.getElementById('payment-status-container');
    try {
      const result = await this.card.tokenize();
      if (result.status === 'OK') {
        this.isButtondisabled = true;

        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
       
        let data = {
        
          
          customer_id: localStorage.getItem('UserId'),
          amount:localStorage.getItem('campamount'),
          gstamount:localStorage.getItem('gstamount'),
          ath_fname:localStorage.getItem('ath_fname'),
          ath_lname:localStorage.getItem('ath_lname'),
          par_fname:localStorage.getItem('par_fname'),
          par_lname:localStorage.getItem('par_lname'),
          par_firstemail:localStorage.getItem('par_firstemail'),
          par_secondemail:localStorage.getItem('par_secondemail'),
          par_address:localStorage.getItem('par_address'),
          par_city:localStorage.getItem('par_city'),
          par_phno:localStorage.getItem('par_phno'),
          par_postalcode:localStorage.getItem('par_postalcode'),
          ath_desiredsports:localStorage.getItem('ath_desiredsports'),
          ath_careno:localStorage.getItem('ath_careno'),
          ath_allergiesandfood:localStorage.getItem('ath_allergiesandfood'),
          ath_withpermission:localStorage.getItem('ath_withpermission'),
          ath_otherinfo:localStorage.getItem('ath_otherinfo'),
          radiobtn1:localStorage.getItem('radiobtn1'),
          month:localStorage.getItem('month'),
          day:localStorage.getItem('day'),
          year:localStorage.getItem('year'),
          tsize:localStorage.getItem('tsize'),
          country:localStorage.getItem('country'),
          province:localStorage.getItem('province'),
          billing_fname:localStorage.getItem('billing_fname'),
          billing_lname:localStorage.getItem('billing_lname'),
          payment_method:localStorage.getItem('payment_method'),
          billing_country:localStorage.getItem('billing_country'),
          billing_address:localStorage.getItem('billing_address'),
          billing_city:localStorage.getItem('billing_city'),
          billing_province:localStorage.getItem('billing_province'),
          billing_postalcode:localStorage.getItem('billing_postalcode'),
          billing_email:localStorage.getItem('billing_email'),
          totalAmount:localStorage.getItem('totalAmount'),
        
        
     
     

      
          transaction_response: 'details',
          transaction_method: 'card',
          payment_status: 'success',
          paymentToken: result.token,
          locationId: this.locationId1,
          accesstoken: this.accesstoken
          
        };
       
        this.web.postData('addregistrationcamps', data).then(
         
          (res) => {
            if (res.status == '200') {
              this.common.presentToast('Payment Successfully');
             
              this.isButtondisabled = false;
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              });
              //this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
              this.isButtondisabled = false;
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
            this.isButtondisabled = false;
          });

        
    
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }
  
  calculateInitialTotalAmount() {
    this.totalAmount = this.subtotal + this.gstAmount;
  }
  async submitForm(form: any) {

   
      if (this.formDetails.radiobtn1 == null || this.formDetails.radiobtn1 == '') {
        this.common.presentToast('Enter your Ages Option');
      }
      else if (this.formDetails.ath_fname == null || this.formDetails.ath_fname == '') {
        this.common.presentToast('Enter your First name');
      }
      else if (this.formDetails.ath_lname == null || this.formDetails.ath_lname == '') {
        this.common.presentToast('Enter your last name');
  
       } 
      else if (this.formDetails.month == null || this.formDetails.month == '') {
        this.common.presentToast('Enter your Birthday Month')
      }
      else if (this.formDetails.day == null || this.formDetails.day == '') {
        this.common.presentToast('Enter your Birthday Date')
      }
      else if (this.formDetails.year == null || this.formDetails.year == '') {
        this.common.presentToast('Enter your Birthday Year')
      }
      else if (!this.formDetails.tsize || this.formDetails.tsize === '') {
        this.common.presentToast('Enter your T-size');
      }
      else if (this.formDetails.par_fname == null || this.formDetails.par_fname == '') {
        this.common.presentToast('Enter your Parent First name');
      }
      else if (this.formDetails.par_lname == null || this.formDetails.par_lname == '') {
        this.common.presentToast('Enter your Parent Last name');
      }
      
  
      else if (this.formDetails.par_firstemail == null || this.formDetails.par_firstemail == '') {
        this.common.presentToast('Enter your parent first mail');
      }
      else if (this.formDetails.par_secondemail == null || this.formDetails.par_secondemail == '') {
        this.common.presentToast('Enter your parent second mail');
      }
      //===============
      else if(this.formDetails.par_phno==null || this.formDetails.par_phno=='' ||this.formDetails.par_phno.trim().length==0){
          this.common.presentToast('Enter Phone Number');
         }
         else if(this.common.validateMobileNumber(this.formDetails.par_phno)== false){
          this.common.presentToast('Enter Valid Phone Number');
         }
        //=================
      else if (this.formDetails.country == null || this.formDetails.country == '') {
        this.common.presentToast('Enter your Parent Country');
      }
      else if (this.formDetails.par_address == null || this.formDetails.par_address == '') {
        this.common.presentToast('Enter your parent address');
      }
      else if (this.formDetails.par_city == null || this.formDetails.par_city == '') {
        this.common.presentToast('Enter your parent city');
      }
      else if (this.formDetails.province == null || this.formDetails.par_city == '') {
        this.common.presentToast('Enter your parent province');
      }
      else if (this.formDetails.par_postalcode == null || this.formDetails.par_postalcode == '') {
        this.common.presentToast('Enter your Postal code');
      }
      //===============
      else if (this.formDetails.par_postalcode == null || this.formDetails.par_postalcode == '') {
          this.common.presentToast('Enter the Postal code');
         }
         else if(this.common.validateNumber(this.formDetails.par_postalcode)==false){
          this.common.presentToast('Enter valid postal code');
         }
        //=============
      else if (this.formDetails.ath_desiredsports == null || this.formDetails.ath_desiredsports == '') {
        this.common.presentToast('Enter your Desired Sports');
      }
     
      //===========
      else if(this.formDetails.ath_careno==null || this.formDetails.ath_careno=='' ||this.formDetails.ath_careno.trim().length==0){
          this.common.presentToast('Enter Phone Number');
         }
         else if(this.common.validateMobileNumber(this.formDetails.ath_careno)== false){
          this.common.presentToast('Enter Valid Phone Number');
         }
        //============
     
      else if (this.formDetails.ath_allergiesandfood == null || this.formDetails.ath_allergiesandfood == '') {
        this.common.presentToast('Enter your Food Habits and allergies');
      }
      else if (this.formDetails.ath_withpermission == null || this.formDetails.ath_withpermission == '') {
        this.common.presentToast('Enter your Permission Details');
      }
      else if (this.formDetails.ath_otherinfo == null || this.formDetails.ath_otherinfo == '') {
        this.common.presentToast('Enter your Other Information');
      }
  
    
      // // else if (this.formDetails.session2Option == null || this.formDetails.session2Option == '') {
      // //   this.common.presentToast('Enter your Camp duration');
      // // }
      // // else if (this.formDetails.session3Option == null || this.formDetails.session3Option == '') {
      // //   this.common.presentToast('Enter your Additional Cost')
      // // }
      // // else if (this.formDetails.session1Option == null || this.formDetails.session1Option == '') {
      // //   this.common.presentToast('Enter yourDrop in Option')
      // // }
  
      else if (this.formDetails.billing_fname == null || this.formDetails.billing_fname == '') {
        this.common.presentToast('Enter your Billing First Name ')
      }
      else if (this.formDetails.billing_lname == null || this.formDetails.billing_lname == '') {
        this.common.presentToast('Enter your billing Last Name ')
      }
  
      else if (this.formDetails.billing_country == null || this.formDetails.billing_country == '') {
        this.common.presentToast('Enter your   Billing Country ')
      }
      else if (this.formDetails.billing_address == null || this.formDetails.billing_address == '') {
        this.common.presentToast('Enter your Billing Address  ')
      }
      else if (this.formDetails.billing_city == null || this.formDetails.billing_city == '') {
        this.common.presentToast('Enter your Billing City   ')
      }
      else if (this.formDetails.billing_province == null || this.formDetails.billing_province == '') {
        this.common.presentToast('Enter your Billing Province  ')
      }
    
      //===============
      else if (this.formDetails.billing_postalcode == null || this.formDetails.billing_postalcode == '') {
          this.common.presentToast('Enter the  Billing Postal code');
         }
         else if(this.common.validateNumber(this.formDetails.billing_postalcode)==false){
          this.common.presentToast('Enter valid postal code');
         }
        //==============
      else if (this.formDetails.billing_email == null || this.formDetails.billing_email == '') {
        this.common.presentToast('Enter your Billing Email ')
      }
      else if (this.common.validateEmail(this.formDetails.par_secondemail) == false) {
        this.common.presentToast('Enter valid Email address');
      }
      // else if (this.formDetails.par_phno == null || this.formDetails.par_phno == '') {
      //   this.common.presentToast('Enter your Parent Phone');
      // }
      else if (this.acceptTerms == false) {
           this.common.presentToast('Accept the Terms and Conditions');
        }
        // if (this.formDetails.billing_cvv == null || this.formDetails.billing_cvv === '') {
        //   this.common.presentToast('Enter the CVV number');
        // } else if (!/^\d{3}$/.test(this.formDetails.billing_cvv)) {
        //   this.common.presentToast('Invalid CVV number');
        // }
    
    
        // if (this.selectedPaymentMethod === 'E-Transfer (or Cash)') {
        //   this.formDetails.payment_method = 'E-Transfer (or Cash)';
        //   this.formDetails.billing_cardno = 'InActive'; // Set the billing card number to an empty string for E-Transfer (or Cash) payment
        // } 
        // else {
        //   const cardNumber = this.formDetails.billing_cardno?.replace(/\s/g, '') || ''; // Null check and remove spaces from the card number input
        //   if (cardNumber.length === 16 && /^\d{4}(\s?\d{4}){3}$/.test(cardNumber)) {
        //     this.formDetails.payment_method = 'Credit Card';
        //     this.formDetails.billing_cardno =cardNumber ; // Store the validated card number in the billing_cardno field
        //    } else {
        //     this.formDetails.billing_cardno = 'Active'; // Reset the billing card number if it is invalid
        //   }
       // }
  
    else{
      localStorage.setItem('ath_fname', this.formDetails.ath_fname);
      localStorage.setItem('ath_lname', this.formDetails.ath_lname);
      localStorage.setItem('par_fname', this.formDetails.par_fname);
      localStorage.setItem('par_lname', this.formDetails.par_lname);
      localStorage.setItem('par_firstemail', this.formDetails.par_firstemail);
      localStorage.setItem(' par_secondemail', this.formDetails.par_secondemail);
      localStorage.setItem('par_address', this.formDetails.par_address);
      localStorage.setItem(' par_city', this.formDetails.par_city);
      localStorage.setItem('par_phno', this.formDetails.par_phno);
      localStorage.setItem(' par_postalcode', this.formDetails.par_postalcode);
      localStorage.setItem('ath_desiredsports', this.formDetails.ath_desiredsports);
      localStorage.setItem('ath_careno', this.formDetails.ath_careno);
      localStorage.setItem('ath_allergiesandfood', this.formDetails.ath_allergiesandfood);
      localStorage.setItem('ath_withpermission', this.formDetails.ath_withpermission);
      localStorage.setItem('ath_otherinfo', this.formDetails.ath_otherinfo);
      localStorage.setItem('radiobtn1', this.formDetails.radiobtn1);
      localStorage.setItem('month', this.formDetails.month);
      localStorage.setItem('day', this.formDetails.day);
      localStorage.setItem('year', this.formDetails.year);
      localStorage.setItem('tsize', this.formDetails.tsize);
      localStorage.setItem('country', this.formDetails.country);
      localStorage.setItem('province', this.formDetails.province);
      localStorage.setItem('billing_fname', this.formDetails.billing_fname);
      localStorage.setItem('billing_lname', this.formDetails.billing_lname);
      localStorage.setItem('payment_method', this.formDetails.payment_method);
      localStorage.setItem('billing_cardno', this.formDetails.billing_cardno);
      localStorage.setItem('billing_country', this.formDetails.billing_country);
      localStorage.setItem('billing_address', this.formDetails.billing_address);
      localStorage.setItem('billing_city', this.formDetails.billing_city);
      localStorage.setItem('billing_province', this.formDetails.billing_province);
      localStorage.setItem('billing_postalcode', this.formDetails.billing_postalcode);
      localStorage.setItem('billing_email', this.formDetails.billing_email);
      
      localStorage.setItem('exp_month', this.formDetails.exp_month);
      localStorage.setItem('billing_cvv', this.formDetails.billing_cvv);
      localStorage.setItem('session1Option', this.formDetails.session1Option);
      localStorage.setItem('session2Option', this.formDetails.session2Option);
      localStorage.setItem('session3Option', this.formDetails.session3Option);
      

      this.web.postData('summercampregform', this.formDetails).then(async res => {

        
        if (res.status == '200') {
          console.log("statusssssssss",res.status);
          console.log("APIIIIIIthis.formDetailsssssssssssss",this.formDetails);
        
          this.formDetails = {
          
            
        // this.formDetailsSubmitted = true;
        // if (this.formDetailsSubmitted) {

        //   this.submitted = true;
        // }
       // this.listradselect = res.data;
        
       
           
       'web_id':'',  
       'ath_fname': '',
       'ath_lname': '',
       'par_fname': '',
       'par_lname': '',
       'par_firstemail': '',
       'par_secondemail': '',
       'par_address': '',
       'par_city': '',
       'par_phno': '',
       'par_postalcode': '',
       'ath_desiredsports': '',
       'ath_careno': '',
       'ath_allergiesandfood': '',
       'ath_withpermission': '',
       'ath_otherinfo': '',
       'radiobtn1': '',
       'month': '',
       'day': '',
       'year': '',
       'tsize': '',
       'country': '',
       'province': '',
       'totalAmount' : '',
       'billing_fname': '',
       'billing_lname': '',
       'payment_method': '',
       'billing_country': '',
       'billing_address': '',
       'billing_city': '',
       'billing_cardno': '',
       'billing_province': '',
       'billing_postalcode': '',
       'billing_email': '',
       'coupon_desp':'',
        'value_1':''
      
           

           
            };
            this.common.presentToast('Updated Sucessfully');
            if (this.totalAmount !== 0) {
                       this.makePayment();
                      } else {
                       console.log("No payment needed. Subtotal is 0.");
                      }
                   //this.makePayment();
                   console.log("res.data",res.data);
           //this.makePayment();
           console.log("res.data",res.data);
           
           this.router.navigate(['/summercampsformconfo'], {
                   queryParams: { webId: res.data}
                  }); 
          
          
        }
        else{
          
         this.common.presentToast('Connection Error')
        }
       
      }
     
      )
     // form.resetForm();
    
    }
  
}
}



  





// declare var Square: any;
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////
// @Component({
//   selector: 'summercampsrefform',
//   templateUrl: 'summercampsrefform.html',
//    styleUrls: ['summercampsrefform.scss']
// })
// export class payment{
//  // campid:number = this.activateRoute.params['_value'].id;
// //  formData = {
// //   campid: this.activateRoute.params['_value'].id,
// //  }
  
//   payments: any;
//   card: any;
//   cardButton: HTMLButtonElement;
//   statusContainer: HTMLElement;
//   accesstoken = "EAAAEPJJiem4rJOB_n6eW84Imj-Ypyf_qr37M7gFzeQ0-lDOmbjrKrgCmOuTGDzw";
//   applicationId1 = "sandbox-sq0idb-O6e2c7juXuf9P0_gSYn32A";
//   locationId1 = "LBWZSZWVJFF4M";
//   paymentForm: any; 
//   userDetailsTemp: any;
//   campdetails1: any=[];
//   isButtondisabled=false;
//   resultcontents: any=[];
  


//   constructor(public common: CommonService,private web: WebService, public dialog: MatDialog,private activateRoute:ActivatedRoute) { 
//   }
//   ngOnInit(): void {
    
//   this.loadScript();
//   this.getresultContents();
//  this.makePayment();
//   }
// oncancel(){
//     this.dialog.closeAll();
//   }
 

//   async  loadScript() {
   
   
//     // Your SqPaymentForm script here
  
//     var applicationId = "sandbox-sq0idb-O6e2c7juXuf9P0_gSYn32A";
  
//     // Set the location ID
//     var locationId = "LQC04P5CAFGVD";
  
//     this.payments = Square.payments(applicationId, locationId);
  
//     this.card = await this.payments.card();
  
//     await this.card.attach('#card-container');
  
//     this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
//     this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
//     const form = document.querySelector('#card-payment') as HTMLFormElement;
  
//     form.addEventListener('submit', async (event: Event) => {
  
//        event.preventDefault();
  
//        const result = await this.card.tokenize(); // the card nonce
  
//     });
//     console.log("result");
//     // onCancel: () => {
//     //   this.common.presentToast('Payment cancelled.');
//     //   console.log("OnCancel");
//     // }
    
//   }
//   async makePayment() {
    
   
//     const statusContainer = document.getElementById('payment-status-container');
//     try {
//       const result = await this.card.tokenize();
//       if (result.status === 'OK') {
//         this.isButtondisabled = true;

//         this.userDetailsTemp = JSON.parse(
//           localStorage.getItem('UserDetails')
//         );
//         console.log("this.userDetailsTemp", this.userDetailsTemp);
       
//         let data = {
        
          
//           customer_id: localStorage.getItem('UserId'),
//           //amount: localStorage.getItem('campamount'),
//           ath_fname:localStorage.getItem('ath_fname'),
//           ath_lname:localStorage.getItem('ath_lname'),
//           par_fname:localStorage.getItem('par_fname'),
//           par_lname:localStorage.getItem('par_lname'),
//           par_firstemail:localStorage.getItem('par_firstemail'),
//           par_secondemail:localStorage.getItem('par_secondemail'),
//           par_address:localStorage.getItem('par_address'),
//           par_city:localStorage.getItem('par_city'),
//           phone:localStorage.getItem('phone'),
//           par_postalcode:localStorage.getItem('par_postalcode'),
//           ath_desiredsports:localStorage.getItem('ath_desiredsports'),
//           ath_careno:localStorage.getItem('ath_careno'),
//           ath_allergiesandfood:localStorage.getItem('ath_allergiesandfood'),
//           ath_withpermission:localStorage.getItem('ath_withpermission'),
//           ath_otherinfo:localStorage.getItem('ath_otherinfo'),
//           radiobtn1:localStorage.getItem('radiobtn1'),
//           month:localStorage.getItem('month'),
//           day:localStorage.getItem('day'),
//           year:localStorage.getItem('year'),
//           tsize:localStorage.getItem('tsize'),
//           country:localStorage.getItem('country'),
//           province:localStorage.getItem('province'),
//           billing_fname:localStorage.getItem('billing_fname'),
//           billing_lname:localStorage.getItem('billing_lname'),
//           payment_method:localStorage.getItem('payment_method'),
//           billing_country:localStorage.getItem('billing_country'),
//           billing_address:localStorage.getItem('billing_address'),
//           billing_city:localStorage.getItem('billing_city'),
//           billing_province:localStorage.getItem('billing_province'),
//           billing_postalcode:localStorage.getItem('billing_postalcode'),
//           billing_email:localStorage.getItem('billing_email'),
        
     
     

      
//           transaction_response: 'details',
//           transaction_method: 'card',
//           payment_status: 'success',
//           paymentToken: result.token,
//           locationId: this.locationId1,
//           accesstoken: this.accesstoken
//         };
//         this.web.postData('addregistrationcamp', data).then(
         
//           (res) => {
//             if (res.status == '200') {
//               this.common.presentToast('Payment Successfully');
             
//               this.isButtondisabled = false;
//               // this.common.presentToast('Registered Successfully');
//               setTimeout(() => {
//                 window.location.reload();
//               });
//               //this.ngOnInit();
//             } else {
//               this.common.presentToast(res.error);
//               this.isButtondisabled = false;
//             }
//           }, err => {
//             console.log(err);
//             this.common.presentToast('Connection Error');
//             this.isButtondisabled = false;
//           });

        
//     //this.processPayment(result)
//         // this.http.post('http://your-api-endpoint.com/charge', {
//         //   paymentToken: result.token,
//         //   amount: this.EventDetails.price
//         // }).subscribe(response => {
//         //   console.log(response);
//         //   statusContainer.innerHTML = "Payment Successful";
//         // }, error => {
//         //   console.error(error);
//         //   statusContainer.innerHTML = "Payment Failed";
//         // });
//       } else {
//         let errorMessage = `Tokenization failed with status: ${result.status}`;
//         if (result.errors) {
//           errorMessage += ` and errors: ${JSON.stringify(
//             result.errors
//           )}`;
//         }
//         throw new Error(errorMessage);
//       }
//     } catch (e) {
//       console.error(e);
//       statusContainer.innerHTML = "Payment Failed";
//     }
//   }

//   getresultContents(){
//     this.web.getData('getResultContents').then((res) => {
//         if (res.status == '200') {
//           this.resultcontents = res.data;
//         console.log("resultcontents",this.resultcontents);
//         } else {
//           console.log(":(")
//         }
//       }, err => {
//         console.log(err)