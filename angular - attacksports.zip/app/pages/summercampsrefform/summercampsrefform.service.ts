import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../services/common.service';
@Injectable({
  providedIn: 'root'
})
export class SummercampsrefformService {
  private campregisterform: FormGroup;
  constructor(private fb: FormBuilder, private toast: ToastrService,  private common:CommonService)
   {
    this.campregisterform = this.fb.group({

      ath_fname: ['', {validators: Validators.compose([Validators.required])}],
      ath_lname: ['', {validators: Validators.compose([Validators.required])}],
      par_fname: ['', {validators: Validators.compose([Validators.required])}],
      par_lname : ['', {validators: Validators.compose([Validators.required])}],
      par_firstemail: ['', {validators: Validators.compose([Validators.required])}],
      par_secondemail: ['', {validators: Validators.compose([Validators.required])}],
      par_address: ['', {validators: Validators.compose([Validators.required])}],
      par_city: ['', {validators: Validators.compose([Validators.required])}],
      phone: ['', {validators: Validators.compose([Validators.required])}],
      par_postalcode: ['', {validators: Validators.compose([Validators.required])}],
      ath_desiredsports: ['', {validators: Validators.compose([Validators.required])}],
      ath_careno: ['', {validators: Validators.compose([Validators.required])}],
      ath_allergiesandfood: ['', {validators: Validators.compose([Validators.required])}],
      ath_withpermission: ['', {validators: Validators.compose([Validators.required])}],
      ath_otherinfo: ['', {validators: Validators.compose([Validators.required])}],
      radiobtn1: ['', {validators: Validators.compose([Validators.required])}],
      radiobtn2: ['', {validators: Validators.compose([Validators.required])}],
      radiobtn3: ['', {validators: Validators.compose([Validators.required])}],
      month: ['', {validators: Validators.compose([Validators.required])}],
      day: ['', {validators: Validators.compose([Validators.required])}],
      year: ['', {validators: Validators.compose([Validators.required])}],
      tsize: ['', {validators: Validators.compose([Validators.required])}],
      country: ['', {validators: Validators.compose([Validators.required])}],
      province: ['', {validators: Validators.compose([Validators.required])}],
      billing_fname: ['', {validators: Validators.compose([Validators.required])}],
      billing_lname: ['', {validators: Validators.compose([Validators.required])}],
      payment_method: ['', {validators: Validators.compose([Validators.required])}],
      billing_cardno: ['', {validators: Validators.compose([Validators.required])}],
      billing_country: ['', {validators: Validators.compose([Validators.required])}],
      billing_address: ['', {validators: Validators.compose([Validators.required])}],
      billing_city: ['', {validators: Validators.compose([Validators.required])}],
      billing_province: ['', {validators: Validators.compose([Validators.required])}],
      billing_postalcode: ['', {validators: Validators.compose([Validators.required])}],
      billing_email: ['', {validators: Validators.compose([Validators.required])}],
      exp_day: ['', {validators: Validators.compose([Validators.required])}],
      exp_month: ['', {validators: Validators.compose([Validators.required])}],
      billing_cvv: ['', {validators: Validators.compose([Validators.required])}],
     
     
    });
   }
   exportNewForm(){
    return this.campregisterform;
  }
}
