import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SummercampsrefformComponent } from './summercampsrefform.component';
import { SummercampsRefformRoutingModule } from './summercampsrefform.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CurrencyPipe } from '@angular/common';


@NgModule({
  declarations: [
    SummercampsrefformComponent
  ],
  imports: [
    CommonModule,
    SummercampsRefformRoutingModule,
    HeaderFooterModule,
    ReactiveFormsModule,
    FormsModule,
    MatRadioModule,
    MatCheckboxModule
   
  ],
  providers: [CurrencyPipe],
})
export class SummerMultiSportCampsModule { }
