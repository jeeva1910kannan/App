import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HockeycampsRoutingModule } from './hockeycamps-routing.module';
import { HockeycampsComponent } from './hockeycamps.component';
import { JulyhockeycampsComponent } from './julyhockeycamps/julyhockeycamps.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { KelownacampComponent } from './kelownacamp/kelownacamp.component';

@NgModule({
  declarations: [
    HockeycampsComponent,
    JulyhockeycampsComponent,
    KelownacampComponent
  ],
  imports: [
    CommonModule,
    HockeycampsRoutingModule,
    HeaderFooterModule
  ]
})
export class HockeycampsModule { }
