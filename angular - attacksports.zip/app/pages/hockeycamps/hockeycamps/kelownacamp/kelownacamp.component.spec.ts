import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KelownacampComponent } from './kelownacamp.component';

describe('KelownacampComponent', () => {
  let component: KelownacampComponent;
  let fixture: ComponentFixture<KelownacampComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KelownacampComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KelownacampComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
