import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { WebService } from './../../../providers/web.service';

@Component({
  selector: 'app-kelownacamp',
  templateUrl: './kelownacamp.component.html',
  styleUrls: ['./kelownacamp.component.scss']
})
export class KelownacampComponent implements OnInit {
  sectionOne:any
  sectionTwo:any

  constructor(private web:WebService,private sanitizer:DomSanitizer) { }

  ngOnInit(): void {
    this.getPageContents()
  }

  sanitizeContents(htmlString){
    return this.sanitizer.bypassSecurityTrustHtml(htmlString)
  }
  getPageContents(){
    this.web.getData('gethockeycampdetails?id=2').then((res) => {
      if(res['status'] == '200'){        
        this.sectionOne = JSON.parse(res['data']['section_one'])
        this.sectionTwo = JSON.parse(res['data']['section_two'])
        console.log(this.sectionOne)
        console.log(this.sectionTwo)
      }
    })
  }

}
