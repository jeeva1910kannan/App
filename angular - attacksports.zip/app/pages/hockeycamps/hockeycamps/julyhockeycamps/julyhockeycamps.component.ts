import { Component, OnInit } from '@angular/core';
import { WebService } from './../../../../providers/web.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-julyhockeycamps',
  templateUrl: './julyhockeycamps.component.html',
  styleUrls: ['./julyhockeycamps.component.scss']
})
export class JulyhockeycampsComponent implements OnInit {
  sectionOne:any
  sectionTwo:any
  constructor(private web:WebService,private sanitizer:DomSanitizer) { }

  ngOnInit(): void {
    this.getPageContents()
  }
 
  sanitizeContents(htmlString){
    return this.sanitizer.bypassSecurityTrustHtml(htmlString)
  }
  getPageContents(){
    this.web.getData('gethockeycampdetails?id=1').then((res) => {
      if(res['status'] == '200'){        
        this.sectionOne = JSON.parse(res['data']['section_one'])
        this.sectionTwo = JSON.parse(res['data']['section_two'])
        console.log(this.sectionOne)
        console.log(this.sectionTwo)
      }
    })
  }

  

  

}
