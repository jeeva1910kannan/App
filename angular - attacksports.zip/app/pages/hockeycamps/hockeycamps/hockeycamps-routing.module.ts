import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HockeycampsComponent } from './hockeycamps.component';
import { JulyhockeycampsComponent } from './julyhockeycamps/julyhockeycamps.component';
import { KelownacampComponent } from './kelownacamp/kelownacamp.component';

const routes: Routes = [
  {
    path : '',
    component : HockeycampsComponent
  },
  {
    path : 'julyhockeycamps',
    component : JulyhockeycampsComponent
  },
  {
    path : 'attackkelownhockeycamp',
    component : KelownacampComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HockeycampsRoutingModule { }
