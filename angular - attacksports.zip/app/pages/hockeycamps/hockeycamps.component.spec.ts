import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HockeycampsComponent } from './hockeycamps.component';

describe('HockeycampsComponent', () => {
  let component: HockeycampsComponent;
  let fixture: ComponentFixture<HockeycampsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HockeycampsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HockeycampsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
