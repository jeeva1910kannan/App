import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hockeycamps',
  templateUrl: './hockeycamps.component.html',
  styleUrls: ['./hockeycamps.component.scss']
})
export class HockeycampsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
