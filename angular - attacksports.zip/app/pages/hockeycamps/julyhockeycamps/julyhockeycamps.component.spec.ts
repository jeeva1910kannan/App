import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JulyhockeycampsComponent } from './julyhockeycamps.component';

describe('JulyhockeycampsComponent', () => {
  let component: JulyhockeycampsComponent;
  let fixture: ComponentFixture<JulyhockeycampsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JulyhockeycampsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JulyhockeycampsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
