import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,Params} from '@angular/router';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-tournament-confopage',
  templateUrl: './tournament-confopage.component.html',
  styleUrls: ['./tournament-confopage.component.scss']
})
export class TournamentConfopageComponent implements OnInit {

  base_url: string = environment.base_url;
  webId: string;
  tournamentConfoPage: any;

  constructor(private web: WebService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params: Params) => {
      this.webId = params['webId'];
      console.log('webId:', this.webId);
      this.getTournamentConfoPage();
    });
  }


  getTournamentConfoPage() {
    this.web.getData('getTournamentConfoPage').then((res) => {
      if (res.status == '200') {
        const tournamentConfoPageArray = res.data;
        console.log("ARRAY", tournamentConfoPageArray)
        this.tournamentConfoPage = tournamentConfoPageArray.find(item => item.web_id === this.webId);
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
}