import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TournamentConfopageComponent } from './tournament-confopage.component';

const routes: Routes = [
  {
    path: '',
    component: TournamentConfopageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TournamentConfopageRoutingModule { }
