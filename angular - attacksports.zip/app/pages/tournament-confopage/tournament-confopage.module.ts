import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TournamentConfopageComponent } from './tournament-confopage.component';
import { TournamentConfopageRoutingModule } from './tournament-confopage.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    TournamentConfopageComponent
  ],
  imports: [
    CommonModule,
    TournamentConfopageRoutingModule,
    HeaderFooterModule,
    ReactiveFormsModule,
    FormsModule,
   
  ],
})

export class TournamentConfopageModule { }