import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../services/common.service';
import { DatePipe, formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { PaymentPopupComponent } from '../payment-popup/payment-popup.component';
import { da } from 'date-fns/locale';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  ICreateOrderRequest,
  IPayPalConfig,
  NgxPaypalComponent,
  PayPalScriptService,
} from 'ngx-paypal';

@Component({
  selector: 'app-instructordetails',
  templateUrl: './instructordetails.component.html',
  styleUrls: ['./instructordetails.component.scss']
})
export class InstructordetailsComponent implements OnInit {
  profile: string;
  EventDetails: any;
  instructor: any;
  myvideos: any;
  videodate: Date;
  request_date: Date;
  startdate:any;
  customer_id:any;
  status:number=0;
  date : any;
  formatedDate : any;
  request:Boolean;
  request_message:string="You have a request from";
  userValidation: any = {
  };
  tradeid: any;
  today= new Date();
  // todaysDataTime = '';
  todaysDataTime = new Date();
continuepayment: boolean = false;
  notify: any;
  userdetails: any;
  user_type:any="Instructor";
  details: any;
  litedesc: string;
  public payPalConfig?: IPayPalConfig;
  paymentMethod:any;
  payPalSubscribeConfig:IPayPalConfig;
  availablePlans: any ={}
  selectedPlanAmount: any;
  selectedPlanName: any;
  selectedPlanId: any;
  selectedPlanTemp:any;
  userDetailsTemp: any;
  subscribe: any;
  follow_disable:boolean = false;

  constructor(private activateRoute:ActivatedRoute, private web: WebService,
    public common: CommonService, public dialog: MatDialog) { }
    base_url: string = environment.base_url;
  ngOnInit(): void {
    this.getsubplan();
    this.request=false;
    // this.todaysDataTime = formatDate(this.today, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530');

    this.test(this.activateRoute.params['_value'].id);
  }
  async findstart(startdate: any) {
    this.videodate = new Date(startdate * 1000);
  }
  async finddesc(desc: any) {
    this.litedesc= desc.substring(0, 170) + '....';    
  }
  test(id){
    let data =
    {
   
      instructor_id:id,
      customer_id:localStorage.getItem('UserId'),
    }
    console.log(data);
    this.tradeid=data.instructor_id
    console.log("tradeid",this.tradeid);
    this.web.postData('getselectedinstructor',data).then((res) => {
      if (res.status == '200') {
        this.getsubscribestatus(id);
        this.instructor = res.data;
     this.getallvideos(data);
        this.profile=this.base_url+'uploads/Profile/'+this.instructor.profile;
        this.web.postData('getallstatus',data).then((res) => {
          if (res.status == '200') {
            this.details = res.data[0];
            // this.status=res.data.data.status;
            console.log(this.details,"status")
            console.log(this.status,"status")
          } else {
            console.log(res.error);
          }
        }, err => {
          console.log(err);
        this.common.presentToast('Connection Error.');
        });
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    this.common.presentToast('Connection Error.');
    });
  
    

}
async getallvideos(data) {
   data = {
       customer_id:localStorage.getItem("UserId"),
       instructor_id:this.activateRoute.params['_value'].id
  }
  
  await this.web.postData('getinstructorvideos',data).then((res) => {
    if (res.status == '200') {
      this.myvideos = res.data;
    } else {
      console.log(":(")
    }
  }, err => {
    console.log(err);
    console.log(":)")
  })
}
//get subscribtion status
async getsubscribestatus(id) {
let data={
  instructor_id:id,
  customer_id:localStorage.getItem('UserId'),
}
  await this.web.postData('getsubscribe_status',data).then((res) => {
    if (res.status == '200') {
      this.subscribe = res.data[0]['payment_status'];
      console.log(this.subscribe,"subscribe");

    } else {
      console.log(":(")
    }
  }, err => {
    console.log(err);
    console.log(":)")
  })
}
request_instrutor(startdate:any){
this.follow_disable = true;
  this.userValidation.customer_id=localStorage.getItem('UserId');
 
  this.userValidation.instructor_id=this.tradeid;
  this.userValidation.status=this.status;
  this.userValidation.request_date= this.todaysDataTime ;
  this.userValidation.notification= this.request_message ;
  console.log(this.todaysDataTime)
  this.web.postData('followrequest',this.userValidation).then((res) => {

    if (res.status == '200') {
      console.log(res.data);
      console.log(res);
      this.common.presentToast(res.error);
      this.test(this.userValidation.instructor_id);
       this.request=true; 
      // this.store_request();
    } else {
        this.common.presentToast(res.error);
    }
  }, err => {
    console.log(err);
    this.common.presentToast('Connection Error');
  });
}

getConfig(plan_id:string): IPayPalConfig {
  console.log(plan_id,"plannnn")
  var that = this;
  return {
    clientId: environment.paypal_key,
    currency: "USD",
    vault: "true",
    style: {
      label: "paypal",
      layout: "vertical",
      // size: "small",
      // shape: "pill",
      // color: "silver",
      // tagline: false,
    },
    createSubscription: function (data) {
      return data.subscription.create({
        'plan_id':plan_id,
      });
    },
    onApprove: function (data, actions) {
      console.log(data,"plannnn")

      actions.order.get().then((details:any) => {
        console.log("subscription details:", details);
        that.createTokenPaypal(details)
      });
    },
    onCancel: (data, actions) => {
      this.common.presentToast('Payment cancelled.');
    },
    onError: (err) => {
      this.common.presentToast('Service not available.');
      console.log("OnError", err);
    },
    onClick: (data, actions) => {
      console.log("Clicked:", data, actions);
    },
  } 
}

createTokenPaypal(details:any): void {
  this.userDetailsTemp = JSON.parse(
    localStorage.getItem('UserDetails')
  );

  console.log('Paypal id', details.id);
  let data = {
    user: localStorage.getItem('UserId'),
    instructor: this.activateRoute.params['_value'].id,
    payment_id: details.id,
    plan_id: this.selectedPlanId,
    email: this.userDetailsTemp.email,
    payment_response: details,
    payment_method: 'paypal'
  };

  console.log(data);
  this.web.postData('makePayment2', data).then(
    (res) => {
      if (res.status == '200') {
        this.getsubscribestatus(this.activateRoute.params['_value'].id);
        this.continuepayment = false;
        this.common.presentToast(res.error);
        // this.pageAction = 'view';
        // this.dialog.closeAll();
        // setTimeout(() => {
          // this.dialog.open(RegisterCongratsComponent);
        // }, 400);
      } else {
        this.common.presentToast(res.error);
      }
    },
    (err) => {
      console.log(err);
      this.common.presentToast('Connection Error');
    }
  );
}
 
async getsubplan(){
    
  this.web.getData('customerSubscribePlanDetails').then((res) => {
      if (res.status == '200') {
        this.availablePlans = res.data;
        this.selectedPlanId = this.availablePlans[0].web_id;
        this.selectedPlanName = this.availablePlans[0].plan_name;
        this.selectedPlanAmount = this.availablePlans[0].plan_amount;
        this.selectedPlanTemp = this.availablePlans[0].plan_validity;
        this.payPalSubscribeConfig = this.getConfig(this.availablePlans[0].plan_paypal_id);
      
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    this.common.presentToast('Connection Error.');
    });

  }

open_dialog(data1){
//this.continuepayment = true;
this.dialog.open(Payment, {
  data: {
    instructor_id: this.activateRoute.params['_value'].id,
     type: localStorage.getItem('type'),
     amount: this.selectedPlanAmount,
     planname: this.selectedPlanName,
     planid: this.selectedPlanId,
     paymentid: this.details.id
   }
   

})
}
close_dialog(){
  this.continuepayment = false;
}

}

declare var Square: any;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
@Component({
  selector: 'Insrtuctorpayment',
  templateUrl: 'instructorpayment.html',
   styleUrls: ['instructorpayment.scss']
  // styleUrls: ['./withdraw.scss']
})

export class Payment{
 // campid:number = this.activateRoute.params['_value'].id;
//  formData = {
//   campid: this.activateRoute.params['_value'].id,
//  }
//public value = this.dialog.get('value');
EventDetails: any;
  payments: any;
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEOKq3_JUA1xw1RCiov2mms1eJviBzaBrw1rM40aMSTdKXCpfJWnkIfJfwad-";
  applicationId1 = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  locationId1 = "LC2PEQFX591R6";
  paymentForm: any; 
  userDetailsTemp: any;
  campdetails1: any;
  phone: string;
  email: string;
  fetchingStatus: boolean = true;
  loading = true;
  isButtonDisabled = false;
  test: any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public common: CommonService,private web: WebService, public dialog: MatDialog,private activateRoute:ActivatedRoute) { 
  }
  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit(): void {
    this.email = localStorage.getItem('email');
    this.phone = localStorage.getItem('phone');
  this.loadScript();
  this.test = this.activateRoute.params['_value'].id;
  console.log("id=>",)
  console.log("id=>",this.data);
  // setTimeout(() => {
  //   this.fetchingStatus = false;
  // }, 2500);

  setTimeout(() => {
    this.loading = false;
  }, 1000);
 
  }
oncancel(){
    this.dialog.closeAll();
  }
 

  async  loadScript() {
   
  
    // Your SqPaymentForm script here
  
    var applicationId = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  
    // Set the location ID
    var locationId = "LQC04P5CAFGVD";


    // var applicationId = "sandbox-sq0idb-N2D0zEBfzwuEIW8uNfVzZg";
  
    // // Set the location ID
    // var locationId = "LC2PEQFX591R6";
    this.fetchingStatus = true;
    this.payments = Square.payments(applicationId, locationId);
  
    this.card = await this.payments.card();
  
    await this.card.attach('#card-container');
    this.fetchingStatus = false;
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
    const form = document.querySelector('#card-payment') as HTMLFormElement;
  
    form.addEventListener('submit', async (event: Event) => {
  
       event.preventDefault();
  
       const result = await this.card.tokenize(); // the card nonce
  
    });
    console.log("result");
    // onCancel: () => {
    //   this.common.presentToast('Payment cancelled.');
    //   console.log("OnCancel");
    // }
    
  }
  async makePayment() {
    
    const statusContainer = document.getElementById('payment-status-container');
    
    try {
      const result = await this.card.tokenize();
      
      if (result.status === 'OK') {
        this.isButtonDisabled = true;
        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
        //console.log('Paypal id', details.id);
        let data = {
          user: localStorage.getItem('UserId'),
         // customer_id: this.cust_id,
          email: this.email,
          phone: this.phone,
          amount: this.data.amount,
          //instructor: this.activateRoute.params['_value'].id,
         // payment_id: details.id,
          plan_id: this.data.planid,
          payment_id: this.data.paymentid,
          //payment_response: details,
          payment_method: 'card',
          instructor: this.data.instructor_id,
          payment_status: 'success',
          planname: this.data.planname,
          paymentToken: result.token,
          locationId: this.locationId1,
          accesstoken: this.accesstoken
        };
        this.web.postData('makepayment3', data).then(
          
          (res) => {
            
            if (res.status == '200') {
              
              this.common.presentToast('Payment Successfully');
              this.isButtonDisabled = false;
              //this.eventregister = 'true';
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              }, 600);
              //this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
              this.isButtonDisabled = false;
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
            this.isButtonDisabled = false;
          });


        
    //this.processPayment(result)
        // this.http.post('http://your-api-endpoint.com/charge', {
        //   paymentToken: result.token,
        //   amount: this.EventDetails.price
        // }).subscribe(response => {
        //   console.log(response);
        //   statusContainer.innerHTML = "Payment Successful";
        // }, error => {
        //   console.error(error);
        //   statusContainer.innerHTML = "Payment Failed";
        // });
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }
  
  

}




