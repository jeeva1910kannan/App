
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { HeaderFooterModule } from '../../header-footer/header-footer.module';

import { CommonModule } from '@angular/common';
import { NgxPayPalModule } from 'ngx-paypal';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatPaginatorModule} from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { InstructordetailsRoutingModule } from './instructordetailsrouting.module';
import { InstructordetailsComponent, Payment } from './instructordetails.component';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';


@NgModule({
  declarations: [
    InstructordetailsComponent,
    Payment
  ],
  imports: [
    HeaderFooterModule,
    RouterModule,
    InstructordetailsRoutingModule,
CommonModule,MatFormFieldModule,MatPaginatorModule,FormsModule,MatInputModule,NgxPayPalModule,
NgxSkeletonLoaderModule
  ],
 schemas:[CUSTOM_ELEMENTS_SCHEMA,
NO_ERRORS_SCHEMA]
})
export class InstructordetailsModule { }

