import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { InstructordetailsComponent } from "./instructordetails.component";



const routes: Routes = [
  {
    path: "",
    component: InstructordetailsComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class InstructordetailsRoutingModule { }