import { Injectable } from '@angular/core';
import { MatSnackBar } from "@angular/material/snack-bar";
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  questionSearchQueryBehaviour: BehaviorSubject<any> = new BehaviorSubject(false);
  inDropinSubscription: BehaviorSubject<any> = new BehaviorSubject(false);
  private dropinRestriction:boolean = false;
  
  showToast(arg0: string, arg1: string, error: any) {
    throw new Error('Method not implemented.');
  }
  grecaptcha: any;
  getResponse(length: number) {
    throw new Error('Method not implemented.');
  }

  constructor(private _snackBar: MatSnackBar) {

    this.inDropinSubscription.subscribe(res=>{
      this.dropinRestriction = res;
    });
    
   }

  validateDropinRestriction(){  
    if(this.dropinRestriction){
      this.presentToast('Navigating other pages may cause you to lose your chat history.', 5500)
      return false;
    }
    return true;
  }
  validateNumber(val: any) {
    // var re = /^\d+$/;
    var re = /^(?!0)\d+$/;
   //var re = /^((00|\+)[0-9]{2,5}|0)[1-9][0-9]{7,9}$/i;
   if (re.test(val)) {
     return true;
   } else {
     return false;
   }
 }
  presentToast(msg: string, duration:number=3000) {

    let toast =msg ;

    if(toast !=''){
      this._snackBar.open(toast, "x", {
        duration,
        horizontalPosition: 'right',
        verticalPosition: 'top'

      });
    }


  }


  validateEmail(email: string) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email) && email.indexOf(" ") == -1;
  }


  validateMobileNumber(val: any) {
     var re = /^(\+\d{1,3}[- ]?)?\d{10}$/g;
    //var re = /^((00|\+)[0-9]{2,5}|0)[1-9][0-9]{7,9}$/i;
    if (re.test(val)) {
      return true;
    } else {
      return false;
    }
  }
  validatespace(val: any) {
    // var re= /^[\+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$;
    /*  var re = /^(\+\d{1,3}[- ]?)?\d{10}$/i; */
     var re = /^\S*$/;
    // var re = /^((00|\+)[0-9]{2,5}|0)[1-9][0-9]{7,9}$/i;
    if (re.test(val)) {
      return true;
    } else {
      return false;
    }
  }

  timeConverter(UNIX_timestamp:any){
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var hour_str;
    var min_str;
    var sec_str;
    var amppm='AM';

//     if (month.length < 2)
//     month = '0' + month;
// if (day.length < 2)
//     day = '0' + day;

    if(hour>12){
      hour=(hour-12);
      amppm='PM';
    }
    else if(hour==12){
      amppm='PM';
    }
    else if(hour<12){
      amppm='AM';
    }

    if((hour+'').length<2){
      hour_str='0'+hour;
    }
    else{
      hour_str=hour;
    }

    var min = a.getMinutes();
    if((''+min).length<2){
      min_str='0'+min;
    }
    else{
      min_str=min;
    }

    var sec = a.getSeconds();
    if((''+sec).length<2){
      sec_str='0'+sec;
    }
    else{
      sec_str=sec;
    }
    var time = date + ' ' + month + ' ' + year + ' ' + hour_str + ':' + min_str + ':' + sec_str + ' ' + amppm;
    return time;
  }
}
