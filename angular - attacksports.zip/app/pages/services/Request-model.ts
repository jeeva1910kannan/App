export class R{
  public status: string;
  public data: any;
  public error: string;

  constructor(params:any) {
    this.status = params.status || '';
    this.data = params.data || {};
    this.error = params.error || '';
  }

}
