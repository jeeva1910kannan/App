import { Routes } from '@angular/router';

import { SummermultisportcampsComponent } from './summermultisportcamps.component';

export const SummermultisportcampsRoutes: Routes = [
  {
    path: '',
    component: SummermultisportcampsComponent
  },
];
