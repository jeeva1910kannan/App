export default class SummermultisportcampsModel {
    public web_id: number;
    public multisportcamps_title1:any;
    public multisportcamps_title2:any;
    public multisportcamps_content1:any;
    public multisportcamps_content2:any;

    //start_end_date: any;
    public action: string;
    
  
    constructor(summermultisportcamps:any = {}){
  
    this.web_id = summermultisportcamps.web_id || '';
    this.multisportcamps_title1 = summermultisportcamps.multisportcamps_title1 || '';
    this.multisportcamps_title2 = summermultisportcamps.multisportcamps_title2 || '';
    this.multisportcamps_content1 = summermultisportcamps.multisportcamps_content1 || '';
    this.multisportcamps_content2 = summermultisportcamps.multisportcamps_content2 || '';

    this.action = summermultisportcamps.action || '' ;
    }
  }