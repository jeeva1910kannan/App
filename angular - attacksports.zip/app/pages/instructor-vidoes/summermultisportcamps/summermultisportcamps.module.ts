import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SummermultisportcampsRoutes } from './summermultisportcamps.routing';
import { SummermultisportcampsComponent } from './summermultisportcamps.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgbdSortableHeader } from './summermultisportcamps.component';
import { SummermultisportcampsTableService } from './summermultisportcamps-table.service';

@NgModule({
  imports: [
    RouterModule.forChild(SummermultisportcampsRoutes),
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    CKEditorModule
  ],
  declarations: [
    SummermultisportcampsComponent,
    NgbdSortableHeader,
  ],
  providers: [SummermultisportcampsTableService]
})
export class SummerMultisportCampsModule {}
