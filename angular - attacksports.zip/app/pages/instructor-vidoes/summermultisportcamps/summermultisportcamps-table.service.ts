import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import  SummermultisportcampsModel  from './summermultisportcamps.model';
import { CommonService } from 'src/app/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class SummermultisportcampsTableService {

  private  SummermultisportcampsForm: FormGroup;

  constructor( private fb: FormBuilder, private toast: ToastrService, private common:CommonService) {
    this.SummermultisportcampsForm = this.fb.group({
        multisportcamps_title1: ['', {validators: Validators.compose([Validators.required])}],
        multisportcamps_title2: ['', {validators: Validators.compose([Validators.required])}],
        multisportcamps_content1: ['', {validators: Validators.compose([Validators.required])}],
        multisportcamps_content2: ['', {validators: Validators.compose([Validators.required])}],
      
      //company_background_image: ['', {validators: Validators.compose([Validators.required])}],
    });
}

exportNewForm(){
  return this.SummermultisportcampsForm;
}
//*ngIf="dialogData.company_gallery_entry_form == '1' "
async SummermultisportcampsFormValidation(val: SummermultisportcampsModel):Promise<boolean> {
  console.log("title ==>",val);
//   var phone = val.banner_phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1 $2 $3');
//   val.banner_phone = phone;
//   console.log(phone);
  let action = val.action;

  if(val.multisportcamps_title1==null || val.multisportcamps_title1=='' || val.multisportcamps_title1.length > 500){
    this.toast.warning('Missing Fields', 'Enter Title within 500 Characters.');
    document.getElementById('title').focus();
    return false;
  } else if(val.multisportcamps_title2==null || val.multisportcamps_title2=='' || val.multisportcamps_title2.length > 500){
    this.toast.warning('Missing Fields', 'Enter Description Within 500 Character.');
    document.getElementById('description').focus();
    return false;
  }else if(val.multisportcamps_content1==null || val.multisportcamps_content1=='' || val.multisportcamps_content1.length > 800000){
    this.toast.warning('Missing Fields', 'Enter Contents Within 8,00,000 Character.');
    document.getElementById('content').focus();
    return false;
  }else if(val.multisportcamps_content2	==null || val.multisportcamps_content2	=='' || val.multisportcamps_content2	.length > 10000){
    this.toast.warning('Missing Fields', 'Enter Contents Within 10,000 Character.');
    document.getElementById('content').focus();
    return false;
  }
  else {
    return true;
  }
}

}
