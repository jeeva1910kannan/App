export default class SummerMultisportCampsTable{
    /*     Id: number=0;
        public banner_title: string|null=null;
        public banner_description: string|null=null;
        public banner_phone: number|null=null;
        public banner_imagePath:string|null=null; */
        public web_id: number;
        public multisportcamps_title1: string='';
        public multisportcamps_title2: string='';
        public multisportcamps_content1	: string='';
        public multisportcamps_content2: string='';
        public action: string='';
       
        constructor(user:any = {}){
          this.web_id = user.web_id || '';
          this.multisportcamps_title1 = user.multisportcamps_title1 || '';
          this.multisportcamps_title2 = user.multisportcamps_title2 || '';
          this.multisportcamps_content1	 = user.multisportcamps_content1	 || '';
          this.multisportcamps_content2 = user.multisportcamps_content2 || '';
          this.action = user.action || '';
        }
      }