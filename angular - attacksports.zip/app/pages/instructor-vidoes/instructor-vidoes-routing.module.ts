import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InstructorVidoesComponent } from './instructor-vidoes.component';

const routes: Routes = [ 
  {
    path: "",
    component: InstructorVidoesComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InstructorVidoesRoutingModule { }
