import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructorVidoesComponent } from './instructor-vidoes.component';

describe('InstructorVidoesComponent', () => {
  let component: InstructorVidoesComponent;
  let fixture: ComponentFixture<InstructorVidoesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstructorVidoesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructorVidoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
