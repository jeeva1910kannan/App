export default class SummerCampsRegformTable{
    
        public web_id: number;
        public ath_fname: string='';
        public ath_lname: string='';
        public par_fname	: string='';
        public par_lname: string='';
        public par_firstemail:  string='';
        public action: string='';
        public par_secondemail: string='';
        public par_address: string='';
        public par_city	: string='';
        public phone: string='';
        public par_postalcode: string='';
        public ath_desiredsports: string='';
        public ath_careno: string='';
        public ath_allergiesandfood	: string='';
        public ath_withpermission: string='';
        public ath_otherinfo: string='';
        public radiobtn1: string='';
        public radiobtn2: string='';
        public radiobtn3	: string='';
          public month	: string='';
        public day: string='';
        public year: string='';
        public tsize: string='';
        public country: string='';
        public province	: string='';
        public billing_fname: string='';
        public billing_lname: string='';
        public billing_cardno: string='';
        public billing_country	: string='';
        public billing_address: string='';
        public billing_city: string='';
        public billing_province: string='';
        public billing_postalcode: string='';
        public billing_email	: string='';
        public exp_day: string='';
        public exp_month: string='';
      
    
    
        constructor(user:any = {}){
          this.web_id = user.web_id || '';
          this.ath_fname = user.ath_fname || '';
          this.ath_lname = user.ath_lname || '';
          this.par_fname	 = user.par_fname	 || '';
          this.par_firstemail	 = user.par_firstemail	 || '';
          this.par_secondemail = user.par_secondemail || '';
          this.par_address = user.par_address || '';
          this.par_city = user.par_city || '';
          this.phone	 = user.phone	 || '';
          this.par_postalcode	 = user.par_postalcode	 || '';
          this.ath_desiredsports = user.ath_desiredsports || '';
          this.ath_careno = user.ath_careno || '';
          this.ath_allergiesandfood = user.ath_allergiesandfood || '';
          this.ath_withpermission	 = user.ath_withpermission	 || '';
          this.ath_otherinfo	 = user.ath_otherinfo	 || '';
          this.radiobtn1 = user.radiobtn1 || '';
          this.radiobtn2 = user.radiobtn2 || '';
          this.radiobtn3 = user.radiobtn3 || '';
          this.month	 = user.month	 || '';
          this.day	 = user.day	 || '';
          this.year = user.year || '';
          this.tsize = user.tsize || '';
          this.country = user.country || '';
          this.province	 = user.province	 || '';
          this.billing_fname	 = user.billing_fname	 || '';
          this.billing_lname = user.billing_lname || '';
          this.billing_cardno = user.billing_cardno || '';
          this.billing_country	 = user.billing_country	 || '';
          this.billing_address = user.billing_address || '';
          this.billing_city = user.billing_city || '';
          this.billing_province = user.billing_province || '';
          this.billing_postalcode	 = user.billing_postalcode	 || '';
          this.billing_email	 = user.billing_email	 || '';
          this.exp_month = user.exp_month || '';
          this.exp_day = user.exp_day || '';
          this.action = user.action || '';
        }
      }