export default class SummercampsregformModel {
  public action: string;
    public web_id: number;
    public ath_fname:any;
    public ath_lname:any;
    public par_fname:any;
    public par_lname:any;
    public par_firstemail: any;
    public par_secondemail:any;
    public par_address:any;
    public par_city:any;
    public phone:any;
    public par_postalcode: any;
    public ath_desiredsports:any;
    public ath_careno:any;
    public ath_allergiesandfood:any;
    public radiobtn2:any;
    public radiobtn3: any;
    public ath_withpermission:any;
    public ath_otherinfo: any;
    public radiobtn1:any;
    public month:any;
    public day:any;
    public year:any;
    public tsize: any;
    public country:any;
    public province:any;
    public billing_fname:any;
    public billing_lname:any;
    public billing_cardno: any;
    public billing_country: any;
    public billing_address:any;
    public billing_city: any;
    public billing_province:any;
    public billing_postalcode:any;
    public billing_email:any;
    public exp_day:any;
    public exp_month: any;
   
   
    
  
    constructor(summercampsreg:any = {}){
      this.action = summercampsreg.action || '' ;
    this.web_id = summercampsreg.web_id || '';
    this.ath_fname = summercampsreg.ath_fname || '';

    this.ath_lname = summercampsreg.ath_lname || '';

    this.par_fname = summercampsreg.par_fname || '';

    this.par_lname = summercampsreg.par_lname || '';

    this.par_firstemail = summercampsreg.par_firstemail || '';

    this.par_secondemail = summercampsreg.par_secondemail || '';

    this.par_address = summercampsreg.par_address || '';

    this.par_city = summercampsreg.par_city || '';

    this.phone = summercampsreg.phone || '';

    this.par_postalcode = summercampsreg.par_postalcode || '';

    this.ath_careno = summercampsreg.ath_careno || '';
    
    this.ath_allergiesandfood = summercampsreg.ath_allergiesandfood || '';

    this.ath_withpermission = summercampsreg.ath_withpermission || '';

    this.ath_otherinfo = summercampsreg.ath_otherinfo || '';

    this.radiobtn1 = summercampsreg.radiobtn1 || '';

    this.radiobtn2 = summercampsreg.radiobtn2 || '';

    this.radiobtn3 = summercampsreg.radiobtn3 || '';

    this.month = summercampsreg.month || '';

    this.day = summercampsreg.day || '';

    this.year = summercampsreg.year || '';

    this.tsize = summercampsreg.tsize || '';

    this.country = summercampsreg.country || '';

    this.province = summercampsreg.province || '';

    this.billing_fname = summercampsreg.billing_fname || '';

    this.billing_lname = summercampsreg.billing_lname || '';

    this.billing_cardno = summercampsreg.billing_cardno || '';

    this.billing_country = summercampsreg.billing_country || '';

    this.billing_address = summercampsreg.billing_address || '';

    this.billing_city = summercampsreg.billing_city || '';

    this.billing_province = summercampsreg.billing_province || '';

    this.billing_postalcode = summercampsreg.billing_postalcode || '';

    this.billing_email = summercampsreg.billing_email || '';

    this.exp_day = summercampsreg.exp_day || '';

    this.exp_month = summercampsreg.exp_month || '';
    
    
   
    }
  }