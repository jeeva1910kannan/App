// import { Injectable } from '@angular/core';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { ToastrService } from 'ngx-toastr';
// import  SummercampsregformModel  from './summercampsregform.model';
// import { CommonService } from 'src/app/services/common.service';

// @Injectable({
//   providedIn: 'root'
// })
// export class SummerCampsregformTableService {

//   private summercampsForm: FormGroup;

//   constructor( private fb: FormBuilder, private toast: ToastrService, private common:CommonService) {
//     this.summercampsForm = this.fb.group({
//       ath_fname: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_description: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_contents: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_link: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_image: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_title: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_description: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_contents: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_link: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_image: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_title: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_description: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_contents: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_link: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_image: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_title: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_description: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_contents: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_link: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_image: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_title: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_description: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_contents: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_link: ['', {validators: Validators.compose([Validators.required])}],
//       springhockey_image: ['', {validators: Validators.compose([Validators.required])}],
    
//     });
// }

// exportNewForm(){
//   return this.summercampsForm;
// }
// //*ngIf="dialogData.company_gallery_entry_form == '1' "
// async springhockeyFormValidation(val: SummercampsregformModel):Promise<boolean> {
//   console.log("title ==>",val);
// //   var phone = val.banner_phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1 $2 $3');
// //   val.banner_phone = phone;
// //   console.log(phone);
//   let action = val.action;
//   console.log(val.springhockey_title.length);
//   console.log("string length");
//   if(val.ath_fname==null || val.ath_fname=='' || val.ath_fname.length > 50){
//     this.toast.warning('Missing Fields', 'Enter Title within 50 Characters.');
//     document.getElementById('title').focus();
//     return false;
//   } else if(val.springhockey_description==null || val.springhockey_description=='' || val.springhockey_description.length > 150){
//     this.toast.warning('Missing Fields', 'Enter Description Within 150 Character.');
//     document.getElementById('description').focus();
//     return false;
//   }else if(val.springhockey_contents==null || val.springhockey_contents=='' || val.springhockey_contents.length > 1000){
//     this.toast.warning('Missing Fields', 'Enter Contents Within 1000 Character.');
//     document.getElementById('content').focus();
//     return false;
//   }else if(val.springhockey_image==null || val.springhockey_image==''){
//     this.toast.warning('Missing Fields', 'Upload Image.');
//     document.getElementById('banner').focus();
//     return false;
//   }
//   else {
//     return true;
//   }
// }

// }
