import { Component, Directive, EventEmitter, Input, OnInit, Output, QueryList, ViewChildren } from '@angular/core';
import SummerCampsRegformTable from './summercampsregform-table';
import { WebService } from 'src/app/services/web.service';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/services/common.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

export type SortDirection = 'asc' | 'desc' | '';
const rotate: { [key: string]: SortDirection } = { 'asc': 'desc', 'desc': '', '': 'asc' };
export const compare = (v1:number, v2:number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

export interface SortEvent {
  column: string|null;
  direction: SortDirection;
}

@Directive({
  selector: 'th[sortable]',
  host: {
    '[class.asc]': 'direction === "asc"',
    '[class.desc]': 'direction === "desc"',
    '(click)': 'rotate()'
  }
})

export class NgbdSortableHeader {

  @Input() sortable: string|null=null;
  @Input() direction: SortDirection = '';
  @Output() sort = new EventEmitter<SortEvent>();

  rotate() {
    this.direction = rotate[this.direction];
    this.sort.emit({ column: this.sortable, direction: this.direction });
  }
}



@Component({
  selector: 'app-summercampsregform',
  templateUrl: './summercampsregform.component.html',
  styleUrls: ['./summercampsregform.component.scss']
})
export class SummercampsregformComponent implements OnInit {
  tableSource: SummerCampsRegformTable[];

  sortInstructorList: SummerCampsRegformTable[] | null = null;
  filterInstructor: SummerCampsRegformTable[] | null = null;
  cfilterInstructor: SummerCampsRegformTable[]   //complete example................
  page = 1;
  pageSize = 4;
  totalLengthOfCollection: number = 0;
  dialogData: SummerCampsRegformTable;
  editAddLabel: string = 'View';

  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>=Object.create(null);
  value: any;
  hide: boolean=false;
  constructor(
    private web: WebService,  
     private toast: ToastrService,    
         private confirmationDialogService: CommonService,
         private modalService: NgbModal

  ) { }

  async ngOnInit(): Promise<void> {
    await this.getrequest();
    this.cfilterInstructor = this.tableSource;
    console.log(this.cfilterInstructor,"instruc")
    this.totalLengthOfCollection = this.cfilterInstructor.length;
  }
  onSort({ column, direction }: SortEvent) {
    this.headers.forEach(header => {
      if (header.sortable !== column) {
        header.direction = '';
      }
      
    });

   // sorting client

    if (direction === '') {
      this.sortInstructorList = this.tableSource;
      this.cfilterInstructor= this.tableSource;
    } else {
   
      }  // // //);

    }

     //complete example................
     cpage = 1;
     cpageSize = 4;
   
     _csearchTerm: string='';
     get csearchTerm(): string {
       return this._csearchTerm;
     }
     set csearchTerm(val: string) {
       this._csearchTerm = val;
       this.cfilterInstructor = this.cfilter(val);
       this.totalLengthOfCollection = this.cfilterInstructor.length;
     }
   
     cfilter(v: string) {
       return this.tableSource.filter(x =>
         x.ath_fname?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
         x.ath_lname?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
          x.par_fname?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
          x.par_lname?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
          x.par_firstemail?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
           x.par_secondemail?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
           x.par_city?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
           x.phone?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
            x.par_postalcode?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
            x.ath_desiredsports?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
            x.ath_careno?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
             x.ath_allergiesandfood?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
             x.ath_withpermission?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
             x.ath_otherinfo?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
              x.radiobtn1?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
              x.radiobtn2?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
              x.radiobtn3?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
               x.month ?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
               x.day?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
               x.year?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                x.tsize?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                x.country?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                x.province?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                 x.billing_fname?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                 x.billing_lname?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                 x.billing_cardno?.toLowerCase().indexOf(v.toLowerCase()) !== -1||
                 x.billing_country?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
              x.billing_address?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
               x.billing_city ?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
               x.billing_province?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
               x.billing_postalcode?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                x.billing_email?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                x.exp_day?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
                x.exp_month?.toLowerCase().indexOf(v.toLowerCase()) !== -1 );
                
     } 
   
  async getrequest() {
    await this.web.getData('getsummercampsregform').then(res => {
    if(res.status=='200'){
      // this.loading = false;
        //console.log(res.data);
        this.tableSource =res.data;
        //return res.data;
        //console.log('asdafs',this.tableSource);
    }
    else{
      this.toast.error('danger', res.error);
    }
    },err=>{
      // this.loading = false;
      this.toast.error('danger', 'Connection Error');

    });
    console.log('asd',this.tableSource);
  }

  
  openModal(targetModal:NgbModal,action:any,summercampsform:any) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static'
    });
    //console.log(targetModal);
    //console.log(action);
    this.value = action;
    console.log(targetModal);
   
    
    if (this.value == 'viewsummercampsform') {
      this.dialogData = summercampsform;
      console.log(this.dialogData);
      this.editAddLabel = 'View';
    }
  }



  delete(id:number) {
    console.log(id);
 
    if (window.confirm('Are you sure you want to delete..?')) {
      this.web.postData('deleteSummerCampsForm', {web_id: id}).then(res=>{
        console.log(res.data);
        if(res.status=='200'){
          this.toast.success('Success', res.error);
          this.ngOnInit();
        }else{
          this.toast.warning('Error', res.error);
        }
      },err=>{
        this.toast.warning('Error', 'Connection Error');
      })
    }

  }


  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }


}
