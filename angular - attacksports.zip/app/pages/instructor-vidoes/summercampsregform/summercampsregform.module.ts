import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SummercampsregformRoutes } from './summercampsregform.routing';
import { SummercampsregformComponent } from './summercampsregform.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgbdSortableHeader } from './summercampsregform.component';

@NgModule({
  imports: [
    RouterModule.forChild(SummercampsregformRoutes),
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    CKEditorModule
  ],
  declarations: [
    SummercampsregformComponent,
    NgbdSortableHeader,
  ],

})
export class SummerCampsRegFormModule {}
