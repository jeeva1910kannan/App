import { Routes } from '@angular/router';

import { SummercampsregformComponent } from './summercampsregform.component';

export const SummercampsregformRoutes: Routes = [
  {
    path: '',
    component: SummercampsregformComponent
  },
];
