import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SpringHockeyRoutes } from './springhockey.routing';
import { SpringhockeyComponent } from './springhockey.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgbdSortableHeader } from './springhockey.component';
import { SpringHockeyTableService } from './springhockey-table.service';

@NgModule({
  imports: [
    RouterModule.forChild(SpringHockeyRoutes),
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    CKEditorModule
  ],
  declarations: [
    SpringhockeyComponent,
    NgbdSortableHeader,
  ],
  providers: [SpringHockeyTableService]
})
export class SpringHockeyModule {}
