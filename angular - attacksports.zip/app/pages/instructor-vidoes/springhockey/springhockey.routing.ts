import { Routes } from '@angular/router';

import { SpringhockeyComponent } from './springhockey.component';

export const SpringHockeyRoutes: Routes = [
  {
    path: '',
    component: SpringhockeyComponent
  },
];
