export default class SpringHockeyTable{
    /*     Id: number=0;
        public banner_title: string|null=null;
        public banner_description: string|null=null;
        public banner_phone: number|null=null;
        public banner_imagePath:string|null=null; */
        public web_id: number;
        public springhockey_title: string='';
        public springhockey_description: string='';
        public springhockey_contents	: string='';
        public springhockey_image: string='';
        public action: string='';
        public springhockey_link:  string='';
    
        constructor(user:any = {}){
          this.web_id = user.web_id || '';
          this.springhockey_title = user.springhockey_title || '';
          this.springhockey_description = user.springhockey_description || '';
          this.springhockey_contents	 = user.springhockey_contents	 || '';
          this.springhockey_link	 = user.springhockey_link	 || '';
        
          this.springhockey_image = user.springhockey_image || '';
          this.action = user.action || '';
        }
      }