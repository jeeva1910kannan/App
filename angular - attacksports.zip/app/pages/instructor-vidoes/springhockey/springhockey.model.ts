export default class SpringHockeyModel {
  public web_id: number;
  public springhockey_title:any;
  public springhockey_description:any;
  public springhockey_contents:any;
  public springhockey_link:any;
  public springhockey_image: any;
  //start_end_date: any;
  public action: string;

  constructor(springhockey:any = {}){

  this.web_id = springhockey.web_id || '';
  this.springhockey_title = springhockey.springhockey_title || '';
  this.springhockey_description = springhockey.springhockey_description || '';
  this.springhockey_contents = springhockey.springhockey_contents || '';
  this.springhockey_link = springhockey.springhockey_link || '';
  this.springhockey_image = springhockey.springhockey_image || '';
  this.action = springhockey.action || '' ;
  }
}