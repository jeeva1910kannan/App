import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { Component, OnInit, Directive, EventEmitter, Input, Output, QueryList, ViewChildren } from '@angular/core';
import SpringHockeyTable from './springhockey-table';
import { FormBuilder, FormGroup } from '@angular/forms';
import { environment } from './../../../environments/environment';
import { WebService } from './../../services/web.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { SpringHockeyTableService } from './springhockey-table.service';

export type SortDirection = 'asc' | 'desc' | '';
const rotate: { [key: string]: SortDirection } = { 'asc': 'desc', 'desc': '', '': 'asc' };
export const compare = (v1:number, v2:number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

export interface SortEvent {
  column: string|null;
  direction: SortDirection;
}

@Directive({
  selector: 'th[sortable]',
  host: {
    '[class.asc]': 'direction === "asc"',
    '[class.desc]': 'direction === "desc"',
    '(click)': 'rotate()'
  }
})

export class NgbdSortableHeader {

  @Input() sortable: string|null=null;
  @Input() direction: SortDirection = '';
  @Output() sort = new EventEmitter<SortEvent>();

  rotate() {
    this.direction = rotate[this.direction];
    this.sort.emit({ column: this.sortable, direction: this.direction });
  }
}

@Component({
  selector: 'app-springhockey',
  templateUrl: './springhockey.component.html',
  styleUrls: ['./springhockey.component.scss']
})
export class SpringhockeyComponent implements OnInit {

  value: string;
  countoftab: any;
  public Editor = ClassicEditor;
  //dialogData:BannerTable;
  tableSource: SpringHockeyTable[];
  //bannerForm: FormGroup;
  //tableSource: BannerMgmtModel[];
  //bannerTable = this.tableService.getTable();
  sortBannerList:SpringHockeyTable[]|null=null;
  filterBanner:SpringHockeyTable[]|null=null;
  cfilterBanner:SpringHockeyTable[]|null=null;
  page = 1;
  pageSize = 2;
  SpringHockeyForm: FormGroup;
  editAddLabel: string = 'Edit';
  dialogData: SpringHockeyTable;
  totalLengthOfCollection: number=0;
  load:any;
  //Sorting purpose...
  @ViewChildren(NgbdSortableHeader) headers: QueryList<NgbdSortableHeader>=Object.create(null);

  base_url: string = environment.base_url;
  loading: boolean;
  formService: any;

  constructor(
    private web: WebService,
    private toast: ToastrService,
    private tableService: SpringHockeyTableService, 
    private fb: FormBuilder, 
    private modalService: NgbModal,
    //public Editor = ClassicEditor
  ) {
    console.log(this.dialogData);
    this.SpringHockeyForm = this.tableService.exportNewForm();
    //console.log(this.tableService.getTable());
    //console.log(this.dialogData);
  }

  async ngOnInit(){
    await this.getPageData();
    console.log('asd13',this.tableSource);
    this.filterBanner = this.tableSource;
    this.cfilterBanner = this.tableSource;
    this.sortBannerList = this.tableSource;
    this.totalLengthOfCollection = this.cfilterBanner.length;
  }

  onSort({ column, direction }: SortEvent) {
    this.headers.forEach(header => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });
  }

    //complete example................
    cpage = 1;
    cpageSize = 4;
  
    _csearchTerm: string='';
    get csearchTerm(): string {
      return this._csearchTerm;
    }
    set csearchTerm(val: string) {
      this._csearchTerm = val;
      this.cfilterBanner = this.cfilter(val);
      this.totalLengthOfCollection = this.cfilterBanner.length;
      console.log(this.cfilter(val));
    }
  
   cfilter(v: string) {
      return this.tableSource.filter(x => x.springhockey_title?.toLowerCase().indexOf(v.toLowerCase()) !== -1 ||
        x.springhockey_description?.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.springhockey_contents?.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.springhockey_image?.toLowerCase().indexOf(v.toLowerCase()) !== -1|| x.springhockey_link?.toLowerCase().indexOf(v.toLowerCase()) !== -1 )
    } 
  
    formsErrors = {
    }
  
  
    openModal(targetModal:NgbModal,action:any,springhockey:any) {
      this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static'
      });
      //console.log(targetModal);
      //console.log(action);
      this.value = action;
      console.log(targetModal);
      if(this.value == 'addspringhockey'){
        this.editAddLabel = 'Add';
        this.dialogData=new SpringHockeyTable();
      
      }  
      if (this.value == 'editspringhockey') {
         
        this.dialogData = springhockey;
        console.log(this.dialogData);
        this.editAddLabel = 'Edit';
        this.SpringHockeyForm.patchValue({
          springhockey_title: springhockey.springhockey_title,
          springhockey_description: springhockey.springhockey_description,
          springhockey_contents: springhockey.springhockey_contents,
          springhockey_image: springhockey.springhockey_image,
          springhockey_link: springhockey.springhockey_link,
        });
        // console.log("banner",this.bannerForm);
      }
      if (this.value == 'viewspringhockey') {
        this.dialogData = springhockey;
        console.log(this.dialogData);
        this.editAddLabel = 'View';
      }
    }
  
    closeBtnClick() {
      this.modalService.dismissAll()
      this.ngOnInit();
    }
   /*  $(document).ready(function(){  
      $('.phone').inputmask('(999)-999-9999');  
      $('.phone2').inputmask('(99)-9999-9999');  
      $('.phone3').inputmask('99-9999999999');  
   }); */
  
    delete(id:number) {
      console.log(id);
   
      if (window.confirm('Are you sure you want to delete..?')) {
        this.web.postData('deletespringhockey', {web_id: id}).then(res=>{
          console.log(res.data);
          if(res.status=='200'){
            this.toast.success('Success', res.error);
            this.ngOnInit();
          }else{
            this.toast.warning('Error', res.error);
          }
        },err=>{
          this.toast.warning('Error', 'Connection Error');
        })
      }
  
    }

    async submitFormResults(){
      //console.log("hii");
      console.log(this.dialogData);
      console.log('asdf',this.dialogData);
      console.log(this.editAddLabel);
      console.log('hello');
      let confirm = await this.tableService.springhockeyFormValidation(this.dialogData);
      if(confirm){
        this.loading = true;
      console.log(this.value);
      this.web.postData(this.value, this.dialogData).then(res=>{
        console.log(this.tableSource);

        this.loading = false;
        if(res.status=='200'){
          this.toast.success('Success', res.error);
          //this.closeWindow();
          this.closeBtnClick();
        }else{
          this.toast.error('Error', res.error);
        }
      },err=>{
        this.loading = false;
        //console.log('end');
        console.log(err, 'Error');
        //console.log('end');
        this.toast.error('Error', 'Connection Error');
      })
    }else{
      this.loading=false;
    }
      //this.common.showToast('danger','Error','Filled the form');
    }
  onFileChange(event,imgval) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      this.onUpload(files,imgval);
    }
    this.load="false";
  }
  onUpload(file: any,imgval:any) {
    let d = new Date();
    let n: any = d.valueOf();
    let fname = file[0].name;
    console.log(file);
    console.log(file[0].name);
    fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
    let filename = 'Attacksports_' + n.toString().substring(4, 8) + file[0].name;
    const formData = new FormData();
    formData.append("image", file[0]);
    formData.append("image", filename);
    formData.append("profile_image", filename);
    this.loading = true;
    let pagename = "content";
    this.web.uploadWebsitePicture(`${this.base_url}dev/attack-sports/restapi/homepage_springhockey_image.php?filename=` + filename, formData).subscribe((Res: any) => {
      this.loading = false;
      if (Res.status == '200') {
        this.toast.success('Success', Res.error);
        console.log("Resssssssssssssssss",Res.error)
        this.dialogData.springhockey_image = filename;
        this.load='true';
      } else {
        this.toast.error('Error', Res.error);
      }
    }, (err) => {
      this.toast.error('Error', 'Connection Error');
      this.loading = false;
    });
  }
    
  async getPageData() {
    this.loading = true;
    //let companyId = localStorage.getItem('remcoCompanyAdminId');
    await this.web.getData('getAllspringhockey').then(res => {
    if(res.status=='200'){
      this.loading = false;
        console.log(res.data);
        this.tableSource =res.data;
        //return res.data;
        //console.log('asdafs',this.tableSource);
    }
    else{
      this.toast.error('danger', res.error);
    }
    },err=>{
      this.loading = false;
      this.toast.error('danger', 'Connection Error');

    });
    console.log('asd',this.tableSource);
  }

}
