import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import {MatPaginatorModule} from '@angular/material/paginator';
import { comment } from './instructor-vidoes.component';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { InstructorVidoesRoutingModule } from './instructor-vidoes-routing.module';
import { InstructorVidoesComponent } from './instructor-vidoes.component';


@NgModule({
  declarations: [
    InstructorVidoesComponent,
    comment
  ],
  imports: [
    CommonModule,
    InstructorVidoesRoutingModule,
    HeaderFooterModule,
    MatPaginatorModule,
    NgxSkeletonLoaderModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class InstructorVidoesModule { }
