export interface Languages {
    code: string
    nativeName: string
    name: string
}