import { Component, OnInit } from '@angular/core';
import { WebService } from 'src/app/services/web.service';
import { CommonService } from 'src/app/services/common.service';
import { InitialService } from 'src/app/services/initial.service';
import { Router } from '@angular/router';
import { R } from 'src/app/services/Request-model';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  listSite:any=[];
  listFooterMenu:any=[];
  base_url:string = environment.base_url;

  // URL

  wikipediaURL:any='';
  androidURL:any='';
  iosURL:any='';
  fbURL:any='';
  inURL:any='';
  ytURL:any='';
  igURL:any='';

  constructor(private web: WebService, public common: CommonService, private initial: InitialService, private router: Router) { }

  ngOnInit(): void {
    // let user = localStorage.getItem('divinkUserId');
    // if(user==null || user==''){
    //   this.router.navigate(['/']);
    // }
    this.web.getData('getSiteList?id=2').then((res:R)=>{
      if(res.status =='200'){
        this.listSite = res.data[0];
      }else{
        this.common.presentToast(res.error);
      }
    },err=>{
      console.log(err);
      this.common.presentToast('Connection Error');
    })

    this.web.getData('getFooterMenuList').then((res:R)=>{
      if(res.status =='200'){
        this.listFooterMenu = res.data;

        res.data.forEach((data, index)=>{
          this.setURL(data);
        });
      }else{
        this.common.presentToast(res.error);
      }
    },err=>{
      console.log(err);
      this.common.presentToast('Connection Error');
    })
  }

  setURL(data){
    switch(data.menu_for){
      case 'Company_Wikipedia':
        this.wikipediaURL=data.menu_link;
        if(data.menu_status==0){
          this.wikipediaURL = '';
        }
        break;
        case 'GDG_Android':
          this.androidURL=data.menu_link;
          if(data.menu_status==0){
            this.androidURL = '';
          }
      break;
      case 'GDG_iOS':
        this.iosURL=data.menu_link;
        if(data.menu_status==0){
          this.iosURL = '';
        }
      break;
      case 'Social_Facebook':
        this.fbURL=data.menu_link;
        if(data.menu_status==0){
          this.fbURL = '';
        }
      break;
      case 'Social_LinkedIn':
        this.inURL=data.menu_link;
        if(data.menu_status==0){
          this.inURL = '';
        }
      break;
      case 'Social_YouTube':
        this.ytURL=data.menu_link;
        if(data.menu_status==0){
          this.ytURL = '';
        }
      break;
      case 'Social_Instagram':
        this.igURL=data.menu_link;
        if(data.menu_status==0){
          this.igURL = '';
        }
      break;
    }
  }


  redirectToUrl(route:string){
    let confirm  = this.common.validateDropinRestriction();
    if(!confirm){
      return false;
    }
    this.router.navigateByUrl(route);
  }
  
}
