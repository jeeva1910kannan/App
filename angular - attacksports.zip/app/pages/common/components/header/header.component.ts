import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ChangepasswordComponent } from '../../changepassword/changepassword.component';
import * as $ from 'jquery';
import { R } from 'src/app/services/Request-model';
import { InitialService } from 'src/app/services/initial.service';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { AuthService } from 'src/app/services/auth.service';

declare global {
  interface JQuery {
    dropdownHover(options?: any): JQuery;
    dropdown(options?: any): JQuery;
  }
}

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  tutorid: string;
  userid: string;
  listSite: any=[];
  dialog: any;
  listMainMenu:any=[];
  announcementTXT:any='';

  storeURL:any='';

  dropinRestriction:boolean = false;


  constructor(private web: WebService,
    public common: CommonService,
    private initial: InitialService,
    private router: Router,
    private authService: AuthService) { }

  ngOnInit(): void {
    this.web.getData('getSiteList?id=2').then((res:R)=>{
      if(res.status =='200'){
        this.listSite = res.data[0];
      }else{
        this.common.presentToast(res.error);
      }
    },err=>{
      console.log(err);
      this.common.presentToast('Connection Error');
    })

    this.web.getData('getFooterMenuList').then((res:R)=>{
      if(res.status =='200'){
        this.listMainMenu = res.data;

        res.data.forEach((data, index)=>{
          this.setURL(data);
        });
      }else{
        this.common.presentToast(res.error);
      }
    },err=>{
      console.log(err);
      this.common.presentToast('Connection Error');
    })

    this.web.getData('getAnnouncement').then((res:R)=>{
      if(res.status =='200'){
        this.announcementTXT=res.data[0].announcement_txt;
      }else{
        //this.common.presentToast(res.error);
      }
    },err=>{
      console.log(err);
      //this.common.presentToast('Connection Error');
    })


    this.userid=localStorage.getItem('UserId');

    console.log('header',  this.userid);

    var menu = $('.header-nav'),
      pos = menu.offset();

    $(window).scroll(function () {
      if ($(this).scrollTop() > pos.top + menu.height() && menu.hasClass('set') && $(this).scrollTop() > 100) {
        menu.fadeOut('fast', function () {
          $(this).removeClass('set').addClass('sticky').fadeIn('fast');
        });
      } else if ($(this).scrollTop() <= pos.top + 100 && menu.hasClass('sticky')) {
        menu.fadeOut(0, function () {
          $(this).removeClass('sticky').addClass('set').fadeIn(0);
        });
      }
    });

    jQuery('.js-activated').dropdownHover({
        instantlyCloseOthers: false,
        delay: 0
    }).dropdown();

    function stopPropagation(event) {
        event.stopPropagation();
    }

    $('.dropdown-menu a, .social .dropdown-menu, .social .dropdown-menu input').on("click", stopPropagation);
  }


  logout()
  {
  //  localStorage.setItem('UserId','');
  //  this.router.navigate(['/home']);
  let confirm  = this.common.validateDropinRestriction();
    if(!confirm){
      return false;
    }
  this.authService.logout();
  }
  userinfo()
  {
    let confirm  = this.common.validateDropinRestriction();
    if(!confirm){
      return false;
    }
   this.router.navigate(['/userinfo']);
  }

  openPasswordModal(){
    const modal =  this.dialog.open(ChangepasswordComponent);
    modal.afterClosed().subscribe(res=>{

    });
   }

   setURL(data){
    switch(data.menu_for){
      case 'Mainmenu_Store':
        this.storeURL=data.menu_link;
        // if(data.menu_status==0){
        //   this.storeURL = '';
        // }
      break;
    }
  }

  redirectToUrl(route:string){
    let confirm  = this.common.validateDropinRestriction();
    if(!confirm){
      return false;
    }
    this.router.navigateByUrl(route);
  }

}
