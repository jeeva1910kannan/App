import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-pdf-preview',
  templateUrl: './pdf-preview.component.html',
  styleUrls: ['./pdf-preview.component.scss']
})
export class PdfPreviewComponent implements OnInit {
  questionTitle:string = '';
  questionUrl:string = '';
  loading:boolean = false;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    console.log('this.data :>> ', this.data);
    this.questionUrl = this.data.url;
    this.questionTitle = this.data.title;
    this.loading = true;
  }


  fileLoaded(){
    console.log('loaded');
    this.loading = false;
  }
}
