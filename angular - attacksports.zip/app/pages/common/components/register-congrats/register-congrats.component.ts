import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-congrats',
  templateUrl: './register-congrats.component.html',
  styleUrls: ['./register-congrats.component.scss']
})
export class RegisterCongratsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
