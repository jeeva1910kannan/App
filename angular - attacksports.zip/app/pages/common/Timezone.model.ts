

export interface Timezone {
    value: string
    abbr: string
    offset:number
    isdst:Boolean
    text:string
}