export interface Currencies {
    cc: string
   symbol: string
    name: string
    
}