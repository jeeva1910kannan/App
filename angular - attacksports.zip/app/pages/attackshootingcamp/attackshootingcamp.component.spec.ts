// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { AttackshootingcampComponent } from './attackshootingcamp.component';

// describe('AttackshootingcampComponent', () => {
//   let component: AttackshootingcampComponent;
//   let fixture: ComponentFixture<AttackshootingcampComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ AttackshootingcampComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AttackshootingcampComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
