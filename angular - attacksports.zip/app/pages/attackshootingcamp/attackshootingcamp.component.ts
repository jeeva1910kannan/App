import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
declare let jQuery: any;

@Component({
  selector: 'app-attackshootingcamp',
  templateUrl: './attackshootingcamp.component.html',
  styleUrls: ['./attackshootingcamp.component.scss']
})
export class AttackshootingcampComponent implements OnInit {
  base_url: string = environment.base_url;
  // springhockey: any;
  shootingcampcontents: any[] = [];
  constructor(private web: WebService, private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,private  common:CommonService  ) { } 


  ngOnInit(): void {

    this.getShootingCampsContents();
  }
  getShootingCampsContents() {
    this.web.getData('getShootingCampsContents').then((res) => {
      if (res.status == '200') {
        this.shootingcampcontents = res.data;
       
        console.log(this.shootingcampcontents, "this.springhockeycontents");
       

      }
      // else {
      // this.bannercontents[1].home_video=null;  
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
 

}
