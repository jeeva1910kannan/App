import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttackshootingcampComponent } from './attackshootingcamp.component';
import {AttackshootingcampRoutingModule} from './attackshootingcamp.routing.module';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'

@NgModule({
  declarations: [
    AttackshootingcampComponent
  ],
  imports: [
    CommonModule,
    AttackshootingcampRoutingModule,
    HeaderFooterModule
  ],
  exports: [
    AttackshootingcampComponent
  ]
})
export class AttackshootingcampModule { }

