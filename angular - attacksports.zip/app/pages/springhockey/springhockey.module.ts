import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpringhockeyComponent } from './springhockey.component';
import {SpringHockeyRoutingModule} from '../springhockey/springhockey.routing.module';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'

@NgModule({
  declarations: [
    SpringhockeyComponent
  ],
  imports: [
    CommonModule,
    SpringHockeyRoutingModule,
    HeaderFooterModule
  ],
  exports: [
    SpringhockeyComponent
  ]
})
export class SpringhockeyModule { }

