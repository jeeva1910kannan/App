import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { SpringhockeyComponent } from './springhockey.component';

const routes: Routes = [
  {
    path: "",
    component: SpringhockeyComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class SpringHockeyRoutingModule { }