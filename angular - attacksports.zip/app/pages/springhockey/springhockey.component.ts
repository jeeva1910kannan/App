import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
declare let jQuery: any;


@Component({
  selector: 'app-springhockey',
  templateUrl: './springhockey.component.html',
  styleUrls: ['./springhockey.component.scss']
})
export class SpringhockeyComponent implements OnInit {
  
   base_url: string = environment.base_url;
  // springhockey: any;
  springhockeycontents: any[] = [];
  constructor(private web: WebService, private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,private  common:CommonService  ) { } 


  ngOnInit(): void {

    this.getspringhockeyContents();
  }
    getspringhockeyContents() {
    this.web.getData('getSpringHockeyContents').then((res) => {
      if (res.status == '200') {
        this.springhockeycontents = res.data;
       
        console.log(this.springhockeycontents, "this.springhockeycontents");
       

      }
      // else {
      // this.bannercontents[1].home_video=null;  
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
 

  }
