import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
declare let jQuery: any;
//localStorage.getItem('UserId');
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',       
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {

  contents: any;

  bannercontents: any[] = [];
  blockcontents: any[] = [];
  campcontents: any[] = [];
  campcontents1: any[] = [];
  traincontents: any[] = [];
  traincontents1: any[] = [];
  logocontents: any[] = [];
  resultcontents1: any[] = [];
  resultcontentsname:any = {};
  usertype: any;
  video: any;

  resultcontents: any[] = [];
  base_url: string = environment.base_url;

  resulthome: any[] = [];
  instructor: any;
  events: any;
  active_users: any;
  userid: any;
  campdetail: any;
  status: any;
  data: {};
  constructor(private web: WebService, private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,private  common:CommonService  ) { }

  ngOnInit(): void {
    //localStorage.setItem('UserId',null);
    
    jQuery(".loader").fadeOut("1500");
    this.getContents();
    this.getblockContents();
    this.gettrainContents();
    this.getresultContents();
    this.getcampContents();
    this.getlogoContents();
    this.getAllHome();
    this.refresh();
    this.usertype = localStorage.getItem("type");
    this.userid = localStorage.getItem("UserId");
    //localStorage.setItem('UserId',null);


    var $video_play = jQuery('.btn-play');
    if ($video_play.length > 0) {
      $video_play.magnificPopup({
        type: 'iframe',
        removalDelay: 160,
        preloader: true,
        fixedContentPos: true,
        callbacks: {
          beforeOpen: function () {

          }
        },
      });
    }

  console.log("restult ==>", this.resultcontents[5]);
  }
  refresh(){
    this.cdr.detectChanges();

  }
  updatestatus(){
    const email = "jeeva.zerosoft@gmail.com";
  const password = "1234567890";
  const phoneno = "1234567890";
  const type = "instructor";
  const certificate = "";
      this.data = {
        email: email,
        password: password,
        phoneno: phoneno,
        type: type,
        certificate: certificate,
        
      };
    
    this.web.postData('intructorregistration', this.data).then((res) => {
      if (res.status == '200') {
       
        this.status = res.data;
        console.log(this.status, "status");
       
  
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
  
  
  getContents() {
    this.web.getData('getAllContents').then((res) => {
      if (res.status == '200') {
        this.bannercontents = res.data;

        console.log(this.bannercontents);
        setTimeout(() => {

          jQuery('#slider2').owlCarousel({
            margin: 0,
            dots: false,
            nav: true,
            loop: true,
            navText: ['<i class="fal fa-long-arrow-left"></i>', '<i class="fal fa-long-arrow-right"></i>'],
            responsiveClass: true,
            responsive: {
              0: {
                items: 1
              },
              600: {
                items: 1
              },
              1600: {
                items: 1
              }
            }
          })



        }, 400);
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });

  }

  getAllHome() {
    this.web.getData('getAllHome').then((res) => {
      if (res.status == '200') {
        this.resulthome = res.data;

        this.resulthome.map((res, i) => {
          if (res.web_id == 4) {
            this.instructor = res.instructors;
            console.log(this.instructor, "instructor");
            this.events = res.events;
            console.log(this.events, "events");
            this.active_users = res.active_users;
            console.log(this.active_users, "active_users");
            console.log(this.resulthome, "resulthome");
            this.resultcontents1 = res.data;
          }
        })

      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
  getblockContents() {
    this.web.getData('getBlockContents').then((res) => {
      if (res.status == '200') {
        this.blockcontents = res.data;
        this.video = res.data[1].home_video;
        console.log(this.blockcontents, "this.blockcontents");
        console.log(this.video, "this.video");

      }
      // else {
      // this.bannercontents[1].home_video=null;
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
  getcampContents() {
    this.web.getData('getCampContents').then((res) => {
      if (res.status == '200') {
        this.campcontents = res.data;
        this.campcontents1 = res.data.slice(1, 6);


        setTimeout(() => {

          jQuery('#campcontent').owlCarousel({

            dots: false,
            nav: true,

            //loop:true,
            navText: [],
            rewind: false,
            // autoplay: true, //true if you want enable autoplay
            responsiveClass: true,
            responsive: {
              0: {
                items: 1
              },
              768: {
                items: 2
              },
              992: {
                items: 2
              },
              1200: {
                items: 3
              },
              1430: {
                items: 3
              },

            }
          })
        }, 1000);

      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
  gettrainContents() {
    this.web.getData('getTrainContents').then((res) => {
      if (res.status == '200') {
        this.traincontents = res.data;
        console.log(this.traincontents,"this.traincontents");
        this.traincontents1 = res.data.slice(1, 10);


        setTimeout(() => {

          jQuery('#product').owlCarousel({
            margin: 30,
            dots: false,
            nav: true,
            loop: true,
            navText: ['<i class="fal fa-long-arrow-left"></i>', '<i class="fal fa-long-arrow-right"></i>'],
            rewind: false,
            autoplay: true, //true if you want enable autoplay
            responsiveClass: true,
            responsive: {
              0: {
                items: 1
              },
              768: {
                items: 2
              },
              992: {
                items: 2
              },
              1200: {
                items: 3
              },
              1430: {
                items: 3
              },
              1600: {
                items: 3
              }
            }
          })


        }, 1000);

      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
  getresultContents() {
    //if(!localStorage.getItem('UserId') || localStorage.getItem('UserId')){
    // if(!localStorage.getItem('UserId') || localStorage.getItem('UserId')){
    //   this.campdetail = true;
    // }
    console.log(this.campdetail, 'gghghg');
    this.web.getData('getResultContents').then((res) => {
      if (res.status == '200') {
        this.resultcontents = res.data;
        this.resultcontentsname = res.name;
        //this.resultcontents1 = res.data.slice(1, 10);
        console.log("resultcontents", this.resultcontents);
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
    //}
  }

  getlogoContents() {
    this.web.getData('getlogoContents').then((res) => {
      if (res.status == '200') {
        this.logocontents = res.data;
        setTimeout(() => {
          jQuery('#partners').owlCarousel({
            margin: 10,
            loop: true,
            rewind: false,
            autoplay: true, //true if you want enable autoplay
            smartSpeed: 3000,
            responsiveClass: true,
            responsive: {
              0: {
                items: 3
              },
              481: {
                items: 4
              },
              576: {
                items: 5
              },
              768: {
                items: 6
              },
              992: {
                items: 7
              },
              1200: {
                items: 8
              },
              1430: {
                items: 9
              },
              1600: {
                items: 10
              }
            }
          });
        }, 1000);
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

  Instructcamp(){
    this.common.presentToast('Camps register only for customers');   
  }
}
