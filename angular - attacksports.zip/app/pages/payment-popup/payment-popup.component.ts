import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import {
  ICreateOrderRequest,
  IPayPalConfig,
  NgxPaypalComponent,
  PayPalScriptService,
} from 'ngx-paypal';
import { environment } from 'src/environments/environment';

import { WebService } from 'src/app/providers/web.service';
import { CommonService } from 'src/app/providers/common.service';

@Component({
  selector: 'app-payment-popup',
  templateUrl: './payment-popup.component.html',
  styleUrls: ['./payment-popup.component.scss']
})
export class PaymentPopupComponent implements OnInit {
  public payPalConfig?: IPayPalConfig;
  paymentMethod:any;
  payPalSubscribeConfig:IPayPalConfig;
  availablePlans: any ={}
  selectedPlanAmount: any;
  selectedPlanName: any;
  selectedPlanId: any;
  selectedPlanTemp:any;

  constructor(private activatedRoute:ActivatedRoute, public dialogRef: MatDialogRef<PaymentPopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any
  , private web:WebService, private common:CommonService) { }

  ngOnInit(): void {
    this.getsubplan();
  }

  getConfig(plan_id:string): IPayPalConfig {
    console.log(plan_id,"plannnn")
    var that = this;
    return {
      clientId: environment.paypal_key,
      currency: "USD",
      vault: "true",
      style: {
        label: "paypal",
        layout: "vertical",
        // size: "small",
        // shape: "pill",
        // color: "silver",
        // tagline: false,
      },
      createSubscription: function (data) {
        return data.subscription.create({
          'plan_id':plan_id,
        });
      },
      onApprove: function (data, actions) {
        console.log(data,"plannnn")

        actions.order.get().then((details:any) => {
          console.log("subscription details:", details);
          that.createTokenPaypal(details)
        });
      },
      onCancel: (data, actions) => {
        this.common.presentToast('Payment cancelled.');
      },
      onError: (err) => {
        this.common.presentToast('Service not available.');
        console.log("OnError", err);
      },
      onClick: (data, actions) => {
        console.log("Clicked:", data, actions);
      },
    } 
  }

  createTokenPaypal(details:any): void {
  console.log(details);
  }
 

  async getsubplan(){
    
    this.web.getData('customerSubscribePlanDetails').then((res) => {
        if (res.status == '200') {
          this.availablePlans = res.data;
          this.selectedPlanName = this.availablePlans[0].plan_name;
          this.selectedPlanAmount = this.availablePlans[0].plan_amount;
          this.selectedPlanTemp = this.availablePlans[0].plan_validity;
          this.payPalSubscribeConfig = this.getConfig(this.availablePlans[0].plan_paypal_id);
        console.log(this.payPalSubscribeConfig);
        } else {
          console.log(res.error);
        }
      }, err => {
        console.log(err);
      this.common.presentToast('Connection Error.');
      });

    }

  oncancel(){
    this.dialogRef.close();
  }

  subscribe_instructor(){ 
    console.log(this.payPalSubscribeConfig);
    /* console.log(this.data.instructor_id);
    console.log(localStorage.getItem('UserId'));
    console.log(this.availablePlans);
   */
  }
}
