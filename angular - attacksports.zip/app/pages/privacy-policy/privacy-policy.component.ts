import { Component, OnInit } from '@angular/core';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component.scss']
})
export class PrivacyPolicyComponent implements OnInit {

  base_url: string = environment.base_url;

  privacy :any;

  constructor(private web:WebService) { }

  ngOnInit(): void {
    this.getprivacyContents();
  }
  async getprivacyContents(){
    await this.web.getData('getAllPrivacypolicy').then((res) => {
        if (res.status == '200') {
          this.privacy = res.data[0];
          console.log(res.data);
                 } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
      console.log(this.privacy);
  }

}


