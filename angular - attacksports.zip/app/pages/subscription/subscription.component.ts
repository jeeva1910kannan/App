import { AfterViewInit, Component, OnInit, NgModule, OnDestroy, ViewChild, ElementRef, Injector } from '@angular/core';
import { CommonService } from '../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { SubscriptionService } from './subscription.service';
import { Square } from '@square/web-payments-sdk-types';
import { payments } from '@square/web-sdk';
import { ActivatedRoute } from '@angular/router';
import type { Payments } from '@square/web-sdk';
import { DomSanitizer } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { Observable, of } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';

//import * as Square from 'path/to/square-library';
//import { SqPaymentForm } from '@square/web-payments-sdk';

declare let jQuery: any;
declare var SqPaymentForm: any;
declare var Square: any;
// declare interface Window {
//   SqPaymentForm: any;
// }
// declare global {
//   interface Window {
//     Square?: any;
//   }
// }

@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.scss'],
  // template: `<div #sqForm id="sq-form"></div>`
  //  template: `
  //     <div [innerHTML]="scriptTag"></div>
  //   `

  //   template: `
  //   <iframe [src]="corsUrl"></iframe>
  // `,


})

export class SubscriptionComponent implements OnInit, AfterViewInit {

  //scriptTag = '<script type="text/javascript" src="https://js.squareupsandbox.com/v2/paymentform"></script>';

  @ViewChild('sqPaymentForm') paymentFormRef: any;
  subscriptiondetails$: Observable<any[]> = of([]);

  // @ViewChild('sq-card-number', { static: false }) sqCardNumber: ElementRef;

  formLoaded: boolean = false;
  popup = false
  //name = 'Angular';
  currDiv: any;
  window: any;
  amount: any;
  paymentHandler: any = null;
  Square: any;
  subscription: any;
  subscription1: any;
  register: any;
  i: number;
  litedesc: string;
  userid: any;
  IsmodelShow: any;
  payshow: any;
  sqPaymentForm: any;
  safeUrl: any;
  selectedPaymentType = 'credit_card';
  iframeUrl = 'https://pci-connect.squareupsandbox.com/';
  type: string;
  details: any;
  subscriptiondetails: any;
  subscription_planid: any;
  subscription_status: any;
  subscription_id: any;
  subscription_webid: any;
  subscriptionPlanIds = [];
  uniqueWeb: string[] = [];
  subscribed: any;
  cancelsuscribed: any;
  subscrip1: any;
  showButton: boolean = false;
  conditionEvaluated = false;

  trackByFn(index: number, subscription1: any) {
    return subscription1.plan_id;
  }
  
  ShowDiv(divVal: string, value: any, id: any, planname: any, plan_duration:any, plan_type:any) {
    localStorage.setItem('Amount', value);
    localStorage.setItem('plan_id', id);
    localStorage.setItem('plan_name', planname);
    localStorage.setItem('plan_duration', plan_duration);
    localStorage.setItem('plan_type', plan_type);
    //localStorage.setItem('subscription_webid', web)
    //this.renewButtonDisplayed = true;
    this.currDiv = divVal;
    this.amount = value;

    let data1 = {
      customer_id: localStorage.getItem('UserId'),
      //

    }
    this.web.postData('getuserdetails', data1).then((res) => {
      if (res.status == '200') {
        this.details == res.data;
        localStorage.setItem('firstname', res.data[0].first_name);
        localStorage.setItem('lastname', res.data[0].last_name);
        //this.couponcode = res.data[0];
        //this.faqquiz = res.data.slice(1);


        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });

    console.log("fdjhgjdf");



    //this.IsmodelShow = true;
    //this.payshow = false;
    console.log("value", value)
    this.dialog.open(Paymentcard, {

      data: {
        user_id: localStorage.getItem('UserId'),
        type: localStorage.getItem('type'),
      },
    });
  }

  close() {
    this.IsmodelShow = false;// set false while you need open your model popup
    // do your more code
    this.payshow = true;
  }

  constructor(private web: WebService, private router: Router, private elementRef: ElementRef, private modalService: NgbModal,
    public common: CommonService, private dsls: SubscriptionService, private sanitizer: DomSanitizer, private injector: Injector, public dialog: MatDialog,) { }
    sub_id:any;
    subweb_id: any;
  paymentForm: any; //this is our payment form object
  payments: any;
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  applicationId1 = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  locationId1 = "LC2PEQFX591R6";
  renewButtonDisplayed: boolean = false;
  subcutomerid: any;
  isButtonDisabled = false;
  uniquearr: any;

  originalUrl = 'https://pci-connect.squareupsandbox.com/';
  corsAnywhere = 'https://cors-anywhere.herokuapp.com/';
  corsUrl = this.corsAnywhere + this.originalUrl;

  ngOnInit(): void {
    this.subscriptiondetails$ = this.subscriptiondetails$.pipe(distinctUntilChanged());
    this.userid = localStorage.getItem('UserId');
    this.type = localStorage.getItem('type');

    this.getsubscription()
    this.getregisteruser()
    this.getsubContents()
   // this.getuserdetails()
this.getsubscriptiondetails()


  }



  showRenewButton1(subscription1: any, item: any, index: number) {
    return !this.renewButtonDisplayed && this.type === 'Customer' && subscription1.plan_id === item.subscription_plan_id && subscription1.plan_status === 'Inactive' && index === 0;
  }

 

  ngAfterViewInit() {


  }

  // async  loadScript() {



  //   // Your SqPaymentForm script here

  //   var applicationId = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";

  //   // Set the location ID
  //   var locationId = "LQC04P5CAFGVD";

  //   this.payments = Square.payments(applicationId, locationId);

  //   this.card = await this.payments.card();

  //   await this.card.attach('#card-container');

  //   this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
  //   this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce

  //   const form = document.querySelector('#card-payment') as HTMLFormElement;

  //   form.addEventListener('submit', async (event: Event) => {

  //      event.preventDefault();

  //      const result = await this.card.tokenize(); // the card nonce

  //   });
  //   console.log("result");
  //   // onCancel: () => {
  //   //   this.common.presentToast('Payment cancelled.');
  //   //   console.log("OnCancel");
  //   // }

  // }
  // requestCardNonce(event) {


  //   // Request a nonce from the SqPaymentForm object
  //   this.paymentForm.requestCardNonce();
  // }

  isNotInArray2(obj: any, array2: any[]): boolean {
    if (!array2 || array2.length === 0) {
      console.log('897887')
      return true;
    }
    return !array2.some(x => x.property === obj.property);
    console.log('897887678')
  }
  


  async getsubscription() {
    await this.web.getData('getsubscription').then((res) => {
      if (res.status == '200') {
        this.subscription = res.data;
        console.log(this.subscription.length,"length");
        this.subscription1 = res.data.slice(1,6);
          
       
          console.log(this.subscription.length,"length111");  
          setTimeout(() => {

            jQuery('#campcontent').owlCarousel({
             
              dots: false,
              nav:true,
              
              //loop:true,
              navText: [],
              rewind: false,
             // autoplay: true, //true if you want enable autoplay
              responsiveClass: true,
              responsive:{
                  0:{
                      items:1
                  },
                  768:{
                      items:2
                  },
                  992:{
                      items:2
                  },
                  1200:{
                      items:3
                  },
                  1430:{
                      items:3
                  },
                
              }
          })
          }, 1000);
        
      } else {
        // console.log(":(")
      }
    }, err => {
      console.log(err);
      // console.log(":)")
    })
  }

  async getsubscriptiondetails() {
    let data={
      customer_id: localStorage.getItem('UserId')
      //email: this.email,
     
    }
   this.web.postData('subscriptiondetails',data).then((res) => {
          if (res.status == '200') {
            this.subscriptiondetails = res.data;
this.subcutomerid = this.subscriptiondetails[0].customer_id;
console.log(this.subcutomerid,'this.subcutomerid')
console.log(this.subscriptiondetails,'898gj')
            // const uniqueArray = this.subscriptiondetails.reduce((acc, curr) => {
            //   if (!acc[curr.plan_id]) {
            //     acc[curr.id] = curr;
            //   }
            //   return acc;
            // }, {});
            // console.log(Object.values(uniqueArray), '7857687');

            // const uniquePlans = new Set();
            // const filteredData = this.subscriptiondetails.filter(item => {
            //   if (uniquePlans.has(item.plan_id)) {
            //     return false;
            //   } else {
            //     uniquePlans.add(item.plan_id);
            //     return true;
            //   }
            // });
//             const dataArray = Object.values(this.subscriptiondetails);
// const filteredData = dataArray.filter(item => {
//   return item.plan_id !== plan_id;
// });
//console.log(filteredData,'jkfilteredData')


const uniqueArray =this.subscriptiondetails.reduce((accumulator, current) => {
  const duplicate = accumulator.find(item => item.plan_id === current.plan_id);
  if (!duplicate) {
    accumulator.push(current);
  } else {
    // Replace the duplicate element with the current element
    const index = accumulator.indexOf(duplicate);
    accumulator[index] = current;
  }
  return accumulator;
}, []);

this.uniquearr =uniqueArray;

console.log(this.uniquearr,'uniqueArray')



            if (this.subscription && this.subscriptiondetails ) {
            const ids = this.subscription.map(obj => obj.id);
            const isFound = this.subscriptiondetails.some(obj => ids.includes(obj.id));
            console.log(isFound,'ryityui'); // t
            }else{
              console.log('ryityui567');
            }





            //for (let i = 0; i < this.subscription.length; i++) {
              if (this.subscription && this.subscriptiondetails) {
              this.subscription.forEach((part1, index) => { 
                //if (this.subscriptiondetails) {
           // for (let j = 0; j < this.subscriptiondetails.length; j++) {
              this.subscriptiondetails.forEach((part, index) => { 
              console.log(part1.subscription_plan_id != part.plan_id);
                  if(part1.subscription_plan_id != part.plan_id){
                       this.register = 0;
                     }
                  //  }
                  //}

            })
          //}
          })
        }



console.log(this.subscription_planid,'this.subscription_planid')


                   } else {
            console.log(":(")
          }
        }, err => {
          console.log(err);
          console.log(":)")
        });
        //console.log(this.couponcode);
        console.log("fdjhgjdf");
  }


  async cancelsubscription(subplan_id:any) {
    this.isButtonDisabled = true;
    this.subscriptiondetails.forEach(function(part, index){
console.log(part.plan_id, 'part.plan_id')
console.log(part.subscription_id, 'part.subscription_id')
console.log(part.plan_id == subplan_id && part.plan_status == 'Active','part.plan_id == subplan_id && part.plan_status == ')
if(part.plan_id == subplan_id && part.plan_status == 'Active'){
localStorage.setItem('sub_id',part.subscription_id)
localStorage.setItem('subweb_id', part.web_id)
}


    })

    let data={
      subplan_id: subplan_id,
      subscription_id: localStorage.getItem('sub_id'),
      web_id: localStorage.getItem('subweb_id')
      //email: this.email,
     
    }
   this.web.postData('cancelsubscription1',data).then((res) => {
          if (res.status == '200') {
            this.common.presentToast('Cancelled Subscription');
            setTimeout(() => {
              window.location.reload();
            }, 600);
            this.isButtonDisabled = false;
            //this.couponcode = res.data[0];
            //this.faqquiz = res.data.slice(1);
           
            //console.log(this.couponcode);
                   } else {
                    this.common.presentToast('res.error');
                  }
          
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
          console.log(":)")
        });
        //console.log(this.couponcode);
        console.log("fdjhgjdf");
  }


  
  
  


  async renewsubscription(subplan_id:any) {
    this.subscriptiondetails.forEach(function(part, index){
console.log(part.plan_id, 'part.plan_id')
console.log(part.subscription_id, 'part.subscription_id')
console.log(part.plan_id == subplan_id && part.plan_status == 'Active','part.plan_id == subplan_id && part.plan_status == ')
if(part.plan_id == subplan_id && part.plan_status == 'Active'){
localStorage.setItem('sub_id',part.subscription_id)
localStorage.setItem('subweb_id', part.web_id)
}


    })

    let data={
      subplan_id: subplan_id,
      subscription_id: localStorage.getItem('sub_id'),
      web_id: localStorage.getItem('subweb_id')
      //email: this.email,
    }
   this.web.postData('renewsubscription',data).then((res) => {
          if (res.status == '200') {
            this.common.presentToast('Subscription Added Successfully');
            setTimeout(() => {
              window.location.reload();
            }, 600);
            //this.couponcode = res.data[0];
            //this.faqquiz = res.data.slice(1);
           
            //console.log(this.couponcode);
                   } else {
                    this.common.presentToast('res.error');
                  }
          
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
          console.log(":)")
        });
        //console.log(this.couponcode);
        console.log("fdjhgjdf");
  }



  isPlanIdNotFound(item) {
    if(this.subscriptiondetails != null){
    return this.subscriptiondetails.some(el => el.plan_id === item.subscription_plan_id);
    }
  }


  isPlanIdNotFound1() {
    return this.subscriptiondetails.some(el => el.plan_id ==='Inactive');
  }


  showRenewButton(subscription1: any, item: any) {
    return this.type === 'Customer' && subscription1.plan_id === item.subscription_plan_id && subscription1.plan_status === 'Inactive';
  }
  


  async getregisteruser() {
    await this.web.getData('getregisteruser').then((res) => {
      if (res.status == '200') {
        this.register = res.data;

      } else {
        // console.log(":(")
      }
    }, err => {
      console.log(err);
      // console.log(":)")
    })
  }

  async getsubContents() {
    await this.web.getData('getsubscription').then((res) => {
      if (res.status == '200') {
        this.subscription = res.data;
        this.subscription1 = res.data.slice(1, 6);

        
        setTimeout(() => {

          jQuery('#subscripioncontent').owlCarousel({

            dots: false,
           // nav: true,
           // loop: true,

            rewind: false,
            //true if you want enable autoplay
            responsiveClass: true,
            responsive: {
              0: {
                items: 1
              },
              768: {
                items: 2
              },
              992: {
                items: 2
              },
              1200: {
                items: 3
              },
              1430: {
                items: 3
              },

            }
          })
        }, 1000);

      } else {
        // console.log(":(")
      }
    }, err => {
      console.log(err);
      // console.log(":)")
    })


  }


  get iframeSrc() {
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.iframeUrl);
  }



  onKeyUp(x) { // appending the updated value to the variable
    window.location.reload();
  }
  async finddesc(desc: any) {
    this.litedesc = desc.substring(0, 170) + '....';
  }

  // getuserdetails(): void {

  //   //console.log("coupon");
  //   let data = {
  //     customer_id: localStorage.getItem('UserId'),
  //     //

  //   }
  //   this.web.postData('getuserdetails', data).then((res) => {
  //     if (res.status == '200') {
  //       this.details == res.data;
  //       localStorage.setItem('firstname', this.details.first_name);
  //       //this.couponcode = res.data[0];
  //       //this.faqquiz = res.data.slice(1);


  //       console.log(":(")
  //     }
  //   }, err => {
  //     console.log(err);
  //     console.log(":)")
  //   });

  //   console.log("fdjhgjdf");
  // }

  // async makeSubscription() {
  //   const statusContainer = document.getElementById('payment-status-container');
  //   try {
  //     const result = await this.card.tokenize();
  //     if (result.status === 'OK') {

  //       let data = {
  //         transaction_method: 'card',
  //         payment_status: 'success',
  //         paymentToken: result.token,
  //         locationId: this.locationId1,
  //       }

  //       this.web.postData('subscriptionpayment',data).then(
  //         (res) => {
  //           if (res.status == '200') {
  //             this.common.presentToast('Payment Successfully');

  //             // this.common.presentToast('Registered Successfully');
  //             setTimeout(() => {
  //               window.location.reload();
  //             }, 600);
  //            // this.ngOnInit();
  //           } else {
  //             this.common.presentToast(res.error);
  //           }
  //         }, err => {
  //           console.log(err);
  //           this.common.presentToast('Connection Error');
  //         });



  //     } else {
  //       let errorMessage = `Tokenization failed with status: ${result.status}`;
  //       if (result.errors) {
  //         errorMessage += ` and errors: ${JSON.stringify(
  //           result.errors
  //         )}`;
  //       }
  //       throw new Error(errorMessage);
  //     }
  //   } catch (e) {
  //     console.error(e);
  //     statusContainer.innerHTML = "Payment Failed";
  //   }
  // }
}
declare var Square: any;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
@Component({
  selector: 'Subscriptionpayment',
  templateUrl: 'Subscriptionpayment.html',
  styleUrls: ['Subscriptionpayment.scss']
  // styleUrls: ['./withdraw.scss']
})

export class Paymentcard {

  payments: any;
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEOKq3_JUA1xw1RCiov2mms1eJviBzaBrw1rM40aMSTdKXCpfJWnkIfJfwad-";
  applicationId1 = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";
  locationId1 = "LC2PEQFX591R6";
  paymentForm: any;
  userDetailsTemp: any;
  campdetails1: any;
  phone: string;
  email: string;
  fetchingStatus: boolean = true;
  loading = true;
  customer_id: any;
  isButtonDisabled = false;
  firstname: any;
  lastname: any;
  planid: any;
  renewButtonDisplayed: boolean = false;

  constructor(public common: CommonService, private web: WebService, public dialog: MatDialog, private activateRoute: ActivatedRoute) {
  }
  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit(): void {
    this.email = localStorage.getItem('email');
    this.phone = localStorage.getItem('phone');
    this.firstname = localStorage.getItem('firstname');
    this.lastname = localStorage.getItem('lastname');
    this.loadScript();


    setTimeout(() => {
      this.loading = false;
    }, 1000);

  }
  oncancel() {
    this.dialog.closeAll();
  }


  async loadScript() {


    // Your SqPaymentForm script here

    var applicationId = "sandbox-sq0idb-qC4fhhGZBPWcBl8j0eVqnw";

    // Set the location ID
    var locationId = "LQC04P5CAFGVD";
    this.fetchingStatus = true;
    this.payments = Square.payments(applicationId, locationId);

    this.card = await this.payments.card();

    await this.card.attach('#card-container');
    this.fetchingStatus = false;
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce

    const form = document.querySelector('#card-payment') as HTMLFormElement;

    form.addEventListener('submit', async (event: Event) => {

      event.preventDefault();

      const result = await this.card.tokenize(); // the card nonce

    });
    console.log("result");
    // onCancel: () => {
    //   this.common.presentToast('Payment cancelled.');
    //   console.log("OnCancel");
    // }

  }
  async makeSubscription() {
   // this.isButtonDisabled = true;

    const statusContainer = document.getElementById('payment-status-container');
    try {
      const result = await this.card.tokenize();
      if (result.status === 'OK') {
        this.isButtonDisabled = true;
        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
        //console.log('Paypal id', details.id);
        let data = {
          planid:localStorage.getItem('plan_id'),
          firstname:this.firstname,
          lastname: this.lastname,
          amount: localStorage.getItem('Amount'),
          customer_id: localStorage.getItem('UserId'),
          plan_name: localStorage.getItem('plan_name'),
          plan_type:localStorage.getItem('plan_type'),
          plan_duration: localStorage.getItem('plan_duration'),
          email: this.email,
          phone: this.phone,
          transaction_method: 'card',
          payment_status: 'success',
          paymentToken: result.token,
          locationId: this.locationId1,
        }

        this.web.postData('subscriptionpayment', data).then(
          (res) => {
            if (res.status == '200') {
              this.common.presentToast('Payment Successfully');
              this.renewButtonDisplayed = true;
              this.isButtonDisabled = false;
              // this.common.presentToast('Registered Successfully');
              setTimeout(() => {
                window.location.reload();
              }, 600);
              //this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
              this.isButtonDisabled = false;
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
            this.isButtonDisabled = false;
          });



        //this.processPayment(result)
        // this.http.post('http://your-api-endpoint.com/charge', {
        //   paymentToken: result.token,
        //   amount: this.EventDetails.price
        // }).subscribe(response => {
        //   console.log(response);
        //   statusContainer.innerHTML = "Payment Successful";
        // }, error => {
        //   console.error(error);
        //   statusContainer.innerHTML = "Payment Failed";
        // });
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }



}
