import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Paymentcard, SubscriptionComponent } from './subscription.component';
import { SubscriptionRoutingModule } from './subscription.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
//import { SlickCarouselModule } from 'ngx-slick-carousel';

@NgModule({
  declarations: [
    SubscriptionComponent,
    Paymentcard

  ],
  imports: [
    CommonModule,
    SubscriptionRoutingModule,
    HeaderFooterModule,
    NgxSkeletonLoaderModule,
    //CarouselModule
   
  ]
})
export class SubscriptionModule { }
