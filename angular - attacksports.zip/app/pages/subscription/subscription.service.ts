import { Injectable, Injector  } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

interface Scripts {
  name: string;
  src: string;
}

export const ScriptStore: Scripts[] = [
  {name: 'square-sandbox', src: 'https://js.squareupsandbox.com/v2/paymentform'},
  {name: 'square', src: 'https://js.squareup.com/v2/paymentform'},
  {name: 'squarecdn', src: "https://sandbox.web.squarecdn.com/v1/square.js"},
  {name: 'code', src: "https://code.jquery.com/jquery-3.4.1.min.js"}

];

@Injectable({
  providedIn: 'root'
})
export class SubscriptionService {

    private requestHeaders: HttpHeaders;

  private scripts: any = {};

  constructor(private http: HttpClient, private injector: Injector) {

    // this.requestHeaders = new HttpHeaders();
    // this.requestHeaders.append('Content-Type', 'application/json');
    // this.requestHeaders.append('Accept', 'application/json');

    ScriptStore.forEach((script: any) => {
      this.scripts[script.name] = {
          loaded: false,
          src: script.src
      };
  });
   }

   load(scriptUrl: string) {
    return new Promise((resolve, reject) => {
      const scriptElement = document.createElement('script');
      scriptElement.src = scriptUrl;
      scriptElement.type = 'text/javascript';
      scriptElement.async = true;
      scriptElement.charset = 'utf-8';
      scriptElement.onload = resolve;
      scriptElement.onerror = reject;
      document.head.appendChild(scriptElement);
    });
  }

   getPaymentForm() {
    return this.http.get('https://pci-connect.squareupsandbox.com/');
  }

//    loadScripts(...scripts: string[]): Promise<any> {
//     const promises: any[] = [];
//     scripts.forEach((script) => promises.push(this.loadScript(script)));
//     return Promise.all(promises);
// }

// loadScript(name: string) {
//     return new Promise((resolve, reject) => {
//         if (!this.scripts[name].loaded) {
//             // load script
//             const script = document.createElement('script');
//             script.type = 'text/javascript';
//             script.src = this.scripts[name].src;
//             // @ts-ignore
//             if (script.readyState) {  // IE
//                 // @ts-ignore
//                 script.onreadystatechange = () => {
//                     // @ts-ignore
//                     if (script.readyState === 'loaded' || script.readyState === 'complete') {
//                         // @ts-ignore
//                         script.onreadystatechange = null;
//                         this.scripts[name].loaded = true;
//                         resolve({script: name, loaded: true, status: 'Loaded'});
//                     }
//                 };
//             } else {  // Others
//                 script.onload = () => {
//                     this.scripts[name].loaded = true;
//                     resolve({script: name, loaded: true, status: 'Loaded'});
//                 };
//             }
//             script.onerror = (error: any) => resolve({script: name, loaded: false, status: 'Loaded'});
//             document.getElementsByTagName('head')[0].appendChild(script); // <--- !!!
//         } else {
//             console.warn('Already Loaded...')
//             resolve({script: name, loaded: true, status: 'Already Loaded'});
//         }
//     });
//}

isAlreadyLoaded(name): boolean {
    return this.scripts[name]?.loaded;
}

headRequest(url: string):Observable<any> {
    return this.http.head(url, {observe: 'response'}); //is observe property necessary to make this http call? If not you can remove it.
  }

}