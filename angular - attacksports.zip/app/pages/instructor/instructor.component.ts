import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import {PageEvent} from '@angular/material/paginator';


@Component({
  selector: 'app-instructor',
  templateUrl: './instructor.component.html',
  styleUrls: ['./instructor.component.scss']
})
export class InstructorComponent implements OnInit {
  base_url: string = environment.base_url;
  instructor:any;
  i:number;
  litedesc: string;

  constructor(private web: WebService,private router:Router,
    public common: CommonService, ) { }

  ngOnInit(): void {
    this.getallinstructor()
  }
  selectedinstructor(data:any){
  this.router.navigate(['/instructordetails',data.instructor_id]);
  }
  async getallinstructor() {
    await this.web.getData('getallinstructor').then((res) => {
      if (res.status == '200') {
        this.instructor = res.data;
       
      } else {
        // console.log(":(")
      }
    }, err => {
      console.log(err);
      // console.log(":)")
    })
  }
  onKeyUp(x) { // appending the updated value to the variable
    window.location.reload();
  }
  async finddesc(desc: any) {
    this.litedesc= desc.substring(0, 170) + '....';    
  }
}
