
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import{InstructorRoutingModule} from './instructor.routing.module'
import { HeaderFooterModule } from '../../header-footer/header-footer.module';

import { CommonModule } from '@angular/common';
import { InstructorComponent } from './instructor.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatPaginatorModule} from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    InstructorComponent
  ],
  imports: [
    HeaderFooterModule,
    RouterModule,
    InstructorRoutingModule,
CommonModule,MatFormFieldModule,MatPaginatorModule,FormsModule,MatInputModule
  ]
})
export class InstructorModule { }

