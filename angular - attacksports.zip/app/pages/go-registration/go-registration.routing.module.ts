import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { TournamentConfopageComponent } from "../tournament-confopage/tournament-confopage.component";
import { GoRegistrationComponent } from "./go-registration.component";


const routes: Routes = [
  {
    path: "",
    component: GoRegistrationComponent
  },
  {
    path: "tournament-confopage/ + webId",
    component: TournamentConfopageComponent
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class GoRegistrationRoutingModule { }