import { Component, OnInit } from '@angular/core';
import { environment } from '../../../../src/environments/environment';
import { countries } from '../../pages/common/commonjson/country-data-store';
import { WebService } from '../../../../src/app/providers/web.service';
import { CommonService } from '../services/common.service';
import { FormBuilder, FormGroup} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GoRegistrationFormService } from './go-registration.services';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

declare var Square: any;

@Component({
  selector: 'app-go-registration',
  templateUrl: './go-registration.component.html',
  styleUrls: ['./go-registration.component.scss']
})

export class GoRegistrationComponent implements OnInit {
  formDetails  = {
    web_id: '',
    UserId: '',
    registration_field: '',
    registration_fees: '',
    u18division: '',
    u15division: '',
    u13division: '',
    u11division:'',
    u9division:'',
    player_fname: '',
    player_lname: '',
    dob_month:'',
    dob_day:'',
    dob_year:'',
    gender:'',
    shirtsize:'',
    preferred_position:'',
    current_association:'',
    season_division:'',
    parent_fname: '',
    parent_lname: '',
    parent_email: '',
    parent_addemail: '',
    parent_phone:'',
    player_country:'',
    street_address:'',
    city:'',
    province:'',
    postal_code:'',
    jersey_size:'',
    jersey_choice1:'',
    jersey_choice2:'',
    jersey_choice3:'',
    friend_request1:'',
    friend_request2:'',
    friend_request3:'',
    volunteers:'',
    auction:'',
    sponsor:'',
    order_id:'',
    order_date:'',
    hoodie_ticket:'',
    coupon_code:'',
    bill_fname: '',
    bill_lname: '',
    payment_method: '',
    total_amount: '',
    payment_status: '',
    bill_country: '',
    bill_address:'',
    bill_city:'',
    bill_province: '',
    bill_postalcode: '',
    bill_email:'',
    bill_phone:'',
  };

  base_url: string = environment.base_url;
  checked: boolean = true;
  goregistrationform: FormGroup;
  countries = countries;

  numberyear: number[] = [];
  currentYear: number = new Date().getFullYear();
  userid:any; 
  resultcontents: any=[];
  acceptTerms: boolean=false;
  formGroup: FormGroup;
  totalAmount: number = 0;
  registration_price = 0;
  showRemoveButton: boolean = false;
  showRemoveButton1: boolean = false;
  showRemoveButton2: boolean = false;
  quantitySelected: number = 0;
  quantitySelected1: number = 0;
  quantitySelected2: number = 0;
  payments: any;
  card: any;
  cardButton: HTMLButtonElement;
  statusContainer: HTMLElement;
  accesstoken = "EAAAEM7lDK-ZqOZPAwqWN6RbXR_a7YAEHWCYfnMVGCC0cnj5mTejBbXmQUIUFAjC";
  applicationId = "sandbox-sq0idb-njBgtuXFMDflZxobPrR7Jg";
  locationId = "L8KFYVYEZHHHX";
  paymentForm: any; 
  userDetailsTemp: any;
  registrationdetails: any;
  registrationamount: any;
  paymentContainerVisible = false;
  isSpinning: boolean;
  isLoading: boolean;
  showPaymentContainer = false;
  registrationFee: any;
  pricedetails: any;


  months: string[] = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  numbermonth: number[] = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12
  ];


  days: number[] = Array.from({ length: 31 }, (_, i) => i + 1);
  years: number[] = Array.from({ length: 50 }, (_, i) => new Date().getFullYear() - i);
  
  tournamentshirt: string[] = [
    'Youth Small', 'Youth Medium', 'Youth Large', 'Youth X-Large', 'Adult Small', 'Adult Medium', 'Adult Large'
  ];

  position: string[]= [
    'Forward', 'Defense', 'Goalie'
  ];

  province: string[]= [
    'AB', 'BC', 'MB', 'NB', 'NL' ,'NT', 'NS', 'NU', 'ON', 'PE', 'QC', 'SK', 'YT'
  ];

  jersey: string[]= [
    'Youth S/M', 'Youth L/XL', 'Adult Small', 'Adult Medium', 'Adult Large', 'Youth Goalie Cut', 'Adult Goalie Cut'
  ];

  volunteer: string[]= [
    'Head Coach', 'Assistant Coach', 'Friday Morning (Set-up)', 'Registration/Check-in Table', 'Silent Auction Table',
    'Square Board (Sales person)', 'Just tell me what to do', 'I just want to enjoy the weekend'
  ];

  auction: string[] =[
    'Yes, please contact me', 'No, but I know someone who can', 'No'
  ];

  sponsorship: string[]= [
    'Yes, please contact me', 'Yes, I have another company in mind', 'No Thank you!'
  ]
  couponCode: any;
  discountedAmount: any;
  nightTicket: any;
  jerseyTicket: any;
  hoodieTicket: any;
  gstPrice: any;
  nightSum: any;
  jerseySum: any;
  hoodieSum: any;
  orderID: string;
  orderDate: any;
  
  constructor(private activateRoute:ActivatedRoute,
    public common: CommonService,
    private web:WebService,
    private tableService: GoRegistrationFormService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private router: Router) {
      this.nightSum = 0;
      this.totalAmount = 0;
      this.jerseySum = 0;
      this.hoodieSum = 0;
      this.goregistrationform = this.tableService.exportNewForm();
  }


  ngOnInit(): void {

    for (let i = 0; i <= 20; i++) {
      this.numberyear.push(this.currentYear + i);
    }
    console.log(this.numberyear);

    this.getRegistrationDetails();
    this.getPriceDetails();
    this.generateOrderNumber();
  }

  onPaymentMethodChange(){
    if (this.formDetails.payment_method === 'credit_card') {
      this.loadScript();
      this.formDetails.payment_status ="Active";
      this.paymentContainerVisible = true;
    } else if(this.formDetails.payment_method === 'offline_payment') {
      this.paymentContainerVisible = false;
      this.formDetails.payment_status ="Inactive";
    } else{
      
    }
  }

  getPriceDetails(){
    this.web.getData('getPriceDetails').then((res) => {
        if (res.status == '200') {
        this.pricedetails = res.data;
        console.log("PRICE DETAILSSSSSSSSSSS",this.pricedetails);

        this.registrationFee = parseFloat(res.data[0].registration_price);
        console.log("Registration Fees:", this.registrationFee)
      
        this.gstPrice = parseFloat(res.data[0].gst_price);
        console.log("GST:", this.gstPrice)

        this.nightTicket = parseFloat(res.data[0].pub_price);
        console.log("Pub Price:", this.nightTicket)
    
        this.jerseyTicket = parseFloat(res.data[0].jersey_price);
        console.log("Jersey Price:", this.jerseyTicket);

        this.hoodieTicket = parseFloat(res.data[0].hoodie_price);
        console.log("Hoodie Price:", this.hoodieTicket);

        this.updateTotalAmount(); 
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }

  

  updateTotalAmount(){
    const discountPercentage = this.discountedAmount || 0;
    this.formDetails.total_amount = this.totalAmount.toString();
    console.log("TOTAL VALUEEEEEEE", this.formDetails.total_amount);
    console.log("TOTALLLLLLLLL", this.totalAmount);
    this.totalAmount = parseFloat(this.registrationFee || 0) + parseFloat(this.gstPrice || 0) +
    parseFloat(this.nightSum || 0) + parseFloat(this.jerseySum || 0)
    + parseFloat(this.hoodieSum || 0)- discountPercentage;
  }

  // Night Ticket Function
  addItem() {
    this.nightSum += this.nightTicket;
    this.showRemoveButton = true;
    this.quantitySelected++;
    this.updateTotalAmount(); 
  }

  removeItem() {
    this.nightSum -= this.nightTicket;
    this.totalAmount -= this.nightTicket;
    this.quantitySelected--;
    if(this.quantitySelected == 0){
      this.showRemoveButton = false;
    }
  }

   // Jersey Ticket Function
  addAmount() {
    console.log("this.totalAmount", this.totalAmount)
    this.showRemoveButton1= true;
    this.quantitySelected1++;
    this.updateTotalAmount(); 
  }
  removeAmount() {
    this.jerseySum -= this.jerseyTicket;
    this.totalAmount -= this.jerseyTicket;
    this.quantitySelected1--;
    if(this.quantitySelected1 == 0){
      this.showRemoveButton1 = false;
    }
  }

   // Hoodie Ticket Function
   addPrice() {
    this.hoodieSum += this.hoodieTicket;
    this.showRemoveButton2= true;
    this.quantitySelected2++;
    this.updateTotalAmount(); 
  }
  removePrice() {
    this.hoodieSum -= this.hoodieTicket;
    this.totalAmount -= this.hoodieTicket;
    this.quantitySelected2--;
    if(this.quantitySelected2 == 0){
      this.showRemoveButton2 = false;
    }
    }


  getRegistrationDetails() {
    this.web.postData('getRegistrationDetails', this.formDetails).then((res) => {
      if (res.status === '200') {
        this.registrationamount = res.data;
        this.registrationamount.map((res, i) => {
          localStorage.setItem('registrationamount', res.total_amount);
          this.totalAmount = res.total_amount; 
          
        });
      } else {
        console.log(":(");
      }
    }).catch(err => {
      console.log(err);
      console.log(":)");
    });
  }

  generateOrderNumber() {
      const randomNumber = Math.floor(Math.random() * 1000000).toString();
      const timestamp = Date.now().toString();
      console.log("TIme Stamp:", timestamp)
      this.formDetails.order_id = this.orderID = randomNumber + timestamp;
      this.formDetails.order_date = this.orderDate= new Date().toISOString().split('T')[0];
      // console.log('orderNumber', this.orderID);
     }

  async submitForm() {
    if(this.userid=='null')
    {
      this.common.presentToast('Please Login before Registration');
    }
  else if (this.formDetails.registration_field == null || this.formDetails.registration_field == '') {
    this.common.presentToast('Fill the Registration Field');
  }
  else if (this.formDetails.player_fname == null || this.formDetails.player_fname == '') {
    this.common.presentToast('Enter your First name');
  }
  else if (this.formDetails.player_lname == null || this.formDetails.player_lname == '') {
    this.common.presentToast('Enter your Last name');
  }
  else if (this.formDetails.dob_month == null || this.formDetails.dob_month == '') {
    this.common.presentToast('Fill the Month');
  }
  else if (this.formDetails.dob_day == null || this.formDetails.dob_day == '') {
    this.common.presentToast('Fill the Day');
  }
  else if (this.formDetails.dob_year == null || this.formDetails.dob_year == '') {
    this.common.presentToast('Fill the Year');
  }
  else if (this.formDetails.gender == null || this.formDetails.gender == '') {
    this.common.presentToast('Fill the Gender');
  }
  else if (this.formDetails.shirtsize == null || this.formDetails.shirtsize == '') {
    this.common.presentToast('Fill the Shirt Size');
  }
  else if (this.formDetails.preferred_position == null || this.formDetails.preferred_position == '') {
    this.common.presentToast('Fill the Preferred Position');
  }
  else if (this.formDetails.current_association == null || this.formDetails.current_association == '') {
    this.common.presentToast('Fill the Current Association');
  }
  else if (this.formDetails.season_division == null || this.formDetails.season_division == '') {
    this.common.presentToast('Fill the Season Division');
  }
  else if (this.formDetails.parent_fname == null || this.formDetails.parent_fname == '') {
    this.common.presentToast('Enter the Parent`s First Name');
  }
  else if (this.formDetails.parent_lname == null || this.formDetails.parent_lname == '') {
    this.common.presentToast('Enter the Parent`s Last Name');
  }
  else if (this.formDetails.parent_email == null || this.formDetails.parent_email == '') {
    this.common.presentToast('Enter the Parent`s Email');
  }
  else if(this.common.validateEmail(this.formDetails.parent_email)==false){
    this.common.presentToast('Enter valid Email address');
  }
  else if(this.formDetails.parent_phone==null || this.formDetails.parent_phone=='' ||this.formDetails.parent_phone.trim().length==0){
    this.common.presentToast('Enter Phone Number');
  }
  else if(this.common.validateMobileNumber(this.formDetails.parent_phone)== false){
    this.common.presentToast('Enter Valid Phone Number');
  }
  else if (this.formDetails.player_country == null || this.formDetails.player_country == '') {
    this.common.presentToast('Fill the Country');
  }
  else if (this.formDetails.street_address == null || this.formDetails.street_address == '') {
    this.common.presentToast('Enter the Address');
  }
  else if (this.formDetails.city == null || this.formDetails.city == '') {
    this.common.presentToast('Enter the City');
  }
  else if (this.formDetails.province == null || this.formDetails.province == '') {
    this.common.presentToast('Enter the Province');
  }
  else if (this.formDetails.postal_code == null || this.formDetails.postal_code == '') {
    this.common.presentToast('Enter the Postal code');
  }
  else if(this.common.validateNumber(this.formDetails.postal_code)==false){
    this.common.presentToast('Enter valid postal code');
  }
  else if (this.formDetails.jersey_size == null || this.formDetails.jersey_size == '') {
    this.common.presentToast('Enter the Jersey size');
  }
  else if (this.formDetails.jersey_choice1 == null || this.formDetails.jersey_choice1 == '') {
    this.common.presentToast('Enter the Jersey choice 1');
  }
  else if(this.common.validateNumber(this.formDetails.jersey_choice1)==false){
    this.common.presentToast('Enter Valid Jersey Number');
  }
  else if (this.formDetails.jersey_choice2 == null || this.formDetails.jersey_choice2 == '') {
    this.common.presentToast('Enter the Jersey choice 2');
  }
  else if(this.common.validateNumber(this.formDetails.jersey_choice2)==false){
    this.common.presentToast('Enter Valid Jersey Number');
  }
  else if (this.formDetails.jersey_choice3 == null || this.formDetails.jersey_choice3 == '') {
    this.common.presentToast('Enter the Jersey choice 3');
  }
  else if(this.common.validateNumber(this.formDetails.jersey_choice3)==false){
    this.common.presentToast('Enter Valid Jersey Number');
  }
  else if (this.formDetails.friend_request1 == null || this.formDetails.friend_request1 == '') {
    this.common.presentToast('Enter the Friend request 1');
  }
  else if (this.formDetails.friend_request2 == null || this.formDetails.friend_request2 == '') {
    this.common.presentToast('Enter the Friend request 2');
  }
  else if (this.formDetails.friend_request3 == null || this.formDetails.friend_request3 == '') {
    this.common.presentToast('Enter the Friend request 3');
  }
  else if (this.formDetails.volunteers == null || this.formDetails.volunteers == '') {
    this.common.presentToast('Fill the Volunteers');
  }
  else if (this.formDetails.auction == null || this.formDetails.auction == '') {
    this.common.presentToast('Fill the Auction');
  }
  else if (this.formDetails.sponsor == null || this.formDetails.sponsor == '') {
    this.common.presentToast('Enter the Sponsor');
  }
  else if (this.acceptTerms == false) {
    this.common.presentToast('Accept the Terms and Conditions');
  }
  else if (this.formDetails.bill_fname == null || this.formDetails.bill_fname == '') {
    this.common.presentToast('Enter your First Name');
  }
  else if (this.formDetails.bill_lname == null || this.formDetails.bill_lname == '') {
    this.common.presentToast('Enter your Last name');
  }
  else if (this.formDetails.payment_method == null || this.formDetails.payment_method == '') {
    this.common.presentToast('Select your Payment method');
  }
  else if (this.formDetails.bill_country == null || this.formDetails.bill_country == '') {
    this.common.presentToast('Select your Country');
  }
  else if (this.formDetails.bill_address == null || this.formDetails.bill_address == '') {
    this.common.presentToast('Enter your Address');
  }
  else if (this.formDetails.bill_city == null || this.formDetails.bill_city == '') {
    this.common.presentToast('Fill the City');
  }
  else if (this.formDetails.bill_province == null || this.formDetails.bill_province == '') {
    this.common.presentToast('Enter the Province');
  }
  else if (this.formDetails.bill_postalcode == null || this.formDetails.bill_postalcode == '') {
    this.common.presentToast('Enter your Postal code');
  }
  else if(this.common.validateNumber(this.formDetails.bill_postalcode)==false){
    this.common.presentToast('Enter valid postal code');
  }
  else if (this.formDetails.bill_email == null || this.formDetails.bill_email == '') {
    this.common.presentToast('Enter your Email');
  }
  else if(this.common.validateEmail(this.formDetails.bill_email)==false){
    this.common.presentToast('Enter valid Email address');
  }
  else if(this.formDetails.bill_phone==null || this.formDetails.bill_phone=='' ||this.formDetails.bill_phone.trim().length==0){
    this.common.presentToast('Enter Phone Number');
  }
  else if(this.common.validateMobileNumber(this.formDetails.bill_phone)== false){
    this.common.presentToast('Enter Valid Phone Number');
  }
  
  else{
    {
      this.web.postData('tournamentform', this.formDetails).then(res=>{
        if(res.status=='200'){
      localStorage.setItem('web_id',this.formDetails.web_id);
      localStorage.setItem('UserId',this.formDetails.UserId);
      localStorage.setItem('registration_field',this.formDetails.registration_field);
      localStorage.setItem('registration_fees',this.formDetails.registration_fees);
      localStorage.setItem('u18division',this.formDetails.u18division);
      localStorage.setItem('u15division',this.formDetails.u15division);
      localStorage.setItem('u13division',this.formDetails.u13division);
      localStorage.setItem('u11division',this.formDetails.u11division);
      localStorage.setItem('u9division',this.formDetails.u9division);
      localStorage.setItem('player_fname',this.formDetails.player_fname);
      localStorage.setItem('player_lname',this.formDetails.player_lname);
      localStorage.setItem('dob_month',this.formDetails.dob_month);
      localStorage.setItem('dob_day',this.formDetails.dob_day);
      localStorage.setItem('dob_year',this.formDetails.dob_year);
      localStorage.setItem('gender',this.formDetails.gender);
      localStorage.setItem('shirtsize',this.formDetails.shirtsize);
      localStorage.setItem('preferred_position',this.formDetails.preferred_position);
      localStorage.setItem('current_association',this.formDetails.current_association);
      localStorage.setItem('season_division',this.formDetails.season_division);
      localStorage.setItem('parent_fname',this.formDetails.parent_fname);
      localStorage.setItem('parent_lname',this.formDetails.parent_lname);
      localStorage.setItem('parent_email',this.formDetails.parent_email);
      localStorage.setItem('parent_addemail',this.formDetails.parent_addemail);
      localStorage.setItem('parent_phone',this.formDetails.parent_phone);
      localStorage.setItem('player_country',this.formDetails.player_country);
      localStorage.setItem('street_address',this.formDetails.street_address);
      localStorage.setItem('city',this.formDetails. city);
      localStorage.setItem('province',this.formDetails.province);
      localStorage.setItem('postal_code',this.formDetails.postal_code);
      localStorage.setItem('jersey_size',this.formDetails.jersey_size);
      localStorage.setItem('jersey_choice1',this.formDetails.jersey_choice1);
      localStorage.setItem('jersey_choice2',this.formDetails.jersey_choice2);
      localStorage.setItem('jersey_choice3',this.formDetails.jersey_choice3);
      localStorage.setItem('friend_request1',this.formDetails.friend_request1);
      localStorage.setItem('friend_request2',this.formDetails.friend_request2);
      localStorage.setItem('friend_request3',this.formDetails.friend_request3);
      localStorage.setItem('volunteers',this.formDetails.volunteers);
      localStorage.setItem('auction',this.formDetails.auction);
      localStorage.setItem('sponsor',this.formDetails.sponsor);
      localStorage.setItem('order_id',this.formDetails.order_id);
      localStorage.setItem('order_date',this.formDetails.order_date);
      localStorage.setItem('hoodie_ticket',this.formDetails.hoodie_ticket);
      localStorage.setItem('coupon_code',this.formDetails.coupon_code);
      localStorage.setItem('bill_fname',this.formDetails.bill_fname);
      localStorage.setItem('bill_lname',this.formDetails.bill_lname);
      localStorage.setItem('payment_method',this.formDetails.payment_method);
      localStorage.setItem('total_amount',this.formDetails.total_amount);
      localStorage.setItem('payment_status',this.formDetails.payment_status);
      localStorage.setItem('bill_country',this.formDetails.bill_country);
      localStorage.setItem('bill_address',this.formDetails.bill_address);
      localStorage.setItem('bill_city',this.formDetails.bill_city);
      localStorage.setItem('bill_province',this.formDetails.bill_province);
      localStorage.setItem('bill_postalcode',this.formDetails.bill_postalcode);
      localStorage.setItem('bill_email',this.formDetails.bill_email);
      localStorage.setItem('bill_phone',this.formDetails.bill_phone);
      
      if(this.formDetails.payment_method =="offline_payment"){
        this.common.presentToast('Form Submitted Successfully, the Payment is Pending');
        setTimeout(() => {
                window.location.reload();
              }, 3000);
      }
     this.makePayment();
     this.router.navigate(['/tournament-confopage'], {
      queryParams: { webId: res.data }
     });
     
    }
  }
  )}
}
}

  async makePayment() {
    this.isSpinning= true;
    const statusContainer = document.getElementById('payment-status-container');
    try {
      const result = await this.card.tokenize();
      if (result.status === 'OK') {

        this.userDetailsTemp = JSON.parse(
          localStorage.getItem('UserDetails')
        );
        console.log("this.userDetailsTemp", this.userDetailsTemp);
        let data = {
          web_id: localStorage.getItem('web_id'),
          UserId: localStorage.getItem('UserId'),
          registration_field: localStorage.getItem('registration_field'),
          registration_fees:localStorage.getItem('registration_fees'),
          u18division:localStorage.getItem('u18division'),
          u15division:localStorage.getItem('u15division'),
          u13division:localStorage.getItem('u13division'),
          u11division:localStorage.getItem('u11division'),
          u9division:localStorage.getItem('u9division'),
          player_fname:localStorage.getItem('player_fname'),
          player_lname:localStorage.getItem('player_lname'),
          dob_month:localStorage.getItem('dob_month'),
          dob_day:localStorage.getItem('dob_day'),
          dob_year:localStorage.getItem('dob_year'),
          gender:localStorage.getItem('gender'),
          shirtsize:localStorage.getItem('shirtsize'),
          preferred_position:localStorage.getItem('preferred_position'),
          current_association:localStorage.getItem('current_association'),
          season_division: localStorage.getItem('season_division'),
          parent_fname: localStorage.getItem('parent_fname'),
          parent_lname:localStorage.getItem('parent_lname'),
          parent_email:localStorage.getItem('parent_email'),
          parent_addemail:localStorage.getItem('parent_addemail'),
          parent_phone:localStorage.getItem('parent_phone'),
          player_country:localStorage.getItem('player_country'),
          street_address:localStorage.getItem('street_address'),
          city:localStorage.getItem('city'),
          province:localStorage.getItem('province'),
          postal_code:localStorage.getItem(' postal_code'),
          jersey_size:localStorage.getItem('jersey_size'),
          jersey_choice1:localStorage.getItem('jersey_choice1'),
          jersey_choice2:localStorage.getItem('jersey_choice2'),
          jersey_choice3:localStorage.getItem('jersey_choice3'),
          friend_request1:localStorage.getItem('friend_request1'),
          friend_request2:localStorage.getItem('friend_request2'),
          friend_request3: localStorage.getItem('friend_request3'),
          volunteers: localStorage.getItem('volunteers'),
          auction:localStorage.getItem('auction'),
          sponsor:localStorage.getItem('sponsor'),
          order_id:localStorage.getItem('order_id'),
          order_date:localStorage.getItem('order_date'),
          hoodie_ticket:localStorage.getItem('hoodie_ticket'),
          coupon_code:localStorage.getItem('coupon_code'),
          bill_fname:localStorage.getItem('bill_fname'),
          bill_lname:localStorage.getItem('bill_lname'),
          payment_method:localStorage.getItem('payment_method'),
          total_amount:localStorage.getItem('total_amount'),
          payment_status:localStorage.getItem('payment_status'),
          bill_country:localStorage.getItem('bill_country'),
          bill_address:localStorage.getItem('bill_address'),
          bill_city:localStorage.getItem('bill_city'),
          bill_province:localStorage.getItem('bill_province'),
          bill_postalcode:localStorage.getItem('bill_postalcode'),
          bill_email:localStorage.getItem('bill_email'),
          bill_phone:localStorage.getItem('bill_phone'),
        
          // customer_id: localStorage.getItem('UserId'),
          amount: localStorage.getItem('registrationamount'),
          transaction_response: 'details',
          transaction_method: 'card',
          payment_status1: 'success',
          paymentToken: result.token,
          locationId: this.locationId,
          accesstoken: this.accesstoken,
        };
        console.log(this.totalAmount);
        this.web.postData('tournamentBilling', data).then(
        
          (res) => {
            if (res.status == '200') {
              this.discountedAmount=res.discountedAmount
              this.common.presentToast('Form Submitted Successfully. Payment Successful!')
              this.isSpinning= false;
              setTimeout(() => {
                window.location.reload();
              }, 3000);
              // this.ngOnInit();
            } else {
              this.common.presentToast(res.error);
            }
          }, err => {
            console.log(err);
            this.common.presentToast('Connection Error');
          });
  
      } else {
        let errorMessage = `Tokenization failed with status: ${result.status}`;
        if (result.errors) {
          errorMessage += ` and errors: ${JSON.stringify(
            result.errors
          )}`;
        }
        throw new Error(errorMessage);
      }
    } catch (e) {
      console.error(e);
      statusContainer.innerHTML = "Payment Failed";
    }
  }

  async  loadScript() {

    var applicationId = "sandbox-sq0idb-njBgtuXFMDflZxobPrR7Jg";
    var locationId = "L8KFYVYEZHHHX";
    this.payments = Square.payments(applicationId, locationId);
  
    this.card = await this.payments.card();
  
    this.card.attach('#card-container');
  
    this.cardButton = document.getElementById('card-button') as HTMLButtonElement;
    this.statusContainer = document.getElementById('payment-status-container') as HTMLElement; // the card nonce
  
    const form = document.querySelector('#card-payment') as HTMLFormElement;
  
    form.addEventListener('submit', async (event: Event) => {
  
      event.preventDefault();
      const result = await this.card.tokenize();
      console.log(result, "Resultttttttttt"); // the card nonce
    });
    
  }
  oncancel() {
    this.common.presentToast('Payment cancelled.');
    console.log("OnCancel");
  }

  async applyCoupon() {
      try {
       const requestData = {
        coupon_code: this.couponCode,
        UserId: localStorage.getItem('UserId'),
        totalAmount: this.totalAmount
        
       };
      // console.log("this.userId",this.userId);
       this.formDetails.coupon_code=this.couponCode
      
       const response: any = await this.web.postData('getCouponCodeValidation', requestData);
       console.log("Response :", response);
       if (response.status === '200') {
        console.log("Response Status:", response.status);
        this.discountedAmount = response.discountedAmount;
       } else if (response.status === '404') {
        this.common.presentToast('Invalid coupon code.');
       } else if (response.status === '403') {
        this.common.presentToast('Coupon code has expired.');
       } else if (response.status === '405') {
        this.common.presentToast('You have reached the usage limit for this coupon code.');
       } else {
        this.common.presentToast('Connection Error');
       }
      } catch (error) {
       console.error(error);
       this.common.presentToast('An error occurred while processing the request.');
      }
     }
  }