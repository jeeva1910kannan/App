import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LtadStagesRoutingModule } from './ltad-stages-routing.module';
import { LtadStagesComponent } from './ltad-stages.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';


@NgModule({
  declarations: [LtadStagesComponent],
  imports: [
    CommonModule,
    LtadStagesRoutingModule,
    HeaderFooterModule
  ]
})
export class LtadStagesModule { }
