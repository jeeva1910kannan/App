import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LtadStagesComponent } from './ltad-stages.component';

describe('LtadStagesComponent', () => {
  let component: LtadStagesComponent;
  let fixture: ComponentFixture<LtadStagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LtadStagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LtadStagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
