import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CommonService } from '../services/common.service';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-ltad-stages',
  templateUrl: './ltad-stages.component.html',
  styleUrls: ['./ltad-stages.component.scss']
})
export class LtadStagesComponent implements OnInit {
  covidcontent: any;
  ltadstages: any;
  base_url: string = environment.base_url;
  constructor(private web: WebService,private  common:CommonService  ) {
   
   }
   @ViewChildren('subDescRef') subDescRefs!: QueryList<ElementRef>;
   scrollToSubDesc(elementId: string) {
    // Get the target element based on the elementId
    const targetElement = document.getElementById(elementId);

    if (targetElement) {
        // Get the top position of the target element
        const yOffset = targetElement.getBoundingClientRect().top;

        // Use the scrollTo method to scroll to the element smoothly
        window.scrollTo({
            top: yOffset,
            behavior: 'smooth'
        });
    }
}

  ngOnInit(): void {
    this.getltadstages();
  }
  getltadstages() {
    this.web.getData('getltadStages').then((res) => {
      if (res.status == '200') {
        this.ltadstages = res.data;
       
        console.log(this.ltadstages, "this.ltadstages");
       

      }
      
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }

}
