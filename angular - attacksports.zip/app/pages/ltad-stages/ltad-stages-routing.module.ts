import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LtadStagesComponent } from './ltad-stages.component';

const routes: Routes = [
  {
    path: "",
    component: LtadStagesComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LtadStagesRoutingModule { }
