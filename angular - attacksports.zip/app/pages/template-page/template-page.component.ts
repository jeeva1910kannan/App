import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import * as CKEDITOR from '@ckeditor/ckeditor5-angular';



@Component({
  selector: 'app-template-page',
  templateUrl: './template-page.component.html',
  styleUrls: ['./template-page.component.scss']
})
export class TemplatePageComponent implements OnInit {
  web_id: any;
  campcontentdetails: any;
  camp_id: any;
  
  
  constructor( 
    private web:WebService,
    private http: HttpClient,
    private activateRoute:ActivatedRoute
  
    ) { 

  }
   campid:number = this.activateRoute.params['_value'].id;
  // campid:number = this.activateRoute.params['_value'].id;

  ngOnInit(): void {
    this.getcampdetails();
    //this.test(this.activateRoute.params['_value'].id)
    //CKEDITOR.config.allowedContent = true;
  }

  test(id) {
    this.camp_id = id;
    let data = {
     
      camp_id: this.campcontentdetails.web_id,
    
    }
  }


  getcampdetails(){
    let data_get = {
      web_id:this.campid

    }
    this.web.postData('getCampContents_id',data_get).then((res) => {
        if (res.status == '200') {
         this.campcontentdetails = res.data;
         console.log(this.campcontentdetails,"this.campcontentdetails");
        } else {
          console.log(":(")
        }
      }, err => {
        console.log(err);
        console.log(":)")
      });
  }



}
