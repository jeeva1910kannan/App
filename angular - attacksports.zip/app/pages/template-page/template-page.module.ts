import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TemplatePageRoutingModule } from './template-page-routing.module';
import { TemplatePageComponent } from './template-page.component';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';



@NgModule({
  declarations: [
    TemplatePageComponent
  ],
  imports: [
    CommonModule,
    TemplatePageRoutingModule,
    HeaderFooterModule,
    CKEditorModule
   ]
})
export class TemplatePageModule { }
