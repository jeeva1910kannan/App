import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WinterbreakfastclubComponent } from './winterbreakfastclub.component';

describe('WinterbreakfastclubComponent', () => {
  let component: WinterbreakfastclubComponent;
  let fixture: ComponentFixture<WinterbreakfastclubComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WinterbreakfastclubComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WinterbreakfastclubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
