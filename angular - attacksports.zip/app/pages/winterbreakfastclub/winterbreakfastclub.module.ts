import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WinterbreakfastclubComponent } from './winterbreakfastclub.component';
import {winterbreakfastRoutingModule} from './winterbreakfastclub.routing.module';
import {HeaderFooterModule} from '../../header-footer/header-footer.module'

@NgModule({
  declarations: [
    WinterbreakfastclubComponent
  ],
  imports: [
    CommonModule,
    winterbreakfastRoutingModule,
    HeaderFooterModule
  ],
  exports: [
    WinterbreakfastclubComponent
  ]
})
export class WinterbreakfastclubModule { }

