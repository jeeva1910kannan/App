import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { WebService } from '../../providers/web.service';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../services/common.service';
declare let jQuery: any;

@Component({
  selector: 'app-winterbreakfastclub',
  templateUrl: './winterbreakfastclub.component.html',
  styleUrls: ['./winterbreakfastclub.component.scss']
})
export class WinterbreakfastclubComponent implements OnInit {

  base_url: string = environment.base_url;
  // springhockey: any;
  winterbreakfastcontents: any[] = [];
  constructor(private web: WebService, private sanitizer: DomSanitizer,private cdr: ChangeDetectorRef,private  common:CommonService  ) { } 


  ngOnInit(): void {

    this.getWinterBreakfastClub();
  }
  getWinterBreakfastClub() {
    this.web.getData('getWinterBreakfastClub').then((res) => {
      if (res.status == '200') {
        this.winterbreakfastcontents = res.data;
       
        console.log(this.winterbreakfastcontents, "this.winterbreakfastcontents");
       

      }
      // else {
      // this.bannercontents[1].home_video=null;  
      // }
    }, err => {
      console.log(err);
      console.log(":)")
    });
  }
}
