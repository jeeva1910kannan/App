import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotifycustomerComponent } from './notifycustomer.component';

describe('NotifycustomerComponent', () => {
  let component: NotifycustomerComponent;
  let fixture: ComponentFixture<NotifycustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotifycustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotifycustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
