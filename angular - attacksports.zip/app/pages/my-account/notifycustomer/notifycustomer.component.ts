import { Component, OnInit } from '@angular/core';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-notifycustomer',
  templateUrl: './notifycustomer.component.html',
  styleUrls: ['./notifycustomer.component.scss']
})
export class NotifycustomerComponent implements OnInit {
  name = "ng2-ckeditor";
  ckeConfig: any;
  mycontent: string;
  editor = ClassicEditor;
  notifymsg: any = {
    'description': "",
  };
  nodata: boolean = true;
  show: boolean = false;
  messages: any;
  msgdate: Date;
  add:boolean=false;
  isDisabledVariable:boolean=false;
  constructor(private web: WebService,
    public common: CommonService,) { }

  ngOnInit(): void {
    this.isDisabledVariable=false;
    this.add=false;
    this.nodata=true;
    this.notifymsg.desc = "";
    this.notifymsg.title = "";
    this.getallnotifications();
  }
  async newnotify() {
    this.isDisabledVariable=true;
    if (this.notifymsg.title == null || this.notifymsg.title == '') {
      this.common.presentToast('Enter your title');
    }
    else if (this.notifymsg.description == null || this.notifymsg.description == '') {
      this.common.presentToast('Enter your message');
    }
    else {
      let data = {
        instructor_id: localStorage.getItem('UserId'),
        instructor_email: localStorage.getItem('email'),
        description: this.notifymsg.description,
        title: this.notifymsg.title,
        date: new Date(),
      }
      this.web.postData('newnotification', data).then((res) => {

        if (res.status == '200') {     
          
          this.ngOnInit();
          this.common.presentToast('Send Successfully');
        } else {
          this.common.presentToast('res.error');
        }
      }, err => {
        this.ngOnInit();
        this.common.presentToast('You not have any followers');
        console.log(err);
        
      });
    }
  }
  async cancel() {
  
    this.notifymsg.desc = "";
    this.ngOnInit();
  }
  async findstart(startdate: any) {
    this.msgdate = new Date(startdate * 1000);
  }
  async newmsg() {
    this.nodata=false;
    this.notifymsg=[];
    this.add=true;
    this.show=false;
  }
  async getallnotifications() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('getallnotifications', data).then((res) => {
      if (res.status == '200') {
        this.messages = res.data;
        this.show = true;
        this.nodata=false;
      } else {
       
        console.log(":(")
      }
    }, err => {

      console.log(err);
      console.log(":)")
    })
  }
}
