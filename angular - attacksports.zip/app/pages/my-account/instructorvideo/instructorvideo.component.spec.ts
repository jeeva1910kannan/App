import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructorvideoComponent } from './instructorvideo.component';

describe('InstructorvideoComponent', () => {
  let component: InstructorvideoComponent;
  let fixture: ComponentFixture<InstructorvideoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstructorvideoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructorvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
