import { DOCUMENT } from '@angular/common';
import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { ActivatedRoute, Router } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../services/common.service';
@Component({
  selector: 'app-instructorvideo',
  templateUrl: './instructorvideo.component.html',
  styleUrls: ['./instructorvideo.component.scss']
})

export class InstructorvideoComponent implements OnInit {
  public delid:any;
  category: any = [];
  subcategory: any = [];
  video: any;
  vname:any;
  eventvid: string = "";
  eventvid1: string = "";
  loading:boolean = false;
  uploadvideo:boolean = true;
  base_url:string = environment.base_url;
  currentPlayingVideo: HTMLVideoElement;
  user_id: any;
  thumbnailData: string;
  scaleFactor: any;
  eventimg: string;
  imageBase64: any;
  myvideos: any;
  videodate: Date;
  editvideo: boolean=false;
  fileNameDialogRef: MatDialogRef<ConfirmationpopupComponent>;
  litedesc: string;
  constructor(private web: WebService,public dialog: MatDialog,
    public common: CommonService,private router: Router, @Inject(DOCUMENT) private document: Document) {  this.video = {
      category: "",
      subcategory: "",
      title: "",
      description: "",
      image: "",
    };}
   
  ngOnInit(): void {
    this.myvideos=[];
    this.uploadvideo=false;
    this.editvideo=false;
    this.getallvideos();

    console.log("Ranjithhhhhh");
    
  }
  ngAfterContentInit() {
    this.subcategory ="";
   

}
async finddesc(desc: any) {
  this.litedesc= desc.substring(0, 170) + '....';    
}

getsub(id: any) {
 // console.log(id);
  this.web.getsubCategory('getactiveSub?table=Talev_subcategory&catid='+id+'').then((res)=>{
   // console.log(res);
    if(res.status =='200'){
     this.subcategory = res.data;
      
    }else{
      this.subcategory = "";
      //this.common.presentToast(res.error);
    }
  },err=>{
    console.log(err);
   // this.common.presentToast('Connection Error', );
  })


}

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      console.log(files);
      if(files[0].type == "video/mp4" || files[0].type == "video/mkv"){
      this.onSubmit(files);
      }
      else{
        this.common.presentToast("Only videos can be uploaded");
      }
    }
  }

  onSubmit(file: any) {
    let d = new Date();
    let n:any = d.valueOf();
  //  console.log(file[0].name);
    let fname = file[0].name;
    this.loading = true;
    this.generateThumbnail(file[0]).then(thumbnailData => {
      //console.dir(thumbnailData);
      this.thumbnailData = thumbnailData;
    //this.web.videoimage(this.thumbnailData);
    let d = new Date();
    let imagename = fname.substring(fname.lastIndexOf(".") + 1, fname.length) || fname;
    this.imageBase64 = ({base64 : this.thumbnailData, imagename:'ATTACK_'+n +'.png', });

    this.web.videoimage(this.imageBase64).then(
      (Response: any) => {
        if (Response.status == "200") {
        //  console.log(Response.msg);
          //this.common.closeLoading();
          console.log(Response.data);
          this.video.image = Response.data;
          this.common.presentToast( Response.msg);
        } else {
        //  console.log("failed");
          //this._commonService.closeLoading();
          this.common.presentToast(Response.error);
        }
      },
      (err) => {
        //this._commonService.closeLoading();
        //this._commonService.presentToast(`Connection error`);
      }
    );
  });

    //this.vidimageupload(myFile);
    fname = fname.substring(fname.lastIndexOf('.')+1, fname.length) || fname;
    let filename = 'ATTACK_'+n +'.'+ fname;
    const formDataevent = new FormData();
    formDataevent.append("video_upload_file", file[0]);
    // formDataevent.append("video_upload_file", filename);
    this.eventvid = filename;
    this.web.uploadWebsiteVideo(this.base_url+`uploads/video/uploadVideo.php?filename=${filename}`,formDataevent).subscribe((Res: any) =>{
      if(Res.status == 'success')      {
      //  console.log("sucess");
        this.loading = false;

        
        this.eventvid1 = this.base_url+"uploads/video/instructorvideos/" + filename;
        console.log("Uploaded video is",this.eventvid1);
       }else{
       //  console.log("failed");
         this.loading = false;
       }
     }, (err) => {
      this.loading = false;
          console.log(JSON.stringify(err));
      });
    }

    SubmitVideo(video, vname) {
      if (video.title == "" || video.title == undefined) {
         this.common.presentToast("Enter Title");
       } else if (video.description == "" || video.description == undefined) {
         this.common.presentToast("Enter Description");
       } else if (vname == "" || vname == undefined) {
         this.common.presentToast("Choose Video");
       } else {
       //  console.log(vname);
         var data = {     
           title: video.title,
           description: video.description,
           video_name: vname,
           instructor_id: localStorage.getItem('UserId'),         
           image: video.image,
           date: new Date(),
         }; 
         //this.common.presentLoading();
         this.web.postData('instructorvideo', data).then((res) => {
          if (res.status == '200') {   	
            this.common.presentToast('Uploaded Successfully');  
            this.ngOnInit(); 
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
       }
     }

   
  onPlayingVideo(event) {
  //  console.log("this"+event);
    event.preventDefault();
    // play the first video that is chosen by the user
    if (this.currentPlayingVideo === undefined) {
      this.currentPlayingVideo = event.target;
      this.currentPlayingVideo.play();
    } else {
      // if the user plays a new video, pause the last one and play the new one
      if (event.target !== this.currentPlayingVideo) {
        this.currentPlayingVideo.pause();
        this.currentPlayingVideo = event.target;
        this.currentPlayingVideo.play();
      }
    }
}
public generateThumbnail(videoFile: Blob): Promise<string> {
  const video: HTMLVideoElement = this.document.createElement('video');
  const canvas: HTMLCanvasElement = this.document.createElement('canvas');
  const context: CanvasRenderingContext2D = canvas.getContext('2d');
  return new Promise<string>((resolve, reject) => {
    canvas.addEventListener('error',  reject);
    video.addEventListener('error',  reject);
    video.addEventListener('canplay', event => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
      resolve(canvas.toDataURL());
    });
    if (videoFile.type) {
      video.setAttribute('type', videoFile.type);
    }
    video.preload = 'auto';
    video.src = window.URL.createObjectURL(videoFile);
    video.load();
  });
}
async addvideo(){

  this.video.title="";
  this.video.description="";
  this.uploadvideo=true;
  this.editvideo=false;
}
async findstart(startdate: any) {
  this.videodate = new Date(startdate * 1000);
}
async getallvideos() {
  let data = {
    instructor_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type')
  }
  await this.web.postData('getinstructorvideos_instructor',data).then((res) => {
    if (res.status == '200') {
      this.myvideos = res.data;
this.uploadvideo=false
    } else {
      this.uploadvideo=false;
      this.editvideo=false;
this.myvideos=[];
      console.log(":(")
    }
  }, err => {
    console.log(err);
    console.log("error working")
  })
}

async editevent(currentvideo:any){
  this.editvideo=true;

  let data = {
    user_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type'),
    web_id:currentvideo.web_id
  }
  this.web.postData('geteditvideoDetails',data).then((res) => {
    if (res.status == '200') {
      this.video = res.data;  
      this.video.image = this.video.video_name;
console.log(this.video.image);

    } else {
      console.log(res.error);
    }
  }, err => {
    console.log(err);
  this.common.presentToast('Connection Error.');
  });



}
async deleteevent(currentvideo:any){
  this.delid=currentvideo.web_id;
  this.fileNameDialogRef = this.dialog.open(ConfirmationpopupComponent, {
        data: {
          web_id:this.delid,
        },
      });
      this.fileNameDialogRef.afterClosed().pipe(
      
      ).subscribe(name => {
    this.ngOnInit();
      })
}
cancel(){

  this.uploadvideo=false;
  this.editvideo=false;
}

SubmiteditVideo(video, vname) {
  if (video.title == "" || video.title == undefined) {
     this.common.presentToast("Enter Title");
   } else if (video.description == "" || video.description == undefined) {
     this.common.presentToast("Enter Description");
   } else {
   //  console.log(vname);
     var data = {     
       title: video.title,
       description: video.description,
     web_id:video.web_id
     };
     
     //this.common.presentLoading();
     this.web.postData('editinstructorvideo', data).then((res) => {

      if (res.status == '200') {
  
        this.common.presentToast('Uploaded Successfully');  
this.ngOnInit();
      } else {
          this.common.presentToast('res.error');
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
   }
 }
}
@Component({
  selector: 'app-confirmationpopup',
  templateUrl: 'confirmationpopup.component.html',
  styleUrls: ['confirmationpopup.component.scss']
})

export class ConfirmationpopupComponent  {
  pop:boolean=true;
  display: string;
menu='instructorvideo';
  selectedMenu: string;
  participantsForm: any;
  loading: boolean=false;
  @Output() notifyParent: EventEmitter<any> = new EventEmitter();
  litedesc: any;
  constructor(
    private router: Router,
    private web: WebService,
    public common: CommonService,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data:InstructorvideoComponent
  ) { }
 
  okdelete(){

console.log(this.data);

    

    this.web.postData('deleteinstructorvideo',this.data).then((res) => {

      if (res.status == '200') {
        this.dialog.closeAll();  
         
//this.changeSideMenu('instructorvideo');
      this.common.presentToast('Deleted Successfully');
      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    
    });
  
  }
  // changeSideMenu(menu: string) {
  //   this.selectedMenu = menu;
  //   this.notifyParent.emit(menu);
  // }

  canceldelete(){
    this.dialog.closeAll();   
  }
}