import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswrodComponent implements OnInit {

  passwordForm: any;

  userId: any;

  userType: any;

  constructor(
    private web: WebService,
    public common: CommonService,
  ) {
    this.userId = localStorage.getItem('UserId');
    this.userType = localStorage.getItem('type');
  }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.passwordForm = new FormGroup({
      type: new FormControl(''),
      userId: new FormControl(''),
      old_pass: new FormControl('', [Validators.required]),
      new_pass: new FormControl('', [Validators.required]),
      confirm_pass: new FormControl('', [Validators.required])
    });
  }

  onSubmit() {
    console.log("present");
    
    this.passwordForm.get('type').setValue(this.userType);
    this.passwordForm.get('userId').setValue(this.userId);
    if (this.passwordForm.get('old_pass').value == null || this.passwordForm.get('old_pass').value == '') {
      this.common.presentToast('Enter old password');
    }  
     else if (this.passwordForm.get('new_pass').value  == null || this.passwordForm.get('new_pass').value == '') {
      this.common.presentToast('Enter new password');
    }  else if (this.passwordForm.get('new_pass').value  < 6) {
      this.common.presentToast('Password should have 6 characters');
    }else if (this.passwordForm.get('confirm_pass').value == null || this.passwordForm.get('confirm_pass').value== '') {
      this.common.presentToast('Enter confirm password');
    } else if (this.passwordForm.get('new_pass').value  != this.passwordForm.get('confirm_pass').value) {
      this.common.presentToast('Confirm password is mismatched')
    } 
   else if (this.passwordForm.valid && (this.passwordForm.get('new_pass').value === this.passwordForm.get('confirm_pass').value) && (this.passwordForm.get('old_pass').value != this.passwordForm.get('new_pass').value)) {
  
      this.web.postData('resetPassword', this.passwordForm.value).then((res) => {
        if (res.status == '200') {
       //   this.alert.successMsg(res.error, '');
       this.common.presentToast(res.error);
          this.passwordForm.reset();

        } else {
          this.common.presentToast(res.error);
        }
      }, err => {
 
        this.common.presentToast('Connection Error');
       // this.alert.errorMsg('Connection Error', '');
      });
    } else {
      this.common.presentToast('Check if all fields are filled properly and then try');
     // this.alert.warningMsg('Check if all fields are filled properly and then try', '');
    }
  }

  onCancel() {
  
      window.location.reload();
      this.ngOnInit();
    
  }

}
