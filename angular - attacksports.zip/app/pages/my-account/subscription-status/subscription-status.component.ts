import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Route, Router } from '@angular/router';
import { CommonService } from 'src/app/providers/common.service';
import { WebService } from 'src/app/providers/web.service';
declare let $:any;
@Component({
  selector: 'app-subscription-status',
  templateUrl: './subscription-status.component.html',
  styleUrls: ['./subscription-status.component.scss']
})
export class SubscriptionStatusComponent implements OnInit {
  CancelPlan: any;

  openDialog(userId:any,msg:any,cForType:any) {
    let dialogRef = this.dialog.open(Confirmation);
    dialogRef.componentInstance.userId=userId;
    dialogRef.componentInstance.msg=msg;
    dialogRef.componentInstance.cForType=cForType;
    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }

  plan:any;
  PlanCancel: any;
  userId:any;
  planDate: any;
  planexpireDate: number;
  loading: boolean = false;
  fetchingStatus: boolean = true;

  constructor(
    private web:WebService,
    private common: CommonService,
    private dialog:MatDialog,
    private router :Router
  ) {
   }

   loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }

  ngOnInit(): void {
    this.userId = localStorage.getItem('UserId');
    console.log('userId::',this.userId);
    this.getplan(this.userId);
    this.CancelPlanStatus(this.userId);
    setTimeout(() => {
      $(function () {
        $('[data-toggle="tooltip"]').tooltip()
      })
    }, 100);
  }

  openPricing(){
    this.router.navigate(['./pricing']);
  }

  getplan(userId) {
    if(userId){
      this.fetchingStatus = true;
      this.web.getData('getplandetails?planDetails_id='+ userId).then((res) => {
        this.loading = false;
        if (res.status == '200') {
          this.plan = res.data[0];
          this.planDate = this.plan.subscribe_date*1000;
          this.planexpireDate = this.plan.subscribe_expired_date*1000;
          setTimeout(() => {
            this.fetchingStatus = false;
          }, Math.random() * 1000 + 1000);
          console.log('planDetails',this.plan);
        } else {
          // this.alert.errorMsg(res.error, '');
        }
      }, err => {
        this.common.presentToast('connection error');
      });
    }
  }


  CancelPlanStatus(userId){
    if(userId){
      this.web.getData('getCanceldetails?planDetails_id='+ userId).then((res) => {
        if (res.status == '200') {
          this.CancelPlan = res.data[0];
          if(this.CancelPlan.subscribe_status=="cancelled"){
            this.PlanCancel = "cancel";
          }
        } else {
          // this.alert.errorMsg(res.error, '');
          this.PlanCancel = "not_cancelled";
        }
      }, err => {
        this.common.presentToast('connection error');
      });
    }
  }

  openModal(){
    let id = localStorage.getItem('UserId');
    this.openDialog(id,"Do you really want to cancel subscription?","Cancel");
  }

}

@Component({
  selector: 'confirmation',
  templateUrl: './confirmation.html',
  styleUrls: ['./confirmation.scss'],
  // encapsulation: ViewEncapsulation.None
})
export class Confirmation {
  userId:any;
  msg:any;
  cForType:any;
  loading:boolean;
  constructor(public dialogRef: MatDialogRef<Confirmation>,
              private web: WebService,
              public common: CommonService) {

  }

  closeDialog(){
    this.dialogRef.close();
  }

  ngOnInit(){

  }
  onClose(){
this.dialogRef.close();
  }

  onSuccess(){
    this.cForType=="cancel";
    // let urlPath=(this.cForType=="Cancel")?"cancelSubscription":"reactivateSubscription";
    this.loading = true;
    this.web.postData('cancelSubscription',{"user_id":this.userId}).then(res => {
      this.loading = false;
      if (res.status == 'success') {
        this.common.presentToast(res.msg);
        this.closeDialog();
      } else{
        // this.common.presentToast(res.msg);
      }
    }, err => {
      this.loading = false;
      this.common.presentToast('connection error');
    });
  }
}
