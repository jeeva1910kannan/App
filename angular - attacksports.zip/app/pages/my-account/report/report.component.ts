import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { Router, UrlMatcher } from '@angular/router';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
  customer: any;
  profile: string;
  web_id: any;

  constructor(private activateRoute:ActivatedRoute, private web: WebService,private router: Router,
    public common: CommonService,) { }
    base_url: string = environment.base_url;

  ngOnInit(): void {
    this.test(this.activateRoute.params['_value'].id,this.activateRoute.params['_value'].web_id)
console.log("jhsdfhdsjfh")
  }
  test(id,web_id){
    let data =
    {
   
      customer_id:id,
    }
    this.web.postData('getselectedcustomer',data).then((res) => {
      if (res.status == '200') {
        this.customer = res.data;
        this.profile=this.base_url+'uploads/Profile/'+this.customer.profile;
        console.log(res.data,"daataa");

      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    this.common.presentToast('Connection Error.');
    });
  
    

}


}
