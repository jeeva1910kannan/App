import { Component,Inject, OnInit } from '@angular/core';
import Pusher from 'pusher-js';
import { WebService } from 'src/app/providers/web.service';
import { CommonService } from '../../services/common.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import {FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {  ViewChild, ElementRef, ChangeDetectionStrategy } from '@angular/core';
import { ContactList } from './contactList';
import { ChatMessages } from './chatMessages';
// import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { Chat } from './chat';
import { DatePipe } from '@angular/common';
import { LoaderService } from 'src/app/providers/loader.service';


@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],

  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatComponent implements OnInit {
  @ViewChild('scrollframe') private myScrollContainer: ElementRef;

  // public config: PerfectScrollbarConfigInterface = {};
  interval:any;
  CustomersForm: any = {};
  message_enable: boolean=true;
  public showSidebar = false;
  public now: Date | null = null;
  activeChatUserId :any;
  activeChatUser: string | null | undefined = '';
  activeChatUserImg: string | null = '';
  activeChatUserStatus = '';
  fetchingStatus: boolean = true;
  test: boolean = true;

  @ViewChild('messageInput', { static: true })
  messageInputRef: ElementRef | null = null;

  message :any;
  messages = new Array();
  base_url: string = environment.base_url;

  contactList: ContactList[] | null = null;

  savedMessages: Chat[] | null = null;
    viewProfile: any;
    instructor_name: any;
    alldata: any;
    contactLists: any[];
  messagelist: any = [];
  user_id: any;
  users_id: any;
  scrollframe: any;
  profile: any;


  constructor(    private loaderService: LoaderService,
    private datePipe: DatePipe,    public common: CommonService,    private web: WebService,

    ) {
      if (localStorage.getItem('type') == "Instructor") {

        this.get_customer();
      }

      // const chatMessage: ChatMessages = new ChatMessages();
    //   this.contactList=this.contactLists;
    //   this.contactList = [
    //       {
    //           id: 1,
    //           imagePath: 'assets/images/users/1.jpg',
    //           name: 'Steve Rogers',
    //         //   signature: 'Hey Banner, where are you?',
    //         //   time: '9:30AM',
    //         //   chats: chatMessage.chat1,
    //       },
    //       {
    //           id: 2,
    //           imagePath: 'assets/images/users/2.jpg',
    //           name: 'Ram',
    //         //   signature: 'ram ram ram .....',
    //         //   time: '10:30AM',
    //         //   chats: chatMessage.chat2,
    //       },
    //       {
    //           id: 3,
    //           imagePath: 'assets/images/users/3.jpg',
    //           name: 'Shyam',
    //         //   signature: 'shyam shyam .....',
    //         //   time: '11:30AM',
    //         //   chats: chatMessage.chat3,
    //       },
    //       {
    //           id: 4,
    //           imagePath: 'assets/images/users/4.jpg',
    //           name: 'Mark',
    //         //   signature: 'mark mark ......',
    //         //   time: '8:30AM',
    //         //   chats: chatMessage.chat4,
    //       },
    //       {
    //           id: 5,
    //           imagePath: 'assets/images/users/5.jpg',
    //           name: 'Robin',
    //         //   signature: 'robin robin ......',
    //         //   time: '6:30AM',
    //         //   chats: chatMessage.chat5,
    //       }

    //   ];


    //   // tslint:disable-next-line:no-non-null-assertion
    //   this.activeChatUser = this.contactList!.find(x => x.id === 1)?.name;
    // //   // tslint:disable-next-line:no-non-null-assertion
    //   this.activeChatUserImg = this.contactList!.find(x => x.id === 1)!.imagePath;
      // tslint:disable-next-line:no-non-null-assertion
    //   this.savedMessages = this.contactList!.find(x => x.id === 1)!.chats;



      // this.activeChatUserStatus = 'Online';
  }
  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit() {
  this.getAccountDetails();
  if (localStorage.getItem('type') == "Instructor") {

    // this.get_customer();
    // this.interval= setInterval(() => {
    //   this.getmesgae();
    //     }, 5000);  
      } else {
    this.get_instructor();
    this.interval= setInterval(() => {
      this.getmessage();
        }, 5000); 
    

  }
 
  }

  set(){
    this.test=false;
  }
  messagecount()
{
  console.log('ewr');
  this.message_enable=true;
    let str=this.CustomersForm.message.trim();
    console.log(str);
    if(str)
    {
      this.message_enable=false;
      console.log(this.message_enable);
    }

}
  async get_customer() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    // this.fetchingStatus = false;

     this.web.postData('trainee',data).then((res) => {
      if (res.status == '200') {
        this.fetchingStatus = false;

        console.log(res.data,"trainee");
        console.log(res.data.notification,"notify");
                this.alldata=res.data;
                let array = [];
                this.alldata.map((res,i)=>{
                    console.log(res,"pushhh");
                    console.log(i,"pushhh");
                     let obj={};
                     obj["name"]=res.first_name;
                    
                     obj["id"]=res.web_id;
                     obj["imagePath"]=this.base_url+'uploads/Profile/'+res.profile;
                    //  obj["chats"]=t;

                     array[i]=obj;
                  })
                this.contactList = array;
                console.log( this.contactList," this.contactList");

        // this.request=false;
        setTimeout(() => {
         // this.continueregister = true;
        }, Math.random() * 2000 + 2000);
        // this.accepet_request(res.data.customer_id);
      } else {


      }
      
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }

  async get_instructor() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('trainer',data).then((res) => {
      if (res.status == '200') {
        console.log(res.data,"trainer");
        console.log(res.data.notification,"notify");
                this.alldata=res.data;
                let array = [];
                this.alldata.map((res,i)=>{
                    console.log(res,"pushhh");
                    console.log(i,"pushhh");
                     let obj={};
                     obj["name"]=res.first_name;
                    
                     obj["id"]=res.web_id;
                     obj["imagePath"]=this.base_url+'uploads/Profile/'+res.profile;
                    //  obj["chats"]=t;

                     array[i]=obj;
                  })
                this.contactList = array;
                console.log( this.contactList," this.contactList");

        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
 async getAccountDetails() {

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }

    this.web.postData('getAccountDetails', data).then((res) => {

      if (res.status == '200') {
        this.viewProfile = res.data;
        this.instructor_name = res.data.first_name;
        this.profile = res.data.profile;

        this.users_id=res.data.web_id
        console.log("VIEW PROFILE",this.profile);

      } else {
        this.viewProfile.profile='';
        
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }
  // chat user list click event function
  setActive(chatId: number) {
    this.activeChatUserId=chatId;
      if (this.contactList !== null) {
          for (let i = 0; i < this.contactList.length; i++) {

              if (this.contactList[i].id === chatId) {
                  this.activeChatUserId = this.contactList[i].id;
                  this.activeChatUser = this.contactList[i].name;
                  this.activeChatUserImg = this.contactList[i].imagePath;
                console.log(this.contactList[i].id,"contactlist");
                console.log(this.activeChatUser,"activeChatUser")

              }
          }
      }

      this.getmesgae(chatId);
  }

  async scrollToBottom() {
    console.log('Robert');
        try {
    
          this.myScrollContainer.nativeElement.scroll({
            top: this.myScrollContainer.nativeElement.scrollHeight,
            left: 0,
            behavior: 'smooth'
          });
    
        } catch(err) {
          console.log(err);
        }
    }

  onAddMessage() {
    
       
          // console.log(this.messageInputRef,"this.messageInputRef")
    console.log(this.CustomersForm.message,"this.message")
    this.now = new Date();

      // if (this.messageInputRef?.nativeElement.value !== '') {
      //   console.log(1);
      //     this.messages.push(this.messageInputRef?.nativeElement.value);
      // }
      // if (this.messageInputRef !== null) {
      //   console.log(11);

      //     this.messageInputRef.nativeElement.value = '';
      //     this.messageInputRef.nativeElement.focus();
      // }

      if(localStorage.getItem('type') == "Instructor"){
      let data = {
        instructor_id: localStorage.getItem('UserId'),
        message:this.CustomersForm.message,
        customer_id:this.activeChatUserId,
        sent_time:new Date().getTime() / 1000,
        fromid:1,

      }
      this.messagelist.push(data);
      setTimeout(()=>{
        this.scrollToBottom();
    }, 100);
     this.web.postData('message',data).then((res) => {
        if (res.status == '200') {
                 
        } else {



        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
      this.now = new Date();
      console.log(new Date().getTime() / 1000);
    }else{
      let data = {
        customer_id: this.users_id,
        message:this.CustomersForm.message,
        instructor_id:this.activeChatUserId,
        sent_time:new Date().getTime() / 1000,
        fromid :0,
      }
      this.messagelist.push(data);
      setTimeout(()=>{
        this.scrollToBottom();
    }, 100);
     this.web.postData('message',data).then((res) => {
        if (res.status == '200') {
                 
        } else {

        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
      this.now = new Date();
      console.log(this.now);
    }
  }
  getdate(date)
{

  return this.datePipe.transform(new Date(date*1000),'short');

}
    getmesgae(chatId:any)
    {
      console.log('hai', chatId);
      if(chatId){
        // this.fetchingStatus = true;

       this.web.getData('getusermessage?id='+chatId).then(res=>{
  
  
        if(res.status=='200'){
          //this.mappingTableData(res.data)
          this.messagelist = res.data;
          // this.ustatus = res.userstatus;
          // console.log(this.ustatus);
        //   setTimeout(()=>{
        //     // this.scrollToBottom();
        // }, 500);
          console.log('data', this.messagelist);
        }else{
  
        }
        
      },err=>{
  
      })
    }
  }
    getmessage()
    {
      if(this.activeChatUserId){

      this.web.getData('getusermessages?id='+this.activeChatUserId).then(res=>{
  
  
        if(res.status=='200'){
          //this.mappingTableData(res.data)
          this.messagelist = res.data;
          // this.ustatus = res.userstatus;
          // console.log(this.ustatus);
          setTimeout(()=>{
            // this.scrollToBottom();
        }, 500);
          console.log('data', this.messagelist);
        }else{
  
        }
      },err=>{
  
      })
    }
  } 
    // async scrollToBottom() {
    //   console.log('Robert');
    //       try {
      
    //         this.myScrollContainer.nativeElement.scroll({
    //           top: this.myScrollContainer.nativeElement.scrollHeight,
    //           left: 0,
    //           behavior: 'smooth'
    //         });
      
    //       } catch(err) {
    //         console.log(err);
    //       }
    //   }
  mobileSidebar() {
      this.showSidebar = !this.showSidebar;
  }
 
}

