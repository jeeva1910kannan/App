import { DOCUMENT } from '@angular/common';
import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
// import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import * as CryptoJS from 'crypto-js';

import { ActivatedRoute, Router } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../services/common.service';
@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.scss']
})
export class GenerateReportComponent implements OnInit {

  pop:boolean=true;
  display: string;
  menu='generate-report';
  editor = ClassicEditor;
  Eventform:any={
    'desc':"",   
  };
  selectedMenu: string;
  participantsForm: any;
  loading: boolean=false;
  @Output() notifyParent: EventEmitter<any> = new EventEmitter();
  litedesc: any;
  type: boolean | undefined;
  newdes:boolean= false;
  alldata:any;
  data_customer:any={};
  base_url: string = environment.base_url;
  notify: boolean;
  report_desc: any;
  report_to_customer: any;
  customer_email: any;
  web_id: any;
  constructor(
    private router: Router,
    private web: WebService,
    public common: CommonService,
    // public dialog: MatDialog,
    // @Inject(MAT_DIALOG_DATA) public data:GenerateReportComponent
  ) { }

  ngOnInit(): void {
    console.log("123");
    if (localStorage.getItem('type') == "Instructor"){
      this.get_customer();
      }
      if (localStorage.getItem('type') == "Customer"){
      this.get_instructor();
      }
  
    if (localStorage.getItem('type') == "Instructor") {
      this.type = true;
    }
    else {
      this.type = false;
    }

  }

  async get_customer() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('getallrequestfrom_followedcustomer',data).then((res) => {
      if (res.status == '200') {
        console.log(res.data,"getallrequestfromcustomer");
        console.log(res.data.notification,"notify");
                this.alldata=res.data;
   
        // this.request=false;
  
        // this.accepet_request(res.data.customer_id);
      } else {
    
      this.notify=true;

      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  //customer
async get_instructor() {
  let data = {
    customer_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type')
  }
  await this.web.postData('getallrequestfrom_followedinstructor',data).then((res) => {
    if (res.status == '200') {
      // console.log(res.data.notification,"notify");
      this.data_customer=res.data;
            console.log(res.data_customer,"cust");
     this.customer_email=res.data.email;
      console.log(this.data_customer,"getallrequestfrom_followedcustomer");

      // this.request=false;

      // this.accepet_request(res.data.customer_id);
    } else  {

      this.notify=true;

    }
  }, err => {
    console.log(err);
    console.log(":)")
  })
}
report(dat:any){
  console.log(this.report_desc,"des");
  let data = {
    instructor_id: localStorage.getItem('UserId'),
    customer_id: dat.customer_id,
    description:this.report_desc,
    email:this.customer_email
  }
  if (this.report_desc == null || this.report_desc == '') {
    this.common.presentToast('Please enter description')
  }
 this.web.postData('report_management',data).then((res) => {
    if (res.status == '200') {
      // console.log(res.data.notification,"notify");
      this.report_to_customer=res.data;
            console.log(this.report_to_customer,"cust");

      console.log(this.report_to_customer,"getallrequestfrom_followedcustomer");
      this.router.navigate(['/my-account/report',dat.customer_id,this.report_to_customer]);

      // this.request=false;

      // this.accepet_request(res.data.customer_id);
    } else  {

      // this.notify=true;

    }
  }, err => {
    console.log(err);
    console.log(":)")
  })



}
report_des(data:any){
  console.log(data.web_id,"web_id")
  this.newdes=data.web_id;

}
cancel(){
  this.newdes=false;

}
// encryptWithAES = (text) => {
//   const passphrase = '123';
//   this.web_id= CryptoJS.AES.encrypt(text, passphrase).toString();
// };
}
