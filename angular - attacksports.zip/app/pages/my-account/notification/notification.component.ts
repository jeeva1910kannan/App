import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../services/common.service';
import { DatePipe, formatDate } from '@angular/common';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {

  @Output() notifyParent: EventEmitter<any> = new EventEmitter();

  type: boolean | undefined;
  base_url: string = environment.base_url;
  instructor_id:any;
  request_data:any;
  notification_msg: any;
  date_req: any;
  // todaysDataTime = '';
  today= new Date();
  notification:string="Your request has been accepted by";
  deny_notification:string="Your request has been denied by";
  request:Boolean;
  alldata: any={};
  data_customer:any;
  status:number=1;
  status_deny:number=-1;
  pending_status:number=1;
  customer_id: any;
  notify: boolean=true;
  date: Date;
  todaysDataTime = new Date();
nodata:boolean=true;
customervideos:any = [];
videocomments:any = [];
reply:boolean = false;
videoId:number;
  constructor(
    private web: WebService,
    public common: CommonService,private router: Router
    ) { }

  ngOnInit(): void {
    this.alldata=[];
    this.request=true;
    console.log(this.request,"usereq")
    this.instructor_id = localStorage.getItem('UserId');
    if (localStorage.getItem('type') == "Instructor"){
    this.getrequest();
    this.customervideos = [];
    this.getcustomerComments()
    this.getnotified_customervideos();
    }
    if (localStorage.getItem('type') == "Customer"){
    this.getrequest_customer();
    this.getinstructorComments();
    this.getnotified_instructorvideos()
    }
    // this.todaysDataTime = formatDate(this.today, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530');

    if (localStorage.getItem('type') == "Instructor") {
      this.type = true;
    }
    else {
      this.type = false;
    }
  
  }
  async findstart(startdate: any) {
    this.date = new Date(startdate * 1000);
    //console.log(this.date,"date")
  }

  accepet_request(customer_id:any){
    // this.value=0;
    console.log("accepted",customer_id);
    let data={
      status:this.status,
      pending_status:this.pending_status,
      acceped_date: this.todaysDataTime ,
      customer_id:customer_id,
      instructor_id:localStorage.getItem('UserId'),
      notification:this.notification,
    };
    console.log(data);
    this.web.postData('update_accept_status',data).then((res) => {
  
      if (res.status == '200') {
        this.ngOnInit();
        console.log(res.data,"accepted");
        console.log(res);
        this.common.presentToast(res.error); 
        this.request=false; 
        // this.store_request();
      } else {
          this.common.presentToast(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }
  
  deny_request(item:any){
    console.log("deny");
    let data={
      customer_id:item.customer_id,
      instructor_id:localStorage.getItem('UserId'),
    };
    this.web.postData('deny_status',data).then((res) => {
  
      if (res.status == '200') {
  
console.log("delete successfully");
this.ngOnInit();
        // this.store_request();
      } else {
          this.common.presentToast(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });

  }



async getrequest() {
  let data = {
    instructor_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type')
  }
  await this.web.postData('getallrequestfromcustomer',data).then((res) => {
    if (res.status == '200') {
      console.log(res.data,"getallrequestfromcustomer");
      console.log(res.data.notification,"notify");
      this.notification_msg=res.data.notification;
      this.date_req=res.data.request_date;
      this.customer_id=res.data.customer_id;
      this.alldata=res.data;
console.log(this.notification_msg);
      // this.request=false;
      // this.accepet_request(res.data.customer_id);
    } else {
    }
  }, err => {
    this.notify=true;
    console.log(err);
    console.log(":)")
  })
}

//customer
async getrequest_customer() {
  let data = {
    customer_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type')
  }
  await this.web.postData('getallrequestfrominstructor',data).then((res) => {
    if (res.status == '200') {
      console.log(res.data.notification,"notify");
      this.notification_msg=res.data.notification;
      this.date_req=res.data.request_date;
      this.instructor_id=res.data.instructor_id;
      this.data_customer=res.data;
      console.log(this.data_customer,"getallrequestfrominstructor");

      // this.request=false;

      // this.accepet_request(res.data.customer_id);
    } else if(res.status == '500') {

    }
  }, err => {
    console.log(err);
    console.log(":)")
  })
}

async getnotified_customervideos(){
  let data = {
    instructor_id:localStorage.getItem('UserId')
  }
  await this.web.postData('getcustomer_postedvideos',data).then((res)=>{
     if(res.status == '200'){
       this.notify = false;
       this.customervideos = res.data;
      console.log(this.customervideos);
     }else{
      this.notify=false

     }
  }, err => {
    this.common.presentToast(err);
    console.log(":)")
  })
}



async getnotified_instructorvideos(){
  let data = {
    customer_id:localStorage.getItem('UserId')
  }
  await this.web.postData('getinstructor_postedvideos',data).then((res)=>{
     if(res.status == '200'){
       this.notify = false;
       this.customervideos = res.data;
      console.log(this.customervideos);
     }else{
      this.notify=false

     }
  }, err => {
    this.common.presentToast(err);
    console.log(":)")
  })
}


ShowVideo(customerId, id){
let data = {
  web_id:id,
  type:localStorage.getItem("type")
}
this.web.postData("changeNotification_status", data).then((res) => {
  if(res.status == '200'){
    this.router.navigate(['customer-videos',customerId]);
  }else{
    this.common.presentToast("can't redirect");
  }
}, err => {
  this.common.presentToast(err);
  console.log(":)")
})
}




ShowVideo_customer(Instructor_id, id){
  let data = {
    web_id:id,
    type:localStorage.getItem("type")
  }
  this.web.postData("changeNotification_status", data).then((res) => {
    if(res.status == '200'){
      this.router.navigate(['instructor-videos',Instructor_id]);
    }else{
      this.common.presentToast("can't redirect");
    }
  }, err => {
    this.common.presentToast(err);
    console.log(":)")
  })
  }
  
async getinstructorComments(){
  let data = {
    customer_id: localStorage.getItem("UserId")
  }
await this.web.postData("getinstructorComments", data).then((res) => {
  if(res.status == "200"){
    console.log(res);
      this.videocomments = res.data;
      console.log(this.videocomments,"videocomment")
  }else{
    this.videocomments = [];
    this.notify=false

  }
}, err => {
  this.common.presentToast(err);
  console.log(":)")
})
}


  
async getcustomerComments(){
  let data = {
    instructor_id: localStorage.getItem("UserId")
  }
await this.web.postData("getcustomerComments", data).then((res) => {
  if(res.status == "200"){
    console.log(res);
      this.videocomments = res.data;
  }else{
    this.videocomments = [];
    this.notify=false
  }
}, err => {
  this.common.presentToast(err);
  console.log(":)")
})
}
ShowComments(id){
  let data;
  for(let i = 0; i<this.videocomments.length; i++){
   data = {
    video_id:this.videocomments[i].video_id,
    instructor_id:this.videocomments[i].sender_id
  }
}
  this.web.postData("changeCommentNotification", data).then((res) => {
    if(res.status == '200'){
      this.videoId = id;
      this.reply = true;
    }else{
      console.log('error');
    }
  }, err => {
    this.common.presentToast(err);
    console.log(":)")
  });
}
ShowComments_instructor(id){
  let data;
  for(let i = 0; i<this.videocomments.length; i++){
   data = {
    video_id:this.videocomments[i].video_id,
    instructor_id:this.videocomments[i].sender_id
  }
}
  this.web.postData("changeCommentNotification", data).then((res) => {
    if(res.status == '200'){
      this.videoId = id;
      this.reply = true;
    }else{
      console.log('error');
    }
  }, err => {
    this.common.presentToast(err);
    console.log(":)")
  });
}
}
