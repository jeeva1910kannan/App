import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { DatePipe } from '@angular/common';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../services/common.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-withdrawl',
  templateUrl: './withdrawl.component.html',
  styleUrls: ['./withdrawl.component.scss']
})

export class WithdrawlComponent implements OnInit {

  alldata: any;
  TotalAmountSum:any;
  TotalAmount:number;

  displayedColumns: string[] = [
    'name',
    'email',
    'plan_name',
    'plan_amount',
    'payment_date',
  ];

  EmpData: Employee[];

  dataSource: MatTableDataSource<Employee>
  @ViewChild(MatPaginator) paginator: MatPaginator;
  TotalearnedAmount: any;
  EarnedAmount: any;

  constructor(private web: WebService,public dialog: MatDialog,public common: CommonService,) { }

  ngAfterViewInit() {

    let data = {
      instructor_id: localStorage.getItem('UserId')
    }

    this.web.postData('getcustomerPayment', data).then((res) => {
      if (res.status == '200') {
        this.EmpData = res.data;
        this.alldata = res.data;
        this.dataSource = new MatTableDataSource(this.EmpData);

        this.dataSource.paginator = this.paginator;
        console.log(this.EmpData,"this.EmpData")
        console.log(this.paginator,"this.paginator")
    

      } else {
        console.log(111);
      }
    }, err => {

      console.log(err);
    })

  }

  ngOnInit(): void {
    this.amount_earn();
    let data = {
      instructor_id: localStorage.getItem('UserId')
    }
    this.web.postData('gettotalamount', data).then((res) => {
      if (res.status == '200') {
        console.log(res.data)
        this.TotalAmountSum = res.data;
        this.TotalAmount = this.TotalAmountSum[0].total_amount
      }
      else {
        console.log(111);
      }
    }, err => {

      console.log(err);
    })


  }

  amount_earn(){
    let data = {
      instructor_id: localStorage.getItem('UserId')
    }
    this.web.postData('getearnedamount', data).then((res) => {
      //this.earnedamount = res.data;
      //console.log(this.earnedamount,"earned");
      if (res.status == '200') {
        console.log(res.data)
        this.TotalearnedAmount = res.data;
        this.EarnedAmount = this.TotalearnedAmount[0].earned_amount
      }else{

      }
    })
  }
  openModal() {
    this.openDialog();
  }

  openDialog(): void {
   let pending=this.TotalAmount-this.EarnedAmount;
  //  console.log(pending,"pending")
    if (pending > 5) {
      this.dialog.open(withdraw, {
        data: {
          user_id: localStorage.getItem('UserId'),
          type: localStorage.getItem('type'),
        },
      });

    }
    else {
      this.common.presentToast('Amount is less than limit, try after some time');
    }
  }

}

export interface Employee {
}

@Component({
  selector: 'withdraw',
  templateUrl: 'withdraw.html',
  // styleUrls: ['./withdraw.scss']
})
export class withdraw { 
  email: any;
  amount: string;
  button: boolean=false;

  constructor(public common: CommonService,private web: WebService, public dialog: MatDialog) { }

  submit(){
   if (this.email == null || this.email == '') {
      this.common.presentToast('Enter your mail id');
    }
    else if (this.common.validateEmail(this.email) == false) {
      this.common.presentToast('Enter valid email Address');
    } else if (this.amount == null || this.amount == '') {
      this.common.presentToast('Enter amount');
    }  else if (this.common.validateNumber(this.amount) == false) {
      this.common.presentToast('Enter valid amount');
    }  else {
      this.button=true;

      let data={
        email:this.email,
        amount:this.amount,
        user_id:localStorage.getItem('UserId'),
      }
      this.web.postData('withdraw_request', data).then((res) => {
        if (res.status == '200') {
          this.common.presentToast('Request sent successfully');   
          this.dialog.closeAll();
        } else {
          console.log(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error.');
      });
    }
   
  }
  }




