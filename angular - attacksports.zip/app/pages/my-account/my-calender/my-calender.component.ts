import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import {
  ChangeDetectionStrategy,
  ViewChild,
  TemplateRef,
} from '@angular/core';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours,
} from 'date-fns';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  CalendarEvent,
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView,
} from 'angular-calendar';
import { EventColor } from 'calendar-utils';
import { DialogComponent } from '../dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';



const colors: Record<string, EventColor> = {
    red: {
      primary: '#ad2121',
      secondary: '#FAE3E3',
    },
    blue: {
      primary: '#1e90ff',
      secondary: '#D1E8FF',
    },
    yellow: {
      primary: '#e3bc08',
      secondary: '#FDF1BA',
    },
};

@Component({
  selector: 'app-my-calender',
  //changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './my-calender.component.html',
  styleUrls: ['./my-calender.component.scss']
})
export class MyCalenderComponent implements OnInit {

  @ViewChild('modalContent', { static: true }) modalContent: TemplateRef<any>;

  view: CalendarView = CalendarView.Month;

  CalendarView = CalendarView;

  viewDate: Date = new Date();

  modalData: {
    action: string;
    event: CalendarEvent;
  };
  //events: CalendarEvent[] = [];
  type: boolean | undefined;

  actions: CalendarEventAction[] = [
    // {
    //   label: '<i class="fas fa-fw fa-pencil-alt"></i>',
    //   a11yLabel: 'Edit',
    //   onClick: ({ event }: { event: CalendarEvent }): void => {
    //     this.handleEvent('Edited', event);
    //   },
    // },
    {
      label: '<i class="fas fa-fw fa-trash-alt"></i>',
      a11yLabel: 'Delete',
      onClick: ({ event }: { event: CalendarEvent }): void => 
      {
        
        let dialogRef = this.dialog.open(DialogComponent, {
          data: {
            //id: web_id_booked,
            message: 'Are you sure to delete this record?',
           
          }

      

          
          
        });


       
    
       
      dialogRef.afterClosed().subscribe(result => {
        
       if (result == 'confirm') {
        
          this.deleteevent(event);
          this.events = this.events.filter((iEvent) => iEvent !== event);
          console.log(this.events,"events");

          //this.get_consultant_customer();
          
          //this.events = this.events.filter((iEvent) => iEvent !== event);
        

        }
        
       
      });

      
      
      

        //}
      },

    },
  ];

  refresh = new Subject<void>();
  CalenterEvent=[];


  
  events: CalendarEvent[]=[
  
    // {
    //   start: subDays(startOfDay(new Date()), 1),
    //   end: addDays(new Date(), 1),
    //   title:"",
    //   color: { ...colors.red },
    //   actions: this.actions,
    //   allDay: true,
    //   resizable: {
    //     beforeStart: true,
    //     afterEnd: true,
    //   },
    //   draggable: true,
    // },
    // {
    //   start: startOfDay(new Date()),
    //   title: 'An event with no end date',
    //   color: { ...colors.yellow },
    //   actions: this.actions,
    // },
    // {
    //   start: subDays(endOfMonth(new Date()), 3),
    //   end: addDays(endOfMonth(new Date()), 3),
    //   title: 'A long event that spans 2 months',
    //   color: { ...colors.blue },
    //   allDay: true,
    // },
    // {
    //   start: addHours(startOfDay(new Date()), 2),
    //   end: addHours(new Date(), 2),
    //   title: 'A draggable and resizable event',
    //   color: { ...colors.yellow },
    //   actions: this.actions,
    //   resizable: {
    //     beforeStart: true,
    //     afterEnd: true,
    //   },
    //   draggable: true,
  ];

 

  activeDayIsOpen: boolean = false;
  cus_consultant: any;
  data_consultant: any;
  alldata: any;
  data_customer: any;
  Eventform: any[];
  Eventformee: any;
  event: any;
  


  constructor(private web: WebService,
    public dialog: MatDialog,
    public common: CommonService, private router: Router, private modal: NgbModal) {
      
      this.get_customer();
      this.get_consultant_instrutor();
     }
  ngOnInit(): void {
    // throw new Error('Method not implemented.');
    console.log(subDays(startOfDay(new Date()), 1), "dateee");
    console.log(new Date(1661851846 * 1000), "newdateee");
    console.log(addDays(new Date(), 1), "dateeeafter");
    // console.log(this.eventArray,"array");
    console.log("calender")
    let date="20-1-2023";
    let a=this.events;
    
   
    
    
    if (localStorage.getItem('type') == "Instructor") {
      this.get_customer();
      this.get_consultant_instrutor();
      
      

    }
    if (localStorage.getItem('type') == "Customer") {
      console.log("calender")
      this.get_consultant_instrutor()

     this.get_instructor();
    }
    if (localStorage.getItem('type') == "Instructor") {
      this.type = true;
      console.log("instruc")
    }
    else {
      this.type = false;
    }

    
  
  
  }


 
   dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
      this.ngOnInit();
    console.log(this.events, "dayclicked");
    // details(this.dayClicked);
    // let day = this.dayClicked;
    // console.log(day,"4325634875");
    
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
   
  
}
  
}




  eventTimesChanged({
    event,
    newStart,
    newEnd,
  }: CalendarEventTimesChangedEvent): void {
    this.events = this.events.map((iEvent) => {
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd,
        };
      }
      return iEvent;
    });
    this.handleEvent('Dropped or resized', event);
  }

  handleEvent(action: string, event: CalendarEvent): void {
    this.modalData = { event, action };
    //this.modal.open(this.modalContent, { size: 'lg' });

    if ((action == "Deleted") && (localStorage.getItem('type') == "Instructor")) {
      console.log("11111111111111111");
      // let dialogRef = this.dialog.open(DialogComponent, {
      //   data: {
      //     //id: element.web_id_booked,
      //     message: 'Are you sure to delete this record?',
         
      //   }
        
        
      // });
      //this.events = this.events.filter((iEvent) => iEvent !== event);
      // dialogRef.afterClosed().subscribe(result => {
      //   this.events = this.events.filter((iEvent) => iEvent !== event);
      //   if (result == 'confirm') {
      //     this.events = this.events.filter((iEvent) => iEvent !== event);
      //     this.deleteevent(event);

      //   }
      // });
    }

    // else if ((action == "Deleted") && (localStorage.getItem('type') == "Customer")) {
    //   this.modalData = { event, action };
    //   this.deleteevent(event);
    // }

  }

  addEvent(): void {
    this.events = [
      ...this.events,
      {
        title: 'New event',
        start: startOfDay(new Date()),
        end: endOfDay(new Date()),
        color: colors.red,
        draggable: true,
        resizable: {
          beforeStart: true,
          afterEnd: true,
        },
      },
    ];
  }

  // deleteEvent(eventToDelete: CalendarEvent) {
  //   this.events = this.events.filter((event) => event !== eventToDelete);

  // }




  setView(view: CalendarView) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

  async get_instructor() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('trainer', data).then((res) => {
      if (res.status == '200') {
        // console.log(res.data.notification,"notify");
        this.data_customer = res.data;
        console.log(res.data_customer, "cust");

        console.log(this.data_customer, "get_instructor");

        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }

  // remove(element: any) {
  //   console.log("remove", element)
  //   let dialogRef = this.dialog.open(DialogComponent, {
  //     data: {
  //       id: element.web_id_booked,
  //       message: 'Are you sure to delete this record?',
  //     }
  //   });
  //   dialogRef.afterClosed().subscribe(result => {
  //     if(result == 'confirm'){
  //       this.deleteEvent(element.web_id_booked);
  //     }
  //   });
  // }



  async deleteevent(currentevent: any) {

console.log(currentevent,"cuerrentevent");
    let data = {
      instructor_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      web_id_booked: currentevent.web_id_booked,
    }

    this.web.postData('delete_booked_slot_instructor', data).then((res) => {
      if (res.status == '200') {
        this.Eventformee = res.data;
        this.common.presentToast('Deleted successfully.');
        this.get_consultant_instrutor( );
       
       

      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });


  }


  async get_customer() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('trainee', data).then((res) => {
      if (res.status == '200') {
        console.log(res.data, "getallrequestfromcustomer");
        console.log(res.data.notification, "notify");
        this.alldata = res.data;

        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }





  async get_consultant_instrutor( ) {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('getbooked_slots_instructor', data).then((res) => {
      if (res.status == '200') {
        console.log(res.data, "booked_slots_instructor");
        this.data_consultant = res.data;
        let dataa = this.data_consultant;





        // let sum=sumOFHours(this.data_consultant);
        // console.log(sum,"sum");
        //console.log(sum,"sum");
        let array = [];
        this.data_consultant.map((res, i) => {
          console.log(res, "pushhh");
          console.log(i, "pushhh");

          var time1 = res.booked_time.split(':');
          var time2 = res.duration.split(':');

          let secondSum = Number(time1[1]) + Number(time2[1]);
          let minSum = Number(time1[0]) + Number(time2[0]);

          if (secondSum > 59) {
            secondSum = Math.abs(60 - secondSum);
            minSum += 1;
          }

          if (secondSum < 10) {
            secondSum => `0${secondSum}`;
          }

          if (minSum < 10) {
            minSum => `0${minSum}`;
          }

          let sum = [`${minSum}:${secondSum}`];

           
          color: colors.yellow;
          let obj = {};
          obj["start"] = new Date(res.booked_date);
          console.log(new Date(res.booked_date), "pushhhstart")
          let a = parseInt(res.booked_time);
          console.log("aaaaaa", a);

          //  obj["end"]=addDays(new Date(), 1);
          obj["end"] = (new Date(res.booked_date));
          obj["title"] = [res.first_name + " " + res.booked_time + "-" + sum];
          obj["actions"] = this.actions;
          obj["allDay"] = true;

          obj["web_id_booked"] = res.web_id_booked;
          //obj["color"]={...colors.yellow};
          obj["instructor_id"] = res.instructor_id;
          obj["color"] = { ...colors.yellow };
          array[i] = obj;

        })
        this.events = array;
       
        console.log( this.CalenterEvent,"calendar");
        console.log(this.events, " this.eventArray");
        console.log(this.events, " this.eventArray");
       
      } else {



      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }








  async get_consultant_customer() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('getbooked_slots_customer', data).then((res) => {
      if (res.status == '200') {
        console.log(res.data, "customer");
        this.cus_consultant = res.data;
        this.data_consultant = res.data;
        let array = [];
        this.data_consultant.map((res, i) => {
          console.log(res, "pushhh");
          console.log(i, "pushhh");
          let obj = {};
          obj["start"] = new Date(res.booked_date);
          console.log(new Date(res.booked_date), "pushhhstart")

          //  obj["end"]=addDays(new Date(), 1);
          obj["end"] = (new Date(res.booked_date));
          obj["title"] = res.booked_date;
         // obj["actions"] = this.actions;
          obj["allDay"] = true;
          // obj["color"]={...colors.yellow};
          obj["web_id_booked"] = res.web_id_booked;
          obj["customer_id"] = res.customer_id;
          obj["color"] = { ...colors.yellow };
          array[i] = obj;
        })
        this.events = array;
         

      } else {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  async cancel() {
    this.Eventform = [];
    this.ngOnInit();
  }
}

function setLatest(value: any) {
  throw new Error('Function not implemented.');
}

function dayclicked(): ({ date, events }: { date: Date; events: CalendarEvent[]; }) => void {
  throw new Error('Function not implemented.');
}


