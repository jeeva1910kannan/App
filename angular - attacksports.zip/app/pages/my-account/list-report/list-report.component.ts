import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../services/common.service';
@Component({
  selector: 'app-list-report',
  templateUrl: './list-report.component.html',
  styleUrls: ['./list-report.component.scss']
})
export class ListReportComponent implements OnInit {
  alldata: any;
  base_url: string = environment.base_url;
  notify: boolean;
  report_to_customer: any;

  constructor(   private web: WebService,
    public common: CommonService,private router: Router) { }

  ngOnInit(): void {
    this.get_customer();
    console.log("1254");
  }
  async get_customer() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('listallreport',data).then((res) => {
      if (res.status == '200') {
        console.log(res.data,"listallreport");
        console.log(res.data.notification,"notify");
                this.alldata=res.data;
           this.report_to_customer=res.data.web_id;
  
      } else {
    
      this.notify=true;

      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  report(dat:any){
   console.log("test")
        this.router.navigate(['/my-account/report',dat.customer_id,dat.report_id]);
  
  }
}
