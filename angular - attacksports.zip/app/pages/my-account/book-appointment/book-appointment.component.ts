import { Component, ComponentFactoryResolver, EventEmitter, Inject, OnInit, Output, ViewChild } from '@angular/core';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ThemePalette } from '@angular/material/core';
import { CommonService } from 'src/app/providers/common.service';
import { MatCalendarCellClassFunction } from '@angular/material/datepicker';
import { FormControl } from '@angular/forms';
import { NgxMaterialTimepickerTheme } from 'ngx-material-timepicker';

@Component({
  selector: 'app-book-appointment',
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.scss']
})
export class BookAppointmentComponent implements OnInit {

  fetchingStatus:boolean = true;
  data_customer:any = [];
  notify:boolean;
  base_url:any = environment.base_url;
  constructor(public web:WebService,
    public dialog:MatDialog) { }

  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }

  ngOnInit(): void {
    this.get_instructor();
  }
  async get_instructor() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('getallinstructor_sametimezone', data).then((res) => {
      if (res.status == '200') {
        this.fetchingStatus=false
        // console.log(res.data.notification,"notify");
        this.data_customer = res.data;
        console.log(this.data_customer);
        // this.request=false;
        // this.accepet_request(res.data.customer_id);
      } else {

        this.notify = true;

      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }

  openModal(bookData){
    this.dialog.open(bookSlot, {
      data:{
        book:bookData
      }
    })
  }

}

@Component({
  selector: 'book-slot',
  templateUrl: './book-slot.component.html',
  styleUrls: ['./book-slot.scss']
})

export class bookSlot implements OnInit {


  alldata:any = [];
  title:any;
  first_name:string;
  last_name:string;
  fetchingStatus:boolean;
  restrict_days:any = [];
  restricted_days:any;
  from_time:any;
  to_time:any;
  slotForm:any = [];
  minDate = new Date();
  booked_data:any;
  booked_status:any;
  serializedDate:any;
  slot_id:number;
  time:any;
  date_Free:boolean;

  datefilter = date=>{
    const day = date.getDay();
    return day == this.restrict_days[0] || day == this.restrict_days[1] || day == this.restrict_days[2] || day == this.restrict_days[3] 
    || day == this.restrict_days[4] || day == this.restrict_days[5] || day == this.restrict_days[6];
   
  }

  @ViewChild('picker') picker: any;
  @Output() opened:EventEmitter<null>;
  @Output() timeChanged:EventEmitter<string>;

  constructor( @Inject(MAT_DIALOG_DATA) public data:bookSlot,
  public web:WebService, public common:CommonService, public dialog:MatDialog ){}

  darkTheme: NgxMaterialTimepickerTheme = {
    container: {
        bodyBackgroundColor: '#fff',
        buttonColor: '#fff'
    },
    dial: {
        dialBackgroundColor: '#ed1c24',
    },
    clockFace: {
        clockFaceBackgroundColor: '#b5191f',
        clockHandColor: '#9fbd90',
        clockFaceTimeInactiveColor: '#fff'
    }
};

ngOnInit(): void {
  this.alldata = this.data;
  console.log(this.alldata);
  let data_res = {
    instructor_id:this.alldata.book.instructor_id
 }

 this.web.postData("get_restrict_available_days",data_res).then((res) =>{
   if(res.status == '200'){
     this.restricted_days = res.data;
      this.restrict_days = JSON.parse(this.restricted_days[0].available_days);
      console.log(this.restrict_days.length);
      let curtime = new Date();
      let hours = curtime.getHours() < 10 ? "0" + curtime.getHours() : curtime.getHours();
      let minutes = curtime.getMinutes() < 10 ? "0" + curtime.getMinutes() :curtime.getMinutes();
      let currentTime = hours + ":" + minutes;
     this.from_time = res.data[0].available_from_time;
      console.log(currentTime.slice(0,2));
      console.log(this.from_time.slice(0,2));

      if(this.from_time > currentTime){
        this.from_time = res.data[0].available_from_time;
      }else{
        this.from_time = currentTime;
      }
     this.to_time = res.data[0].available_to_time;
     

   }
 })
  this.first_name = this.alldata.book.first_name;
  this.last_name = this.alldata.book.last_name; 
  this.getCustomerBooking();
/*   this.getalreadyBookedInstructor(); */
}

 convertDate(inputFormat) {
  function pad(s) { return (s < 10) ? '0' + s : s; }
  var d = new Date(inputFormat)
  return [ pad(d.getMonth()+1),pad(d.getDate()), d.getFullYear()].join('/')
}

book_slot(){
  if(this.slotForm.date == '' || this.slotForm.date == undefined){
    this.common.presentToast("Pick a date");
  }else if(this.slotForm.time == '' || this.slotForm.time == undefined){
    this.common.presentToast("Pick a time slot");
  }else{

  let data_book = {
    instructor_id:this.alldata.book.instructor_id,
    customer_id:localStorage.getItem("UserId"),
    date: this.convertDate(this.slotForm.date),
    time: this.slotForm.time,
    duration: this.alldata.book.duration,
    first_name:this.alldata.book.first_name,
    last_name:this.alldata.book.last_name
  }
  this.web.postData("post_CustomerBooking",data_book).then((res) => {
    if(res.status == '200'){
      this.common.presentToast(res.error);
      this.dialog.closeAll();
    }else{
      this.common.presentToast(res.error);
    }
  },err=>{
    console.log(err);
  })
}
}

async getCustomerBooking(){
  let data_get = {
    instructor_id:this.alldata.book.instructor_id,
    customer_id:localStorage.getItem('UserId'),
  }
  this.web.postData("get_CustomerBooking", data_get).then((res) => {
    if(res.status == '200'){
      this.booked_data = res.data;
      this.booked_status = this.booked_data[0].booked_status;
      this.slotForm.time = this.booked_data[0].booked_time;
      this.slotForm.date = new Date(this.booked_data[0].booked_date).toISOString(); 
      this.slot_id = this.booked_data[0].web_id_booked;
  
    }else{
      this.common.presentToast(res.error);
    }
  }, err =>{
    console.log(err);
  })
}
update_slot(){
  let data_update = {
    instructor_id:this.booked_data[0].instructor_id,
    customer_id:this.booked_data[0].customer_id,
    date:this.convertDate(this.slotForm.date),
    time:this.slotForm.time,
    web_id: this.slot_id,
    first_name:this.alldata.book.first_name,
    last_name:this.alldata.book.last_name
  }
  this.web.postData("update_CustomerBooking", data_update).then((res) =>{
    if(res.status == '200'){
      this.common.presentToast(res.error);
      this.dialog.closeAll();
    }else{
      this.common.presentToast(res.error);
    }
  },(err) =>{
    console.log(err);
  })
}



Selected_time(Selected_time){

  let data = {
    instructor_id:this.alldata.book.instructor_id,
    selected_time:Selected_time,
    selected_date:this.convertDate(this.slotForm.date),
    customer_id:localStorage.getItem('UserId'),
  }
console.log(data, "data");
  this.web.postData("getalreadybooked_Instructor", data).then((res) =>{
    if(res.status == '200'){
      this.date_Free = true;

     this.common.presentToast(res.error);
     
    }else{
      this.date_Free = false;
     console.log("Free slot");
    }
  },(err)=>{
    console.log(err);
  })
}

}