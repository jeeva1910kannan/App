import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { OwlDateTimeComponent } from 'ng-pick-datetime';
@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss'],
})
export class EventsComponent implements OnInit {
  //@ViewChild('myForm') myForm!: NgForm;
  @ViewChild('dt13') dateTimePicker: OwlDateTimeComponent<any>;
  editor = ClassicEditor;
  Eventform:any={
    'desc':"",   
  };
  minDate = new Date();
  name = "ng2-ckeditor";
  ckeConfig: any;
  mycontent: string;
  log: string = "";
  base_url: string = environment.base_url;
  type: boolean | undefined;
  fetchingStatus: boolean = true;
  loading: boolean = false;
  edit: boolean = false;
  expire: boolean = false;
  upcomming: boolean = false;
  imageUploading: boolean;
  editEvent: boolean = false;
  newEvent: boolean = false;
  ententionName: string | undefined;
  uploadedFileList: any = [];
  code: any;
  profile: any;
  urls = [];
  event: any;
  live: boolean = false;
  duration: string;

  mfu_box: any;
  countryCodes: any;
  events: any;
  Eventforme: any;
  litedesc: any;
  durationRange: string;
  isButtonDisabled = false;
  constructor(  private web: WebService,
    public common: CommonService,private router:Router, private datePipe: DatePipe) { 
    
    this.mycontent = `<p>My html content</p>`;
  }
  
 
  ngOnInit(): void {
    this.getallevents();
    this.newEvent=false;
    this.editEvent=false;

      }
  

    selectedevent(data:any){
    this.router.navigate(['/eventcontent',data.event_id]);
  }
  registered_user(data:any){
    this.router.navigate(['/register_user',data.event_id]);

  }
  selectedevents(data:any){
    this.router.navigate(['/eventvideo',data.event_id]);
  }
  async getallevents() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('getinstructorevents',data).then((res) => {
      if (res.status == '200') {
        this.events = res.data;
        const timestamp=Math.round(new Date().getTime()/1000);
        this.events.forEach(function(part, index){ 
         if (timestamp >= part.start_time && timestamp <= part.end_time) {
           part.live = true;
           part.edit=false;
         }
         else {
           if (timestamp <= part.end_time) {
             part.upcomming=true;
           } else {
             part.expire=true;
             part.upcomming=false;
           }
           part.live = false;
         }
       });
      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  
  async Newevent(){
    this.newEvent=true;
    this.editEvent=false
  }
  async findstart(startdate: any) {
    this.events.newstart = new Date(startdate * 1000);
    // const currentdate = new Date();
    // console.log( this.events.newstart,"start_date");
    // console.log(currentdate,"today");
    // console.log(this.events.newend,"end");
    // if(currentdate>=this.events.newstart && currentdate<=this.events.newend){
    // this.live=true;
    // this.edit=true;
    // this.expire=false;
    // this.upcomming=false;
    // }
    // else{
    //   if(currentdate>this.events.newend){
    //    this.expire=true;
    //   }else{
    //     this.expire=false;

    //   this.upcomming=true;
    //   }
    //   this.live=false;
    // }
  }
  async findend(enddate: any) {
    
    this.events.newend = new Date(enddate * 1000);

  }
  async finddesc(desc: any) {
    this.litedesc= desc.substring(0, 170) + '....';   

  }

  
    onFileChange(event: any) {
      if (event.target.files.length > 0) {
        const files = event.target.files;
        this.onSubmit(files);
      }
    }
  
    onSubmit(file: any) {
      let d = new Date();
      let n: any = d.valueOf();
      let fname = file[0].name;
      fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
      let filename = 'Attack_' + n.toString().substring(4, 8) + file[0].name;
      const formData = new FormData();
      formData.append("image", file[0]);
      formData.append("image", filename);
      formData.append("profile", filename);
      this.loading = true;
      this.web.uploadWebsitePicture(`${this.base_url}restapi/upload_website_event_picture.php?filename=` + filename, formData).subscribe((Res: any) => {
        this.loading = false;
        this.ententionName = filename.split('.').pop();
        console.log('filename', this.name)
        if (this.ententionName == 'png' || this.ententionName == 'jpg' || this.ententionName == 'jpeg') {
          if (Res.status == '200') {
            this.common.presentToast(Res.error);
            this.profile = filename;
  
            console.log('the img is---<>', filename);
          } else {
            this.profile = '';
            this.common.presentToast(Res.error);
          }
        } else {
          this.common.presentToast('Please upload valid images');
        }
      }, (err) => {
        this.common.presentToast('Connection Error');
        this.loading = false;
      });
    }

    // onDurationRangeChange() {
    //   const [start, end] = this.durationRange.split(' to ');
    //   this.Eventforme.duration = `${start} - ${end}`;
    // }
    
async Editevent(currentevent:any){
  this.editEvent=true;
  this.newEvent=false;
  let data = {
    user_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type'),
    event_id:currentevent.event_id
  }
  this.web.postData('getediteventDetails',data).then((res) => {
    if (res.status == '200') {
      this.Eventforme = res.data;  
      


    
   this.profile=this.Eventforme.event_profile;

    } else {
      console.log(res.error);
    }
  }, err => {
    console.log(err);
  this.common.presentToast('Connection Error.');
  });



}
    //Validation
    async newevent(){   
      this.Eventform.profile = this.profile;
 this.Eventform.instructor_id = localStorage.getItem('UserId');
      if (this.Eventform.event_name == null || this.Eventform.event_name== '') {
        this.common.presentToast('Enter event name')
      // } else if (this.Eventform.title == null || this.Eventform.title == '') {
      //   this.common.presentToast('Enter title');
       }
      else if (this.Eventform.duration[0] == null || this.Eventform.duration[0] == '') {
        this.common.presentToast('Enter start time');
      }
      else if (this.Eventform.duration[1] == null || this.Eventform.duration[1] == '') {
        this.common.presentToast('Enter end time');
      }
      else if (this.Eventform.price == null || this.Eventform.price == ''|| isNaN(this.Eventform.price) || Number(this.Eventform.price) === 0) {
        this.common.presentToast('Enter valid price');
      }
      else if (this.Eventform.desc == null || this.Eventform.desc == '') {
        this.common.presentToast('Enter description');
      }
      else if (this.Eventform.profile == null || this.Eventform.profile == '') {
        this.common.presentToast('Enter event picture');
      }
      else {
        this.isButtonDisabled = true;
        this.web.postData('newevent', this.Eventform).then((res) => {
  
          if (res.status == '200') {
    	
            this.common.presentToast('Event created Successfully');  
            this.ngOnInit(); 
            this.Eventform=[];
            this.profile=null;
            this.isButtonDisabled = false;
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
      }
    }
async cancel(){
  this.Eventform=[];
  this.profile=null;
  this.ngOnInit(); 
}
    //editnewevent
    async editnewevent(){   
      this.Eventforme.profile = this.profile;
 this.Eventforme.instructor_id = localStorage.getItem('UserId');
      if (this.Eventforme.event_name == null || this.Eventforme.event_name== '') {
        this.common.presentToast('Enter event name')
      // } else if (this.Eventforme.title == null || this.Eventforme.title == '') {
      //   this.common.presentToast('Enter title');
      }
      else if (this.Eventforme.duration1[0] == null || this.Eventforme.duration1[0] == '') {
        this.common.presentToast('Enter start time');
      }
      else if (this.Eventforme.duration1[1] == null || this.Eventforme.duration1[1] == '') {
        this.common.presentToast('Enter end time');
      }
      else if (this.Eventforme.price == null || this.Eventforme.price == '' || isNaN(this.Eventforme.price) || Number(this.Eventforme.price) === 0) {
        this.common.presentToast('Enter valid price');
      }
      else if (this.Eventforme.desc == null || this.Eventforme.desc == '') {
        this.common.presentToast('Enter description');
      }
      else if (this.Eventforme.profile == null || this.Eventforme.profile == '') {
        this.common.presentToast('Enter event picture');
      }
      else {
      
        this.web.postData('editnewevent', this.Eventforme).then((res) => {
  
          if (res.status == '200') {

            this.common.presentToast('Event edited Successfully'); 
            this.ngOnInit(); 
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
      }
    }
}
