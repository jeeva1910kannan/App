import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CustomerReportComponent } from "./customer-report/customer-report.component";
import { InstructorvideoComponent } from "./instructorvideo/instructorvideo.component";

import { MyAccountComponent } from './my-account.component';
import { ReportComponent } from "./report/report.component";

const routes: Routes = [
  {
    path: "",
    component: MyAccountComponent
  },
  {
    path: "myvideos",
    component: InstructorvideoComponent
  },
  {
    path: 'report/:id/:web_id',
    component: ReportComponent,
  },
  // {
  //   path: 'report',
  //   component: CustomerReportComponent
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class MyAccountRoutingModule { }
