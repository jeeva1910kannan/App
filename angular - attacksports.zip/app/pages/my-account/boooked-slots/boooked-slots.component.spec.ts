import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoookedSlotsComponent } from './boooked-slots.component';

describe('BoookedSlotsComponent', () => {
  let component: BoookedSlotsComponent;
  let fixture: ComponentFixture<BoookedSlotsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BoookedSlotsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BoookedSlotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
