import { Component, OnInit, ViewChild} from '@angular/core';
import { WebService } from 'src/app/providers/web.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonService } from '../../services/common.service';
import { MatSort } from '@angular/material/sort';
import { DialogComponent } from '../dialog/dialog.component';

export interface PeriodicElement {
  first_name: string;
  booked_time: string;
  action: string;
  // merchant_name: string;
  // download: string;
}

@Component({
  selector: 'app-boooked-slots',
  templateUrl: './boooked-slots.component.html',
  styleUrls: ['./boooked-slots.component.scss']
})
export class BoookedSlotsComponent implements OnInit {
  listDetails: any;
  displayedColumns: string[] = ['first_name', 'booked_time', 'action'];
  EmpData: PeriodicElement[];
  ELEMENT_DATA:any = [];
  dataSource = new MatTableDataSource<PeriodicElement>(this.ELEMENT_DATA);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor( public web: WebService,
    public dialog: MatDialog,
    public common: CommonService) { }

  ngOnInit(): void {
     this.getbooked_slots();
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.getbooked_slots();
  }

  getbooked_slots(){
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    this.web.postData('getbooked_slots', data).then((res) => {
      if (res.status == '200') {
        this.listDetails = res.data;
        console.log(this.listDetails,"listdetails")
        this.EmpData = res.data;
        this.dataSource = new MatTableDataSource(this.EmpData);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      } else {
        this.EmpData = res.data;
        this.dataSource = new MatTableDataSource(this.EmpData);
        this.listDetails = res.data;
      }
    }, err => {
      console.log(err);
    });
  }


  remove(element: any) {
    console.log("remove", element)
    let dialogRef = this.dialog.open(DialogComponent, {
      data: {
        id: element.web_id_booked,
        message: 'Are you sure to delete this record?',
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if(result == 'confirm'){
        this.onConfirmClick(element.web_id_booked);
      }
    });
  }

  onConfirmClick(id:any): void {
    let data = {
      web_id: id,
    }
    this.web.postData('delete_slots', data).then((res) => {
      if (res.status == '200') {
        this.getbooked_slots();
        this.ngAfterViewInit();
        this.common.presentToast('Deleted successfully.');
      } else {
        this.getbooked_slots();
        console.log(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
  }

}
