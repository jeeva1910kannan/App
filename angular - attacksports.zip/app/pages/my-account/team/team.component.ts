import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import {FormControl} from '@angular/forms';

import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { Router } from '@angular/router';
@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.scss']
})
export class TeamComponent implements OnInit {
  toppings = new FormControl('');
  // toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  editor = ClassicEditor;
  Eventform:any={
    // 'desc':"",   
  };
  minDate = new Date();
  name = "ng2-ckeditor";
  ckeConfig: any;
  mycontent: string;
  log: string = "";
  base_url: string = environment.base_url;
  type: boolean | undefined;
  fetchingStatus: boolean = true;
  loading: boolean = false;
  edit: boolean = false;
  expire: boolean = false;
  upcomming: boolean = false;
  imageUploading: boolean;
  editEvent: boolean = false;
  newEvent: boolean = false;
  ententionName: string | undefined;
  uploadedFileList: any = [];
  code: any;
  profile: any;
  urls = [];
  event: any;
  live: boolean = false;

  mfu_box: any;
  countryCodes: any;
  events: any;
  Eventforme: any;
  // litedesc: any;
  alldata: any;
  teammembers: any;
  Eventform_mem: any;
  constructor(  private web: WebService,
    public common: CommonService,private router:Router) { 
    
    this.mycontent = `<p>My html content</p>`;
  }
  
 
  ngOnInit(): void {
    this.getallevents();
    this.newEvent=false;
    this.editEvent=false;
    this.get_customer();
      }
  

    selectedevent(data:any){
    this.router.navigate(['/eventcontent',data.event_id]);
  }
  selectedevents(data:any){
    console.log(123);
    this.router.navigate(['/team',data.web_id]);
  }
  async getallevents() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('getinstructorteam',data).then((res) => {
      if (res.status == '200') {
        this.events = res.data;
     this.teammembers=res.data[0].team_players_details;

        console.log(this.teammembers,"teammembers")

      } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  
  async Newevent(){
    this.newEvent=true;
    this.editEvent=false
  }
  // async findstart(startdate: any) {
  //   this.events.newstart = new Date(startdate * 1000);
  //   const currentdate = new Date();
  //   // console.log( this.events.newstart,"start_date");
  //   // console.log(currentdate,"today");
  //   // console.log(this.events.newend,"end");
  //   if(currentdate>=this.events.newstart && currentdate<=this.events.newend){
  //   this.live=true;
  //   this.edit=true;
  //   this.expire=false;
  //   this.upcomming=false;
  //   }
  //   else{
  //     if(currentdate>this.events.newend){
  //      this.expire=true;
  //     }else{
  //       this.expire=false;

  //     this.upcomming=true;
  //     }
  //     this.live=false;
  //   }
  // }
  // async findend(enddate: any) {
  //   this.events.newend = new Date(enddate * 1000);

  // }
  // async finddesc(desc: any) {
  //   this.litedesc= desc.substring(0, 170) + '....';   

  // }

  
    // onFileChange(event: any) {
    //   if (event.target.files.length > 0) {
    //     const files = event.target.files;
    //     this.onSubmit(files);
    //   }
    // }
  
    // onSubmit(file: any) {
    //   let d = new Date();
    //   let n: any = d.valueOf();
    //   let fname = file[0].name;
    //   fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
    //   let filename = 'Attack_' + n.toString().substring(4, 8) + file[0].name;
    //   const formData = new FormData();
    //   formData.append("image", file[0]);
    //   formData.append("image", filename);
    //   formData.append("profile", filename);
    //   this.loading = true;
    //   this.web.uploadWebsitePicture(`${this.base_url}restapi/upload_website_event_picture.php?filename=` + filename, formData).subscribe((Res: any) => {
    //     this.loading = false;
    //     this.ententionName = filename.split('.').pop();
    //     console.log('filename', this.name)
    //     if (this.ententionName == 'png' || this.ententionName == 'jpg' || this.ententionName == 'jpeg') {
    //       if (Res.status == '200') {
    //         this.common.presentToast(Res.error);
    //         this.profile = filename;
  
    //         console.log('the img is---<>', filename);
    //       } else {
    //         this.profile = '';
    //         this.common.presentToast(Res.error);
    //       }
    //     } else {
    //       this.common.presentToast('Please upload valid images');
    //     }
    //   }, (err) => {
    //     this.common.presentToast('Connection Error');
    //     this.loading = false;
    //   });
    // }
    
async Editevent(currentevent:any){
  console.log(currentevent.web_id,"web_id")
  this.editEvent=true;
  this.newEvent=false;
  let data = {
    user_id: localStorage.getItem('UserId'),
    type: localStorage.getItem('type'),
    web_id:currentevent.web_id
  }
  this.web.postData('geteditteamDetails',data).then((res) => {
    if (res.status == '200') {
      this.Eventforme = res.data;  
      this.Eventform_mem = res.team;  
      // console.log( this.Eventform_mem ,"mem")
  //  this.profile=this.Eventforme.event_profile;

    } else {
      console.log(res.error);
    }
  }, err => {
    console.log(err);
  this.common.presentToast('Connection Error.');
  });



}
    //Validation
    async newevent(){   
      console.log(this.Eventform.title.length,"title")
     this.Eventform.instructor_id = localStorage.getItem('UserId');
      if (this.Eventform.event_name == null || this.Eventform.event_name== '') {
        this.common.presentToast('Enter Team name')
      } else if (this.Eventform.title == null || this.Eventform.title == '') {
        this.common.presentToast('Choose team Players');
      }else if (this.Eventform.title.length <=1) {
        this.common.presentToast('Choose more than one team Players');
      }
      else {
      
        this.web.postData('newteam', this.Eventform).then((res) => {
  
          if (res.status == '200') {
    	
            this.common.presentToast('Team created Successfully');  
            this.ngOnInit(); 
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
      }
    }
async cancel(){
  this.Eventform=[];
  this.profile=null;
  this.ngOnInit(); 
}
    //editnewevent
    async editnewevent(){   
      console.log(this.Eventforme,"WEB_UID");
      let data={
        web_id:this.Eventforme.web_id,
        team_name:this.Eventforme.team_name ,
        team_member:this.Eventform_mem
      }
      // this.Eventforme.profile = this.profile;
 this.Eventforme.instructor_id = localStorage.getItem('UserId');
      if (this.Eventforme.team_name == null || this.Eventforme.team_name== '') {
        this.common.presentToast('Enter team name')
      } else if (this.Eventform_mem == null || this.Eventform_mem == '') {
        this.common.presentToast('Choose team member');
      }
    
      else {
      
        this.web.postData('editnewteam', data).then((res) => {
  
          if (res.status == '200') {

            this.common.presentToast('Event edited Successfully'); 
            this.ngOnInit(); 
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
      }
    }
    async get_customer() {
      let data = {
        instructor_id: localStorage.getItem('UserId'),
      }
      await this.web.postData('trainee',data).then((res) => {
        if (res.status == '200') {
          console.log(res.data,"getallrequestfromcustomer");
          console.log(res.data.notification,"notify");
                  this.alldata=res.data;

          // this.request=false;

          // this.accepet_request(res.data.customer_id);
        } else {


        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
    }
}
