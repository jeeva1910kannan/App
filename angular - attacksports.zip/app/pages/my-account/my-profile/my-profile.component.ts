import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Lightbox } from 'ngx-lightbox';
import { PdfPreviewComponent } from '../../common/components/pdf-preview/pdf-preview.component';
import { MatDialog } from '@angular/material/dialog';
import { countries } from 'src/app/pages/common/commonjson/country-data-store';
import { languages } from 'src/app/pages/common/commonjson/language';
import { currencies } from 'src/app/pages/common/commonjson/currencies';
import { timezone } from 'src/app/pages/common/commonjson/timezone';

import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { LoaderService } from 'src/app/providers/loader.service';

import { ActivatedRoute, Router } from '@angular/router';

import {
  ICreateOrderRequest,
  IPayPalConfig,
  NgxPaypalComponent,
  PayPalScriptService,
} from 'ngx-paypal';
import { RegisterCongratsComponent } from './register-congrats/register-congrats.component';
import { CommonService } from 'src/app/providers/common.service';
import { ThemePalette } from '@angular/material/core';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  public payPalConfig?: IPayPalConfig;
  paymentMethod:any;
  registerResponse: any = {};
  continuepayment: boolean = false;
  public countries: any = countries;
  public languages: any = languages;
  public currencies: any = currencies;
  public timezone: any = timezone;
  base_url: string = environment.base_url;
  continueregister: boolean = false;
  type: boolean | undefined;
  fetchingStatus: boolean = true;
  loading: boolean = false;
  editprofile: boolean = false;

  imageUploading: boolean;
  viewaccount: boolean = false;
  name: string | undefined;
  ententionName: string | undefined;
  uploadedFileList: any = [];
  code: any;
  profile: any;
  urls = [];
  event: any;
  mfu_box: any;
  countryCodes: any;
  viewDetails: any = {};
  CustomersForm: any = {
    profile: null,
    email:localStorage.getItem('email'),
    phone:localStorage.getItem('phone'),
  };
  InstructorForm: any = {
    profile: null,

  };
  countryCode: any;
  gaService: any;
  availablePlans: any ={};
  selectedPlanAmount: any;
  selectedPlanName: any;
  selectedPlanId: any;
  selectedPlanTemp:any;
  payPalSubscribeConfig:IPayPalConfig;
  userDetailsTemp: any;
  availableDays:any = [{'day':'Sunday','id':0},
  {'day':'Monday','id':1},
  {'day':'Tuesday','id':2},
  {'day':'Wednesday','id':3},
  {'day':'Thursday','id':4},
  {'day':'Friday','id':5},
  {'day':'Saturday','id':6}];
  days:any;

  given_duration:any =[{'hours':'1 hour','value':'01:00'},
{'hours':'1.5 hours','value':'01:05'},
{'hours':'2 hours','value':'02:00'},
{'hours':'2.5 hours','value':'02.05'},
{'hours':'3 hours','value':'03:00'}];

  constructor(
    private web: WebService,
    public common: CommonService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private loaderService: LoaderService,
    private _lightbox: Lightbox,
    public dialog: MatDialog,
    private payPalScriptService: PayPalScriptService,
  ) {
  }

  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit() {

    if (localStorage.getItem('type') == "Instructor") {
      this.type = true;
    }
    else {
      this.type = false;
    }
    this.getsubplan();
  }
  async getsubplan(){
    
      this.web.getData('subscribePlanDetails').then((res) => {
          if (res.status == '200') {
            this.availablePlans = res.data;
            console.log("SK - subscribePlanDetails", this.availablePlans);
            this.getAccountDetails();
          } else {
            console.log(res.error);
          }
        }, err => {
          console.log(err);
        this.common.presentToast('Connection Error.');
        });

    //     this.web.getData('subscribePlanDetails').then(
    //   (res: any) => {
    //     if (res.status == '200') {
    //       this.availablePlans = res.data;
        
    //     } else {
    //       console.log(res.error);
    //     }
    //   },
    //   (err) => {
    //     console.log(err);
    //     this.common.presentToast('Connection Error.');
    //   }
    // );
  }
  getConfig(plan_id:string): IPayPalConfig {
    console.log(plan_id,"plannnn")
    var that = this;
    return {
      clientId: environment.paypal_key,
      currency: "USD",
      vault: "true",
      style: {
        label: "paypal",
        layout: "vertical",
        // size: "small",
        // shape: "pill",
        // color: "silver",
        // tagline: false,
      },
      createSubscription: function (data) {
        console.log(plan_id,"plannnn")

        return data.subscription.create({
          'plan_id':plan_id,
        });
      },
      onApprove: function (data, actions) {
        console.log(data,"plannnn")

        actions.order.get().then((details:any) => {
          console.log("subscription details:", details);
          that.createTokenPaypal(details)
        });
      },
      onCancel: (data, actions) => {
        this.common.presentToast('Payment cancelled.');
      },
      onError: (err) => {
        this.common.presentToast('Service not available.');
        console.log("OnError", err);
      },
      onClick: (data, actions) => {
        console.log("Clicked:", data, actions);
      },
    };
  }
  createTokenPaypal(details:any): void {
    this.userDetailsTemp = JSON.parse(
      localStorage.getItem('UserDetails')
    );
    console.log("this.userDetailsTemp",this.userDetailsTemp);
    console.log('Paypal id', details.id);
    let data = {
      user: localStorage.getItem('UserId'),
      payment_method_id: details.id,
      plan_id: this.selectedPlanId,
      email: this.CustomersForm.email,
      payment_response: details,
      payment_method: 'paypal'
    };
    this.loading = true;
    this.web.postData('makePayment1', data).then(
      (res) => {
        this.loading = false;
        if (res.status == '200') {
          this.common.presentToast(res.error);
          // this.pageAction = 'view';
          // this.dialog.closeAll();
          // setTimeout(() => {
            // this.dialog.open(RegisterCongratsComponent);
          // }, 400);
        } else {
          this.common.presentToast(res.error);
        }
      },
      (err) => {
        this.loading = false;
        console.log(err);
        this.common.presentToast('Connection Error');
      }
    );
  }


  continueRegister() {
    this.continueregister = true;
  }
  onFileChange(event: any) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      this.onSubmit(files);
    }
  }

  onSubmit(file: any) {
    let d = new Date();
    let n: any = d.valueOf();
    let fname = file[0].name;
    fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
    let filename = 'Attack_' + n.toString().substring(4, 8) + file[0].name;
    const formData = new FormData();
    formData.append("image", file[0]);
    formData.append("image", filename);
    formData.append("profile", filename);
    this.loading = true;
    this.web.uploadWebsitePicture(`${this.base_url}restapi/upload_website_profile_picture.php?filename=` + filename, formData).subscribe((Res: any) => {
      this.loading = false;
      this.ententionName = filename.split('.').pop();
      console.log('filename', this.name)
      if (this.ententionName == 'png' || this.ententionName == 'jpg' || this.ententionName == 'jpeg') {
        if (Res.status == '200') {
          this.common.presentToast(Res.error);
          this.profile = filename;

          console.log('the img is---<>', filename);
        } else {
          this.profile = '';
          this.common.presentToast(Res.error);
        }
      } else {
        this.common.presentToast('Please upload valid images');
      }
    }, (err) => {
      this.common.presentToast('Connection Error');
      this.loading = false;
    });
  }
  async customerRegistration() {
    this.CustomersForm.profile = this.profile;
    console.log(this.CustomersForm.profile);
    if (this.CustomersForm.profile == null || this.CustomersForm.profile == '') {
      this.common.presentToast('Please choose your profile')
    } else if (this.CustomersForm.first_name == null || this.CustomersForm.first_name == '') {
      this.common.presentToast('Enter your name');
    }
    else if (this.CustomersForm.last_name == null || this.CustomersForm.last_name == '') {
      this.common.presentToast('Enter your last name')
    }
    else if (this.CustomersForm.business_name == null || this.CustomersForm.business_name == '') {
      this.common.presentToast('Enter your Business name')
    }
    else if (this.CustomersForm.country == null || this.CustomersForm.country == '') {
      this.common.presentToast('Select country')
    }
    else if (this.CustomersForm.currencies == null || this.CustomersForm.currencies == '') {
      this.common.presentToast('Select currencies')
    }
    else if (this.CustomersForm.timezone == null || this.CustomersForm.timezone == '') {
      this.common.presentToast('Select timezone')
    }

    else if (this.CustomersForm.address == null || this.CustomersForm.address == '') {
      this.common.presentToast('Enter your address')
    }
    else if (this.CustomersForm.language == null || this.CustomersForm.language == '') {
      this.common.presentToast('Enter your language')
    }

    else {
      this.CustomersForm.customerid = localStorage.getItem('UserId');
      this.CustomersForm.profile = this.profile;
      console.log(this.profile);
      this.web.postData('customerAdditionalInfo', this.CustomersForm).then((res) => {

        if (res.status == '200') {
          this.web.getData('subscribePlanDetails').then(
              (res: any) => {
                if (res.status == '200') {

                  this.availablePlans = res.data;
                  console.log("SK - subscribePlanDetails", this.availablePlans);
                } else {
                  console.log(res.error);
                }
              },
              (err) => {
                console.log(err);
                this.common.presentToast('Connection Error.');
              }
            );
          this.common.presentToast('Registered Successfully');
          console.log("Saravana - ",this.availablePlans);
          this.selectedPlanName = this.availablePlans[0].plan_name;
          this.selectedPlanAmount = this.availablePlans[0].plan_amount;
          this.selectedPlanId = this.availablePlans[0].web_id;
          this.selectedPlanTemp = this.availablePlans[0].plan_validity;
          this.payPalSubscribeConfig = this.getConfig(this.availablePlans[0].plan_paypal_id);
          this.continueregister = false;
          this.continuepayment = true;
        } else {
          // this.alert.errorMsg(res.error, '');
        }
      }, err => {
        console.log(err);
        // this.alert.errorMsg('Connection Error', '');
      });
    }
  }


  async instructorRegistration() {
    this.InstructorForm.profile = this.profile;

    console.log(this.InstructorForm.profile);
    if (this.InstructorForm.profile == null || this.InstructorForm.profile == '') {
      this.common.presentToast('Please choose your profile')
    }
    else if (this.InstructorForm.first_name == null || this.InstructorForm.first_name == '') {
      this.common.presentToast('Enter your name');
    }
    else if (this.InstructorForm.last_name == null || this.InstructorForm.last_name == '') {
      this.common.presentToast('Enter your last name')
    }
    else if (this.InstructorForm.business_name == null || this.InstructorForm.business_name == '') {
      this.common.presentToast('Enter your Business name')
    }
    else if (this.InstructorForm.country == null || this.InstructorForm.country == '') {
      this.common.presentToast('Select country')
    }
    else if (this.InstructorForm.currencies == null || this.InstructorForm.currencies == '') {
      this.common.presentToast('Select currencies')
    }
    else if (this.InstructorForm.timezone == null || this.InstructorForm.timezone == '') {
      this.common.presentToast('Select timezone')
    }
    else if (this.InstructorForm.language == null || this.InstructorForm.language == '') {
      this.common.presentToast('Select language')
    }
    else if (this.InstructorForm.customerlanguage == null || this.InstructorForm.customerlanguage == '') {
      this.common.presentToast('Select your customer language')
    }
    else if (this.InstructorForm.ex_skills == null || this.InstructorForm.ex_skills == '') {
      this.common.presentToast('Enter your exercise skills')
    }
    else if (this.InstructorForm.ex_years == null || this.InstructorForm.ex_years == '') {
      this.common.presentToast('Enter your number of experience')
    }
    else if (this.InstructorForm.achievements == null || this.InstructorForm.achievements == '') {
      this.common.presentToast('Enter your achievements')
    }
    else if (this.InstructorForm.about == null || this.InstructorForm.about == '') {
      this.common.presentToast('Enter your address')
    }else if(this.InstructorForm.available_days == null || this.InstructorForm.available_days == ''){
      this.common.presentToast('Enter available days');
    }
    
    else {
    
      this.InstructorForm.instructor_id = localStorage.getItem('UserId');

      this.web.postData('instructorAdditionalInfo', this.InstructorForm).then((res) => {


        if (res.status == '200') {
          this.common.presentToast('Registered Successfully');

    
    
           
          console.log("Saravana - ",this.availablePlans);
          this.selectedPlanName = this.availablePlans[0].plan_name;
          this.selectedPlanAmount = this.availablePlans[0].plan_amount;
          this.selectedPlanId = this.availablePlans[0].web_id;
          this.selectedPlanTemp = this.availablePlans[0].plan_validity;
          this.payPalSubscribeConfig = this.getConfig(this.availablePlans[0].plan_paypal_id);
          this.continuepayment = true;
        

        }else {
          this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });
    }
  }
  //View functions  ........
 async getAccountDetails() {

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    this.fetchingStatus = true;

    this.web.postData('getAccountDetails', data).then((res) => {
      console.log("MY PROFILE API")
      if (res.status == '200') {
        this.viewDetails = res.data;
        this.CustomersForm = res.data;
        this.CustomersForm.email=localStorage.getItem('email');
        this.CustomersForm.phone=localStorage.getItem('phone');
        this.InstructorForm = res.data;
        this.InstructorForm.email=localStorage.getItem('email');
        this.InstructorForm.phone=localStorage.getItem('phone');
        if(res.data.subscribe_status==0){              
          console.log("Saravana - ",this.availablePlans);
          this.selectedPlanName = this.availablePlans[0].plan_name;
          this.selectedPlanAmount = this.availablePlans[0].plan_amount;
          this.selectedPlanId = this.availablePlans[0].web_id;
          this.selectedPlanTemp = this.availablePlans[0].plan_validity;
          this.payPalSubscribeConfig = this.getConfig(this.availablePlans[0].plan_paypal_id);
          console.log(this.payPalSubscribeConfig)
          this.continuepayment = true;   
        }
        else{
          this.viewaccount = true;
          this.continueregister = true;
        }       
        console.log('account details is', this.CustomersForm);
        setTimeout(() => {
          this.fetchingStatus = false;
         // this.continueregister = true;
        }, Math.random() * 2000 + 2000);
        // console.log('account details is', res);
      } else {


        this.continueregister = false;
        // this.common.presentToast(res.error);
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
    console.log("this.CustomersForm.email",this.CustomersForm.email)
  }
  imagePreview(images: string[] = [], index: number, title: string = '') {
    if (images.length > 0) {
      let albumsArray = images.map((x: any) => {
        let y: any = {};
        y.src = this.base_url + 'uploads/uploadcontent/' + x;
        y.caption = title;
        return y;
      });
      this._lightbox.open(albumsArray, index);
    }
  }
  deleteImg(fileDeleted: any) {
    let del_filename = this.uploadedFileList[fileDeleted].uploadedFileName;
    this.web.postDataService('uploadservice/', 'delFile', { 'del_filename': del_filename }).then(
      (success: any) => {
        this.uploadedFileList.splice(fileDeleted, 1);
      },
      (error: any) => {
        console.log('error', error);
      });
  }
  previewDocument(url: string = '', title: string = '') {
    this.dialog.open(PdfPreviewComponent, {
      autoFocus: false,
      panelClass: 'pdf-reader',
      minHeight: '80vh',
      maxHeight: '85vh',
      minWidth: '90vw',
      maxWidth: '95vw',
      data: {
        url: url,
        title: title
      },
    });
  }
  dropStart(e) {
    e.preventDefault();
    e.stopPropagation();
    this.mfu_box = document.getElementById("multiple_file_upload_box");
    this.mfu_box.classList.add('is-dragover');
  }
  dropFinish(e) {
    e.preventDefault();
    e.stopPropagation();
    this.mfu_box = document.getElementById("multiple_file_upload_box");
    this.mfu_box.classList.remove('is-dragover');
  }
  dropFile(e) {
    e.preventDefault();
    e.stopPropagation();
    this.mfu_box = document.getElementById("multiple_file_upload_box");
    this.mfu_box.classList.remove('is-dragover');
    this.uploadFileToServer(e.dataTransfer.files[0]);
  }
  onSelectFile(evt) {
    if (evt.target.files && evt.target.files[0]) {
      this.uploadFileToServer(evt.target.files[0]);
    }
  }
  uploadFileToServer(file: any) {
    let image;
    if (file) {
      let that = this;
      let _URL = window.URL || window.webkitURL;
      var reader = new FileReader();
      reader.onload = (event: any) => {
        that.urls.push(event.target.result);
        let formData: FormData = new FormData();
        formData.append('uploadedFile', file);
        that.imageUploading = true;
        that.web.postFormData('ucFileUpload', formData).then(
          (success: any) => {
            that.imageUploading = false;
            if (success.status == 'success') {
              that.uploadedFileList.push(success.data);

              console.log('success', success.data);
            }
            else {
              this.common.presentToast(success.msg);
            }

          },
          (error: any) => {
            that.imageUploading = false;
            this.common.presentToast(error);
            console.log('error', error);
          }).catch(err => {
            //  this.common.pres
          })
      }
      reader.readAsDataURL(file);
    }
    else {
      alert('Please select image/document file');
    }
  }



  //edit profile
  Editprofile() {

    this.editprofile = true;
    if (localStorage.getItem('type') == "Instructor") {
      this.profile = this.InstructorForm.profile
      this.InstructorForm.available_days = JSON.parse(this.InstructorForm.available_days);
    
    }
    else {
      this.profile = this.CustomersForm.profile
    }
  }

  //edit customer
  async customeredit() {
    this.CustomersForm.profile = this.profile;
    console.log(this.CustomersForm.profile);
    if (this.CustomersForm.profile == null || this.CustomersForm.profile == '') {
      this.common.presentToast('Please choose your profile')
    } else if (this.CustomersForm.phone == null || this.CustomersForm.phone == '') {
      this.common.presentToast('Enter your phone number');
    } else if (this.common.validateMobileNumber(this.CustomersForm.phone) == false) {
      this.common.presentToast('Enter valid phone number');
    } else if (this.CustomersForm.first_name == null || this.CustomersForm.first_name == '') {
      this.common.presentToast('Enter your name');
    }
    else if (this.CustomersForm.last_name == null || this.CustomersForm.last_name == '') {
      this.common.presentToast('Enter your last name')
    }
    else if (this.CustomersForm.business_name == null || this.CustomersForm.business_name == '') {
      this.common.presentToast('Enter your Business name')
    }
    else if (this.CustomersForm.country == null || this.CustomersForm.country == '') {
      this.common.presentToast('Select country')
    }
    else if (this.CustomersForm.currencies == null || this.CustomersForm.currencies == '') {
      this.common.presentToast('Select currencies')
    }
    else if (this.CustomersForm.timezone == null || this.CustomersForm.timezone == '') {
      this.common.presentToast('Select timezone')
    }

    else if (this.CustomersForm.address == null || this.CustomersForm.address == '') {
      this.common.presentToast('Enter your address')
    }
    else if (this.CustomersForm.language == null || this.CustomersForm.language == '') {
      this.common.presentToast('Enter your language')
    }

    localStorage.setItem('phone',this.CustomersForm.phone);
      this.CustomersForm.customerid = localStorage.getItem('UserId');
      this.CustomersForm.profile = this.profile;
      console.log(this.profile);
      this.web.postData('customeredit', this.CustomersForm).then((res) => {

        if (res.status == '200') {
         // this.common.presentToast('Registered Successfully');

          window.location.reload();
          this.ngOnInit();
        } else {
          this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });

  }
  async instructoredit() {
    this.InstructorForm.profile = this.profile;
      console.log(this.InstructorForm.duration);
    if (this.InstructorForm.profile == null || this.InstructorForm.profile == '') {
      this.common.presentToast('Please choose your profile')
    }  else if (this.InstructorForm.phone == null || this.InstructorForm.phone == '') {
      this.common.presentToast('Enter your phone number');
    }else if (this.common.validateMobileNumber(this.InstructorForm.phone) == false) {
      this.common.presentToast('Enter valid phone number');
    }
    else if (this.InstructorForm.first_name == null || this.InstructorForm.first_name == '') {
      this.common.presentToast('Enter your name');
    }
    else if (this.InstructorForm.last_name == null || this.InstructorForm.last_name == '') {
      this.common.presentToast('Enter your last name')
    }
    else if (this.InstructorForm.business_name == null || this.InstructorForm.business_name == '') {
      this.common.presentToast('Enter your Business name')
    }
    else if (this.InstructorForm.country == null || this.InstructorForm.country == '') {
      this.common.presentToast('Select country')
    }
    else if (this.InstructorForm.currencies == null || this.InstructorForm.currencies == '') {
      this.common.presentToast('Select currencies')
    }
    else if (this.InstructorForm.timezone == null || this.InstructorForm.timezone == '') {
      this.common.presentToast('Select timezone')
    }
    else if (this.InstructorForm.language == null || this.InstructorForm.language == '') {
      this.common.presentToast('Select language')
    }
    else if (this.InstructorForm.customerlanguage == null || this.InstructorForm.customerlanguage == '') {
      this.common.presentToast('Select your customer language')
    }
    else if (this.InstructorForm.ex_skills == null || this.InstructorForm.ex_skills == '') {
      this.common.presentToast('Enter your exercise skills')
    }
    else if (this.InstructorForm.ex_years == null || this.InstructorForm.ex_years == '') {
      this.common.presentToast('Enter your number of experience')
    }
    else if (this.InstructorForm.achievements == null || this.InstructorForm.achievements == '') {
      this.common.presentToast('Enter your achievements')
    }
    else if (this.InstructorForm.about == null || this.InstructorForm.about == '') {
      this.common.presentToast('Enter your address')
    }else if(this.InstructorForm.available_days == null || this.InstructorForm.available_days == ''){
      this.common.presentToast('Enter available days');
    }else if(this.InstructorForm.available_from_time == null || this.InstructorForm.available_from_time == ''){
      this.common.presentToast('Select available from time');
    }else if(this.InstructorForm.available_to_time == null || this.InstructorForm.available_to_time == ''){
      this.common.presentToast('Select available to time')
    }else if(this.InstructorForm.duration == null || this.InstructorForm.duration == ''){
      this.common.presentToast("Select duration");
    }
    // else if(this.uploadedFileList.length==0){
    //   this.common.presentToast('Please attach atleast one image');
    // }
    else {
      //   let filteredImg='';
      // let filteredDocs='';
      // let tempArrForFL=[];
      // let filteredKeywords = [];
      // console.log('this.uploadedFileList :>> ', this.uploadedFileList);
      // let filteredImageTemp = this.uploadedFileList.filter(x => x.fileIsImg==true);
      // if(filteredImageTemp.length>0){
      //   filteredImageTemp.forEach((uploadedFileItem:any) => {
      //     if(uploadedFileItem.image_keywords.length>0){
      //       filteredKeywords.push([...uploadedFileItem.image_keywords]);
      //     }
      //   });
      // }
      // filteredImg = this.uploadedFileList.reduce((tempArrForFL, uploadedFileItem) => {
      //     if (uploadedFileItem.fileIsImg) {
      //       tempArrForFL.push(uploadedFileItem.uploadedFileName);
      //       // if(uploadedFileItem.image_keywords.length>0){
      //       //   filteredKeywords.push([...uploadedFileItem.image_keywords]);
      //       // }
      //     }
      //     return tempArrForFL;
      //   }, []).join(',');
      // tempArrForFL=[];
      // filteredDocs = this.uploadedFileList.reduce((tempArrForFL, uploadedFileItem) => {
      //   if (!uploadedFileItem.fileIsImg) {
      //     tempArrForFL.push(uploadedFileItem.uploadedFileName);
      //   }
      //   return tempArrForFL;
      // }, []).join(',');
      // let data={
      //   'ucTxt':this.InstructorForm.uploadcontent_text,
      //   'ucTitle':this.InstructorForm.uploadcontent_title,
      //   'ucImages':filteredImg,
      //   'ucDocs':filteredDocs,
      // }
      // console.log('data',data);
      // this.web.postData('addUploadContent',data).then((res: any) => {
      //   if (res.status == 'success') {
      //     this.gaService.event('upload_content', 'content', 'Upload Content');
      //     this.uploadedFileList = [];
      //     this.InstructorForm;
      //     this.common.presentToast(res.msg);
      //   } else {
      //     this.common.presentToast(res.msg);
      //   }
      // }, err => {
      //   console.log(err);
      //   this.common.presentToast('Connection Error');
      // })
      this.InstructorForm.instructor_id = localStorage.getItem('UserId');
      localStorage.setItem('phone',this.InstructorForm.phone);
      this.web.postData('instructoredit', this.InstructorForm).then((res) => {

        if (res.status == '200') {
          this.common.presentToast(res.error);

          window.location.reload();
          this.ngOnInit();
        } else {
          this.common.presentToast(res.error);
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
      });
    }
  }
  cancelevent(){
    window.location.reload();
    this.ngOnInit();
  }

//Arjun


}
