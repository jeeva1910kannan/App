import { Component, HostListener, NgZone, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-congrats',
  templateUrl: './register-congrats.component.html',
  styleUrls: ['./register-congrats.component.scss']
})
export class RegisterCongratsComponent implements OnInit {

  timer:any;

  constructor(private ngZone: NgZone,private router:Router,private dialog: MatDialogRef<RegisterCongratsComponent>) {
    ;
  }


async close(){
  window.location.reload();
}
  ngOnInit() {

  }


}
