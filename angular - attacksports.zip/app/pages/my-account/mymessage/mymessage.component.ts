import { Component,Inject, OnInit } from '@angular/core';
import Pusher from 'pusher-js';
import { WebService } from 'src/app/providers/web.service';
import { CommonService } from '../../services/common.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import {FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {  ViewChild, ElementRef, ChangeDetectionStrategy } from '@angular/core';

import { DatePipe } from '@angular/common';
import { LoaderService } from 'src/app/providers/loader.service';
@Component({
  selector: 'app-mymessage',
  templateUrl: './mymessage.component.html',
  styleUrls: ['./mymessage.component.scss']
})
export class MymessageComponent implements OnInit {

  // public config: PerfectScrollbarConfigInterface = {};
  interval:any;
  CustomersForm: any = {};
  public showSidebar = false;
  public now: Date | null = null;
  activeChatUserId :any;
  activeChatUser: string | null | undefined = '';
  activeChatUserImg: string | null = '';
  activeChatUserStatus = '';
  fetchingStatus: boolean = true;
  test: boolean = true;

  @ViewChild('messageInput', { static: true })
  messageInputRef: ElementRef | null = null;
  message :any;
  messages = new Array();
  base_url: string = environment.base_url;
  viewProfile: any;
  instructor_name: any;
  alldata: any;
  contactLists: any[];
  messagelist: any = [];
  user_id: any;
  users_id: any;
  scrollframe: any;
  profile: any;


  constructor(    private loaderService: LoaderService,public dialog: MatDialog,
    private datePipe: DatePipe,    public common: CommonService,    private web: WebService,

    ) {
  
   
  }

  ngOnInit() {
  this.getAccountDetails();
  console.log(localStorage.getItem('UserId'),"userrrr")
   if (localStorage.getItem('type') == "Instructor") {

      this.get_customer();
      // this.interval= setInterval(() => {
      //   this.getmesgae();
      //     }, 5000);  
        } 
        else {
      this.get_instructor();
      // this.interval= setInterval(() => {
      //   this.getmessage();
      //     }, 5000); 
      
  
    }
 
  }

  set(){
    this.test=false;
  }

  async get_customer() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    // this.fetchingStatus = false;

     this.web.postData('trainee',data).then((res) => {
      if (res.status == '200') {

        console.log(res.data,"trainee");
        console.log(res.data.notification,"notify");
                this.alldata=res.data;
           

        // setTimeout(() => {
        //  // this.continueregister = true;
        // }, Math.random() * 2000 + 2000);
        // this.accepet_request(res.data.customer_id);
      } else {


      }
      
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }

  async get_instructor() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('trainer',data).then((res) => {
      if (res.status == '200') {
        console.log(res.data,"trainer");
        console.log(res.data.notification,"notify");
                this.alldata=res.data;
              

        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
 async getAccountDetails() {

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }

    this.web.postData('getAccountDetails', data).then((res) => {

      if (res.status == '200') {
        this.viewProfile = res.data;
        this.instructor_name = res.data.first_name;
        this.profile = res.data.profile;

        this.users_id=res.data.web_id
        console.log("VIEW PROFILE",this.profile);

      } else {
        this.viewProfile.profile='';
        
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }
 



  // onAddMessage() {
    
       
  //   console.log(this.CustomersForm.message,"this.message")
  //   this.now = new Date();

  //     if(localStorage.getItem('type') == "Instructor"){
  //     let data = {
  //       instructor_id: localStorage.getItem('UserId'),
  //       message:this.CustomersForm.message,
  //       customer_id:this.activeChatUserId,
  //       sent_time:new Date().getTime() / 1000,
  //       fromid:1,

  //     }
  //     this.messagelist.push(data);
  //     setTimeout(()=>{
  //       this.scrollToBottom();
  //   }, 100);
  //    this.web.postData('message',data).then((res) => {
  //       if (res.status == '200') {
                 
  //       } else {



  //       }
  //     }, err => {
  //       console.log(err);
  //       console.log(":)")
  //     })
  //     this.now = new Date();
  //     console.log(new Date().getTime() / 1000);
  //   }else{
  //     let data = {
  //       customer_id: this.users_id,
  //       message:this.CustomersForm.message,
  //       instructor_id:this.activeChatUserId,
  //       sent_time:new Date().getTime() / 1000,
  //       fromid :0,
  //     }
  //     this.messagelist.push(data);
  //     setTimeout(()=>{
  //       this.scrollToBottom();
  //   }, 100);
  //    this.web.postData('message',data).then((res) => {
  //       if (res.status == '200') {
                 
  //       } else {

  //       }
  //     }, err => {
  //       console.log(err);
  //       console.log(":)")
  //     })
  //     this.now = new Date();
  //     console.log(this.now);
  //   }
  // }
//   getdate(date)
// {

//   return this.datePipe.transform(new Date(date*1000),'short');

// }
  //   getmesgae(chatId:any)
  //   {
  //     console.log('hai', chatId);
  //     if(chatId){
  //       // this.fetchingStatus = true;

  //      this.web.getData('getusermessage?id='+chatId).then(res=>{
  
  
  //       if(res.status=='200'){
  //         //this.mappingTableData(res.data)
  //         this.messagelist = res.data;
  //         // this.ustatus = res.userstatus;
  //         // console.log(this.ustatus);
  //       //   setTimeout(()=>{
  //       //     // this.scrollToBottom();
  //       // }, 500);
  //         console.log('data', this.messagelist);
  //       }else{
  
  //       }
        
  //     },err=>{
  
  //     })
  //   }
  // }
  //   getmessage()
  //   {
  //     if(this.activeChatUserId){

  //     this.web.getData('getusermessages?id='+this.activeChatUserId).then(res=>{
  
  
  //       if(res.status=='200'){
  //         //this.mappingTableData(res.data)
  //         this.messagelist = res.data;
  //         // this.ustatus = res.userstatus;
  //         // console.log(this.ustatus);
  //         setTimeout(()=>{
  //           // this.scrollToBottom();
  //       }, 500);
  //         console.log('data', this.messagelist);
  //       }else{
  
  //       }
  //     },err=>{
  
  //     })
  //   }
  // } 
  
  // mobileSidebar() {
  //     this.showSidebar = !this.showSidebar;
  // }

  openModal(item:any) {
    console.log(item,"cusss")
    if(localStorage.getItem('type') == 'Instructor'){
    let id = item.customer_id;
    this.openDialog(id);

    }else{
      let id = item.instructor_id;
      this.openDialog(id);

    }
  }

  openDialog(current_id: any): void {

    if (localStorage.getItem('type') == 'Instructor') {
      this.dialog.open(Chatmessage, {
        data: {
          sender_id: localStorage.getItem('UserId'),
          receiver_id: current_id,
          type: localStorage.getItem('type'),
        },
      });

    }
    else {
      this.dialog.open(Chatmessage, {
        data: {
          sender_id: localStorage.getItem('UserId'),
          receiver_id: current_id,
          type: localStorage.getItem('type'),
        },
      });    }
  }
 

}



interface Food {
  value: string;
  viewValue: string;
} @Component({
  selector: 'chatmessage',
  templateUrl: 'chatmessage.html', styleUrls: ['./chatmessage.component.scss']
})
export class Chatmessage implements OnInit {
  @ViewChild('scrollframe') private myScrollContainer: ElementRef;

  public payPalConfig: any;
  fetchingStatus: boolean = true;

  base_url: string = environment.base_url;
  eventid: any;
  EventDetails: any;
  selectedValue: string;
  selectedCar: string;
  custominfo: any;
  cust_id: any;
  cust_det: any;
  email: any;
  phone: string;
  payment:boolean=false;
  userDetailsTemp: any;
  messagelist: any = [];
  CustomersForm: any = {};
  now: Date;
  message_enable: boolean=true;
customer_curretid:any;
  viewProfile: any;
  instructor_name: any;
  user_name: any;
  profile: any;
  type: boolean | undefined;
  last_name: any;
  profiles: any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Chatmessage,
    private web: WebService,
    public common: CommonService,   private router:Router, private datePipe: DatePipe, 
    ) {
this.customer_curretid=data;
    console.log(this.customer_curretid,"dataaa")
if(localStorage.getItem('type') == "Instructor"){
  this.fetchingStatus = true;

    this.web.postData('getusermessage', data).then((res) => {
      if (res.status == '200') {
        this.messagelist = res.data;
      } else {
        console.log(res.error);
      }
      setTimeout(() => {
        this.fetchingStatus = false;
       // this.continueregister = true;
      }, Math.random() * 2000 + 2000);
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
  }
  else{
    this.fetchingStatus = true;

    this.web.postData('getusermessages', data).then((res) => {
      if (res.status == '200') {
        this.messagelist = res.data;
      } else {
        console.log(res.error);
      }
      setTimeout(() => {
        this.fetchingStatus = false;
       // this.continueregister = true;
      }, Math.random() * 2000 + 2000);
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error.');
    });
  }
  }
  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit(): void {
    if (localStorage.getItem('type') == "Instructor") {
      this.type = true;
    }
    else {
      this.type = false;
    }
    this.getAccountDetails();
    this.current_getAccountDetails();
    // if (localStorage.getItem('type') == "Instructor") {

      // this.get_customer();
      // this.interval= setInterval(() => {
      //   this.getmesgae();
      //     }, 5000);  
      //   } else {
      // this.get_instructor();
      // this.interval= setInterval(() => {
      //   this.getmessage();
      //     }, 5000); 
      
  
    // }
  }

  async current_getAccountDetails() {
console.log(localStorage.getItem('UserId'),"user")
    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }

    this.web.postData('getAccountDetails', data).then((res) => {

      if (res.status == '200') {
        this.instructor_name = res.data.first_name;
        this.profile = res.data.profile;

        console.log("VIEW PROFILE",this.profile);

      } else {
        this.viewProfile.profile='';
        
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }
 
  async getAccountDetails() {
    if(localStorage.getItem('type') == "Instructor"){

    let data = {
      user_id: this.customer_curretid.receiver_id,
      type: "Customer"
    }
    this.web.postData('getAccountDetails', data).then((res) => {

      if (res.status == '200') {
        this.viewProfile = res.data;
        this.user_name = res.data.first_name;
        this.last_name = res.data.last_name;
        console.log(this.profile,"receiverprofile");

      } else {
        this.viewProfile.profile='';
        
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  
  }else{
    let data = {
      user_id: this.customer_curretid.receiver_id,
      type: "Instructor"
    }
    this.web.postData('getAccountDetails', data).then((res) => {

      if (res.status == '200') {
        this.viewProfile = res.data;
        this.user_name = res.data.first_name;
        this.last_name = res.data.last_name;
        this.profiles=res.data.profile;
        console.log(this.profiles,"receiverprofile");
      
      } else {
        this.viewProfile.profile='';
        
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  
  }
  
}
  async scrollToBottom() {
    console.log('Robert');
        try {
    
          this.myScrollContainer.nativeElement.scroll({
            top: this.myScrollContainer.nativeElement.scrollHeight,
            left: 0,
            behavior: 'smooth'
          });
    
        } catch(err) {
          console.log(err);
        }
    }
  getdate(date)
{
console.log(date,"date")
  return this.datePipe.transform(new Date(date*1000),'short');

}
messagecount()
{
  console.log('ewr');
  this.message_enable=true;
    let str=this.CustomersForm.message.trim();
    console.log(str);
    if(str)
    {
      this.message_enable=false;
      console.log(this.message_enable);
    }

}
onAddMessage() {
       
    console.log(this.CustomersForm.message,"this.message")
    this.now = new Date();

      if(localStorage.getItem('type') == "Instructor"){
      let data = {
        instructor_id: localStorage.getItem('UserId'),
        message:this.CustomersForm.message,
        customer_id:this.customer_curretid.receiver_id,
        sender_id:localStorage.getItem('UserId'),
        receiver_id:this.customer_curretid.receiver_id,
        sent_time:new Date(),
        fromid:1,

      }
      // if(this.messagelist){
// console.log('[;ch')
      this.messagelist.push(data);
      // }
      setTimeout(()=>{
        this.scrollToBottom();
    }, 100);
    console.log(data,"message")
     this.web.postData('message',data).then((res) => {
        if (res.status == '200') {
          this.CustomersForm.message="";
        } else {

        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
      this.now = new Date();
      console.log(new Date().getTime() / 1000);
    }
    else{
      let data = {
        customer_id: localStorage.getItem('UserId'),
        message:this.CustomersForm.message,
        instructor_id:this.customer_curretid.receiver_id,
        sender_id:localStorage.getItem('UserId'),
        receiver_id:this.customer_curretid.receiver_id,
        sent_time:new Date(),
        fromid :0,
      }
      if(this.messagelist){
      this.messagelist.push(data);
      }
      setTimeout(()=>{
        this.scrollToBottom();
    }, 100);
     this.web.postData('message',data).then((res) => {
        if (res.status == '200') {
          this.CustomersForm.message="";

        } else {

        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
      this.now = new Date();
      console.log(this.now);
    }
  }

}
