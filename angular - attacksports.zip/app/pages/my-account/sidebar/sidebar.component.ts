
import { Component, Output, EventEmitter, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/providers/common.service';

import { WebService } from 'src/app/providers/web.service';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {



  @Output() notifyParent: EventEmitter<any> = new EventEmitter();

  image: any;
  type:any;
  base_url: string = environment.base_url;
  userId: any;
  userType: any;
  fetchingStatus: boolean = true;
  accountInfo: any;
  selectedMenu: string;
  participantsForm: any;
  loading: boolean=false;
  editParticipant: boolean = false;
  plan:any;
viewProfile:any={
profile:null
};
  constructor(


    private web: WebService,
    public common: CommonService,


  private activateRoute: ActivatedRoute,

  private router:Router

  ) {
    this.userId = localStorage.getItem('UserId');
    this.userType = localStorage.getItem('Role');
    // this.getAccountDetails();
    console.log('works1')
   }


   getAccountDetails() {

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }

    this.web.postData('getAccountDetails', data).then((res) => {

      if (res.status == '200') {
        this.viewProfile = res.data;
        console.log("VIEW PROFILE",this.viewProfile);
        this.fetchingStatus = false;

      } else {
        this.viewProfile.profile='';
        
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }
  ngOnInit() {
    this.type=localStorage.getItem('type')
    this.activateRoute.queryParams.subscribe(params => {
      if (params.menu === 'training-member-details') {
         this.changeSideMenu('training-member-details');
      }
    });
    this.selectedMenu = 'my-account';
   this.getAccountDetails();
  }
  changeSideMenu(menu: string) {
    let scrollToTop = window.setInterval(() => {
      let pos = window.pageYOffset;
      if (pos > 0) {
          window.scrollTo(0, pos - 20); // how far to scroll on each step
      } else {
          window.clearInterval(scrollToTop);
      }
  }, 16);

    console.log(menu,"menu")
    this.selectedMenu = menu;
    this.notifyParent.emit(menu);
  }


  ngOnChanges(){
    console.log('works123423111')
  }


}
