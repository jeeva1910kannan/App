
import { DOCUMENT } from '@angular/common';
import { Component, OnInit, Inject, Input } from '@angular/core';
import { Router } from '@angular/router';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../services/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-training-member-details',
  templateUrl: './training-member-details.component.html',
  styleUrls: ['./training-member-details.component.scss']
})
export class TrainingMemberDetailsComponent implements OnInit {
  fetchingStatus: boolean = true;

  @Input() vid:number;
videoComments:any = [];
  type: boolean | undefined;
  alldata: any={};
  reply:any = [];
  data_customer: any = {};
  base_url: string = environment.base_url;
  notify: boolean;
  uploadvideo:any = [];
  video: any = [];
  loading: boolean;
  thumbnailData: any;
  imageBase64: any;
  imagename_thumb: any;
  customervid: any;
  customervid1: any;
  sentvideos:any = [];
  showvideo:any = [];
  currentPlayingVideo: HTMLVideoElement;
  litedesc: string;
  videodate: Date;
  uploading:any = [];
  uploadvideo_instructor: any={};
  showvideo_instructor: any={};
  showvideos: boolean;
  constructor(
    private web: WebService,
    public common: CommonService, private router: Router, @Inject(DOCUMENT) private document: Document,
    public dialog: MatDialog

  ) { }
  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }

  ngOnInit(): void {
    if (localStorage.getItem('type') == "Instructor") {
      this.get_customer();
    }
    if (localStorage.getItem('type') == "Customer") {
      this.get_instructor();
      this.getNotifyComments();
    }

    if (localStorage.getItem('type') == "Instructor") {
      this.type = true;
    }
    else {
      this.type = false;
    }
  }

  async get_customer() {
    let data = {
      instructor_id: localStorage.getItem('UserId'),
    }
    this.fetchingStatus=true;
    await this.web.postData('getallrequestfrom_followedcustomer', data).then((res) => {
      if (res.status == '200') {
        this.fetchingStatus=false;

        console.log(res.data, "getallrequestfromcustomer");
        console.log(res.data.notification, "notify");
        this.alldata = res.data;
        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else {

        this.notify = true;

      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  //customer
  async get_instructor() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('getallrequestfrom_followedinstructor', data).then((res) => {
      if (res.status == '200') {
        this.fetchingStatus=false
        // console.log(res.data.notification,"notify");
        this.data_customer = res.data;
        console.log(this.data_customer);

        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else {

        this.notify = true;

      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  async uploadVideo(val) {
    this.uploadvideo = [];
    this.showvideo = [];
    this.uploadvideo[val] = true;
    this.showvideo[val] = false;
  }


  //instructor

  async uploadVideo_instructor(val) {
    this.uploadvideo_instructor = [];
    this.showvideo_instructor = [];
    this.uploadvideo_instructor[val] = true;
    this.showvideo_instructor[val] = false;
  }

  onFileChange(event,val) {
    if (event.target.files.length > 0) {
      const files = event.target.files;
      if (files[0].type == "video/mp4" || files[0].type == "video/mkv") {
        this.onSubmit(files,val);
      }
      else {
        this.common.presentToast("Only videos can be uploaded");
      }
    }
  }

  onSubmit(file: any, val) {
    this.uploading = [];
    this.uploading[val] = true; 
    this.uploadvideo = [];
    this.uploadvideo[val] = false;
    this.uploadvideo_instructor=[];
    this.uploadvideo_instructor[val] = false;

    this.common.presentToast("File uploading");
    let d = new Date();
    let n: any = d.valueOf();
    //  console.log(file[0].name);
    let fname = file[0].name;
    this.loading = true;
    this.generateThumbnail(file[0]).then(thumbnailData => {
      //console.dir(thumbnailData);
      this.thumbnailData = thumbnailData;
      //this.web.videoimage(this.thumbnailData);
      let d = new Date();
      let imagename = fname.substring(fname.lastIndexOf(".") + 1, fname.length) || fname;
      this.imagename_thumb = 'ATTACK_' + n + '.png';
      this.imageBase64 = this.thumbnailData;
      const formData = new FormData();
      formData.append("base64", this.imageBase64);
      formData.append("image", this.imagename_thumb);
      formData.append("profile", this.imagename_thumb);
      this.web.uploadWebsitePicture(this.base_url + `restapi/upload_customer_video_thumbnail.php?filename=${this.imagename_thumb}`, formData).subscribe((Res: any) => {
        if (Res.status == "success") {
         console.log("thumb",Res);
          fname = fname.substring(fname.lastIndexOf('.') + 1, fname.length) || fname;
          let filename = 'ATTACK_' + n + '.' + fname;
          const formDataevent = new FormData();
          formDataevent.append("video_upload_file", file[0]);
          // formDataevent.append("video_upload_file", filename);
          this.customervid = filename;
          this.web.uploadWebsiteVideo(this.base_url + `uploads/video/upload_customer_video.php?filename=${filename}`, formDataevent).subscribe((Res: any) => {
            if (Res.status == 'success') {
              this.customervid1 = this.base_url + "uploads/video/customer_videos/" + filename;
              console.log("Uploaded video is", this.customervid1);
              this.uploading[val] = false;
              this.uploadvideo[val] = true;
              this.uploadvideo_instructor[val] = true;

              this.common.presentToast(Res.error);
            } else {
              //  console.log("failed");
              this.loading = false;
            }
          }, (err) => {
            this.loading = false;
            console.log(JSON.stringify(err));
          });
        }
      })
    });
  }

  public generateThumbnail(videoFile: Blob): Promise<string> {
    const video: HTMLVideoElement = this.document.createElement('video');
    const canvas: HTMLCanvasElement = this.document.createElement('canvas');
    const context: CanvasRenderingContext2D = canvas.getContext('2d');
    return new Promise<string>((resolve, reject) => {
      canvas.addEventListener('error', reject);
      video.addEventListener('error', reject);
      video.addEventListener('canplaythrough', event => {
        video.play();
        setTimeout(() => {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
          resolve(canvas.toDataURL());
        }, 3000);
        
      });
      if (videoFile.type) {
        video.setAttribute('type', videoFile.type);
      }
      video.preload = 'auto';
      video.src = window.URL.createObjectURL(videoFile);
      video.load();
    });
  }

  submitVideo(video, instructorId) {
    if (video.title == "" || video.title == undefined) {
      this.common.presentToast("Enter Title");
    }
    else if (video.description == "" || video.description == undefined) {
      this.common.presentToast("Enter Description");
    }
    else if (this.customervid == "" || this.customervid == undefined) {
      this.common.presentToast("Upload video");
    }
    else {
      var data = {
        title: video.title,
        description: video.description,
        video_name: this.customervid,
        video_thumb_name: this.imagename_thumb,
        customer_id: localStorage.getItem('UserId'),
        instructor_id: instructorId,
        date: new Date(),
      };
    }

    this.web.postData('customervideo', data).then((res) => {
      if (res.status == '200') {
        this.common.presentToast('Uploaded Successfully');
         this.getallvideos(instructorId); 
        this.showvideo = true;
      } else {
        this.common.presentToast('res.error');
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }

  cancel(){
  
    this.uploadvideo = false; 
    this.uploadvideo_instructor = false;
    this.video.title = '';
    this.video.description = '';
    this.customervid = '';
  }
  
  getallvideos(instructor_id, val=null) {
    this.showvideo = [];
    this.uploadvideo = [];
     this.uploadvideo[val] = false;
     this.showvideo[val] = true;
    let data = {
      instructor_id: instructor_id,
    }
   this.web.postData('getcustomervideos',data).then((res) => {
      if (res.status == '200') {
        this.sentvideos = res.data;
      } else {
        this.uploadvideo=false;
        console.log(":(");
        this.sentvideos = [];
      }
    }, err => {
      console.log(err);
      console.log("error working")
    })
  }



//instructor
  getallvideos_instructor(customer_id, val=null) {
    this.showvideo_instructor = [];
    this.uploadvideo_instructor = [];
     this.uploadvideo_instructor[val] = false;
     this.showvideo_instructor[val] = true;
    let data = {
      customer_id: customer_id,
    }
   this.web.postData('getuploadedvideos_to_customer',data).then((res) => {
      if (res.status == '200') {
        this.sentvideos = res.data;
        console.log(this.sentvideos);
      } else {
        this.uploadvideo_instructor=false;
        console.log(":(");
        this.sentvideos = [];
      }
    }, err => {
      console.log(err);
      console.log("error working")
    })
  }

  //instructor module
  submitVideo_instructor(video,Customer_id) {
    if (video.title == "" || video.title == undefined) {
      this.common.presentToast("Enter Title");
    }
    else if (video.description == "" || video.description == undefined) {
      this.common.presentToast("Enter Description");
    }
    else if (this.customervid == "" || this.customervid == undefined) {
      this.common.presentToast("Upload video");
    }
    else {
      var data = {
        title: video.title,
        description: video.description,
        video_name: this.customervid,
        video_thumb_name: this.imagename_thumb,
        instructor_id: localStorage.getItem('UserId'),
        customer_id: Customer_id,
        date: new Date(),
      };
    
    this.web.postData('Instructorvideo_to_customer', data).then((res) => {
      if (res.status == '200') {
        this.common.presentToast('Uploaded Successfully');
        this.getallvideos_instructor(Customer_id);
        this.showvideos = true;
      } else {
        this.common.presentToast('res.error');
      }
    }, err => {
      console.log(err);
      this.common.presentToast('Connection Error');
    });
  }
  }

  async findstart(startdate: any) {
    this.videodate = new Date(startdate * 1000);
  }

  async finddesc(desc: any) {
    this.litedesc= desc.substring(0, 170) + '....';    
  }

  onPlayingVideo(event) {
    console.log("this"+event);
      event.preventDefault();
      // play the first video that is chosen by the user
      if (this.currentPlayingVideo === undefined) {
        this.currentPlayingVideo = event.target;
        this.currentPlayingVideo.play();
      } else {
        // if the user plays a new video, pause the last one and play the new one
        if (event.target !== this.currentPlayingVideo) {
          this.currentPlayingVideo.pause();
          this.currentPlayingVideo = event.target;
          this.currentPlayingVideo.play();
        }
      }
  }
  ShowVideo(custId){
    this.router.navigate(['customer-videos',custId])

  }
  ShowVideo_customer(Instructor_id){
    console.log("'instructor-videos'")
    this.router.navigate(['instructor-videos',Instructor_id])
  }

 async getNotifyComments(){
    
  let data = {
    video_id:this.vid
  }
 await this.web.postData("getInstructorCmt", data).then((res) =>{
   if(res.status == '200'){
     this.videoComments = res.data;
   }else{
     console.log("No result")
   }
 },err => {
  console.log(err);
  console.log("error working")
 }) 
}

openModal(current_id) {
  this.dialog.open(replyComment, {
    data: {
      sender_id: localStorage.getItem("UserId"),
      receiver_id: current_id
    }
  })
}

}

@ Component({
  selector: 'replyComment',
  templateUrl: 'replyComment.html',
  styleUrls: ['./replyComment.component.scss']
})

export class replyComment implements OnInit {

  video_details: any;
  alldetais: any;
  fetchingStatus: boolean = true;
  title: string;
  type: boolean | undefined;
  message_enable: boolean = true;
  CustomersForm: any = {};
  messagelist: any = [];
  replymsg:any = [];
  message:any = [];
  base_url:string = environment.base_url;
sender_id:any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: replyComment,
    public common: CommonService,
    public web: WebService,
    public datePipe: DatePipe) {

      this.alldetais = this.data;
      this.video_details = this.alldetais.receiver_id;
      this.fetchingStatus = true;

      this.web.postData('getvideocomment', this.video_details).then((res) => {
        if (res.status == '200') {

          this.messagelist = res.data;
          console.log(this.messagelist,"message")
          
        } else {
          console.log(res.error);
        }
        setTimeout(() => {
          this.fetchingStatus = false;
          // this.continueregister = true;
        }, Math.random() * 2000 + 2000);
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error.');
      }); 
  }


  loaderTheme = {
    'background-color': '#E5E5E5',
    'margin-bottom': 0,
    'display': 'flex'
  }
  ngOnInit(): void {
    this.alldetais = this.data;
    this.video_details = this.alldetais.receiver_id;
    this.title = this.video_details.title;
    this.fetchingStatus = false;
    this.sender_id=localStorage.getItem("UserId")

  }

  getdate(date)
  {
  console.log(date,"date")
  
    return this.datePipe.transform(new Date(date*1000),'short');
  
  }

  messagecount() {
    console.log('ewr');
    this.message_enable = true;
    let str = this.CustomersForm.message.trim();
    console.log(str);
    if (str) {
      this.message_enable = false;
      console.log(this.message_enable);
    }

  }



  onAddMessage() {

    if(this.CustomersForm.message == "" || this.CustomersForm.message == undefined){
      console.log("Type something...");
    }else{
    if(localStorage.getItem("type")=="Customer"){
        let data = {
          video_id: this.video_details.web_id,
          sender_id: localStorage.getItem('UserId'),
          receiver_id: this.video_details.instructor_id,
          message: this.CustomersForm.message,
          date: Math.round(new Date().getTime()/1000)
        }
      
        console.log(data);
        this.messagelist.push(data);
        this.CustomersForm.message = "";
        this.web.postData("postCustomerReplycomments", data).then((res) => {
          if (res.status == '200') {
            this.CustomersForm.message = "";
    
          } else {
            console.log('errr');
          }
        }, err => {
          console.log(err);
          console.log(":)")
        }) 
      }
      if(localStorage.getItem("type")=="Instructor"){
        let data = {
          video_id: this.video_details.web_id,
          sender_id: localStorage.getItem('UserId'),
          receiver_id: this.video_details.customer_id,
          message: this.CustomersForm.message,
          date:Math.round(new Date().getTime()/1000)
        }
      
        console.log(data);
        this.messagelist.push(data);
        this.CustomersForm.message = "";
        this.web.postData("postCustomerReplycomments", data).then((res) => {
          if (res.status == '200') {
            this.CustomersForm.message = "";
    
          } else {
            console.log('errr');
          }
        }, err => {
          console.log(err);
          console.log(":)")
        }) 
      }

    //  this.replymsg.push(data);
  
  } 
  }
  
}


