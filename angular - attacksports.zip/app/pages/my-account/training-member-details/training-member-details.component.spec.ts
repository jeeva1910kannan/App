import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingMemberDetailsComponent } from './training-member-details.component';

describe('TrainingMemberDetailsComponent', () => {
  let component: TrainingMemberDetailsComponent;
  let fixture: ComponentFixture<TrainingMemberDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainingMemberDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingMemberDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
