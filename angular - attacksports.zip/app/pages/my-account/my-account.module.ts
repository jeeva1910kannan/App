import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { MatSelectModule } from "@angular/material/select";

import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { MyAccountComponent } from './my-account.component';
import { MyAccountRoutingModule } from './my-account-routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ChangePasswrodComponent } from './change-password/change-password.component';
import { SubscriptionStatusComponent } from './subscription-status/subscription-status.component';
import { MatDialogModule } from '@angular/material/dialog';
import { EventsComponent } from './events/events.component';
import { NgxPayPalModule } from 'ngx-paypal';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { InstructorvideoComponent } from './instructorvideo/instructorvideo.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NotifycustomerComponent } from './notifycustomer/notifycustomer.component';
import { NotificationComponent } from './notification/notification.component';
import { TrainingMemberDetailsComponent,replyComment } from './training-member-details/training-member-details.component';
import { GenerateReportComponent } from './generate-report/generate-report.component';
import { CustomerReportComponent } from './customer-report/customer-report.component';
import { ListReportComponent } from './list-report/list-report.component';
import { EventCalenderComponent } from './event-calender/event-calender.component';
import { NgxMatDatetimePickerModule, NgxMatNativeDateModule, NgxMatTimepickerModule } from '@angular-material-components/datetime-picker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
// import {NgxEventCalendarModule} from 'ngx-event-calendar';

import { FlatpickrModule } from 'angularx-flatpickr';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { TeamComponent } from './team/team.component';
import { ChatComponent } from './chat/chat.component';
import { MymessageComponent,Chatmessage } from './mymessage/mymessage.component';

import { MatTableModule } from '@angular/material/table';
import { withdraw, WithdrawlComponent } from './withdrawl/withdrawl.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { BookAppointmentComponent, bookSlot } from './book-appointment/book-appointment.component';
import { BoookedSlotsComponent } from './boooked-slots/boooked-slots.component';
import { DialogComponent } from './dialog/dialog.component';
import { MatButtonModule } from '@angular/material/button';
import { MyCalenderComponent } from './my-calender/my-calender.component';

@NgModule({
  declarations: [
    MyAccountComponent,
    SidebarComponent,
    MyProfileComponent,
    ChangePasswrodComponent,
    SubscriptionStatusComponent,
    EventsComponent,
    InstructorvideoComponent,
    NotifycustomerComponent,
    NotificationComponent,
    TrainingMemberDetailsComponent,
    GenerateReportComponent,
    CustomerReportComponent,
    ListReportComponent,
    EventCalenderComponent,
    TeamComponent,
    ChatComponent,
    replyComment,
    MymessageComponent,
    Chatmessage,
WithdrawlComponent,withdraw, BookAppointmentComponent,
bookSlot,
BoookedSlotsComponent,
DialogComponent,
MyCalenderComponent,
  ],
  imports: [
    NgxSkeletonLoaderModule,
    MatButtonModule,
    MyAccountRoutingModule,
    CommonModule,
    FormsModule,
    HeaderFooterModule,
    ReactiveFormsModule,
    MatSelectModule,
    NgxPayPalModule,
    MatDialogModule,
    NgbModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    CKEditorModule,
    MatProgressSpinnerModule,
    NgbModalModule,
    MatTableModule,
    MatPaginatorModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    MatDatepickerModule,
    NgxMaterialTimepickerModule,
    MatNativeDateModule,
    FlatpickrModule.forRoot(),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
  ],bootstrap:[
    MyAccountModule
  ],schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
  // @ts-ignore
export class MyAccountModule {

 }
