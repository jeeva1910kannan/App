import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { environment } from 'src/environments/environment';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import {
    ChangeDetectionStrategy,
    ViewChild,
    TemplateRef,
  } from '@angular/core';
  import {
    startOfDay,
    endOfDay,
    subDays,
    addDays,
    endOfMonth,
    isSameDay,
    isSameMonth,
    addHours,
  } from 'date-fns';
  import { Subject } from 'rxjs';
  import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
  import {
    CalendarEvent,
    CalendarEventAction,
    CalendarEventTimesChangedEvent,
    CalendarView,
  } from 'angular-calendar';
  import { EventColor } from 'calendar-utils';

  const colors: Record<string, EventColor> = {
    red: {
      primary: '#ad2121',
      secondary: '#FAE3E3',
    },
    blue: {
      primary: '#1e90ff',
      secondary: '#D1E8FF',
    },
    yellow: {
      primary: '#e3bc08',
      secondary: '#FDF1BA',
    },
  };
@Component({
  selector: 'app-event-calender',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './event-calender.component.html',
  styleUrls: ['./event-calender.component.scss']
})
export class EventCalenderComponent implements OnInit {
  @ViewChild('closebutton') closebutton;

    @ViewChild('modalContent', { static: true }) modalContent: TemplateRef<any>;
    @ViewChild('modalContentcus', { static: true }) modalContentcus: TemplateRef<any>;

    @ViewChild('modalAdd', { static: true }) modalAdd: TemplateRef<any>;
    @ViewChild('modalAddcus', { static: true }) modalAddcus: TemplateRef<any>;

  view: CalendarView = CalendarView.Month;
  minDate = new Date();
  type: boolean | undefined;
  btnstate: boolean=false;

  CalendarView = CalendarView;

  viewDate: Date = new Date();

  modalData: {
    action: string;
    event: CalendarEvent;
  };
  modaldata: {
    action: string;
    event: CalendarEvent;
  };
  alldata: any;
  data_customer: any;
  alldata_cus: any;
  data_consultant: any;
  cus_consultant: any;
  events: CalendarEvent[];
  //events: CalendarEvent[];
  Eventforme: any;
  ngOnInit(): void {
  console.log(  subDays(startOfDay(new Date()), 1),"dateee");
  console.log( new Date(1661851846 * 1000),"newdateee");
  console.log(addDays(new Date(), 1),"dateeeafter");
  // console.log(this.eventArray,"array");
console.log("calender")
if (localStorage.getItem('type') == "Instructor"){
  this.get_customer();
  this.get_consultant_instrutor()
  }
  if (localStorage.getItem('type') == "Customer"){
    console.log("calender")
    this.get_consultant_customer()

  this.get_instructor();
  }
  if (localStorage.getItem('type') == "Instructor") {
    this.type = true;
    console.log("instruc")
  }
  else {
    this.type = false;
  }
  }
  actions: CalendarEventAction[] = [
    {
      label: '<i class="fas fa-fw fa-pencil-alt"></i>',
      a11yLabel: 'Edit',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.handleEvent('Edited', event);
        console.log(event,"edit_event")
      },
    },
    {
      label: '<i class="fas fa-fw fa-trash-alt"></i>',
      a11yLabel: 'Delete',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.events = this.events.filter((iEvent) => iEvent !== event);
        this.handleEvent('Deleted', event);
      },
    },
  ];

  refresh = new Subject<void>();
  //events: CalendarEvent[] = this.events;
  //events: CalendarEvent[] =
  // [
  //   {
  //     start: subDays(startOfDay(new Date()), 1),
  //     end: addDays(new Date(), 1),
  //     title: 'A 3 day event',
  //     color: { ...colors.red },
  //     actions: this.actions,
  //     allDay: true,
  //     resizable: {
  //       beforeStart: true,
  //       afterEnd: true,
  //     },
  //     draggable: true,
  //   },
  //   // {
  //   //   start: startOfDay(new Date()),
  //   //   title: 'An event with no end date',
  //   //   color: { ...colors.yellow },
  //   //   actions: this.actions,
  //   // },
  //   // {
  //   //   start: subDays(endOfMonth(new Date()), 3),
  //   //   end: addDays(endOfMonth(new Date()), 3),
  //   //   title: 'A long event that spans 2 months',
  //   //   color: { ...colors.blue },
  //   //   allDay: true,
  //   // },
  //   // {
  //   //   start: addHours(startOfDay(new Date()), 2),
  //   //   end: addHours(new Date(), 2),
  //   //   title: 'A draggable and resizable event',
  //   //   color: { ...colors.yellow },
  //   //   actions: this.actions,
  //   //   resizable: {
  //   //     beforeStart: true,
  //   //     afterEnd: true,
  //   //   },
  //   //   draggable: true,
  //];

  activeDayIsOpen: boolean = true;

  constructor( private web: WebService,
    public common: CommonService,private router:Router,private modal: NgbModal,) {}

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    console.log(events,"dayclicked");
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }

  eventTimesChanged({
    event,
    newStart,
    newEnd,
  }: CalendarEventTimesChangedEvent): void {
    this.events = this.events.map((iEvent) => {
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd,
        };
      }
      return iEvent;
    });
    this.handleEvent('Dropped or resized', event);
  }

  handleEvent(action: string, event: CalendarEvent): void {
    console.log(action,"edit");
    if((action=="Edited") && (localStorage.getItem('type') == "Instructor")){
    this.modalData = { event, action };
    this.modal.open(this.modalContent, { size: 'lg' });
    console.log(event,"edittttttttt");
    this.Editevent(event);

    } else if((action=="Deleted") && (localStorage.getItem('type') == "Instructor")){
      this.modalData = { event, action };
      this.deleteevent(event);

    }
    if((action=="Edited") && (localStorage.getItem('type') == "Customer")){
      this.modalData = { event, action };
      this.modal.open(this.modalContentcus, { size: 'lg' });
      console.log(event,"edit_cus");
      this.Editevent_cus(event);

      } else if((action=="Deleted") && (localStorage.getItem('type') == "Customer")){
        this.modalData = { event, action };
        this.deleteevent(event);

      }else if(action=="Add" ){
      this.modalData = { event, action };
    this.modal.open(this.modalContent, { size: 'lg' });
    console.log("add")

    }else{
      console.log("otherssss")

    }

  }

  addEvent(action: string,event): void {

    this.modaldata = {event,action };
    if((localStorage.getItem('type') == "Instructor")){
    this.modal.open(this.modalAdd, { size: 'lg' });
    }else{
      this.modal.open(this.modalAddcus, { size: 'lg' });

    }
    console.log(this.events,"eventsss");
    console.log(action,"action");
    console.log(event,"event");
    // this.events = [
    //   ...this.events,
    //   {
    //     title: 'New event',
    //     start: startOfDay(new Date()),
    //     end: endOfDay(new Date()),
    //     color: colors.red,
    //     actions: this.actions,
    //     draggable: true,
    //     resizable: {
    //       beforeStart: true,
    //       afterEnd: true,
    //     },
    //   },
    // ];
  }
  addEventcus(action: string,event): void {
    this.modaldata = {event,action };
    this.modal.open(this.modalAddcus, { size: 'lg' });

    console.log(this.events,"eventsss");
    console.log(action,"action");
    console.log(event,"event");
    // this.modal.close();
    // this.events = [
    //   ...this.events,
    //   {
    //     title: 'New event',
    //     start: startOfDay(new Date()),
    //     end: endOfDay(new Date()),
    //     color: colors.red,
    //     actions: this.actions,
    //     draggable: true,
    //     resizable: {
    //       beforeStart: true,
    //       afterEnd: true,
    //     },
    //   },
    // ];
  }

  deleteEvent(eventToDelete: CalendarEvent) {
    console.log(eventToDelete,"delete")
    this.events = this.events.filter((event) => event !== eventToDelete);

    console.log(this.events,"delete eventsss")
    console.log(eventToDelete,"delete function")

  }

  setView(view: CalendarView) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }


//validation store db
Eventform:any={
  'desc':"",
};
    //Validation INstructor add
    async newevent(){
      this.btnstate = true;

 this.Eventform.instructor_id = localStorage.getItem('UserId');
 if (this.Eventform.customer_id == null || this.Eventform.customer_id == '') {
  this.common.presentToast('Enter customer');
}
    else if (this.Eventform.title == null || this.Eventform.title == '') {
        this.common.presentToast('Enter title');
      }
      else if (this.Eventform.duration[0] == null || this.Eventform.duration[0] == '') {
        this.common.presentToast('Enter start time');
      }
      else if (this.Eventform.duration[1] == null || this.Eventform.duration[1] == '') {
        this.common.presentToast('Enter end time');
      }
      else {

        this.web.postData('cousultant', this.Eventform).then((res) => {

          if (res.status == '200') {

            this.common.presentToast('Consultant created Successfully');
            window.location.reload();

            // this.modalAdd.dismissAll();
            this.closebutton.nativeElement.click();


            this.ngOnInit();
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
      }
    }

    //instructor edit get
    async Editevent(currentevent:any){

      let data = {
        user_id: localStorage.getItem('UserId'),
        type: localStorage.getItem('type'),
        event_id:currentevent.web_id,
      }
      this.web.postData('geteditinstructorconsultDetails',data).then((res) => {
        if (res.status == '200') {
          this.Eventforme = res.data;
    console.log(this.Eventforme,"edit value")
        } else {
          console.log(res.error);
        }
      }, err => {
        console.log(err);
      this.common.presentToast('Connection Error.');
      });


    }

    async deleteevent(currentevent:any){

      let data = {
        instructor_id: localStorage.getItem('UserId'),
        type: localStorage.getItem('type'),
        web_id:currentevent.web_id,
      }
      this.web.postData('delete_consultant_instructor',data).then((res) => {
        if (res.status == '200') {
          this.Eventforme = res.data;
          this.common.presentToast('Deleted successfully.');

        } else {
          console.log(res.error);
        }
      }, err => {
        console.log(err);
      this.common.presentToast('Connection Error.');
      });


    }

    async editnewevent(){
     this.Eventforme.instructor_id = localStorage.getItem('UserId');
     if (this.Eventforme.customer_id == null || this.Eventforme.customer_id == '') {
      this.common.presentToast('Enter customer');
    }
      else if (this.Eventforme.title == null || this.Eventforme.title == '') {
        this.common.presentToast('Enter title');
      }
      else if (this.Eventforme.duration[0] == null || this.Eventforme.duration[0] == '') {
        this.common.presentToast('Enter start time');
      }
      else if (this.Eventforme.duration[1] == null || this.Eventforme.duration[1] == '') {
        this.common.presentToast('Enter end time');
      }
      else {

        this.web.postData('editconsultant_instructor', this.Eventforme).then((res) => {

          if (res.status == '200') {

            this.common.presentToast('Event edited Successfully');
            window.location.reload();

            this.ngOnInit();
          } else {
              this.common.presentToast('res.error');
          }
        }, err => {
          console.log(err);
          this.common.presentToast('Connection Error');
        });
      }
    }
    //customer add
    async newevent_customer(){
      this.btnstate = true;

      this.Eventform.customer_id = localStorage.getItem('UserId');
      if (this.Eventform.instructor_id == null || this.Eventform.instructor_id == '') {
       this.common.presentToast('Enter instructor');
     }
         else if (this.Eventform.title == null || this.Eventform.title == '') {
             this.common.presentToast('Enter title');
           }
           else if (this.Eventform.duration[0] == null || this.Eventform.duration[0] == '') {
             this.common.presentToast('Enter start time');
           }
           else if (this.Eventform.duration[1] == null || this.Eventform.duration[1] == '') {
             this.common.presentToast('Enter end time');
           }
           else {

             this.web.postData('cousultant_trainee', this.Eventform).then((res) => {

               if (res.status == '200') {

                 this.common.presentToast('Consultant created Successfully');
                 window.location.reload();

                 // this.modalAdd.dismissAll();
                 this.closebutton.nativeElement.click();


                 this.ngOnInit();
               } else {
                   this.common.presentToast('res.error');
               }
             }, err => {
               console.log(err);
               this.common.presentToast('Connection Error');
             });
           }
         }
         async editnewevent_customer(){
          this.btnstate = true;
          this.Eventforme.customer_id = localStorage.getItem('UserId');
          if (this.Eventform.instructor_id == null || this.Eventform.instructor_id == '') {
           this.common.presentToast('Enter instructor');
         }
           else if (this.Eventforme.title == null || this.Eventforme.title == '') {
             this.common.presentToast('Enter title');
           }
           else if (this.Eventforme.duration[0] == null || this.Eventforme.duration[0] == '') {
             this.common.presentToast('Enter start time');
           }
           else if (this.Eventforme.duration[1] == null || this.Eventforme.duration[1] == '') {
             this.common.presentToast('Enter end time');
           }
           else {

             this.web.postData('editconsultant_customer', this.Eventforme).then((res) => {

               if (res.status == '200') {

                 this.common.presentToast('Event edited Successfully');
                 window.location.reload();
                 this.ngOnInit();
               } else {
                   this.common.presentToast('res.error');
               }
             }, err => {
               console.log(err);
               this.common.presentToast('Connection Error');
             });
           }
         }
    async get_customer() {
      let data = {
        instructor_id: localStorage.getItem('UserId'),
      }
      await this.web.postData('trainee',data).then((res) => {
        if (res.status == '200') {
          console.log(res.data,"getallrequestfromcustomer");
          console.log(res.data.notification,"notify");
                  this.alldata=res.data;

          // this.request=false;

          // this.accepet_request(res.data.customer_id);
        } else {


        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
    }
//consultant service for instructor
    async get_consultant_instrutor() {
      let data = {
        instructor_id: localStorage.getItem('UserId'),
      }
      await this.web.postData('get_consultant_instructor',data).then((res) => {
        if (res.status == '200') {
          console.log(res.data,"get_consultant_instrutor");
                  this.data_consultant=res.data;
                  let array = [];
                  this.data_consultant.map((res,i)=>{
                    console.log(res,"pushhh");
                    console.log(i,"pushhh");
                     let obj={};
                     obj["start"]= new Date(res.start* 1000);
                     console.log(new Date(res.start * 1000),"pushhhstart")

                    //  obj["end"]=addDays(new Date(), 1);
                     obj["end"]=(new Date(res.end * 1000));
                     obj["title"]=res.title;
                     obj["actions"]=this.actions;
                     obj["allDay"]=true;
                     obj["web_id"]=res.web_id;
                     obj["instructor_id"]=res.instructor_id;
                     obj["color"]={...colors.yellow};
                     array[i]=obj;
                  })
                this.events = array;
                console.log( this.events," this.eventArray");


        } else {



        }
      }, err => {
        console.log(err);
        console.log(":)")
      })
    }
    //customer
  async get_instructor() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type')
    }
    await this.web.postData('trainer',data).then((res) => {
      if (res.status == '200') {
        // console.log(res.data.notification,"notify");
        this.data_customer=res.data;
              console.log(res.data_customer,"cust");

        console.log(this.data_customer,"get_instructor");

        // this.request=false;

        // this.accepet_request(res.data.customer_id);
      } else  {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  async Editevent_cus(currentevent:any){

    let data = {
      user_id: localStorage.getItem('UserId'),
      type: localStorage.getItem('type'),
      event_id:currentevent.web_id,
    }
    this.web.postData('geteditcustomerconsultDetails',data).then((res) => {
      if (res.status == '200') {
        this.Eventforme = res.data;
        console.log(this.Eventforme,"edit value")

      } else {
        console.log(res.error);
      }
    }, err => {
      console.log(err);
    this.common.presentToast('Connection Error.');
    });


  }
  //consultant service for customer

  async get_consultant_customer() {
    let data = {
      customer_id: localStorage.getItem('UserId'),
    }
    await this.web.postData('get_consultant_customer',data).then((res) => {
      if (res.status == '200') {
        console.log(res.data,"get_consultant_customer");
                this.cus_consultant=res.data;
                this.data_consultant=res.data;
                let array = [];
                this.data_consultant.map((res,i)=>{
                  console.log(res,"pushhh");
                  console.log(i,"pushhh");
                   let obj={};
                   obj["start"]= new Date(res.start* 1000);
                   console.log(new Date(res.start * 1000),"pushhhstart")

                  //  obj["end"]=addDays(new Date(), 1);
                   obj["end"]=(new Date(res.end * 1000));
                   obj["title"]=res.title;
                   obj["actions"]=this.actions;
                   obj["allDay"]=true;
                   obj["web_id"]=res.web_id;
                   obj["customer_id"]=res.customer_id;
                   obj["color"]={...colors.yellow};
                   array[i]=obj;
                })
              this.events = array;
              console.log( this.events," this.eventArray");

      } else {


      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
async cancel(){
  this.Eventform=[];
  this.ngOnInit();
}

}
