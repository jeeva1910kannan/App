import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParticipationWaiverComponent } from './participation-waiver.component';
import { ParticipationWaiverRoutingModule } from './participation-waiver.routing.module';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';


@NgModule({
  declarations: [
    ParticipationWaiverComponent
  ],
  imports: [
    CommonModule,
    ParticipationWaiverRoutingModule,
    HeaderFooterModule,
    FormsModule,
    MatCheckboxModule,
    MatInputModule,
  ]
})
export class ParticipationWaiverModule { }
