import { AfterViewInit, Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { WebService } from '../../../../src/app/providers/web.service';
import { CommonService } from '../services/common.service';
import { MatDialog } from '@angular/material/dialog';
import { PopupComponent} from './pop-up';



@Component({
  selector: 'app-participation-waiver',
  templateUrl: './participation-waiver.component.html',
  styleUrls: ['./participation-waiver.component.scss']
})
export class ParticipationWaiverComponent implements AfterViewInit {

  @Input() name: 'Angular';
    
  @ViewChild('sigPad') sigPad: ElementRef;
  sigPadElement: HTMLCanvasElement;
  context: CanvasRenderingContext2D;
  isDrawing = false;
  img: string;

  ngAfterViewInit() {
    this.sigPadElement = this.sigPad.nativeElement;
    this.context = this.sigPadElement.getContext('2d');
    this.context.strokeStyle = '#3742fa';
    
  }

  @HostListener('document:mouseup', ['$event'])
  onMouseUp(e) {
    this.isDrawing = false;
  }

  onMouseDown(e) {
    this.isDrawing = true;
    const coords = this.relativeCoords(e);
    this.context.moveTo(coords.x, coords.y);
  }

  onMouseMove(e) {
    if (this.isDrawing) {
      const coords = this.relativeCoords(e);
      this.context.lineTo(coords.x, coords.y);
      this.context.stroke();
    }
  }

  private relativeCoords(event) {
    const bounds = event.target.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    return { x: x, y: y };
  }

  clear() {
    this.context.clearRect(0, 0, this.sigPadElement.width, this.sigPadElement.height);
    this.context.beginPath();
  }


  formDetails: any={}
  checkboxValues: string[] = [];
  otherInputValid = false;
  

 
  constructor(private web: WebService,
    public common: CommonService,
    public dialog: MatDialog) { }

    private isSignatureEmpty() {
      const signatureData = this.context.getImageData(
        0,
        0,
        this.sigPadElement.width,
        this.sigPadElement.height
      ).data;
  
      // Loop through the signature data and check if any non-transparent pixel exists.
      for (let i = 0; i < signatureData.length; i += 4) {
        const alpha = signatureData[i + 3];
        if (alpha !== 0) {
          return false; // Signature is not empty.
        }
      }
  
      return true; // Signature is empty.
    }
    generateReferenceCode(): string {
      const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      const numbers = '0123456789';
    
      let referenceCode = '';
      
      // Generate the first 8 characters using uppercase letters
      for (let i = 0; i < 8; i++) {
        const randomIndex = Math.floor(Math.random() * alphabet.length);
        referenceCode += alphabet.charAt(randomIndex);
      }
      
      // Append 'IS' to the reference code
      referenceCode += 'IS';
      
      // Generate the last 2 characters using numbers
      for (let i = 0; i < 2; i++) {
        const randomIndex = Math.floor(Math.random() * numbers.length);
        referenceCode += numbers.charAt(randomIndex);
      }
      
      return referenceCode;
    }
    

    updateCheckboxValue(value: string) {
      if (value === 'other') {
        if (!this.formDetails.otherChecked) {
          // Clear the custom value and remove it from checkboxValues
          this.formDetails.otherText = '';
          
        } else {
          if (this.formDetails.otherText && this.formDetails.otherText.trim() !== '') {
            this.checkboxValues.push(this.formDetails.otherText.trim());
          }
        }
      } else {
        if (this.checkboxValues.includes(value)) {
          this.checkboxValues = this.checkboxValues.filter(item => item !== value);
        } else {
          this.checkboxValues.push(value);
        }
      }
    
      this.otherInputValid =
        !this.formDetails.otherChecked || (this.formDetails.otherText && this.formDetails.otherText.trim() !== '');
    }
    
    
    
    
   
    
    async submitForm() {
      console.log(this.formDetails.otherChecked,"this.formDetails.otherChecked");
      this.img = this.sigPadElement.toDataURL("");
      console.log( this.checkboxValues," this.checkboxValues");
      console.log(this.formDetails,"formDetails")
      if (this.formDetails.first_name == null || this.formDetails.first_name == '') {
        this.common.presentToast('Enter your First name');
      }
      else if (this.formDetails.otherChecked == true && ( this.formDetails.otherText == '' || this.formDetails.otherText==null)) {
            this.common.presentToast('Enter your Other text');
        
          } 
       else if (this.formDetails.middle_name == null || this.formDetails.middle_name == '') {
        this.common.presentToast('Enter your Middle name');
    
      }  else if(this.formDetails.last_name == null || this.formDetails.last_name == '') {
        this.common.presentToast('Enter your Last name');
      }
     else if (this.formDetails.birthdate == null || this.formDetails.birthdate == '') {
      this.common.presentToast('Enter your Birthdate');
      }
    else if (this.formDetails.guardian_fname == null || this.formDetails.guardian_fname == '') {
      this.common.presentToast('Enter your Guardian First name');
    }
    else if (this.formDetails.guardian_mname == null || this.formDetails.guardian_mname == '') {
      this.common.presentToast('Enter your Guardian Middle name');
    }
    else if (this.formDetails.guardian_lname == null || this.formDetails.guardian_lname == '') {
      this.common.presentToast('Enter your Guardian Last name');
    }
    else if (this.formDetails.email == null || this.formDetails.email == '') {
      this.common.presentToast('Enter your Email');
    }
    else if(this.common.validateEmail(this.formDetails.email)==false){
      this.common.presentToast('Enter valid Email address');
    }
    else if (this.formDetails.phone == null || this.formDetails.phone == '') {
      this.common.presentToast('Enter your Phone');
    }
    else if (this.formDetails.otherChecked && this.formDetails.otherText.trim() === '') {
      // Input field is not valid, handle the validation error (e.g., display an error message)
      return;
    }
    else if (this.isSignatureEmpty()) {
      this.common.presentToast('Enter your Sign');
      return;
    }
      else{
        {
          const formData = {
            first_name: this.formDetails.first_name,
            middle_name: this.formDetails.middle_name,
            last_name: this.formDetails.last_name,
            birthdate: this.formDetails.birthdate,
            guardian_fname: this.formDetails.guardian_fname,
            guardian_mname: this.formDetails.guardian_mname,
            guardian_lname: this.formDetails.guardian_lname,
            email: this.formDetails.email,
            phone: this.formDetails.phone,
            checkboxOptions:this.checkboxValues,
            sign: this.img,
            referencecode:this.generateReferenceCode()
          };
         console.log(formData,"formData");
          
          this.web.postData('contactform', formData).then(res => {
            if (res.status == '200') {
              const myCompDialog = this.dialog.open(PopupComponent, { data: { referencecode: formData.referencecode } });

          
              myCompDialog.afterClosed().subscribe((res) => {
                this.formDetails="";
                this.checkboxValues =[];
                this.clear();
                // Data back from dialog
                console.log(formData.referencecode, "formmmmm");
              });
          
              console.log("FAillllll");
              //  this.common.presentToast(res.error);
              //   localStorage.setItem('divinkUserDetails', JSON.stringify(res.data));
            } else {
              console.log("FAillllll");
              this.common.presentToast(res.error);
            }
          }, err => {
            this.common.presentToast('Connection Error');
          });
        }
      }
      
    }
  ngOnInit(): void {
  }

}
