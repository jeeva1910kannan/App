import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { ParticipationWaiverComponent } from './participation-waiver.component';

const routes: Routes = [
  {
    path: "",
    component: ParticipationWaiverComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class ParticipationWaiverRoutingModule { }