
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.html',
  styleUrls: ['./participation-waiver.component.scss']
})
export class PopupComponent implements OnInit{
    ref:any;
    constructor(@Inject(MAT_DIALOG_DATA) public data: any) {
      console.log(data, "data");
      console.log(data.referencecode, "referencecode");
    }
    
 

    ngOnInit(): void {
      this.ref = this.data.referencecode;
      console.log(this.ref, "ref");
    }

  
}
