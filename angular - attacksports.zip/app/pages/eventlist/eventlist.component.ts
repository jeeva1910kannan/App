import { Component, OnInit } from '@angular/core';

import { CommonService } from '../services/common.service';
import { WebService } from './../../providers/web.service';
import { environment } from './../../../environments/environment';
import { Router } from '@angular/router';
import {MatDialog} from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-eventlist',
  templateUrl: './eventlist.component.html',
  styleUrls: ['./eventlist.component.scss']
})
export class EventlistComponent implements OnInit {
  base_url: string = environment.base_url;
  nodata: boolean = false;
  live: boolean = false;
  eventss: any;
  search: boolean = false;
  constructor(private web: WebService, private router: Router,
    public common: CommonService,public dialog: MatDialog) { }
  events: any;
  eventslist: any
  i: number;
  searchvalue: any;
  card: any;
  Transaction: any;
  event:any;
  transevent:any;
  transaction1: any;

  ngOnInit(): void {

    this.getallevents();

  }

  async getallevents() {
    await this.web.getData('getallevents').then((res) => {
      if (res.status == '200') {
        this.eventslist = res.data;
        for (var value of this.eventslist){
          const currentdate = new Date();
          value.new = new Date(value.end_time * 1000);
          console.log(currentdate,"curerent date");
          //localStorage.setItem('event_id',value.event_id)
          if (value.new < currentdate) {
            //localStorage.setItem('event_id',value.event_id)
            console.log(value.new, "Ranjith:(");
            let data = {
              event_id:value.event_id
             };
             this.web.postData('changeeventstatus', data).then((res) => {
               if (res.status == '200') {
                 this.events = res.data;
         
               } else {
                 console.log(":(")
               }
             }, err => {
               console.log(err);
               console.log(":)")
             })
          }
          else{
       
            this.nextget();

          }
    
        }
      } else {
        this.nodata = true;
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  async getsearch(){
   
    let data = {
      search_value: this.searchvalue,
      // email:this.email
    }
      this.web.postData('serachResult',data).then(res => {
        console.log(res,"assinn")
      if (res.status == '200') {
        this.eventss= res.data;
        console.log(this.eventss,"events search");

this.search=true;
    
  
  
      }else if(res.status=="300"){
        this.common.presentToast(res.error)
      }else if(res.status=="400"){
        this.common.presentToast(res.error)
  
              console.log(res,"400");
  
      }
    })
   }
  async nextget(){
    await this.web.getData('getallevents').then((res) => {
      if (res.status == '200') {
        this.events= res.data;

      } else {
        this.nodata = true;
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    })
  }
  async findstart(startdate: any) {
    this.events.newstart = new Date(startdate * 1000);
    const currentdate = new Date();
    if(this.events.newstart<currentdate){
    this.live=true;
    }
    else{
      this.live=false;
    }
  }
  async findend(enddate: any) {
    this.events.newend = new Date(enddate * 1000);

  }
  selectedevent(data: any) {

    this.event = localStorage.getItem('eventid');
    const script = document.createElement('script');
    script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
    document.head.appendChild(script);
    //console.log("coupon");
    
    //localStorage.setItem('transaction1',this.transaction1)
   
    localStorage.setItem('eventid',data.event_id)
    let details={
     event: data.event_id,
      customer_id: localStorage.getItem('UserId'),
     email: localStorage.getItem('email')
     
    }
    this.web.postData('eventregisterdetails',details).then((res) => {
      if (res.status == '200') {
        this.transaction1 = res.data;
        this.transevent = this.transaction1[0];
        console.log(this.transevent,'transevent');
        console.log(this.event,'event');
        localStorage.setItem('Transaction', res.data[0]);
        // if(this.transaction1.event_id == data.event_id){
        //   localStorage.setItem('transaction1.event_id ',this.transaction1.event_id)
        // }
        this.transaction1.map((res, i) => {

          //console.log(res.result_price,'67667')
          if(res.event_id == data.event_id){
            localStorage.setItem('transaction1.event_id ',res.event_id)
          }
         });
        //this.couponcode = res.data[0];
        //this.faqquiz = res.data.slice(1);
       
        //console.log(this.couponcode);
               } else {
        console.log(":(")
      }
    }, err => {
      console.log(err);
      console.log(":)")
    });
    //console.log(this.couponcode);
    console.log("fdjhgjdf");
    
    this.router.navigate(['/eventcontent', data.event_id]);
  }
 
} 
