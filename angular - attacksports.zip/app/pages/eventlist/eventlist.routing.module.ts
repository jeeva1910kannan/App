import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { EventlistComponent } from './eventlist.component';

const routes: Routes = [
  {
    path: "",
    component: EventlistComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
// @ts-ignore
export class EventlistRoutingModule { }