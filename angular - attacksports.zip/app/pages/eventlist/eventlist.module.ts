
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import{ EventlistRoutingModule} from './eventlist.routing.module'
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { EventlistComponent } from './eventlist.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
  EventlistComponent
  ],
  imports: [
    HeaderFooterModule,
    RouterModule,
    EventlistRoutingModule,
CommonModule,
FormsModule   
  ]
})
export class EventlistModule { }

