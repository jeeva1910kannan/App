import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventRegisterUserRoutingModule } from './event-register-user-routing.module';
import { EventRegisterUserComponent } from './event-register-user.component';
import { RouterModule } from '@angular/router';
import { HeaderFooterModule } from '../../header-footer/header-footer.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    EventRegisterUserComponent
  ],
  imports: [
    CommonModule,
    EventRegisterUserRoutingModule, HeaderFooterModule,
    RouterModule,
    CommonModule,
    FormsModule   
  ]
})
export class EventRegisterUserModule { }
