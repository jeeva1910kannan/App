import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventRegisterUserComponent } from './event-register-user.component';

describe('EventRegisterUserComponent', () => {
  let component: EventRegisterUserComponent;
  let fixture: ComponentFixture<EventRegisterUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventRegisterUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventRegisterUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
