import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { LoaderService } from '../../../providers/loader.service';
import { CommonService } from '../../services/common.service';

import { WebService } from 'src/app/providers/web.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  passwordForm: any;

  constructor(
    private loaderService: LoaderService,
    public common: CommonService,

    private activateRoute: ActivatedRoute,
    private web: WebService,
    private router: Router
  ) {
    this.loaderService.stopLoader();
  }

  ngOnInit() {
    this.buildForm();
    this.activateRoute.queryParamMap.subscribe((obj: any) => {
      console.log('parmas', obj.params.v_token);
      this.passwordForm.get('token').setValue(obj.params.v_token);
    });
  }

  buildForm() {
    this.passwordForm = new FormGroup({
      token: new FormControl(''),
      new_pass: new FormControl('', [Validators.required]),
      confirm_pass: new FormControl('', [Validators.required]),
    });
  }

  onSubmit() {
    if (this.passwordForm.valid && (this.passwordForm.get('new_pass').value === this.passwordForm.get('confirm_pass').value)) {
      console.log('value', this.passwordForm.value);
      this.web.postData('resetnewPassword', this.passwordForm.value).then((res) => {
        if (res.status == '200') {
          this.common.presentToast(res.error);
       //   this.alert.successMsg(res.error, '');
          localStorage.setItem('UserDetails', JSON.stringify(res.data));
          localStorage.setItem('UserId', res.data.web_id);
         
          this.router.navigate(['/login']);
        } else {
          this.common.presentToast(res.error);
     //     this.alert.errorMsg(res.error, '');
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error');
       // this.alert.errorMsg('Connection Error', '');
      });
    } else {
      this.common.presentToast('Check if all fields are filled properly and then try')
   //   this.alert.warningMsg('Check if all fields are filled properly and then try', '');
    }
  }

}
