import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { ResetPasswordComponent } from './reset-password.component';
import { ResetPasswordRoutingModule } from './reset-password-routing.module';
import { RouterModule } from '@angular/router';

import { HeaderFooterModule } from '../../../header-footer/header-footer.module';
import { MatSliderModule } from '@angular/material/slider';
import { MatTabsModule } from '@angular/material/tabs';
import {MatFormFieldModule} from '@angular/material/form-field';

import {MatInputModule} from '@angular/material/input'
@NgModule({
  declarations: [
    ResetPasswordComponent
  ],
  imports: [
    ResetPasswordRoutingModule,
    CommonModule,
    FormsModule,

    ReactiveFormsModule,  HeaderFooterModule,
    MatSliderModule,
    MatTabsModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    RouterModule,
    ReactiveFormsModule
  ],
})
  // @ts-ignore
export class ResetPasswordModule { }
