import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { ForgotpasswordComponent } from './forgotpassword.component';
import { ForgotPasswordRoutingModule } from './forgotpassword-routing.module';

import { RouterModule } from '@angular/router';

import { HeaderFooterModule } from '../../../header-footer/header-footer.module';
import { MatSliderModule } from '@angular/material/slider';
import { MatTabsModule } from '@angular/material/tabs';
import {MatFormFieldModule} from '@angular/material/form-field';

import {MatInputModule} from '@angular/material/input';

@NgModule({
  declarations: [
    ForgotpasswordComponent
  ],
  imports: [
    ForgotPasswordRoutingModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HeaderFooterModule,
    MatSliderModule,
    MatTabsModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    RouterModule,
    ReactiveFormsModule
  ],
})
  // @ts-ignore
export class ForgotPasswordModule { }
