import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from '../../../providers/loader.service';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/providers/web.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.scss']
})
export class ForgotpasswordComponent implements OnInit {
  forgotForm: any;

  constructor(
    private loaderService: LoaderService,
    public common: CommonService,
    private web: WebService
  ) {
    this.loaderService.stopLoader();
  }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.forgotForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(
        /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
      ),])
    })
  }

  onSubmit() {
    if (this.forgotForm.valid) {
      console.log('value', this.forgotForm.value);

      this.web.postData('forgotPassword', this.forgotForm.value).then((res) => {
        if (res.status == '200') {
          this.common.presentToast(res.error);
         // this.alert.successMsg(res.error, '');
          this.forgotForm.reset();
        } else {
          this.common.presentToast(res.error)
      
        }
      }, err => {
        console.log(err);
        this.common.presentToast('Connection Error')
     
      });
    } else 
    {
      this.common.presentToast('Check if all fields are filled properly and then try')
    //  this.alert.warningMsg('Check if all fields are filled properly and then try', '');
    }
  }

}
