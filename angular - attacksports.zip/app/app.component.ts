import { Component } from '@angular/core';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
//localStorage.setItem('UserId',null);
declare let jQuery:any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  editor = ClassicEditor;
  
  title = 'attack-sports';
  ngOnInit(): void {
  }
  
  onActivate(event) {
    if(!localStorage.getItem('UserId')){
      localStorage.setItem('UserId',null);
    }
    //localStorage.setItem('UserId',null);
    console.log(event,"eventttt")
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0, pos - 20); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 16);
}

}
