import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class AzaFinanceService {
  private apiUrl = 'https://api-sandbox.transferzero.com/v1';
  private apiKey = 'SOqo30eh+hmh4EA5v1f8TJNTiIsUS+8tfIuRM5pxUZgYhmoZJoyya32+JayNtzyMk4XsDbComvUUnDHu7AeQwQ==';
  private apiSecret = 'raVLIoeCUUhtGVQ/jM2yvO9B6W1e9/VUyFOUKA9yYj2A/olV7tLUPY+T8xWXaWjZishtDjaNpR0Larws3OyMXg==';

  constructor(private http: HttpClient) { }

  postAccountValidations(accountValidationRequest: { bank_account: string; bank_code: string; country: string; currency: string; method: string; }) {
    const nonce = Math.floor(Math.random() * 1000000);
    const timestamp = Math.floor(Date.now() / 1000);
    const requestBody = JSON.stringify(accountValidationRequest);

    const signatureData = `${nonce}${timestamp}${requestBody}`;
    const signature = CryptoJS.HmacSHA256(signatureData, this.apiSecret).toString();

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'AuthorizationKey': this.apiKey,
      'AuthorizationNonce': nonce.toString(),
      'AuthorizationSignature': signature,
    });

    return this.http.post(`${this.apiUrl}/account_validations`, accountValidationRequest, { headers });
  }
}
