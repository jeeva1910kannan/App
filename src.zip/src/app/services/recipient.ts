export class Recipient{
    recipient_id: number = 0
    recipient_name:string = '';
    phone:string = '';
    country_code:string = ''
    banking_method:string;

    // Mobile Money
    cashout_fee!:boolean;

    // Bank
    bank_name!:string;    
    bank_acc_number!:string;

    //Cash
    address_one!:string;
    address_two!:string;    
    city!:string;
    country!:string;

    constructor(banking_method:string){
        this.banking_method = banking_method;
        if(banking_method == 'Mobile Money'){
            this.cashout_fee = false
        }
        if(banking_method == 'Bank'){
            this.bank_name = ''
            this.bank_acc_number = ''
        }
        if(banking_method == 'Cash'){
            this.address_one = ''
            this.address_two = ''
            this.city = ''
            this.country = ''
        }
    }
}