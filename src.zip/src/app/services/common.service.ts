import { Injectable } from '@angular/core';
import { LoadingController, ToastController } from '@ionic/angular';
import * as IBAN from 'iban';


@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private toast : ToastController, private loadingController:LoadingController) { }


  async presentToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 2500,
      position: "bottom",
      animated: true,
      cssClass:'toast-app',
      buttons: [
        {
          text: 'X',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }

  isValidEmail(email: string): boolean {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(email);
  }

  isValidPhoneNumber(phonenumber: string) : boolean{
    const numberPattern = /^[0-9\s]*$/;
    return numberPattern.test(phonenumber)
  }

  isValidAccountNumber(accountnumber:string) : boolean{
    if(IBAN.isValid(accountnumber)){
      return true
    }else{
      return false
    }
    // const pattern1 = /^[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){1,7}$/;
    // const pattern2 = /^[A-Z]{2}\d{2}[A-Z0-9]{1,30}$/
    // const pattern3 = /^[A-Z]{2}\d{2}(?:-[A-Z0-9]{4}){1,7}$/
    // return (pattern1.test(accountnumber) || pattern2.test(accountnumber) || pattern3.test(accountnumber))
  }

  
  async presentLoading(duration = 600000) {
    let msg:string = 'Please wait...'
    const loading = await this.loadingController.create({
      message: msg,
      spinner: "circular",
      duration: duration,
      translucent:false,
      mode : 'ios',
      cssClass: 'custom-loading',
    });
    await loading.present();
  }

  async closeLoading() {
    //console.log(this.loadingController.getTop());
    //   this.loadingController.dismiss();
    setTimeout(async () => {
      try {
        let topLoader = await this.loadingController.getTop();
        while (topLoader) {
          if (!(await topLoader.dismiss())) {
            throw new Error(
              "Could not dismiss the topmost loader. Aborting..."
            );
            //console.log('Error aborting');
          }
          topLoader = await this.loadingController.getTop();
        }
      } catch (e) {
        console.log("problem with loader");
      }
    }, 500);
  }


  async presentLoadingconfirm(duration = 60000) {
    let msg:string = 'Verifying...'
    const loading = await this.loadingController.create({
      message: msg,
      spinner: 'circular',
      duration: duration,
      translucent:false,
      mode : 'ios',
      cssClass: 'custom-loading',
    });
    await loading.present();
  }

  async closeLoadingconfirm() {
    //console.log(this.loadingController.getTop());
    //   this.loadingController.dismiss();
    setTimeout(async () => {
      try {
        let topLoader = await this.loadingController.getTop();
        while (topLoader) {
          if (!(await topLoader.dismiss())) {
            throw new Error(
              "Could not dismiss the topmost loader. Aborting..."
            );
            //console.log('Error aborting');
          }
          topLoader = await this.loadingController.getTop();
        }
      } catch (e) {
        console.log("problem with loader");
      }
    }, 500);
  }


}
