import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable,throwError } from 'rxjs';
import { catchError,map } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class WebService {

  baseurl:string = environment.apiurl;

  apiLayer:string = "https://api.apilayer.com/currency_data/convert"

  private apiUrl = 'https://api.freecurrencyapi.com/v1/latest?apikey=fca_live_iA8Sr1JZQCuy3PnmCaanBW5iiBKqR88aNlxigrGx';


  constructor(private http: HttpClient) { }

  getExchangeRates(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getData(controller: string,): Observable<any> {
    return this.http.get(`${this.baseurl}${controller}`,  {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    }).pipe(
      map((response: any) => {
        console.log('get request successful:', response);
        return response;
      }),
      catchError((error: any) => {
        console.error('Error making get request:', error);
        return throwError(error);
      })
    );
  }




  postData(controller: string, data: any): Observable<any> {
    return this.http.post(`${this.baseurl}${controller}`, { ...data }, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    }).pipe(
      map((response: any) => {
        console.log('POST request successful:', response);
        return response;
      }),
      catchError((error: any) => {
        console.error('Error making POST request:', error);
        return throwError(error);
      })
    );
  }

  cashoutFee(to:string): Observable<any>{
    return this.http.get(`${this.apiLayer}?to=${to}&from=XAF&amount=195`,{
      headers : new HttpHeaders({
        'apiKey' : environment.currencyApiKey
      })
    }).pipe(
      map((response: any) => {
        console.log('get request successful:', response);
        return response;
      }),
      catchError((error: any) => {
        console.error('Error making get request:', error);
        return throwError(error);
      })
    );
  }

}


