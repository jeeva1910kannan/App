import { Injectable } from '@angular/core';
import * as pdfMake from 'pdfmake/build/pdfmake';
// import * as pdfFonts from 'pdfmake/build/vfs_fonts';
// (pdfMake as any) = pdfFonts.pdfMake.vfs;
// import { }
import { FileOpener } from '@capacitor-community/file-opener';
import { Platform } from '@ionic/angular';
// import { Plugins } from '@capacitor/core';

// const { pdf } = Plugins;
// import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
// import { Capacitor } from '@capacitor/core';
// declare var cordova:any
import { PDFGenerator } from '@awesome-cordova-plugins/pdf-generator/ngx';
@Injectable({
  providedIn: 'root'
})
export class PdfService {
  

  constructor(private plt:Platform,private pdfGenerator:PDFGenerator) { }

  // generatePDF() {
  //   const documentDefinition = {
  //     content: [
  //       'Hello, this is a PDF generated with pdfmake!',
  //     ],
  //   };

  //   let pdfDocGenerator = pdfMake.createPdf(documentDefinition);
  //   if(this.plt.is('capacitor')){
  //     pdfDocGenerator.getBase64(async (data) => {
       
  //         try{
  //           let path = 'demo/demopdf.pdf';
  //           const result = await Filesystem.writeFile({
  //             path,
  //             data: data,
  //             directory : Directory.Documents,
  //             recursive : true
  //           })
  //           FileOpener.open({
  //             filePath : `${result.uri}`,
  //             contentType: 'application/pdf',
  //             openWithDefault : true
  //           })
  //         }          
  //        catch(err){
  //         console.log(err)
  //       }
  //     })
  //   }
  // }

  generatePDF(){
    let html = `<!DOCTYPE html>
    <html>
      <head>
          <style>
              body{
                  padding: 25px;                        
              }
              .header{
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
              }
              .logo-container{
                  width: 20%;
              }
              .heading{
                  margin: 30px 0;
              }
              .footer{
                margin : 30px 0
              }
              .center{
                text-align: center;
              }
          table
          {
          margin : 30px 0
          font-family: arial, sans-serif; 
          border-collapse: collapse; 
          width: 100%;
          }
          td
          {
          border: 1px solid #dddddd; 
          text-align: left; 
          padding: 8px;
          font-size: 16px;
          }
          p{
              font-size: 16px;
          }

          .footer > p{
              text-align: center;
          }
          
          </style>
        
      </head>
      <body>
          <div class="header">
              <div class="logo-container center">
                  <img src="${this.logo}" alt="">
              </div>
              <div class="date">
                  <p><b>23-07-07</b></p>
              </div>
          </div>
          <div class="heading">
              <h2>Transaction Confirmation Receipt</h2>
          </div>
          <table>                                   
            <tr>
                <td>Sender</td>
                <td>Bernard Kamdoum Djoko</td>
            </tr>
            <tr>
                <td>Sender Phone Number</td>                      
                <td>248-485-8392 x7960</td>
            </tr>
            <tr>
              <td>Sender Address</td>                      
              <td>655 Abbott Stravenue, Anikaville, South Carolina, USA</td>
            </tr>
            <tr>
                <td>Recipient Name</td>
                <td>
                  Bernard Kamdoum orange
                </td>
                
            </tr>
            <tr>
                <td>Recipient Phone Number</td>
                <td>+237 6 55 52 70 22</td>
                
            </tr>
            <tr>
                <td>Transfer Amount</td>
                <td>$2.23</td>
                
            </tr>
            <tr>
              <td>Transfer Fee</td>
              <td>
                  $0.00
              </td>
              
          </tr>
          <tr>
              <td>Total Charged </td>
              <td>
                  $2.23
              </td>
              
          </tr>
          <tr>
              <td>Exchange Rate </td>
              <td>
                  $1 = FCFA 447
              </td>
              
          </tr>
          <tr>
              <td>Total to Recipient </td>
              <td>
               FCFA 1,000
              </td>
              
          </tr>
          <tr>
              <td>Transfer Date </td>
              <td>
               23-07-06 20:19 EDT
              </td>
              
          </tr>
        
          <tr>
              <td>Transaction ID</td>
              <td>
               1502047201696682512
              </td>
              
          </tr>
          </table>
          <div class="footer">
              <p class="foot-para">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestias distinctio fuga ipsa perspiciatis illo unde vero at consectetur quis repellendus?</p>
              <p class="foot-para">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestias distinctio fuga ipsa perspiciatis illo unde vero at consectetur quis repellendus?</p>
          </div>
      </body>
  </html>`

  var filename = 'statement-of-account';
      let options:any = {
        documentSize: "A4", landscape: "portrait", type: "share" ,fileName: filename+'.pdf'             
      };
      this.pdfGenerator.fromData(html,options).then(() => console.log('ok')).catch((err:any)=>console.log(err))
  }





  logo:string = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAB7CAYAAABaS9Y5AAAABHNCSVQICAgIfAhkiAAAIABJREFUeJzsnXd4FNXXx78zszW9956QkIRUQg0IoRcBRQhNRURERVAUpFjyRrHSmwqK/AQEDL33HgglDUIgIYX03uu2mfv+EYKoJNndbAq4n+dZH9zM3ntmZ3bOvadS0KJFixYtzwyEEGr9+vX6OjpMD4ri+9laWY5naJngevTtzz7/fNnp9pSFas/JtGjRokXLX4wdOzbIwsLC2NbWthZQcLq6hjKhvlAmpIQcy7IEAKqrqwXV9dX8bt4ulpSC6yfgC1wNTfT7MgzfVCaViCiag6ODPSoqahMuX0kftGDB7JL2kp/XXhNp0aJFi5a/4+DqIDU2MPQDLVtqaaprbGlpyIISszoiA+gb6hFjEyE4BUWfPnOZl5pyn+rq4QZdAz5kMilMTfno5uUMQyMTXDh3DWI9I5/aqoJeAI61l/x0e02kRYsWLVr+zobVGxKsLGx+Pn38XEbU1VsoKy1geIxcQFFyAZ8hQmsrC2E3X1d+RkYadT8xHbX1NZArJLCyNoN3N3eYmhuCx6fg7OaAqqpyyDmJsD3lZ9pzMi1atGjR8neOHz8u++GL5fvKqqui8wtLbZJT7zvoG/LB4xPIJASmZrowNtJDZno+rK3MIRYZQl/XEEaGuhAIGFAUUJBfjNLScji5up/4Y8fu2+0lu9aEpUWLFi0dzNTZU0sA7Fm9el35jevnfueBby2XEqqyshbpqZkIDPRC6oNsJN9PQ1APfdTW1kBSL4VIh4KAFqC2th5CkRAKDm7/HHvVqlXinNKcgB7dfPKmTJmRoUm5tU50LVq0aOlELFiwQDczO2MTReqmTZ00AZ5eXrCyMQZDy3H86BWcO3sVg4b0Qdeu7nB1s4Guni5uRMWhtk6Kyhpu6/iXpr4JAGERYQJJjGRkZlX8x5RRRX9plbBKRAzjFHXMhd6+L1ysrKyMCg8Pl7VGVq0JS4sWLVo6EdeuXZO/Om1yvkisS0ukClJaXGItFApgbGyOgO7+sLU1RXLSQ+jq6sDNzRE0zUGhUODqlUh0dfPwcnXyKHDzd7XPSUveRNk+/MSpu8iR0gHcAw2F1l60k8BUOjA1O+G1opKSwYE9esp6BfZJjYmJkf9Tjrlz5wqnT3/LZ/z4EXqHDx8ve5qs2h2IFi1atHRSXpkyxZvPSrf3eyHQw9/PX8fSUg9m5vpIupePrKwseHo5w8vLGwyPxtbNO3DyUiQ4gYQIzOSUg78urNwMwAkqQEv54BQKUBTAE4lRV0Jw63IOjK3kKLxLxdqL+36zce3GfQCwdfPmHoZmeu9aWloGWFhYdJNIq6pPnjj3/sKFX+z8p3xaBaJFixYtnZj58+eLS0tLTQiRhTM03hw+LIRydXOCTFIPmuajqrYG566fR35NGsRmfMi5ehiYAoTQkNUC5o76MLECwMoBCpAxLBSVfMSeKoaOiIGzRSD4ErPNemKdnY72NnMszA3HULRCpJAxqJfWQ0dPBB1dpjY9rXLMpEnTLjwpm1aBaNGiRcszQBgJo3PeynHhM/yZD1ITFlvYm4LoScEzkMDGSwgrdzEKk+UoKsiGyIQFBQo0J0ZtIR8ePc2hY8BCIVUgJ0OO7HgOdvru6OU9CKYmRpBJKyV8Hk8AKGhdXR6srC1haWUGsViIrOwCxMU9gFTGRUydPGPSkzJpFYgWLVq0dGJIBGE+vPHhEANHrl9GXpKDtFzWS9dC4WHeVRdG9gLoi3mgFArIQFCUSSE7NR865g2+cUIpICsSwauHIyT1dbhztgQFqQRD+45C316BAM1BIqmFmC+CjY0pXNysIRYbgOOAqop8MLQQ+kamiLxyB9k5eTkcJ+7z6quv5jTKpg3j1aJFi5ZODBVKsYvDFjomZJ6ZY+LIGssYAZyDHGFoL4O0nkBaJwNNAEJzMHfkQVZjjpKiYtB8gLAiGBqaITWuDHl3pBg3cDLsh1uD4fFQU1MKXR1deHm4wsHRCiwrR0VlGSoqylFVKUdudgZ0dQ1gZlYCQyM+snMYO0NDwwAAjxWIdgeiRYsWLc8Ay5d/5Xw3PX5xsaxomntfPV1zJwXEYgaEo0EIDZpHoCByCBhd1NdwqMyXoiRPgupCXoGB3DrBz7XrEEcHR0okpqFnoIsu7o4wNTVEZWU1Eu6koLysHBXlVSgpLYFUIgMhPFRXlUMkEkGsS4MienB27bp2Qui0Dxtl0ioQLVq0aHmGmDl3ZkBlbc5c6NeON+9CGdp7GIDHMCgpBIwsKNTX1yE3uRqVWUy5IbH908ezz/fO1lasWCg77+LaxY1lJXBwsENhYT6cnG2Ql1uKi+dvgBACvkAIPT09+Pp5obqqBsVFlSCQorCwCIYGRmA5JjYnr7L/7Nmz6wCtAtGiRYuWZ5IlS5Z4FUtzZ9Uo8qZBt86cZ1wLWaUYbKkwzU7fY4+jddctH330UWrj8d99F+agb6gzg5PXfO7n60MXFpZQwf19UV4mRVVVJdzcXMEwPBQU5EMkEsDAwBQAB4EAkMmA6qpqyBRs+ZEjN/ouWLAgCdAqEC1atGh5plm+fLlFSk7cZFa/rJeZrscZkQQHw8PXVjzt2AsXLoiioi46VVdXztbTM9TT1YUbzWOsGcJZ+/t5GdjaOeNuwn2YW5jgYWoGRowOwckTZ/HSK6NxcN9ZDB42AGfPRn81ZcprXwBaBaJFixYt/znmzp0rNDExYb29vUUAZLGxl5e4uFr+X2pqhqSrh5ewpLiQsrWyhqOLJYoKJNDRIzAzc0Jy0j24dumWXV+PviEhITnaKCwtWrRo+Y+xfv166aN/1gBAVFTUDzt3/o+YmdlGZefVmJWXVA0yMOC/9fNPl7Dsqw/x48ZdePtdbzxMz0G3bh72N27EvQ3gi7/vQCZGMP2FuRaTB/vY3XuYb0RTNGlOCI5wlLeHbZmdtYlk+dqjVYaW5qVHNzc4V55FJoZFCAT1lRZTRvY0uhH30LisolrU0ncAAD39XMqu3ntQaClPzw8PD+faQ1YtjwgLo0c/NLQeMsDXIeVhgT7DUE/9/jnCUU62llVeLmZVP+w4W14jNCyN2Tz7X/V/2ouwsDA6p8beXiQWeF+LfWialJZrXF8r5QOAWFco93a3Luvp51byIDXvztndn+QDVIv3obL4vrZcV0eisB7Wu6tjeVVdp7FCiEQMfS0qJfNqgCIFLfyO5odtd4tLyut18VK8pbuXk2Bgb3cTmUzx+O8MQ1G19fL63YeuV5oa69ePGxGQmp1bFn9m+8KiNj+Rf/Di25t0CJH4J97L9snKK9WbOq63oZDPiFlCHl9TgYCHs5H3S9Mf5MmHDvPP93a2vrEmfFp6e8vayKZNmwzv3o2bam3tkFlXk/6TvqGh+YPkzES3Lq4BmZmZzORJ4xOS7pa99vjmmTrvx+4nLt39vLZOOkAmZw1pmlLqxqJAgRBwBKTW2tKo0MJE766Hs80xOzPDgyvDp7Zba8XWMGPhb4FRMQ9mVNdK+xeUVLkSjtMFpYJ5jwB8PlNta2Vyk8+nVySf++5kG4qrMrPiN7jfKEu1G2zu474t+2JgqaRMz1xsTnwM7M0o0HRKbV5ZVk2+3MfYtWiAWbeEo/k306c59Uv92n16bkfL3hyh7/8UfPHa/aXl1bX9WQWnr8wVIxw4gYCpMjLQTTY30Tvj7Wm35c+172a0ubBPsHlnpPfyTYdXpueU9uc4TgcAnniWAACoRz8/mqKqfT3t9n/9xWvzRvXqUtWaeQkh1OR5P08/ffnukvLyakeax7Rr86GWIACIjJUPC/H9+PT2BeubOm7srLUfHTt3+1uW4wSgAMhYQCoD/vnIoihALARoCiAEYhG/wtnBfM2909+Et+2Z/EXItB+GJSblrC4qrvAEw1DgOKBO+u8DCQFEAoDPAASgaVo6bnDAkgO/zF3dXrI2xdy57/SkefTU4sKKdYQmg6orKqq7eTn8UlPHJVEA8PWPx0eGr963R1Yn1QXDqOYZabzvKQpgWYBtWDiYWhllDwn2Dvtzw3tbNXw+GoMQQveZ8PVnMXFpS+RSuQgUBTB0wzmp8x2wLMARds6skTM3fvnq720gslK8GB2mIyLiAdHlD/spOMWQSkWdV7W8Vg+EBSgeQNEAYQHu0QKc5jW8TxQA4UAzAujzdIoFNC/dW9/+tLnA8ISVsXfs+i6jnnLndwyfrtw36fufjv+uqJcKVbpnG68VxzUofpGg5KWR/h/s2TD3X4Xi2grX4I8vpj3IHQCdxuc39W/5yaP/EABSOYYO8v/wzK5P1rZm3tlLfl+w6dcTyyHkAzym4aHV2VBwMDczSP3k1XH+CxcOq33qMRaTr0Ik7AtahR8pQcM1l8qx8INxs5d/OnmzZgRumrCNx6zW/HgkurKs2hYC3r8VXFMQABIZPD1sz9+/vHxwmwqpJhPHTfTPLHoYSM9fFWGy8sfDa2S1Ul3weQ3amlLhRT96UWi4KYV8QMhHaVGV/Z8Hon7zH/VFWEefbFO4hSwOv349OVyuYEXg8xrkbzwndb4DPg9gaOb3XReX7zsW69je5zMk6ivPHpcXhl8uTL21N/f6sYzavKU59UU9q+W1eqBogOY/uolJgxJhhA0vinn0HgPQfHCEoFJWbV4sKet1sSju8z15Vy8fTj94I+Tq5x/1v7zUur3P6598+PV+642/nVmuqJMKVb5nG68VjwH4DORSmdmew9F/zFq89b32kD0qO1sskSmcHj9QqKcoD6DhvUZ5RXzEJmW5tmbe7zadMYw4HDXnsfIAVLvH2+vF0KisrXeq4Uk9mjqXkEH+cZArmvrz06HQsDjkM/jjQNTCiJNRJq34OpUi+2HB1MqSSlsIG393SvJIVktL4zttJlwr2XNoT/zNqOjf6LTE/DFlFbXuEGjYn85nAIZCfHza/y1bd2iaZgdvPdM/2TI2Lb3gMzA0QGuwNTyPQU1FjfnZq3de1NygzfNC1Geebmfe2XylKP7GrdKkL6pk1V4AoUAxDUqBUuP8KPqxQgEIL7M2z+9CUdzK6Iq0OKdTb3/bO+pTW42fiJKUV5T3rSirttfIPctrUJ6/bDm5fOn3e9p8tVddxqeJkubhJ+Hx6Fb51rIz8rxqpXJHjd7rbQEFsBx4+07ccGjqkFED/f8Aj1GotYPi85CXV+r20/8uvdIaMVsiOjpP58K1ezPAqNFyiRCAR7M9g1z/1LxkmoWOSczwabvRaYCisGbL6fCI43HmbTaPihy/kWJw7vztZVCwUGkbrCx8BnFJ2b00P/DfmZi4yqTP5cWrooqTbqbW5M6SEoX+XwpDk+dFPTZz1bP1lhl1BYvjih7E9rm8eElY3hEdDU6kFDl5ZT4afRDSNMDn6+w6cmPVuh03DDQ38L8xkXMdYjeKS8nT56CSZ69joCiwHId7afmGTR2y8J0RUb7ejscgU3EX8ngOID276O2IiESBumK2xPdbDo55mFnUTa1FjpyFq4PF4R8WTbqueck0Cx3g5WAOaRsGo/B5KMkrdb147e6rbTeJaty6nvhKTlaxj8Z3XY3wGKRmFlm0zeAN9L28aNzFzPioqJK78+WcTK/BDNUOTweKBigaUk5qEVWa+M3Pd/Zd+ThxW7+2n/gvCosqdDWu+AU8PHyQ63vy9JV5mh24c0A4juqUPo8m4GSKZlcIPp52P4LP+8unpQo8HjIfFgXdzUwaraZ4zUIIoW7fz3xHre+bAKApTHix1y8aF6wNoKtqJYZtvq3lMzhz6c7rEYltp/GVhRBCRRy+MQtMW54zBZlcwW+Lkac/3CpyO/fe+utlyQeKpeXuoHkAOsAs8cjEVVhXHLgx/ejJ3lcWfdR+c2supPVvCHi4Ep3ywYUbKXZtMn5Ho7rlrNPyx+rZp7s4W52AQo1dCAWA43DiUsI7GhcMwMpfTw95kJo3EHw1zFdSGbr7upz+fvHEE5qXTPPQ/4ofbAv4PKRkFvplX80JavO5WuCHTSe630/L79Fmu49HMBqM22/krdvrnWMfxh1Jrch4n2v0cXQ0NB8ShUT3esm9lQOufLptYvR3TZoeOj08BtVFlWZbdp6f09Gi/JehaQoOjqY1LR3Xw9dxFRg1o8mEfMTezRgyc+H/gtWRsTn2H781GwpWdYVNCEBReGNyv1WalqmtaJ+lK0UBEjl1LfbBmHaZrxkibya/xNXLeM/aaqzv1aX+B3JvnEqoSBsCRgC1zVWEA7h/rtpIQ0gvUdNP+8isdan49muRJQ8OdL38YYdHaqmNWIC9x26+s2nnha4dLcp/Eo6Ax9AYG+Kb19KhO9e/d9bNyfI45Kzq81AUWKmcvn0vfbY6YjbFmx9t8bsemzIKQjUMEBI5ggLdzs59fegpTcrUlrSf7YPPQ1Rs2phVEVHidpvzH6yKiBJfv502Vq2tZQfif+njHgnlGQdLpZVdGqKiVIE0KAzCgiIcDPl61Q661okURV0HwU0Q7qaA5l93M7BP0ufr1jTkHiieomRaosHRnl9fHJJXVXjA48z7NioO0DlgaEiq6412H7nxYcsHa9E4hIBP04Xuzq4PlDm8u5/rWorHqOcL4TO4k5T78oad573V+PRTyS0qn8lJ5WK1dh8MhemhLzwzuw+gNR0JWRagVUjg4jHIKyjzvhef1A/AGbXnbQW1RcWDiwsrfR7HwbdEY/JRm/pLmmdizIruh3Kv75exMjuVTFaPdhN8RljjoGN2zUbH5IoBX/eSnoDKDvb3y59H/ZUUKANwiCQKPok+bPewJt/Gmm8Ukl1fMiylNi+AcKxuQ4y+kt8BxaBKXtuLBdnf/fLSl2Ne+CZflfPtFAj5iLye9Pq8L//4Zd0X02I6WpwOhQKg4ACJrO3nIg0ZvP1CfA/Me7N/sTIf+XP97NNuLyw8npqaP0plszRNQ1ZVqxd57f5MAK324e07fsPujY+3TAFfjceqVI7u3d1OzZ0++JnwfTSingIhBHa2ZsgvrgTLKmn2oADIOcTfzngFHaRAjpyNnwQFC2UVCJ+hWCtr0+rsvFKjjoif318cbT0v5setMoXErsFZrgSEACAw5utn2euYbfI2dtmzy39eatoTjuenBZd7U94yAOkA0u8BkSBkmeuF972MGPEbqTX5r1fKKi2UjvSiaNTKanoV1OfvOJIXPWaMTdCzVR+NpiCXyMXnLt39GMDUjhanQ5GxcHQ0vx/6Ys9tNfWyNg2C4dEUfet2RmHvANddp7Yp/7mRA3y/25BZNJwQwqi88hfycfJywrTfI6JWTg/t06rSPScv359eXVJlBl2Rah8kBBDwFH7dHJfFHGuNBO2PegpEziI4yH3btZiUwOzs4m5Kr+hpCulZxaN3Hok2mzomqF3rZM1fFmG7afvZYUqvUlgOZmZGyQ52Zoeys4qXQNC+CmRdynHhx/Gbt+TUFfoobbbi5NDh6+Y76lj+aCcy2XwmOLyoIZX1A9UFoCiSBiQCWPj2/U2rbhWlfHS3In22nJXrg1bietM85NYWDdqYcWwVgDaJdmlTBDwkJmZOXLf17E/zZgy50tHidBg0heLymqTlSyd/115TXj+o2vHrv3rtSuCoLw7GxqW9orLvgcegoqjKYs/xqKkAlqv24b9Y9F2E4ZZdl15Xy/chZ+HpaX/wt+9nRqo7f0eh3lOREAiFTKyvh91hKFRwYPEYlJVW2V29eW+IWvO2ApZjx9RV1FgovZOQK+Dv6XCqqKAioyMc7keKby57WJk5UinlQTiAcPA2cj3kaWzV+/7g9cvOBIc3WXU0bNMRHY8BSyZ8+9OhAGVk2ew5Oz9uwIqFvY27DrTTs4oEJ4NSRmeaj5O5V2eH3vrh2YtqarjmvJ0Hry7qaFE6FIZGXeXTS1J1Jgb381xL8RlWrYgshkH03YyZEREX9NSdP7+4amJJUYW70ovpRggBzWcU3X1d1qk7d0ei9rJaLucYf0+7Q5SQr1oYHSGIikmdrO686nL6wu1JSvsyCECJBBAKBLuLKmsApn0VyHt3fhl3Jv/Gh+ApsRXmFNBh+HU+Rs6LE0PWvhzTb11Wc4fPXxZhu3PX1cjkxId7Dp26/bUqcl154ZtYO33PYQMtApczoKGUEuGJcCj/1tdfp+4PVGWuToFQgOu3Hoz+bOW+sR0tSofC6/xtg5YvnXIloJvTQbWy0/kMCrJLPOIzyiaoM3diYqLg2q0Hs9RaaMpZeLpaH9qxetYzucttjQIRfr0o9KaDtcl9lXYhfAbJaQUD3wvb7qbu3Koye9F2v9SMomClo69YFjaWRskHt8y7WVlSKWpP/8fOwuuWB3OvrQTF8Fr0N3AKiGhhzdde0yckhKz9XpkEOwEPNWVlVXoQ8hAdnz50zufbVCq5cr3PR/UX+y37JMTS911wnKxFJULRkMprDbc+PLUimkS3SXKlUrCs6vkCj+pO7jlyc+GFCxc6/1P0P05I325rwOeptwvh0dh54OpbYWFhKv/Yf90bPzL1YX5PlZ3nhIDiM6y/r1uHl2xXF7WfjCxheQAQ4O10BAoV8gdoGrWVNYbFxVVtUkbgaVRUV09S1NbzlV4hKFj4eTs2uLMI2jXm98cHBxfm1RW6tug051gIGX7Var+3Jsx3G6t05Mb3i0MrA72dNoIAComcF3M7Qy3/xNk+4T+biAzeBeEULSoRRoDUyoyQfffvv6XOXK2G5dDV3Q5CAV/1cE8hH8kPcvttOZQyqU1k06IxVn4WGhnYzVHNXQgPGVnFwfkS55GqfvTwmbiZYInqqVlyFl3dbA78seatq6rO2VlQW4FwXIPS6N3d9RBUNWNRFO4/yAslhLS5bWj5ttO6V24mj1faeU4IIODjhV5dD7StZP9mefph38iSu7Na9HsQDjTNk630e3vKu84j/5F0RKhxM1baf7Fi/9B3Pt322oT3Ng4e8GKY2ZNHzH1r5G5jE7180BTi7mWO37r3mlpJc2Wj/vitt6n3XLpxqd4cjAA/p59cvD7rUPvnh0jlGNTX81h3X8cbatV9oymcuXxnwYLlp3U1L5wWTRLSt9saiq9mpV6WQ0ziQ5USC7/ccLBXWlbxKJVzyx75PoL8nVrV46WjUVuB0I8+OqSn1S0nO7N4lcxYAh7upeb1WLJyf5uXNom+kRaSV1TuoXRZZbkC7i5WcUO6j7gBAGjHBrWnC2IWg2MNWtwpcSwGmvt8+b7TyOONbw2YvlU0ee7PE9xeWHTwdFTyvS9X7z/987az2/YeuXE2Jr3gzsApP3w8cWIEAwBjB/sU9u/lsR0cB2lVncGx83Ez1JX5+gvf/TzA1GcdFC3kCVAMyqVlDpcKk2apO5faUEB1jeRm7wC31Wol8PMYFGaX+NdXF76ucdm0aJSVn4VGdu/mdEitXYiQh5g7D0f+8ueF3sp+5NqNlNmQyFQPH5az8HCzObh95exnLvLqSdQ37j/6ZFBQkDy4l8dRlS4YRYGTyvi3YlNeUnt+JcnKKZ4CmUL57SXLwb+r/d6gIKphqcpvH//HpFvLu10uSRgHuoVQe1YKH2OXY5/3Df8eADbtvGD2wqTvPoiLvXlj977IPakPcsfW19Tr8XVEUlAgULCoqaqzvnj5zoqE0tg1jcPYWpv/xtcVVkHAw/FzcVPeWrrTUl3ZZ3SZsNTVwCEabAure5qHC8V334woumml7lxqQdPILaywIjrMYX0jvQwom7v0JAIe9h+/+VFUVGKbNyLS0jpC+nmvhoCn+i6EogCpgrfr0A2ldiERJ2PdLl1PUj10mBBQAkbR3c/5mfV9NKKRp2NIn65HoCvioEqrA4bG7Xu5Y8PCtqqYdaM8K3495nj3Qe5IpZ1bHIFQXyyxMDc68vg9ZXIeNECupGymVC7RaXYlQzjo8nUL+1t2/TCEohSnT9+2+L81B69dvpywpqqi1leoI8p3cbXcEBTQZaBYQHsPHxwQNGJ495/BEQ4Mg6SknPffWfK/dwHgp2WvJvfv4X4IchZ1lfX29dXVU9SV/XUrv9q3XYZ9QjN8ebP1tCgGpfUlDufyY9vXn0BTKCmrNlz9UWj9uGGBu9UyY/F5yM8qcdvw59V3NS+gFk2yfOmkq4HeTgchVWcXwkfk9eSXZn+2tUtLh27ece71+up6A5UrVchZdHW1Obhj1dvXVBewc9EKE9ZfGKB/jLON6Q2VzFgMg5KSim4iC8sX1JWhJSKjUsZUV9YaK32BFSxc7C2ubfjq1YS2kulpbMo8aX2/Oju0RWXFyTHapveGH73npAJAXFxGPZEpCOiGVqAfvzNqevrVVXOjj3xxqSpxc9qprfNjT/7vo3f79On6KUAAmsKfh6MWLVkXYQ4Ar04I/hkCHgsKuHIr6a2IqGy165Qtcnvlgp+h8xaQFu4BisHxgujJF0g7RjVRFMor63QAYHD/rr8JDcXV4NTYhQj5OHomZs66HReez3LvzxEhfb3XUgI1IrJoCrJaqVFhYVWzZt2tB+KMEpNzpqjccfCR76Onj+ualg/u/GhkBxIaSrGeXWyOqOZIB6BgcfJSvFqx18qQkJSt2tiEoLuf896/vdcOFqzI0uQhpZJym2ZrXXEKWOmYp06267O58a1Fi8ZVvzSix2bIWaBeivSsohFP++g373+6wsnO/CIIQXlxlWNFQV0oALw54YVr3X2dToIQZGUUet+/Ht0qk6KbnuMaISOsaPY+oBlk15f0Tsio13gZ7abnpFBXL9EBgBkTBqR087Dbq1YFV4ZGZUm19ZFjN+ZqWkQtmmXlZ6GRAd0cDqibF3LlxoPXjlxINmvqkHOXrw/Lzy11U9l5/sj38fszHHn1JBp7PLq4Wh4V6AhlKpmx+Dwk3M8Z+c2GA6aakqORL9cc7JWRX9ZP6cxQjoNYX1zRu4fb8ZYP1ix3KjNebvEgwuJVu4Hrx1sF/y3D3LuL7S59c4N8MAwOnYqZ+sn3+/61Og4JoRQhwR4rwTAAn8HJS3fHN/4t0Ntlc2Nf+B37o1rl4N7T48PkPsaeu0GaMxFRgEKCKyWkgfzdAAAgAElEQVR3R7VmLpWgaFRUSx5HUA0M9v6JL+Srly8g5OHyrZS33v1sh4cmRdSieUL6+qxVyxfCY1BaUmm3deepJvumP0grekPlXexz5PtoRGMKZMMXrybY25pGgVXFjEWjrKLG7tbtrKGakqORm/FpoWyNhFG69alMgUBfp0vvTxucqWlZmiMsLcIhtSZvYLO7D8JBX2BU4mlov/eff5o7c2heF2erHQBBfUWtVVZW4WtPGyKoR5eLpqYGKeAIqmrqPDb8ftYUACqCdI452ptHAUBKRkHI3LDfW1Vm5t0uo3+jaRHbrC+E4eN8ccKQCELax8FEAaxM/tjTuXLJpFs9g9yPqFVhlqYhraozSc3MV6PAmJb2ZOVnoZFq+0IAJCRlzXhaAun8LyN8YhIeDlTZef4c+T4a0aiBxtfD4ZBKOxAAkCuQnV+mUadqxJlow5i7WeNVygxlGJga6+/WpBzKIJPL/GsV9cbNlkvn5Oht4n5ypsPQpzbZeXPCgN9FuqJa0BQu3UiaERmZpP/PY+aEhtQIBLwsUBSkCtY4KjbTDAD2hIay08YF/wqWA6RyXI9JV6kneCJJFLwZs+6HkdfCj4+78c3ubRnnFgtpHtts2BtFo0Je4/XLtbAD465/t2vs9W8iRkaFH555Z+NgVeZWCfrvWfoTRgVuBE/NbnYiAc5fSXxj16FrStUS09JxhPT1XksL1diF8BmkZhX3+u1wyr9MrbmFJdPYOqlqPT+eM99HIxpWIE4neDrCWpWUiICHeym5g1f9elJjpU2uXEoamp9X6qR86RIOBsa6ue7u9uc1JYOy3K3M6gOuOZMPARghrEXGT6vCDgB4/41Bib0D3A6A45CfX9Zl/c5zT9160xQlBCEQMExNkJdtVeP7Xn72e60czNMgFsBATycFKiR4elPeMldDu90nCmNdD2VdmHQs7+r4ek4maP7HRYElRHSm4NaYQ7kXJx/OOj/xelkSqhjcUHZelfnHPTn/zRFn/X2dTqu1OqUpsPUy8Yb/nVusIem0tBErPwuN9PdWo0YWRYFI5MjOKX7jybfX7ThucO7qXdUWpwAgV8DT3ebA8+L7aESjCiR8wZgkTzebKMhVuFg0jbqqev2b8Wkaa3d7NfbBBJVWHHIFvN3tzqxYOL7JCrZtxf3q7P7Nm68IdHiibF2+oNkbz6eb3WYIBBwIcD0m5e2IiIi/DXroxB2P0rJqHxACQz3x3fmzRzxu9PTqqF5VdjZGrw/q79393O5FHytTU+tJPnUbH+tlZDvAzcj1lEpNrxghQDHwMfO+dKRX2LQ93nNa7IOtFgoW5uaG/9Jor4zosRoMpeYuhI9rMakTPl+1f4AmROzUsOq0++s8DO7ntQZ8NXYhAh6i72aNej9s1+PqCfW1GFRaWNlFpaq7hIDi8xQBPs7P1e4DaIMYo95+LofUCZ27FZ/xSlgYabU8+47ecklOLxih0gXmMQgOdNnf2rlV5cXoMJ2supLmo68IBxuhSeZPvu+VNzfW+i9eu+Lpbn0ahCAzu6RPapHocU2f+WERJst/PbxBUlFjCB6D8S/2XP/Pz0cfCr92fscnseqey72QHwvGdB308iir3psadlRK3AMcCwOhUfJ0pxem9zPrWq3u3C3PQ6CvKzaMJuRvRuvPPxh3smEXokZeCEWByBX0/mO3PtGUmJ0SjgD89m9noEmWL510NdBXjV0IQ6OmrNqCZaWPg1wOnIieovLzTc7C083mwPPk+2hE47H4/u7OJ3UMdGvqJFI9pavY8hikZRf1qMLuQADRrZl//5nYsbXlNYYQK9k8Tc7C1tYkzdPH4WJr5lWHULtBlpGFqcYyVgI0VbORcLAUGkSlKjHe6xP6bV7y5a4RYFmcjbz31tatF86G/3p00m97LyypLKnwgEiAfj09lq1cOknFlj3Ksdo+tB7AOyYnX8+tllb9n5xj6SaVI2FB0VSus57llAUur7R54ALLsYxhauq/bsiXh/VcE387YxgauqmqhoCPxAe5oyZ98NOLf65996hmJO1kKFi4dLGxWvrd5cF1tVKRGsHPTSLg0/S1mLSCccGzYkNDKU0O/S9CenuvjU/IeJlTtWshj8apCwmTAWwMW3/IZsXGo4NVMl898n308HFde++cymJ3ejSuQOa8FZLa88WwSzejU0dDpGwfbQqolwrySismohUKhBBCOQUvnACeChsZhQJ+nvYHZ47r13Yr4CZYmXywS41CYtSsA53hQ4+v80CZ8VxfcD7m4mYdm56aH3jpRvLIOw9yM0oKyy3BchAa6eYN7Nl18antC7ZrSv6mKBux7asp0Wsyj+Rd3VDDSvT/pUQIBxEjqgnvOmXGIvfxcW0tTyMymexfS8ew+WNPBI3+4lh0TOpoiFTs2PoolykmLv0TQshJiqLUC/fpzAh4SM8o7PPW/E1nNT42IQBFwcrKcA6AHzU+/hOs/Cw0svvoL/bHxKZNVCl6iscgPas4ePPeSO/LV+53r62sM1Xp83IWnl4O+58330cjbZIm1zPQ/YDKdbP5PFy+ef/FTZuiddSd96cd5/tk5hT3Vdp8RQgYHSExM9bbp+6creF2SZKxgnBoeunbsCyeajdQKQUS6u0t6xPg9gtYDqxcISjJL7PUM9QrCu7X7ZuJI3sEtYfyaGRX0IfbvvJ+7SWKYgr/lp1OCEA4jLXu/cEi9/Fn2kUYCmBZjpdYhKdqiDkzhn8PPkNUjiAEACEfqQ9y+3+5/vDzW+6dogAhX/MvkQCgafy+8+LHWw5F/ityUNMMCvZeCwFfrmrlcLAc9duOC3NuxKdOVjotAHiU98GXB/g+2xV3m6NNFMioEJ9TeiZ6ZSoVreMxyM+v8Lrx8HY/dec9cComFFI5pXzfDw52VqbRzoaz2y76pxn6WwUqQFpYtBLIThbeVNq57+ZkEmHnYpUg0hWmBAW5zX9nxjCfq3uXfrpjzez8lj+tWea7jj3vaeg4wkHH4vbjNriERTcj108jenz8W/tJQoHjCFNeXP/UlcWMCcFXgnydd0Cmhi8EAGgav+y4uOj06dvacu+qwtCorJM55WeVtnli5vKlk6527+agui9EwMPNuNRZqRmFw1UyX8lZeHaxeq7yPv5JGykQ3xx7G9MzKlc9ZTnEJ2Q1mf3ZHIu+izCMTcgYo1JpAZaDv5fDofBwqh2Ltv/FEFNfG8hrAVbWxEsOEDlvV845pa9T+EehZV99NGWYb5BtUPSR8DUdEVn2JPdC1sbPdRs9rLepz1nIa/GKXf8Ndwet/ab9JaFg3MxfgwJdVwt0RHVq7UIEPORkFfn8cfLmG+pK95+FAjhC6CPn423bY7pBwd5r1ekXwgE8osrz8pHvI8Db9bndfQBt4ANpxN3R6vD9pBzVtvU0hczskhcjjseZh44KKFblozoi4bDSwgoXpe3YhIDREUj79Oxy+NAWlaTUGHKOTQuyDDgqoHiSp/2d5cDo80XV9jqmxVuhdNNBzAjtWaAxITXAQtfxRd/kHpjMUWTKTNeB2zrEXtgCP381Pa7/K8u2Xbl67x2VfSEAwKNx/PztD77ZcHb30veHlGpewucUigJHCLJyS9tl97Z86aSrL0z8duflywmvKx1oA0Dlfh8yBYKCuux8lrsNKkObKRBnF/sLBob38quq6q2VrobbUIPG5vzV28MA/KHKfEfPx01W6SLLFPAJdIlaPHtUu1befZJlXlOPA2j32lsdwVLbl0sBbBiFHzpalCaZ8GLPVTEJGaF19TITlUt08xgUF1V0uXgz7i0A3zd1WBlfFSP6fweG4bdbsknoyJ5rr95KnshyRKyST0NZOAJGxK8f0t937c0jLR/+LNNmtWbXfDo+38vV5rxKJd4BgBBExaRNVOUji77d5XQvOWeIqpUxrS2bzu7W8t/jgxnDUkaH+G+BRE1fCEPjenTqe3OXNJTLfxrOOtUKmqak6sr4vMKyXLsp1vffHBw7oHfXPyFVoxaaMsjk6OnrGvHNJ+PVzqt6VmjTYuWeXewPqryS4/OQ+jB/0HuLtytd2qSiSjK+trzWQOm8E46DjoFOmauz2amWD9YCEKrPK990HT599ehvNh6Z4DX8055eE8PUsPN0fubOGrzayMq4QOWFDwAwNKoqah0S0tPebuqQLl26SEvKampU7iPxvEIIaIqCg61RbXtO+9LIoHU8HZFULZ9Xc3AEfLFAEhLsvU6zA3dO2lSBuLtanDM10c9WyZlOU6itqNMvr61+UZnDwwihL1y9P0mlzHM5C08Xq8sbPn/9ofIf+u8RFhZGL1z25yv2fRacj76THnvqdPTRpeE79ySn5N0oTC07/cLkb5+7YoIvBHnmD+jddY1a/UIAgKERFZMy+/eIqCadwpJ6GdUmppNnEQIwFNjQYT2y2nPaedOHxPXv2XW3xnchMgWCfF3//C/sPoA2ViBL3nux3NPD7rTKP0aawu37OZPCSMulTQoWb+uXllXUUyXzFUWhZ4Bbp/Plvk028XeUHjfoaDkAYMWmC2ZrDxb/uWLTsb3Z6fkD5TK5mBYLQOkIwcpZlBaVD4i+nX72x+3n+j7t858kHdIXHnllIPaPGYRDY0Oe+jrw4uBV2Sc7XY9xFxurX0wtjFLU3YVIK+vsz99MbLrp1LOmPAgaSpq0xUuugKGe6KGPq61SuU6a5JXhQet4OsJ6je1COAKeWFA/oL/Hv0oFPa+0eb+93v7OB8Co+IMR8JCUmhek+GFPUEuHpmcXTGTrZcpHSShYmJoZ5vXwd+l05isuTjbl/2KPXH779qbAjpQjbOsF0frtx3ZVFFVOIABnYWd2YFSI/yvbVr3tG9LXe4pYRxgPmkZdZZ3JFz/s27xm5znLf45xrTgqmOVwATR9DoQ+/+8XdR4U72xJTXGfjjjH5lgdHlo2KNhrtcph6I2IBNh/5PqbZyITHTQrWcdAMxQrFgsUQhFfwy8Bx9MTVo8eFvjtsGF+7WrCAh75Qnpp0Bcik6OHr0vEdwtCYzQzYOenzftSd+nSJdLMwuhhSXGls9JmJooCJ5XzouLTXwZws6nDfj9w03Thl9tfUmn3IWcR0M3hxJuh/VUKE25rliVH9Pvuwb51NdJKwyJJxXH383PefDBoY4dEaF09e+vDzJS8IRDx4e1h/0Xi6WVfH48Bjv8PAJAw8q11kXGxKacKiiq8SooqvE+dip8L4LMnx7hWlmzU8K+mFTtFUbAXmbX7g0MZxvTtv+1GfOrbWdkl/iqX7mZoVJfWmG/bGzkHwKI2EbC94AhEYsGFgG6u7zMMpwM14wueOjQN2sLKrPB/y9/K0dyoqjF+eODaSzeSpyhYTtiqnSFHwBcLJUNe8FwbdUhz8nV22lyBzA4NqnzxjVWnjp649Y6qFXLj72ePCdt05Kvw2WPqnnbImUvxI4qKyu2U/oETAoj4MDLSi1BekLYnOHKR92f3dmwHIYbgiVClqLWsqqzbuyDxtzkrvN/c2p6yHE9JEb49beNrAGBqop84oU+v1Ymn/37MiV/n5Xz6w94vvl5zcC/4DCJvPZi5af/ljbPHv/A4232giQ91vjgWoJu+NoSDrFYh7dBEx6Z4/XW/2gVf/7lyxbpD26Fi4zkAgFiAfSduzTx96fbPwwb4Pbu+NppCXY2k+uqeRckdLUpbMGfGsPiQSd/vvnDx9nSV8kL+iUyOoL5dd3/18YR2q+3WGWhzExYA9OnufhB8nmrlsWgaZSVV3gKWabLfQtzdhxNUsl+yHCzM9JO8/RwiVZCkTdmSdcYmpbrgD4A4gX6kYCkaABGvSTn0a88rC78CCdPYdQpbd9xg5MzVL3kPXbrBZ/hnZ/xHfn5gS0Tk4zISp3fHuFRU1zuDpmBmqp8cHv505f31JxP29Qx0OwsFi+qyaqvEuMy/9XPpb+5p3nyZFgoURcjSpO0aXNNqluVLQ3f6+LlcVav1LUOjrrTGdPu+6+9oXrJ2RtUkumeMR74Q9aoQAI98H8L6kN7d/jO+j0baRYH08LCPtLc1TYZChRo0jyqdnrwYN+Fpf96080LXtKzioSrtahQsfLo6HGtqR9PeHCHROpsfnt5SVFfs96+KtRQNBSH0zeL7nzmfKdxygTwUtWauiRERzMDQ72Zv2nEq/sSp2AOJdzPnJMSnD4m/nvTSip+Pftt4XEFRuYjlCA8UBalE0eycQ17otgsAwBEkpxf8TdEfKbjVHVQzO0PCQY8nru5h7NopTVgAQFEUN3iA97egKJVrgwIAxAIcOhU94/iFO3YaF06Lxnj/zcGxIcFef6rVFwYAZHL0CvjvRF49SbsokGHD/Gp7BbgcVTkai89Dwr2c4UvW/Tsx69i5Oy9Lqup0lc4zIQTg80i/ALc26YWhMoRQM0+uX3ej9N4IME1snSkaoHl4WJPzxieXfzzw9v1N1upMtWRdhHnir3cOXrx85+eCh4XOfAGv1tLW9Kypjcl6/z6ey0Ezj4u9jR7do0Ak4FUBBKVlVd3W/XalyaQ4e3vT80IDnSrwGNxPz/cYMCDsscaoZWXuzT51OQWcdS0eRgZ/36nKrvyTNZ9OOebWxea4Sl02G2FoVFXVma/46fgbGhdMi0bp38fjJ1pXqFB5F0IIGF2RLDjQdWPbSNa5aRcFAgA8gWg/oytSrX0oQ6Oiotb27p3cIU++vWlTNP96fOp4VXM/XJws42wGOnRI5d1/EnIt7Kui+tKZzfkIHkPzcKskccThjGsnXC68002VeSIiosRHj97ZcS8u7UVQFPr28zo0dmivgMLodUNL4zbMiz/+5Sf3z369ovH410YE5dtYGd4FAarLaxzKK0uGNDX2vaTcMjMTg1JwHOplckGxRcP9NPXeCsfc+hLPZjstUgzKpbV5FNUxhSxVYcgA3+8oPsOq1fqWxyA6MePtD7/e/1j56+kI69UaS0ubwbLyfCN93SqVrwvLwdRYt8zIwLDNm6J1RtpNgRh4B96yMNe/rXJopEKBwoLKyU++VSTL619UXBWkUpa7gkVIb49Ds4OCOtzmPit+4+wLxbc/bXjAKmlfZgQokJT5ZVUXnVh0f/tAZefaeuTa7ITb6cPA0OjTq+umawe+eGnfpndSmvuMX1eHvSAEoCls3X9tZlPH1dVIjEvKqk3AETjbmube2xMuAwAXvpVHjbzWsNlGWeDgb+RyW9nz6Eh+/uq1K0G+TnvVMnEwNKpKq+zz8gum/fUWw6plEtPSdhABzRE1y6lwoAinaLdnaWei3U568+wguaer3RGVFYiAh4Tk3EGrfj35uLTJyYt3JkKmUN65xxHQOkKJTzfnDjdfDbsWNuGX1EPrG3pFUfhbs6XmIIQFCFEo5HZrUw4efS12fZMP9kbCwiIE91NypgMEZtbGuZ9/MG7Z044Lmbqie9C4//tlw+/nXgYAYz2dXUYmBhmgKGQ8yB08L2zHUx3BBoY6U6QVNYYA4GZvebjx/ciipJfANXdeBKB4EDL09ZbOobMwaWzf5YxIIFHL0cpjcPHqvdnfbTpjCABisUCi3YFoeR5oV63p42l/FEK+aqYAmkZ9TZ3ejZjUsQAw55vfTe8kZY9SKfdDwcLdyer6h9MH31FVZk1TQ+SpoHjDQZN+UEh79DHpOl1I89lm/QWEg7nI8Lajvm0wKFlfiaRqbHTlg8SW5vLs5WKfXVThAZqGro7o6qgQ38fx9hMjIpj3PvvfMPu+Hx28dD3xWnTk/bdW/nzsyyNHonU2fju9tEeQ63qwHCDg4dddF1dN/XDza42f7fHSN6aDpy3/v43/O/slKApO7ja3/AJtdgBAWHaEyZ3KjJGPI8qeej4EBnydwgAL93jlvrWOZ8Gs4TGjQvx+Vysii8egKK/MLTu7YGrD/1KqdcXToqWT0uZ5IE/iZdkl1sU2Ji49oyBIpeQsmsL1+PRXAKzSo8XDq8tqHFTqS0wIAro57Um6qKrEmuda8Dd/e2i+kffevbyEik8ya/O9m/aHUCiTVXst7DJR+onbmFgAuI+Wu8GWFVUZARA1jIDHW7+5644LL/wWdWhPfNpwgAL4DKAvxsPMom6/HLg6FsDub+ctWF9e9n+Dom8+GF0HiHftufyrsd9780VCYc2d++musqp6G8JxMLE0ju/l5/HqopnjqgEgKi9xUJm02qlZ/wfhYCUyjvnUcXy7d0lsDe+8MXTtuauJk+rqZUYqFwllaJyJvPM2IeTnbsM/rc3RKhAtzwHtugOZPTtI7u/teFRlMxaPQWZuSVDY6gP+Z6/cfUmlzzZU3q0I9u9yTLVJ24fZNmPqHMSmV0Ca+U4oCqy8XhRVmqBSToGxobgUQB04DoYGYkdCCAUA6+eNkhrqiuppsaiuq7fDN56uVm/RgAKEIPlh3juEECooiJKPH9ZrRlcfxyMgBASUoLy8NiA/q7C/tFpiw9fXqRw0JGD1hJf7Df1z49sNdYwIoVIq82e1aJajKLjrWXe4OVFVRg/odj/Iz+VntSKyBDw8SCnw/+jL3S+Zm+iXaLwKrBYtHUC7O378uzkc5olVDJejKIAjgn0nozc9SC8cqtLuRaaAj6f9xfffGtxpoyQCTLpEUIwAzZqxGAGOFERP/T3nnK+y4ybFSwrsLI0zwNC4k5Tt/9WGQ48juCaNDnh7+sv9uiad+/bT0AHfb/Vyt70JQpCckjdgzdZzgwFg6bxRxZb9ho/38LCb6OpmvR8sF90twGVvcLD33NdD+wec/+OTjzaHTy1pHHPe3V9eelidM6zZyDLCQZenW+6ua3tS2fPoTPQO8l5vYKKfp16dLIJjF+Lf5fN5TYZGa9HyLNHuCuSLeePiXJ0sb6hc6ZTH4G5CZs/qWomRqjVrxgzy71SlS/5JP+83LzvrWt4E18zKlqKhUEh0f049uVjZccPDQyQB3RwPQ8GBSBXiY2dvz2/827w3RxVvXfVmdsNxFDd6UMBaMDSgYPHHvsuPdzqXwkMUyee+3Zt26YdXkLu9x90TyyZe3bNkw6/L/l4KP5EkCs4WJbQsG2HRRc/q+CqfhrmfNX5YNC5vcLDXj2rtQvg8pGcVD429m/mKyvW1tGjphHRI6FlPP5fDaq3gBDzVSmGzHPSMDXJp8M6qPln7EUpRrLeB/a4WQzsZPqLK7k2aEb9BqV4pAODgYL5VaCCuAEPjZlzaG24DFj/VDBZ/P1OHFvIBmkZmekHfFZuOmKlyDsvjzs6+V5nas8mkSAAAAUPz4a3n+KsqY3c2XhrV52cLS5M0dXqGKFgWpaVVz15Jdy1ankKHKJDgIJejjK5QvZBIVZCz8Ha3Pb103qhOVXn3aXzkNXGHmdgkq/nwVwqgaPpw/o0flqQ03Tb1SdZ9PjVl5KCANWA5EFBUakbBOsseH2wOnvhdvw+/2u057PUVI32Hf/77qXPxP3P1MoCmZNOmDvpqwewxJS2P3sD8xN97/pF9aRmoFgIbWDm89O0u/9Fj/kVlx+6MTH+5Z+nU8X1Wq7ULoSgo3TlTi5ZOTofcye+8OuSet7vtdcjU+AGqAo9G/8DO1zjqaYToe5SE2vb7CVwLYaIUg9K6Es9L+THrGp3iLeFn/f5XVnamW0AIwHH8wvyyWTdiUy5t3nU+/uzFhON34lJfh5wVOrpYJ/fs4T5yzeeTf1JW7gPlcUaHcq9tlCskBs0nDgKgaAyxCHguSj7MmjD0dyc327ttfg9r0dKJ6bClUEhfr0Pg2rCKhZyFnbVJqqe//eW2m0SzvOky8FdLHcsHzfpCAIAR4lrpvcn9riwJV2bc8HCKM3E0es/X23GhUCzMogU8KBQKuq5GIiAMzdk4WSW8PK73B0s/GN7r5oHPzysrb/fot/lzrq9fn16TF9S86QoAK0OQiceJ1T4zO7U/Slm8vS1qege5fKvN59DyX6bDFIiLvdkxgZ64ss3MWHIFegd1OTpzXL/qtplA8wTpe5QMtQr8WqnSrxSNqyUJn9ueekspp/q9PeGyOye/WtEjyMW/V2CXMZArZvL5wtenvtg3+JVeQ3sc2Dxv3ezQoZXKyuqWMldYUkb9micpebXZpEEAIAQULaj3MXZWSuE9K4zvZ/ank4tVpHYXouW/SocpkA9mDEvp4mx5Va2+0y1BCCDgc8G93PdqfvC2ZXvABzsCjbscBStt4UgKoHnIrS/+xuPC+18qa86K3LmkPGrv0qPI++M3edov2/9YP+v6+vWjWprsb2zKO6IjSa/bkllb8LpS5WRYKUZadf9xq9/7naKQpaYIDQ1lR4b4r3ze+2Vo0dIUHerN6+pmc1DZWoIqoWDh6GAWe02n4pmptdQIRVHcYu9J841ERgUtmrIavjwquSL7867n5vw5PXGjVVvL91bCj77fJx49m1NbNK3hwdnCBWRlcDKwi37Ddfz/tbVsHcFPy1476N/N8aRaJU6eFVitmU7L0+nQYHRHe7OTOvo65XV1EmONRqZwBL5eDgf2hIa2wfam7Qm16JP6Wtzaj7enn/qjwZzV3EOaAigguTJjYqm8JmjM9WXzj/T+TONdmcPIBV5a7J3X9mRGrqyUVhi36PMAAMJCwBPVfuAx5sNQC+8aTcvUWZg+Ifj7+LuZw0EI9dztRggBX5dPyQE82e+lrRg4EFx4eHinL/GvpYEOVSCrPpuS7Tfi84u3b6e/DKGGFAghYMQCSbC/y6EjmhmxQ9ge8MHO12LWem3POP0pGB5aXOkzApTUlzkfld7cH3jxo6MmPP2vzvYLj26tHAMuhPFqmNrRu8/v+yy5MjMIVMNcLUIaFN+7riM/mO847mpr5ejMzJ818uKgyd/vPX8+fiJ0hB0tjsahQb1g23t+THJdZZtaLDhC6MxzAtmQactXn/1j4c62nEuLZujwdNhAb8dDt2+nv6yxAWUKdPVxjFr8/tgWq9V2dvoFBoefLY73yK8vmdBsccJGaB4ICB1bljSWzxON9D4/74yj2Ox3awO9s1u8PypTZe73k7bY3C3LHD3LldAAACAASURBVHOvMuvVYklZP0IUAK1sAUsCgMBD3/7Ltd1mbVFl3mcVfy+Hby9cS3yRECJ+rnYhFAWpVG6Sm1Ni0i7zyVmUl1Zt+PGPs9ffmzYkvV3m1KI2Ha5AfHydzxqciC6qqq6zULnC6dPgOIwa4Lcv8XTrh+poZlNBcq8L782QKAwE5fLqsS3mWQBocK4LIOdYfmJF2qj7VVmjdEtFBc5n3r4kovl3/Y3cru3Kv1zU19itfqhDj/KYwnS92KoHYmeBuWikRXeXjQ9PBBoyOv6/pZ7uWyevM3mUvIgWkwQf07DzMBEZ/JA8ZGNYK07/mWLVF1Piur8YtiMmJnWWSpWinwUoCip1/2wNPAaVFTXGJ88n9gegVSCdnA5XIB9NH5zb75WvL0ZeTQxVyjTSHBwBX1+nzERH0Ckr76rDvZAfazwi33yVqmJ2lEnLHykRZVa4FEDzwQGoltdZVctqJoFiJt2vziYURZPb5Vl16VXFFfWsTFdCFOK8qlLh1eL7FCgK+VzxI6Wh6kODAAQwExgsLxm5bZHqZ/tsM2xgwJrEpJxQiUxuqM02bwUcB30dQdeOFkNLy3SKu7yXr/NBjfzg5Ap4u9lcWjL/5YzWD9Z5SO73W7Udz2Kqq57dzobkSxWjYigaoHmPOjjSFCGga+USvQJJqV2lvMZYqpCKAIp6HFVF86DcbucJCAcGFGzEpt+UjN72iWoffj74dsFL9/r1dP9drda3Wv6CYZCeW6KtWPwM0CkUSPdA9zOm5ga5rc4JoSj09nd9JkqXqMqdYStqBxv7vzHWpu9X4DhW6Va4TUFRDTsMin6iNbCatntOARFPWBlq13963ojfPm2dYM827746cLmRmVFBm+Q3/VegAI7lOsWzSUvzdIqLNHVMUImfl8M5daqbPkbBwszUIN+vZ5eWW/U9o2wOmi0/3HvJF8EW3cZbiU1zwXZ07gEBODmsxOb3vPScR+wK+nhbBwvU4bwyqlfOwL5dv9N0drpCoVyiaLNoy65o0TCdQoEAwPAQv32tKnEtV6C7n/PJd8cHF2lOqs7J1X7fHp5oE9w7wMTzDxA5B66dTSakQXEwoKRBpt7f9zf36Bsb8sMzl7TZVkz9cMhPvgEulzVmymI5uDmZV7RmCB2RgKWelegwAoChtbkgzwA01LyrNH11y8qqLxmaGqSp1Sek4YbD0AHd/tSwWACn3vfT1mu99b6zcuJCVr46y3X0y056tvEgLFrOXG8ljxQHKHA+xl3OjrfrNyR6wA+L9wQtVrqGlobkUOualGtajiYI9faWzXlt2PuUmF+kXufCf0CArs42rSoKOqK/ZwFDQ9bmN6YmYDk4WJmUtu+k9e073XMCTXNEpvLWlgBCPqPRW/H7xaGVbo4Wp9Ta+itYWFubJVbzRJc0KRMAgHC0Wj860j67u1983zs8vcuUPpPs+0+30bW8AXAKEBbN9lhXFcIBhAWP4rGehs6n3nAcOuLOwNXD9gQtiNTcJMrDY2hO5WvCssS4TaR5OrNfHZBgb2M2jeHRpa0yZ0llcHWyujS6d58rrZHH0XT0fWsTw1hIO9rsqQQcB3trk9T2nJLPFxBaTRMfx3KQySTPyPZOs9ACseAWKApQsADHASzXsNJ88sWRhvc5AsgUAA1YWhjGa1qY3oHOPxpaGBVAKvtLFo78W55GmTgOkLOAVIYp43uvCJ8RItG0TMMHBcQzNMVCrmiQ52nfD3kki4Jr+B7lCnRxsbyjaVmaItw5RPJn0Cfb8obZ9e1n6jXSRc9mmy5PJw8AwMrxWKEo8wMhXMOLe7SjocDp8HXSPfQdVk1wCO59f/CGEf8LeP8MRVEdtpYdMcg3Gizb8F2zXMN3/7Tr0Xi9JDLY2JrcCQ0NatedUlbkirPenvajXd1sbkPBAjL5X/eugm36xXGAXAFI5RAb6iV9/O642aGh3q168oeGUuz890Ys1jM1KINEhk7r5FewEOvrVFqaGrVrGwZ3s3F5Jib691Av/eu+edp99c97q14GGxuTB/+3cGKnb1rXFlAREVHi345emxN/P2tCZa3EkQGM5ApW9ORBhIAIhbw6mVxRZmtllOTmZL3DsM7+jz17NF9ratKcze53UzJn5+SXD1WwrDXHcsYcIf9KSKBpRgFCykxNdB+6OVr9dHH3ot81LUsjfsM+e7G0qu7dyuo6X1AwlslYMUD+tsNgGEbKo6lqHR1BuqGeeF9QN9uf/1g/r6qtZGqJHjeXmKJO/gJNUQOy6kv7VClqbRSEtZUqZFSDGeoJ8R8pFooRQMwIZRy4HCuh8f+3d+ZxURzbHv9Vd88MMOwwLLIoILgCLrglKqKSiPsSvRqjxuXFLBdN7k1iTGK4xFxf4jXJjRqNMYkxJj4DgjsaUBBFJQoqKKJssg77MDMMzAwz3fX+ABQENcnHG5P3+vvXfLpOV51zqrur+lT1HKW7pcMpjnLJFUZzVlH4R79vmOoBpKSkcC9/kLS4tqFxmcHQEiCA2vFmodNHRIQQM8exjQxBRXA/78SXFo3f+Oz0kdWPQ9+oz1Osk1PSZ6i0uojbZXXBgiBYW1tZyGk3AzohBM16o9bFxU7p6+l8ijeRHamxb1Y9Kl1e/e8ffNMvFb1cWaV+oqS8VgHC/HGCWlQgYBiy9sWpH/33W8/s/L2bX7/lsE/y+ZuvZN8snWgymT3MPLXheb7Lf9NwLGtkWUYrkbDKAf49kp6ZPuqzVc+Flf/e+v4R6PDaRcmGrQcdG7Um13NXCuzMaP3K0CQIxNpKxoc/2Vd1Kbu0MnbbK7/Tn+JFMf/cMco1O7vEvbSq1kLC3L3QTYJAAnw9mhVWdspN0bN/t0XzqM9TrOWszv3U+XwHbVMz11Gn/v6ejcMH+VQvmze6Dnh8s/P78cKtHc4368r9VS2Njsu8wpyzNSUuDaYmC4Zh0Fvuorbm5OotRQn1s9yGKSv5mryjIdHNj1vnX8KGbxIUytsqt8wbxTbt/WESBOLtpjAMGeRVsyZRV4n/wETntxPFzH3NTva3FXMtNdqu8ws7W1vs/eJA05Ytq37VX+z/eigBVj72D4m74k6B6MebYCUqitk7NEJxJj1PkZ1fbtPupPZnYmBgL+3Qvl41f9R7XURERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERE5M/J/8s8vvcjhsawR7PK/IbI+/g0tGgaIKU3o/2f0wJA1O1dFtHZBzw7nSCYmXCXYeqkJ6M7JbVacmV7r6dd+rtXGRv5K425xXuC36gBgNCUKItU9SXvyR7DtAnDoztnmYuf5QLACeZGJead1FBKiXvyCu+qhmopJAyFYGaGOg1qzBy7obLjaS/nfG69Le9YDzDc3STogpl51m9M7d6gtQ2P0j/j0992Ta68anenLUYgIJRHs1UJ5sXyQKsPFx072NPYXCl5Yej8qi/9VnbJZBhFKZN3dbPfMHtfH42+WWuQkdyP/OZponJirKPzvu1sSwebnnYbVvfTqGjVo7SpVZ8Urjan0H+8Q3+HDE2+Xkt1+dsGdE6cRiklL1/b7hNo08uryaSXgCVVR0uzClLDojulUR6f/rZrcukFezsbF+POSfvK5hHSJZnV8pxPHL/OOaKAxM4cM/OfZfNIa7ramRc3OB2sOOUERi7cr7+XXPnUfndxksu9/f1ywBSlwqq/OTrzYy9IuskyKJiZUK9hqtSQ6Dr3pEXeKlOLxBCxr2jFjU8dvs475gxG3tXnjEAWeYcqS1U6Y6r2Sq9A276Ga2Eby8ececfrbE2a/HX/5WWbghc3dTwlg2ZIQuL+0cvdroexMvzL0ogrGxTHi9Mc7u3TqKBZ5dE+Sx95CmqR35c/YEayx8MJzQXH91Ljv7ioujH3B/YceN4EN0v720l1l0eHOw9Rbs9NXgTKfgmhRQBhmdaUsBwyNIVnAYwFgIX5m21Lqqr+tbfk+LLdRYc5MBykRKL/2/WvV38ycPnOy/q8cAj0sNlE9gFY0EkBRngDIK+Ds3oOwA99Tq/so9JpLoIhVjA28QBlbqhu6HolrTw5q8ewtZ8OWFEAAPGll94DkbwB3iyA4ZjWOYEEpyrydgN4/pE5KCWKy6gvSAC4IeB5CkZCwDMART2gDQCgAoCCfEmE0ag+AkaGm8qSGAB/6VhNQn2+7fq0NdvSa3MW/shIIVAeCqltxYGKi8Fp9TcmgZLvQQkg8AIYzgTezIFhWBAJMhuKvgOw5JHZBGBq+nr/g6cPbctS3Zq4jTkIAHCU2pVvLDw0/02/GecAYH3+Pj//ky9tKG4sm2E26WUgBGBYOFq5pC+9su3vuwa/fB4A+qQts8msLz4DTh6g0Tfh5NUv3gGwoWN7iVVZ8sjrO46DkQ4HNSP35vVnAMQBwNnam/GAfCxa9C2gZuaa6oYuMGV12lsBM9ct9Ai7CgBHKzM/AySLwZtb+wAAwCGxMue9yW4WaeC45Na83WYBRGoGNTEgDAciQXZ1wSHEzJ1T3dx0xoazsE+qzvZobDL/HYLsbYAAVODBsGYIJgkIx4BySFTmrDLDlAheuMnBdBpAmKNU/g4EdmU13/ASgC862pecVxwOajz2hJ3P1jggMrU86yDAPXHnmgFAQPBNwbklAL57lH0p8vsjDiBtbM9NfvdiTebcse4j94Y6BW7K0hZ4KY0NCzR8izMAZU1TlQM4C/Sz801VNtfs0Zh1FqBU4mvhUpAJIIWmcC+eitt9S3VjZrDzwHQJK/02Q1Vg9rN2n5RRn/8MgJ2NBo0EVACYbvxOCQEB0Jb9Pa9BaQXAxtXSGX/vvYyVMByOVF60T65MfyYBjIJSOp4QIlQ1VzmCkSHQvndMnrY00Uh5C8AkDbL2zEh6pB46zWlbbJytODn8rFzev6YpLAfLyUCgh8JwJ/3tmdrs2QDAsFJcaSiYEFN2wWOe16iK9vJdBfFvXqjMWPiE27C4cMXgDdnaQvcSvWqhjuo8reVWZwG6WsJItf627tNuNBTM7mPne7bWUPetqkVt7WrpmF33CC3aoUzyfiPzm8NaQ23f8e6jYm42KX/S8QapLWe1LEOVNw3AuR2qJLt3L3y3v7ZJOWiK1zhMVASDEIJz9bmILUseGVt+ev+BiovjZnkMz7ulzLMA5+BiJZVTKYUQW5664vv6n7c+5zTiTu7ao7U/P3VLUzw8wN4PeZpilOprvAEAFEz9gXoFGAle7Ttf2lvujpO1WfYHS5OnvqlX99urTBn5bI+wunp9nRNYSwyyD/gqW12YLoCRgZolg+29U1xtHOpAhUiGsE0D7PzDrmnyF/W28brSaNZ+Xt1cZ+Vu53GjQdJoIehUcnAWUoncZClnrOJA+Ro7iUOjQma3oqCxZFSQvX/MLW3JCaMg2DjLFAm3NPlOoDwIiAQAxjoNSDhUlrLysrpwGu4ZQDI1hRGgZoQ5B/0UB6DZoFJYWDggQO62IVtdUAxGIiUUzDiX4LN7HmFfijwexAGkjUMVaRMhtcVSz7AtS33CrwC4Qik9QkhbzmOG48G3YIIiMH1r0Au72s/LRAIA4Ex+zcJbqtyZAY59L38ZHPn0CCd/LQAMpDHfel3X9TgDtE69HhY1pG3tEVaAYIKLzBav+U0DR1jMdhsBf1UuyvR1Q7eUHfcBUAjC8uCNWOI97sTrvWftbq8mCccfbnRoFAecBlJTH56DWm9FW3UjwoZ+S76Z1iOk9F6RAxUXnRZlbgwf7zoUflYu2Jkf53RelRMB4Kt2mdjy5HBIrLHIa9zWl3wiLgMApTThjp+BzSYAtceft4Jgnj3GqV/GV4Nf+QYAcnDiIUpSAoxjMdeFIjb2oXnQT5RlrNU2V/Wd0nP818dGrlvRfvyFrO/2SKXEFgDO3b7+am1j6aBwz1AcHvEOGNLaf6t9p2IBYbCv8LB7jPL0XwGsgkQmAGCdpTY5E5wHxu8qTHjvUmXWWABH2+u+0lC8xEHmWDHf88nv31cXrGEI0yG0w/AAsMgzFEPs/bCy11MIaapGVl22X51eOwLAMVCBh9CCSJ9JB5b3evpOJ8ciAbGtP7cKAGoSljZDMC8KtvPNiRv+5tcAcAOJQEKELQhLKShYg1yyK+SvlwFc1gBgE54bCsE0ar7HmMS3x/97V6vPARya7oYOWgY5DUx1snKputVYPm5zeYLnKs/J5QCQQ3Ok4T99PMneyr3ay9YvtdUkVqCUYv3A57+d4TKkAAAEAHtw8GHdI/IngHncCvxR8LXxKAVvRFR+zJtr82MUANDhoQYwMgAEet7Idnd+bFnaXIAgzCno6/bBAwBiyTz+k8BlZb9VL9ohmt1CzeApDxbU0EvmeDdGTxjUtzT+qsnA2g3fT/dqLrvirvPJef7VzyJ/hUawsOi+JFOdF6bT13nO8xiNRd5hAGGR3nBzekcZP+tepRBMWH8z5o03cna5Aff4uY1afR0BYaAzGyS/RKuMDCoJm7dui9vgnnkBVU7J38Sc7P8g+Zeytzmcr78xFRIrTFAM7TSL3hS8uGlDv0WVAJCuypsIToa/+k65M3i0s9R7AiC1xf7K9KdBQQBrHhSkxqjhfGw8DzKcJXK1Fc+2y+8sTvQ5W5c94ynXgT86cDapoF2XHQDA3HacIyzsJXKACrBh5B38wKC6RdvtddhOtaGeAATNvOG+10UzOi1fQGXUEhAGjWZ9N+fctT3c0U8z2qnvcbNBbVWoqpzYfnz3jYxBSp2y92jHAcdmOPdtRMxcFowUDGFwu6nsgfqK/DkRB5A2Vvaa8r6Es6wt1RTP+vxm/I2ApJc3/+3aN153BAQTwMmwryJtIYmfdgoHpp3hDs05ear+qgcAXFfl9uVkdrCVWGTdvxXpr1OKYVHXosUXt09g++0TeP7yZvBmI2Z5jNk63XVk9R05VoothQlrED/lFOKnnHM+vjgui1bJH1T11dyC1S0m80AGCMjJL3k1Pz9f9lB9CEMJCPPutX0zsT9iJvY/vSD8wvtPthen1V+fAakNxjsHYrhDADxse+KiOj90Y/4Bv3aZVwOmfiCTWFYqdeWTt98+nuN/8qXtf83a6dOlLZYBQH/xBZpbmhxYWKx8RSaV+NQ3NI7NK6yY+yD57QVH3aoNKk83K0WlRqor6lbo0JM2eY0lfpYyB/S18exS7GnpBMJIYMVaWGdAaelr7UpBeRiMWtl7vedcDbb3TTlVnTUnpuyCBwD8VJs1A7wR452HxFBGuO+Dvf1RnaEuwFVNEcBZGgnL5LcWti5pbLgV+xHiJ59C/OTzvZNe+pZS2tlVv+lxzQBdl9+7JdQl8AAIg8vqvBntx8qbaqZCaMEE14HxdwQphBbBhLez93yPuCnJiJt0ceK5qPW/RTuRPx7iANLGmoBZF1f6PD1htNuwA8283i5PXRD5VUnSmf3V6UEAAKE1yiMIlAMEO4DYE8BaI5hbp4uEFRhCYCGxbPlNCghmdAlvEQ5VhnpEZnyMlzP+hXM1lzHbO/S174aujr4r0zoxFcDLANiBMHYAtWqGqfvpbRtGo0lKQSFQCp4HKee4X7Ajj/BNvB4/12R/Bk56AITZazAZ1gLA9sJEl9SGmxPHKwbB39odMkaCme4jIRjUtrd0FU+11xDpMy1rue/kCWHuI2OMfIs8v6HwxV1lJ89+UZoU8ktd1R0NGqNUEFrtoZTCZBYebA/LCQABC453MljfJ4TnhNatZgBLut4qFBQABQEhEjB322MYAkLoUFu/ON7UKD2typoEANc0xYtc5W6lK32e+tnIC928x7VWseLqNjxxdi1Gn3kLGqMaS3wnbXree3xOa90cKAABggUAe4DYUwgWhJAH9vejJtA+8IyD3EV5WV044XB1uisA/KzOm2Fr6VI3xmFg2l2TWv1GiSAHYA8Ke56af+VMSuSPijiAdGBr0MpraWM2zJ7lOWqoj53vOa2+rtemm/ujAACchMJsxHyvMbvp7GMhmHU4yDQjbuRsRUglUkI5cBZCC98CbUujx30b4PUsQMFQpsvN3tPGnUIwAbzp7txRMCHAxjvvCc+hgaMUg+fKpQ76c3W5i480Zjh3rrcFq/ymRmP2sRDMOjKwLmJPxCjipX+QrcOC+8RYyqS1Uo5VhwT7/k+Yj88v2FIpsLacFab3GjcDaAkCL4ywl1lGAkB24+0w2qJz05h02Jgfjw/z4lBlUAGsFFfUt+d1rGXbwBW5KaPX/2W216jBfna+yU16lce2/MPvP7z9+zNklG+Oj7frcQnDapwd7QpCAns/fBGIMLTBpLU3SsxO95chMAomNJh0XYo0pmZQUOjM+qZgbNcX6arb1plbB4Ighe8JSOS4qLo586O8A8NvNeQNiXAd+j0ACJTv+o7Quo0CBDhpwXA/9pS7frGi1+QJuwevfreDzgA1Y02fOaswO2EoZh/rXxi+Y/5DbX3EtIax+h1v0tfZFOqqQ2KqfvYp1JYGhTr1Pxri6Ndh67bAWDASfDBw0UzMOTYEz5wISBn9zzW/t74i/xnEAaQbYkPeurbYM+wfkMiRXn+zHwCAsBSgsGS6iTyEpZqfUgSdQ4sWSn3dpPvV+4RiSCVYKSr09V3iId4WLv4AxYQew9r2/ZsAKsCSlejOP7np+oWwj/dPchu0tVpTNPhg/vm7axa0VU4hsf1VNn70zuItMyeNDohcPst/x4evvPvwMwBQSkxUEFb3npSFmcevYd5PF4+MWHcbAPJ1ZfPASFGsry1fnxdb/EF+XElK/fVilrPms7RFI/crz/e9t7ofh6zJXdpzfBQjtUG2trgvEiIeHka7D6P79m0cH/j09LWr5vcZMWLUoAUzx/z8IPkd098r8rVyy242qKyNLfqx3QrNONw40iEgizfUI7Hmapfi/crzgEGNCJdBaSDRAqBj0b5OkhLFrfKeXDjE3jcpW1Masbc85UtwFtTL0nU/ALDdxZgoZVjCYF3feZEpoz+Ynzdx20tfDY1M7ixEAIFHL5nisX/DNc4l+CAIg3RV/tyM+tzlEEwYqwiKv1fOKJgx2Nbvsesr8ugRBxAAe5UpzuHno6K3Fh0LQEKEDClRXIamYDRatJjvHdZ6A5tNBIRBrVFrBQBIDJcjJtS6d0KkDABGOPb7DpylEFdxbuWyzM2vhqZEWY+88JrloozPJoeeeft9APhh7AuXvCydbl5T5z0x5+KHq5EzV4qMFyTPZX4y72ztlRkuMvuCzSNfSQcAmEwAITAJ5jt9NLnHiB9gYU8PVV5cntJ46+5bCMMiV1dh3VGvoRkvPHTx+bPoperXV06r624R+35QCETd0nn2nFCf7ZlanzO5l43H1agRzw5YN3JB0Lp+y4LjIpb7T3IbvIM3NFgkVGbMBoDw8+uiPy0+1q93QqQMMXPZS5rCJwWjGpPcQk5j8nHjL9WjO6Kjw8z/9eyE6j2bOn/c1h0rSYhpqIPvd6AUm/IObHz92rdTkBApW5i/2XZ82roXn7n0r5UAMM9rzA9gOPy78DASqjOhMTVDbWrC1yUnsa3wCCC1009xH/4lAICzbH1IMhKg9gYDAGGKgQdbzM1slupWcB8bz/Pr+y+4AgA8ut8kRkAgEP7B9yXD4aK6qFN/h6ZE/e47Koc4BKbZy93LUmqzluyvuPCOg5VbSYhzz7P3ykkZDkcqL9kgZi6LxHA5EsPlc2mMuKj+fwBxAAGgl0qMBdrS+a9e++oWaUY125CpOlaVHtXD1jtzsU/4hwAAauLAyhCvvLAS8VM0aLZSQmKnUgrVRwFgfb9nU1/ynfkWQMzflCR+mtqQUZVRVVi9pzTpGEPQBwB8iI9hde85a6WslS6u7PS/cbOxjimtqPufstQfLSSWTZG+M18bQFzaYiWE7bQFC8Byz/FZoxz6HKtrUnrEFKW0fohoNrFgJNhVkrQRcVPVbXppblc3b3ukTrJsJgBlAYAhLZ1mk+eqs6eaDGqLCc5B+1c5TdaucZ7R+JZfuCaMhJn72fU8AIkcaaobzyTU/2xbrKua/nrWzhtF+sJqhtM3HKo4/6HC2uPasz7jOi+sCq1bzP+Tgf2lw+Z8PtFj9Hdqo9bl44K4I9AX1MTmJFcm11zebs9ZWQPA3/xm7g33HPtZrb4O085HQ3FiCRTHl2BF5sfgWGlDbxuPFS/2mnQBAKDnCYjAQBA4WOsIAPSz80u0lNnoAGCs44A7s3Om7VVFIG33YOzcO/41E3L/2bpAWRAWX9w+tgvxbf0ttdNe19+O7iTH32cZ3djMQADbtoDTGSpwIABDuqwfsd2troc5+KjHOvVPqmmqRpGmCE+5Do4LcxisviOgqCEAJXqhBZsLDqaCM9Sj2aoSTdaatBPHF3SpUORPh/gdCIDlzqMbN+cnTP6s6NDzHg5OvbXmJsFGanVpgdeTuyc7BTUAwJoBC49tzDvkwQtmgOHabk5eFmDlcaU9uLF98Mp/rbu1J3FnUfJf+tl4+ugFg8EsCMnDFH4HU9pkXu897eD6/H2DDikzF7pIbYJqjZqWelPjrcie0/e8FjD1zm6gqb5PlSRV/PwJQ5iKjrqOcw3+8EJtVvWZupw6AHil7+zvPs8/YuQ5lgfLtj6MBN4i0LZnYuqjdNK408aeSSv/Xd5c52Ev6VHfseiWtkQNTrajl517zL2nhdoPOL9FIt9QaajnHBx7mCL7z5q2JffQCoXMvo9BMFMZQy4v9Ju0a7FbaKc6I1xDzhxXnv/akrM4+SjN6Mhk4m+klD6/PGvbDwfKL0wd49zfrVRfU2MrtT7sMaj/ndBR4sj3XvvLpY/jz9Rfm9JX7tWDEsrn6ZTFox37744d8cbtdrm5A4ZrzpaWbOQpDLUR37YAwAqvsIKxaWtfP1N9NWiq9xP7drbJsmBzIQjfeEqdWwefebG8X9KLWwqblQH2cnmnOIWQKgAAAJJJREFUv8bpyHPeYdu/L0ks4TkJD6atvym1CHHwOftTB7mp3iMzj5ae+1LKSDtdBqH243R5xvJNal5n7+7sqe1YNlrRPz6tKoOz5Wwudzw+y2NE/sHyjM0cy+Xfq0+E2+Cth8vP6SGRmkJs+2z9sWNhWKo57Py6j1IqLw3lGanQtg+aEELY0U79rsfez0iRPw3/C/XIrFfnuBlZAAAAAElFTkSuQmCC`
}

