import { Injectable } from '@angular/core';
import { countryData } from '../countries';
import { WebService } from './web.service';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  countries = [...countryData]  
  selectedCountry = this.countries[0];
  userData:any
  currentPaymentMethod: 0 | 1 = 0

  constructor(private web:WebService) { }

  get landingPageUserData(){
    return {
      id : ''
    }
  }

  get user(){
    let userData = JSON.parse(localStorage.getItem('userData') ?? '')
    return userData;
  }


  countryFromCountryCode(code: any){
    return this.countries.find((country) => {
      return country['code'] == code
    })
  }

  get paymentMethods(){
    let user = this.user;
    return [{
      account_name : user['account_name'],
      account_number : user['account_number'],
      account_expiration_date : user['account_expiration_date'],
      account_cvv : user['account_cvv']
    },{
      mobile_money_name : user['mobile_money_name'],
      mobile_money_number : user['mobile_money_number']
    }]
  }


  get mobileMoneyAccount(){
    let user = this.user;
    return {
      mobile_money_name : user['mobile_money_name'],
      mobile_money_number : user['mobile_money_number']
    }
  }

  get bankAccount(){
    let user = this.user;
    return {
      account_name : user['account_name'],
      account_number : user['account_number'],
      account_expiration_date : user['account_expiration_date'],
      account_cvv : user['account_cvv']
    }
  }


  get userCountry(){
    let user = this.user;
    return this.countryFromCountryCode(user['country_code'])
  }



  userDetails(){
    this.web.postData('/',{
      user_id : this.user['id']
    }).subscribe(
      (res) => {
        this.userData = res['data']
      },
      (err) => {
        console.log(err)
      }
    )
  }

  refresh(){
    this.selectedCountry = this.countries[0];
    this.currentPaymentMethod = 0
  }




}
