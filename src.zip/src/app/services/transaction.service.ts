import { Injectable } from '@angular/core';
import { Recipient } from './recipient';
@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  Recipient!:{
    recipient_id:number,
    recipient_name:string,
    phone:string,
    country_code:string,
    banking_method:string,   
    cashout_fee:boolean,   
    bank_name:string,  
    bank_acc_number:string,    
    address_one:string,
    address_two:string,    
    city:string,
    country:string,    
  }
  
  

  transaction_amount!:number;

  cashoutFee: number = 0;
  

   _transaction_details = {
    'fromCountry' : '',
    'toCountry' : '',
    'fromCurrency' : '',
    'toCurrency' : '',
    'fromAmount' : 0,
    'toAmount' : 0,
    'conversion' : 0,
  }

  get transaction_details(){
    return this._transaction_details
  }

 

  set transaction_details(transactionData){
    this._transaction_details['fromAmount'] = transactionData['fromAmount']
    this._transaction_details['toAmount'] = transactionData['toAmount']
    this._transaction_details['toCurrency'] = transactionData['toCurrency']    
    this._transaction_details['fromCurrency'] = transactionData['fromCurrency']
    this._transaction_details['conversion'] = transactionData['conversion']
    this._transaction_details['fromCountry'] = transactionData['fromCountry']
    this._transaction_details['toCountry'] = transactionData['toCountry']
  }

  constructor() { }

  addNewRecipient(banking_method:string){
    this.Recipient = new Recipient(banking_method)
  }

  existingRecipient(recipientData:any,banking_method:string){
    this.Recipient = new Recipient(banking_method)
    this.Recipient.recipient_name = recipientData.first_name
    this.Recipient.phone = recipientData.phone
    this.Recipient.country_code = recipientData.country_code
    this.Recipient.recipient_id = recipientData.id
    if(banking_method == 'Mobile Money'){
      this.Recipient.cashout_fee = false      
    }
    if(banking_method == 'Bank'){
      this.Recipient.bank_name = recipientData.bank_name
      this.Recipient.bank_acc_number = recipientData.iban
    }
    if(banking_method == 'Cash'){
      this.Recipient.address_one = recipientData.address
      this.Recipient.country = recipientData.country
    }
  }

  refresh(){
    this._transaction_details = {
      'fromCountry' : '',
      'toCountry' : '',
      'fromCurrency' : '',
      'toCurrency' : '',
      'fromAmount' : 0,
      'toAmount' : 0,
      'conversion' : 0,
    }
    this.Recipient = new Recipient('Bank')
    this.cashoutFee = 0
  }


  // clearRecipient(){
  //   this.Recipient = null
  // }

}
