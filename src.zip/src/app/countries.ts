export const countryData = [
  {
    "code": "237",
    "name": "Cameroon",
    "path": "../../assets/flags/cm.svg",
    "value": "CM",
    "currencies": "XAF",
    "symbol": "FCFA"
  },
  
  
  {
    "code": "376",
    "name": "Andorra",
    "path": "../../assets/flags/ad.svg",
    "value": "AD",
    "currencies": "EUR",
    "symbol": "€"
    
  },
  {
    "code": "971",
    "name": "United Arab Emirates",
    "path": "../../assets/flags/ae.svg",
    "value": "AE",
    "currencies": "AED",
    "symbol": "إ.د"
  },
  {
    "code": "93",
    "name": "Afghanistan",
    "path": "../../assets/flags/af.svg",
    "value": "AF",
    "currencies": "AFN",
    "symbol": "؋"
  },
  {
    "code": "1268",
    "name": "Antigua and Barbuda",
    "path": "../../assets/flags/ag.svg",
    "value": "AG",
    "currencies": "XCD", 
    "symbol": "$"
  },
  {
    "code": "1264",
    "name": "Anguilla",
    "path": "../../assets/flags/ai.svg",
    "value": "AI",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "355",
    "name": "Albania",
    "path": "../../assets/flags/al.svg",
    "value": "AL",
    "currencies": "ALL",
    "symbol": "Lek"
  },
  {
    "code": "374",
    "name": "Armenia",
    "path": "../../assets/flags/am.svg",
    "value": "AM",
    "currencies": "AMD",
    "symbol": "֏"
  },
  {
    "code": "244",
    "name": "Angola",
    "path": "../../assets/flags/ao.svg",
    "value": "AO",
    "currencies": "AOA",
    "symbol": "Kz"
  },
  {
    "code": "672",
    "name": "Antarctica",
    "path": "../../assets/flags/aq.svg",
    "value": "AQ",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "54",
    "name": "Argentina",
    "path": "../../assets/flags/ar.svg",
    "value": "AR",
    "currencies": "ARS",
    "symbol": "$"
  },
  {
    "code": "1684",
    "name": "American Samoa",
    "path": "../../assets/flags/as.svg",
    "value": "AS",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "43",
    "name": "Austria",
    "path": "../../assets/flags/at.svg",
    "value": "AT",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "61",
    "name": "Australia",
    "path": "../../assets/flags/au.svg",
    "value": "AU",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "297",
    "name": "Aruba",
    "path": "../../assets/flags/aw.svg",
    "value": "AW",
    "currencies": "AWG",
    "symbol": "ƒ"
  },
  {
    "code": "358",
    "name": "Åland Islands",
    "path": "../../assets/flags/ax.svg",
    "value": "AX",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "994",
    "name": "Azerbaijan",
    "path": "../../assets/flags/az.svg",
    "value": "AZ",
    "currencies": "AZN",
    "symbol": "€"
  },
  {
    "code": "387",
    "name": "Bosnia and Herzegovina",
    "path": "../../assets/flags/ba.svg",
    "value": "BA",
    "currencies": "BAM",
    "symbol": "KM"
  },
  {
    "code": "1246",
    "name": "Barbados",
    "path": "../../assets/flags/bb.svg",
    "value": "BB",
    "currencies": "BBD",
    "symbol": "Bds$"
  },
  {
    "code": "880",
    "name": "Bangladesh",
    "path": "../../assets/flags/bd.svg",
    "value": "BD",
    "currencies": "BDT",
    "symbol": "৳"
  },
  {
    "code": "32",
    "name": "Belgium",
    "path": "../../assets/flags/be.svg",
    "value": "BE",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "226",
    "name": "Burkina Faso",
    "path": "../../assets/flags/bf.svg",
    "value": "BF",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "359",
    "name": "Bulgaria",
    "path": "../../assets/flags/bg.svg",
    "value": "BG",
    "currencies": "BGN",
    "symbol": "Лв."
    
  },
  {
    "code": "973",
    "name": "Bahrain",
    "path": "../../assets/flags/bh.svg",
    "value": "BH",
    "currencies": "BHD",
    "symbol": ".د.ب"
  },
  {
    "code": "257",
    "name": "Burundi",
    "path": "../../assets/flags/bi.svg",
    "value": "BI",
    "currencies": "BIF",
    "symbol": "FBu"
  },
  {
    "code": "229",
    "name": "Benin",
    "path": "../../assets/flags/bj.svg",
    "value": "BJ",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "590",
    "name": "Saint Barthélemy",
    "path": "../../assets/flags/bl.svg",
    "value": "BL",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "1441",
    "name": "Bermuda",
    "path": "../../assets/flags/bm.svg",
    "value": "BM",
    "currencies": "BMD",
    "symbol": "$"
  },
  {
    "code": "673",
    "name": "Brunei Darussalam",
    "path": "../../assets/flags/bn.svg",
    "value": "BN",
    "currencies": "BND",
    "symbol": "B$"
  },
  {
    "code": "591",
    "name": "Bolivia",
    "path": "../../assets/flags/bo.svg",
    "value": "BO",
    "currencies": "BOB",
    "symbol": "Bs."
  },
  {
    "code": "599",
    "name": "Bonaire, Sint Eustatius and Saba",
    "path": "../../assets/flags/bq.svg",
    "value": "BQ",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "55",
    "name": "Brazil",
    "path": "../../assets/flags/br.svg",
    "value": "BR",
    "currencies": "BRL",
    "symbol": "R$"
  },
  {
    "code": "1242",
    "name": "Bahamas",
    "path": "../../assets/flags/bs.svg",
    "value": "BS",
    "currencies": "BSD",
    "symbol": "B$"
  },
  {
    "code": "975",
    "name": "Bhutan",
    "path": "../../assets/flags/bt.svg",
    "value": "BT",
    "currencies": "BTN",
    "symbol": "Nu."
  },
  {
    "code": "47",
    "name": "Bouvet Island",
    "path": "../../assets/flags/bv.svg",
    "value": "BV",
    "currencies": "NOK",
    "symbol": "kr"
  },
  {
    "code": "267",
    "name": "Botswana",
    "path": "../../assets/flags/bw.svg",
    "value": "BW",
    "currencies": "BWP",
    "symbol": "P"
  },
  {
    "code": "375",
    "name": "Belarus",
    "path": "../../assets/flags/by.svg",
    "value": "BY",
    "currencies": "BYR",
    "symbol": "Br"
  },
  {
    "code": "501",
    "name": "Belize",
    "path": "../../assets/flags/bz.svg",
    "value": "BZ",
    "currencies": "BZD",
    "symbol": "$"
  },
  {
    "code": "1",
    "name": "Canada",
    "path": "../../assets/flags/ca.svg",
    "value": "CA",
    "currencies": "CAD",
    "symbol": "$"
  },
  {
    "code": "61",
    "name": "Cocos (Keeling) Islands",
    "path": "../../assets/flags/cc.svg",
    "value": "CC",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "243",
    "name": "Democratic Republic of the Congo",
    "path": "../../assets/flags/cd.svg",
    "value": "CD",
    "currencies": "CDF",
    "symbol": "FC"
  },
  {
    "code": "236",
    "name": "Central African Republic",
    "path": "../../assets/flags/cf.svg",
    "value": "CF",
    "currencies": "XAF",
    "symbol": "FCFA"
  },
  {
    "code": "242",
    "name": "Republic of the Congo",
    "path": "../../assets/flags/cg.svg",
    "value": "CG",
    "currencies": "CDF",
    "symbol": "FC"
  },
  {
    "code": "41",
    "name": "Switzerland",
    "path": "../../assets/flags/ch.svg",
    "value": "CH",
    "currencies": "CHF",
    "symbol": "CHf"
  },
  {
    "code": "225",
    "name": "Côte d'Ivoire",
    "path": "../../assets/flags/ci.svg",
    "value": "CI",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "682",
    "name": "Cook Islands",
    "path": "../../assets/flags/ck.svg",
    "value": "CK",
    "currencies": "NZD",
    "symbol": "$"
  },
  {
    "code": "56",
    "name": "Chile",
    "path": "../../assets/flags/cl.svg",
    "value": "CL",
    "currencies": "CLP",
    "symbol": "$"
  },
  
  {
    "code": "86",
    "name": "China",
    "path": "../../assets/flags/cn.svg",
    "value": "CN",
    "currencies": "CNY",
    "symbol": "¥"
  },
  {
    "code": "57",
    "name": "Colombia",
    "path": "../../assets/flags/co.svg",
    "value": "CO",
    "currencies": "COP",
    "symbol": "$"
  },
  {
    "code": "506",
    "name": "Costa Rica",
    "path": "../../assets/flags/cr.svg",
    "value": "CR",
    "currencies": "CRC",
    "symbol": "₡"
  },
  {
    "code": "53",
    "name": "Cuba",
    "path": "../../assets/flags/cu.svg",
    "value": "CU",
    "currencies": "CUP",
    "symbol": "$"
  },
  {
    "code": "238",
    "name": "Cape Verde",
    "path": "../../assets/flags/cv.svg",
    "value": "CV",
    "currencies": "CVE",
    "symbol": "$"
  },
  {
    "code": "599",
    "name": "Curaçao",
    "path": "../../assets/flags/cw.svg",
    "value": "CW",
    "currencies": "ANG",
    "symbol": "ƒ"
  },
  {
    "code": "61",
    "name": "Christmas Island",
    "path": "../../assets/flags/cx.svg",
    "value": "CX",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "357",
    "name": "Cyprus",
    "path": "../../assets/flags/cy.svg",
    "value": "CY",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "420",
    "name": "Czech Republic",
    "path": "../../assets/flags/cz.svg",
    "value": "CZ",
    "currencies": "CZK",
    "symbol": "Kč"
  },
  {
    "code": "49",
    "name": "Germany",
    "path": "../../assets/flags/de.svg",
    "value": "DE",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "253",
    "name": "Djibouti",
    "path": "../../assets/flags/dj.svg",
    "value": "DJ",
    "currencies": "DJF",
    "symbol": "Fdj"
  },
  {
    "code": "45",
    "name": "Denmark",
    "path": "../../assets/flags/dk.svg",
    "value": "DK",
    "currencies": "DKK",
    "symbol": "Kr."
  },
  {
    "code": "1767",
    "name": "Dominica",
    "path": "../../assets/flags/dm.svg",
    "value": "DM",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "1809",
    "name": "Dominican Republic",
    "path": "../../assets/flags/do.svg",
    "value": "DO",
    "currencies": "DOP",
    "symbol": "$"
  },
  {
    "code": "213",
    "name": "Algeria",
    "path": "../../assets/flags/dz.svg",
    "value": "DZ",
    "currencies": "DZD",
    "symbol": "$"
  },
  {
    "code": "593",
    "name": "Ecuador",
    "path": "../../assets/flags/ec.svg",
    "value": "EC",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "372",
    "name": "Estonia",
    "path": "../../assets/flags/ee.svg",
    "value": "EE",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "20",
    "name": "Egypt",
    "path": "../../assets/flags/eg.svg",
    "value": "EG",
    "currencies": "EGP",
    "symbol": "ج.م"
  },
  {
    "code": "291",
    "name": "Eritrea",
    "path": "../../assets/flags/er.svg",
    "value": "ER",
    "currencies": "ERN",
    "symbol": "Nfk"
  },
  {
    "code": "34",
    "name": "Spain",
    "path": "../../assets/flags/es.svg",
    "value": "ES",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "251",
    "name": "Ethiopia",
    "path": "../../assets/flags/et.svg",
    "value": "ET",
    "currencies": "ETB",
    "symbol": "Nkf"
  },
  {
    "code": "358",
    "name": "European Union",
    "path": "../../assets/flags/eu.svg",
    "value": "EU",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "358",
    "name": "Finland",
    "path": "../../assets/flags/fi.svg",
    "value": "FI",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "679",
    "name": "Fiji",
    "path": "../../assets/flags/fj.svg",
    "value": "FJ",
    "currencies": "FJD",
    "symbol": "FJ$"
  },
  {
    "code": "500",
    "name": "Falkland Islands (Malvinas)",
    "path": "../../assets/flags/fk.svg",
    "value": "FK",
    "currencies": "FKP",
    "symbol": "£"
  },
  {
    "code": "691",
    "name": "Federated States of Micronesia",
    "path": "../../assets/flags/fm.svg",
    "value": "FM",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "298",
    "name": "Faroe Islands",
    "path": "../../assets/flags/fo.svg",
    "value": "FO",
    "currencies": "DKK",
    "symbol": "Kr."
  },
  {
    "code": "33",
    "name": "France",
    "path": "../../assets/flags/fr.svg",
    "value": "FR",
    "currencies": "EUR",
    "symbol": "€"
    
  },
  {
    "code": "241",
    "name": "Gabon",
    "path": "../../assets/flags/ga.svg",
    "value": "GA",
    "currencies": "XAF",
    "symbol": "FCFA"
  },
  {
    "code": "44",
    "name": "England",
    "path": "../../assets/flags/gb-eng.svg",
    "value": "GB-ENG",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "44",
    "name": "Northern Ireland",
    "path": "../../assets/flags/gb-nir.svg",
    "value": "GB-NIR",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "44",
    "name": "Scotland",
    "path": "../../assets/flags/gb-sct.svg",
    "value": "GB-SCT",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "44",
    "name": "Wales",
    "path": "../../assets/flags/gb-wls.svg",
    "value": "GB-WLS",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "44",
    "name": "United Kingdom",
    "path": "../../assets/flags/gb.svg",
    "value": "GB",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "1473",
    "name": "Grenada",
    "path": "../../assets/flags/gd.svg",
    "value": "GD",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "995",
    "name": "Georgia",
    "path": "../../assets/flags/ge.svg",
    "value": "GE",
    "currencies": "GEL",
    "symbol": "ლ"
  },
  {
    "code": "594",
    "name": "French Guiana",
    "path": "../../assets/flags/gf.svg",
    "value": "GF",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "44",
    "name": "Guernsey",
    "path": "../../assets/flags/gg.svg",
    "value": "GG",
    "currencies": "GGP",
    "symbol": "£"
  },
  {
    "code": "233",
    "name": "Ghana",
    "path": "../../assets/flags/gh.svg",
    "value": "GH",
    "currencies": "GHS",
    "symbol": "GH₵"
  },
  {
    "code": "350",
    "name": "Gibraltar",
    "path": "../../assets/flags/gi.svg",
    "value": "GI",
    "currencies": "GIP",
    "symbol": "£"
  },
  {
    "code": "299",
    "name": "Greenland",
    "path": "../../assets/flags/gl.svg",
    "value": "GL",
    "currencies": "DKK",
    "symbol": "Kr."
  },
  {
    "code": "220",
    "name": "Gambia",
    "path": "../../assets/flags/gm.svg",
    "value": "GM",
    "currencies": "GMD",
    "symbol": "D"
  },
  {
    "code": "224",
    "name": "Guinea",
    "path": "../../assets/flags/gn.svg",
    "value": "GN",
    "currencies": "GNF",
    "symbol": "FG"
  },
  {
    "code": "590",
    "name": "Guadeloupe",
    "path": "../../assets/flags/gp.svg",
    "value": "GP",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "240",
    "name": "Equatorial Guinea",
    "path": "../../assets/flags/gq.svg",
    "value": "GQ",
    "currencies": "XAF",
    "symbol": "FCFA"
  },
  {
    "code": "30",
    "name": "Greece",
    "path": "../../assets/flags/gr.svg",
    "value": "GR",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "500",
    "name": "South Georgia and the South Sandwich Islands",
    "path": "../../assets/flags/gs.svg",
    "value": "GS",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "502",
    "name": "Guatemala",
    "path": "../../assets/flags/gt.svg",
    "value": "GT",
    "currencies": "GTQ",
    "symbol": "Q"
  },
  {
    "code": "1671",
    "name": "Guam",
    "path": "../../assets/flags/gu.svg",
    "value": "GU",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "245",
    "name": "Guinea-Bissau",
    "path": "../../assets/flags/gw.svg",
    "value": "GW",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "592",
    "name": "Guyana",
    "path": "../../assets/flags/gy.svg",
    "value": "GY",
    "currencies": "GYD",
    "symbol": "$"
  },
  {
    "code": "852",
    "name": "Hong Kong",
    "path": "../../assets/flags/hk.svg",
    "value": "HK",
    "currencies": "HKD",
    "symbol": "$"
  },
  {
    "code": "672",
    "name": "Heard Island and McDonald Islands",
    "path": "../../assets/flags/hm.svg",
    "value": "HM",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "504",
    "name": "Honduras",
    "path": "../../assets/flags/hn.svg",
    "value": "HN",
    "currencies": "HNL",
    "symbol": "L"
  },
  {
    "code": "385",
    "name": "Croatia",
    "path": "../../assets/flags/hr.svg",
    "value": "HR",
    "currencies": "HRK",
    "symbol": "kn"
  },
  {
    "code": "509",
    "name": "Haiti",
    "path": "../../assets/flags/ht.svg",
    "value": "HT",
    "currencies": "HTG",
    "symbol": "G"
  },
  {
    "code": "36",
    "name": "Hungary",
    "path": "../../assets/flags/hu.svg",
    "value": "HU",
    "currencies": "HUF",
    "symbol": "Ft"
  },
  {
    "code": "62",
    "name": "Indonesia",
    "path": "../../assets/flags/id.svg",
    "value": "ID",
    "currencies": "IDR",
    "symbol": "Rp"
  },
  {
    "code": "353",
    "name": "Ireland",
    "path": "../../assets/flags/ie.svg",
    "value": "IE",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "972",
    "name": "Israel",
    "path": "../../assets/flags/il.svg",
    "value": "IL",
    "currencies": "ILS",
    "symbol": "₪"
  },
  {
    "code": "44",
    "name": "Isle of Man",
    "path": "../../assets/flags/im.svg",
    "value": "IM",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "91",
    "name": "India",
    "path": "../../assets/flags/in.svg",
    "value": "IN",
    "currencies": "INR",
    "symbol": "₹"
  },
  {
    "code": "246",
    "name": "British Indian Ocean Territory",
    "path": "../../assets/flags/io.svg",
    "value": "IO",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "964",
    "name": "Iraq",
    "path": "../../assets/flags/iq.svg",
    "value": "IQ",
    "currencies": "IQD",
    "symbol": "د.ع"
  },
  {
    "code": "98",
    "name": "Iran",
    "path": "../../assets/flags/ir.svg",
    "value": "IR",
    "currencies": "IQD",
    "symbol": "د.ع"
  },
  {
    "code": "354",
    "name": "Iceland",
    "path": "../../assets/flags/is.svg",
    "value": "IS",
    "currencies": "ISK",
    "symbol": "kr"
  },
  {
    "code": "39",
    "name": "Italy",
    "path": "../../assets/flags/it.svg",
    "value": "IT",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "44",
    "name": "Jersey",
    "path": "../../assets/flags/je.svg",
    "value": "JE",
    "currencies": "GBP",
    "symbol": "£"
  },
  {
    "code": "1876",
    "name": "Jamaica",
    "path": "../../assets/flags/jm.svg",
    "value": "JM",
    "currencies": "JMD",
    "symbol": "J$"
  },
  {
    "code": "962",
    "name": "Jordan",
    "path": "../../assets/flags/jo.svg",
    "value": "JO",
    "currencies": "JOD",
    "symbol": "ا.د"
  },
  {
    "code": "81",
    "name": "Japan",
    "path": "../../assets/flags/jp.svg",
    "value": "JP",
    "currencies": "JPY",
    "symbol": "¥"
  },
  {
    "code": "254",
    "name": "Kenya",
    "path": "../../assets/flags/ke.svg",
    "value": "KE",
    "currencies": "KES",
    "symbol": "KSh"
  },
  {
    "code": "996",
    "name": "Kyrgyzstan",
    "path": "../../assets/flags/kg.svg",
    "value": "KG",
    "currencies": "KGS",
    "symbol": "лв"
  },
  {
    "code": "855",
    "name": "Cambodia",
    "path": "../../assets/flags/kh.svg",
    "value": "KH",
    "currencies": "KHR",
    "symbol": "KHR"
  },
  {
    "code": "686",
    "name": "Kiribati",
    "path": "../../assets/flags/ki.svg",
    "value": "KI",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "269",
    "name": "Comoros",
    "path": "../../assets/flags/km.svg",
    "value": "KM",
    "currencies": "KMF",
    "symbol": "CF"
  },
  {
    "code": "1869",
    "name": "Saint Kitts and Nevis",
    "path": "../../assets/flags/kn.svg",
    "value": "KN",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "850",
    "name": "North Korea",
    "path": "../../assets/flags/kp.svg",
    "value": "KP",
    "currencies": "KPW",
    "symbol": "₩"
  },
  {
    "code": "82",
    "name": "South Korea",
    "path": "../../assets/flags/kr.svg",
    "value": "KR",
    "currencies": "KRW",
    "symbol": "₩"
  },
  {
    "code": "965",
    "name": "Kuwait",
    "path": "../../assets/flags/kw.svg",
    "value": "KW",
    "currencies": "KWD",
    "symbol": "ك.د"
  },
  {
    "code": "1345",
    "name": "Cayman Islands",
    "path": "../../assets/flags/ky.svg",
    "value": "KY",
    "currencies": "KYD",
    "symbol": "$"
  },
  {
    "code": "7",
    "name": "Kazakhstan",
    "path": "../../assets/flags/kz.svg",
    "value": "KZ",
    "currencies": "KZT",
    "symbol": "лв"
  },
  {
    "code": "856",
    "name": "Lao People's Democratic Republic",
    "path": "../../assets/flags/la.svg",
    "value": "LA",
    "currencies": "LAK",
    "symbol": "₭"
  },
  {
    "code": "961",
    "name": "Lebanon",
    "path": "../../assets/flags/lb.svg",
    "value": "LB",
    "currencies": "LBP",
    "symbol": "£"
  },
  {
    "code": "1758",
    "name": "Saint Lucia",
    "path": "../../assets/flags/lc.svg",
    "value": "LC",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "423",
    "name": "Liechtenstein",
    "path": "../../assets/flags/li.svg",
    "value": "LI",
    "currencies": "CHF",
    "symbol": "CHf"
  },
  {
    "code": "94",
    "name": "Sri Lanka",
    "path": "../../assets/flags/lk.svg",
    "value": "LK",
    "currencies": "LKR",
    "symbol": "Rs"
  },
  {
    "code": "231",
    "name": "Liberia",
    "path": "../../assets/flags/lr.svg",
    "value": "LR",
    "currencies": "LRD",
    "symbol": "$"
  },
  {
    "code": "266",
    "name": "Lesotho",
    "path": "../../assets/flags/ls.svg",
    "value": "LS",
    "currencies": "LSL",
    "symbol": "L"
  },
  {
    "code": "370",
    "name": "Lithuania",
    "path": "../../assets/flags/lt.svg",
    "value": "LT",
    "currencies": "LTL",
    "symbol": "Lt"
  },
  {
    "code": "352",
    "name": "Luxembourg",
    "path": "../../assets/flags/lu.svg",
    "value": "LU",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "371",
    "name": "Latvia",
    "path": "../../assets/flags/lv.svg",
    "value": "LV",
    "currencies": "LVL",
    "symbol": "Ls"
  },
  {
    "code": "218",
    "name": "Libya",
    "path": "../../assets/flags/ly.svg",
    "value": "LY",
    "currencies": "LYD",
    "symbol": "Lد.ل"
  },
  {
    "code": "212",
    "name": "Morocco",
    "path": "../../assets/flags/ma.svg",
    "value": "MA",
    "currencies": "MAD",
    "symbol": "MAD"
  },
  {
    "code": "377",
    "name": "Monaco",
    "path": "../../assets/flags/mc.svg",
    "value": "MC",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "373",
    "name": "Moldova",
    "path": "../../assets/flags/md.svg",
    "value": "MD",
    "currencies": "MDL",
    "symbol": "L"
  },
  {
    "code": "382",
    "name": "Montenegro",
    "path": "../../assets/flags/me.svg",
    "value": "ME",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "590",
    "name": "Saint Martin (French part)",
    "path": "../../assets/flags/mf.svg",
    "value": "MF",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "261",
    "name": "Madagascar",
    "path": "../../assets/flags/mg.svg",
    "value": "MG",
    "currencies": "MGA",
    "symbol": "Ar"
  },
  {
    "code": "692",
    "name": "Marshall Islands",
    "path": "../../assets/flags/mh.svg",
    "value": "MH",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "389",
    "name": "North Macedonia",
    "path": "../../assets/flags/mk.svg",
    "value": "MK",
    "currencies": "MKD",
    "symbol": "ден"
  },
  {
    "code": "223",
    "name": "Mali",
    "path": "../../assets/flags/ml.svg",
    "value": "ML",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "95",
    "name": "Myanmar",
    "path": "../../assets/flags/mm.svg",
    "value": "MM",
    "currencies": "MMK",
    "symbol": "K"
  },
  {
    "code": "976",
    "name": "Mongolia",
    "path": "../../assets/flags/mn.svg",
    "value": "MN",
    "currencies": "MNT",
    "symbol": "₮"
  },
  {
    "code": "853",
    "name": "Macao",
    "path": "../../assets/flags/mo.svg",
    "value": "MO",
    "currencies": "MOP",
    "symbol": "$"
  },
  {
    "code": "1670",
    "name": "Northern Mariana Islands",
    "path": "../../assets/flags/mp.svg",
    "value": "MP",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "596",
    "name": "Martinique",
    "path": "../../assets/flags/mq.svg",
    "value": "MQ",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "222",
    "name": "Mauritania",
    "path": "../../assets/flags/mr.svg",
    "value": "MR",
    "currencies": "MRO",
    "symbol": "MRU"
  },
  {
    "code": "1664",
    "name": "Montserrat",
    "path": "../../assets/flags/ms.svg",
    "value": "MS",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "356",
    "name": "Malta",
    "path": "../../assets/flags/mt.svg",
    "value": "MT",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "230",
    "name": "Mauritius",
    "path": "../../assets/flags/mu.svg",
    "value": "MU",
    "currencies": "MUR",
    "symbol": "₨"
  },
  {
    "code": "960",
    "name": "Maldives",
    "path": "../../assets/flags/mv.svg",
    "value": "MV",
    "currencies": "MVR",
    "symbol": "Rf"
  },
  {
    "code": "265",
    "name": "Malawi",
    "path": "../../assets/flags/mw.svg",
    "value": "MW",
    "currencies": "MWK",
    "symbol": "MK"
  },
  {
    "code": "52",
    "name": "Mexico",
    "path": "../../assets/flags/mx.svg",
    "value": "MX",
    "currencies": "MXN",
    "symbol": "$"
  },
  {
    "code": "60",
    "name": "Malaysia",
    "path": "../../assets/flags/my.svg",
    "value": "MY",
    "currencies": "MYR",
    "symbol": "RM"
  },
  {
    "code": "258",
    "name": "Mozambique",
    "path": "../../assets/flags/mz.svg",
    "value": "MZ",
    "currencies": "MZM",
    "symbol": "MT"
  },
  {
    "code": "264",
    "name": "Namibia",
    "path": "../../assets/flags/na.svg",
    "value": "NA",
    "currencies": "NAD",
    "symbol": "$"
  },
  {
    "code": "687",
    "name": "New Caledonia",
    "path": "../../assets/flags/nc.svg",
    "value": "NC",
    "currencies": "XPF",
    "symbol": "₣"
  },
  {
    "code": "227",
    "name": "Niger",
    "path": "../../assets/flags/ne.svg",
    "value": "NE",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "672",
    "name": "Norfolk Island",
    "path": "../../assets/flags/nf.svg",
    "value": "NF",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "234",
    "name": "Nigeria",
    "path": "../../assets/flags/ng.svg",
    "value": "NG",
    "currencies": "NGN"
  },
  {
    "code": "505",
    "name": "Nicaragua",
    "path": "../../assets/flags/ni.svg",
    "value": "NI",
    "currencies": "NIO"
  },
  {
    "code": "31",
    "name": "Netherlands",
    "path": "../../assets/flags/nl.svg",
    "value": "NL",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "47",
    "name": "Norway",
    "path": "../../assets/flags/no.svg",
    "value": "NO",
    "currencies": "NOK"
  },
  {
    "code": "977",
    "name": "Nepal",
    "path": "../../assets/flags/np.svg",
    "value": "NP",
    "currencies": "NPR"
  },
  {
    "code": "674",
    "name": "Nauru",
    "path": "../../assets/flags/nr.svg",
    "value": "NR",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "683",
    "name": "Niue",
    "path": "../../assets/flags/nu.svg",
    "value": "NU",
    "currencies": "NZD",
    "symbol": "$"
  },
  {
    "code": "64",
    "name": "New Zealand",
    "path": "../../assets/flags/nz.svg",
    "value": "NZ",
    "currencies": "NZD",
    "symbol": "$"
  },
  {
    "code": "968",
    "name": "Oman",
    "path": "../../assets/flags/om.svg",
    "value": "OM",
    "currencies": "OMR"
  },
  {
    "code": "507",
    "name": "Panama",
    "path": "../../assets/flags/pa.svg",
    "value": "PA",
    "currencies": "PAB"
  },
  {
    "code": "51",
    "name": "Peru",
    "path": "../../assets/flags/pe.svg",
    "value": "PE",
    "currencies": "PEN"
  },
  {
    "code": "689",
    "name": "French Polynesia",
    "path": "../../assets/flags/pf.svg",
    "value": "PF",
    "currencies": "XPF",
    "symbol": "₣"
  },
  {
    "code": "675",
    "name": "Papua New Guinea",
    "path": "../../assets/flags/pg.svg",
    "value": "PG",
    "currencies": "PGK",
    "symbol": "K"
  },
  {
    "code": "63",
    "name": "Philippines",
    "path": "../../assets/flags/ph.svg",
    "value": "PH",
    "currencies": "PHP",
    "symbol": "₱"
  },
  {
    "code": "92",
    "name": "Pakistan",
    "path": "../../assets/flags/pk.svg",
    "value": "PK",
    "currencies": "PKR",
    "symbol": "₨"
  },
  {
    "code": "48",
    "name": "Poland",
    "path": "../../assets/flags/pl.svg",
    "value": "PL",
    "currencies": "PLN",
    "symbol": "zł"
  },
  {
    "code": "508",
    "name": "Saint Pierre and Miquelon",
    "path": "../../assets/flags/pm.svg",
    "value": "PM",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "870",
    "name": "Pitcairn",
    "path": "../../assets/flags/pn.svg",
    "value": "PN",
    "currencies": "NZD",
    "symbol": "$"
  },
  {
    "code": "1",
    "name": "Puerto Rico",
    "path": "../../assets/flags/pr.svg",
    "value": "PR",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "970",
    "name": "Palestine",
    "path": "../../assets/flags/ps.svg",
    "value": "PS",
    "currencies": "ILS",
    "symbol": "₪"
  },
  {
    "code": "351",
    "name": "Portugal",
    "path": "../../assets/flags/pt.svg",
    "value": "PT",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "680",
    "name": "Palau",
    "path": "../../assets/flags/pw.svg",
    "value": "PW",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "595",
    "name": "Paraguay",
    "path": "../../assets/flags/py.svg",
    "value": "PY",
    "currencies": "PYG",
    "symbol": "₲"
  },
  {
    "code": "974",
    "name": "Qatar",
    "path": "../../assets/flags/qa.svg",
    "value": "QA",
    "currencies": "QAR",
    "symbol": "ق.ر"
  },
  {
    "code": "262",
    "name": "Réunion",
    "path": "../../assets/flags/re.svg",
    "value": "RE",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "40",
    "name": "Romania",
    "path": "../../assets/flags/ro.svg",
    "value": "RO",
    "currencies": "RON",
    "symbol": "lei"
  },
  {
    "code": "381",
    "name": "Serbia",
    "path": "../../assets/flags/rs.svg",
    "value": "RS",
    "currencies": "RSD",
    "symbol": "din"
  },
  {
    "code": "7",
    "name": "Russia",
    "path": "../../assets/flags/ru.svg",
    "value": "RU",
    "currencies": "RUB",
    "symbol": "₽"
  },
  {
    "code": "250",
    "name": "Rwanda",
    "path": "../../assets/flags/rw.svg",
    "value": "RW",
    "currencies": "RWF",
    "symbol": "FRw"
  },
  {
    "code": "966",
    "name": "Saudi Arabia",
    "path": "../../assets/flags/sa.svg",
    "value": "SA",
    "currencies": "SAR",
    "symbol": "﷼"
  },
  {
    "code": "677",
    "name": "Solomon Islands",
    "path": "../../assets/flags/sb.svg",
    "value": "SB",
    "currencies": "SBD",
    "symbol": "Si$"
  },
  {
    "code": "248",
    "name": "Seychelles",
    "path": "../../assets/flags/sc.svg",
    "value": "SC",
    "currencies": "SCR",
    "symbol": "SRe"
  },
  {
    "code": "249",
    "name": "Sudan",
    "path": "../../assets/flags/sd.svg",
    "value": "SD",
    "currencies": "SDG",
    "symbol": ".س.ج"
  },
  {
    "code": "46",
    "name": "Sweden",
    "path": "../../assets/flags/se.svg",
    "value": "SE",
    "currencies": "SEK",
    "symbol": "kr"
  },
  {
    "code": "65",
    "name": "Singapore",
    "path": "../../assets/flags/sg.svg",
    "value": "SG",
    "currencies": "SGD",
    "symbol": "$"
  },
  {
    "code": "290",
    "name": "Saint Helena, Ascension and Tristan da Cunha",
    "path": "../../assets/flags/sh.svg",
    "value": "SH",
    "currencies": "SHP",
    "symbol": "£"
  },
  {
    "code": "386",
    "name": "Slovenia",
    "path": "../../assets/flags/si.svg",
    "value": "SI",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "47",
    "name": "Svalbard and Jan Mayen",
    "path": "../../assets/flags/sj.svg",
    "value": "SJ",
    "currencies": "NOK",
    "symbol": "kr"
  },
  {
    "code": "421",
    "name": "Slovakia",
    "path": "../../assets/flags/sk.svg",
    "value": "SK",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "232",
    "name": "Sierra Leone",
    "path": "../../assets/flags/sl.svg",
    "value": "SL",
    "currencies": "SLL",
    "symbol": "Le"
  },
  {
    "code": "378",
    "name": "San Marino",
    "path": "../../assets/flags/sm.svg",
    "value": "SM",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "221",
    "name": "Senegal",
    "path": "../../assets/flags/sn.svg",
    "value": "SN",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "252",
    "name": "Somalia",
    "path": "../../assets/flags/so.svg",
    "value": "SO",
    "currencies": "SOS",
    "symbol": "Sh.so."
  },
  {
    "code": "597",
    "name": "Suriname",
    "path": "../../assets/flags/sr.svg",
    "value": "SR",
    "currencies": "SRD",
    "symbol": "$"
  },
  {
    "code": "211",
    "name": "South Sudan",
    "path": "../../assets/flags/ss.svg",
    "value": "SS",
    "currencies": "SSP",
    "symbol": "SS£"
  },
  {
    "code": "239",
    "name": "Sao Tome and Principe",
    "path": "../../assets/flags/st.svg",
    "value": "ST",
    "currencies": "STD",
    "symbol": "Db"
  },
  {
    "code": "503",
    "name": "El Salvador",
    "path": "../../assets/flags/sv.svg",
    "value": "SV",
    "currencies": "SVC",
    "symbol": "₡"
  },
  {
    "code": "1721",
    "name": "Sint Maarten (Dutch part)",
    "path": "../../assets/flags/sx.svg",
    "value": "SX",
    "currencies": "ANG",
    "symbol": "ƒ"
  },
  {
    "code": "963",
    "name": "Syrian Arab Republic",
    "path": "../../assets/flags/sy.svg",
    "value": "SY",
    "currencies": "SYP",
    "symbol": "LS"
  },
  {
    "code": "268",
    "name": "Swaziland",
    "path": "../../assets/flags/sz.svg",
    "value": "SZ",
    "currencies": "SZL",
    "symbol": "E"
  },
  {
    "code": "1649",
    "name": "Turks and Caicos Islands",
    "path": "../../assets/flags/tc.svg",
    "value": "TC",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "235",
    "name": "Chad",
    "path": "../../assets/flags/td.svg",
    "value": "TD",
    "currencies": "XAF",
    "symbol": "FCFA"
  },
  {
    "code": "262",
    "name": "French Southern Territories",
    "path": "../../assets/flags/tf.svg",
    "value": "TF",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "228",
    "name": "Togo",
    "path": "../../assets/flags/tg.svg",
    "value": "TG",
    "currencies": "XOF",
    "symbol": "CFA"
  },
  {
    "code": "66",
    "name": "Thailand",
    "path": "../../assets/flags/th.svg",
    "value": "TH",
    "currencies": "THB",
    "symbol": "฿"
  },
  {
    "code": "992",
    "name": "Tajikistan",
    "path": "../../assets/flags/tj.svg",
    "value": "TJ",
    "currencies": "TJS",
    "symbol": "SM"
  },
  {
    "code": "690",
    "name": "Tokelau",
    "path": "../../assets/flags/tk.svg",
    "value": "TK",
    "currencies": "NZD",
    "symbol": "$"
  },
  {
    "code": "670",
    "name": "Timor-Leste",
    "path": "../../assets/flags/tl.svg",
    "value": "TL",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "993",
    "name": "Turkmenistan",
    "path": "../../assets/flags/tm.svg",
    "value": "TM",
    "currencies": "TMT",
    "symbol": "T"
  },
  {
    "code": "216",
    "name": "Tunisia",
    "path": "../../assets/flags/tn.svg",
    "value": "TN",
    "currencies": "TND",
    "symbol": "ت.د"
  },
  {
    "code": "676",
    "name": "Tonga",
    "path": "../../assets/flags/to.svg",
    "value": "TO",
    "currencies": "TOP",
    "symbol": "$"
  },
  {
    "code": "90",
    "name": "Turkey",
    "path": "../../assets/flags/tr.svg",
    "value": "TR",
    "currencies": "TRY",
    "symbol": "₺"
  },
  {
    "code": "1868",
    "name": "Trinidad and Tobago",
    "path": "../../assets/flags/tt.svg",
    "value": "TT",
    "currencies": "TTD",
    "symbol": "$"
  },
  {
    "code": "688",
    "name": "Tuvalu",
    "path": "../../assets/flags/tv.svg",
    "value": "TV",
    "currencies": "AUD",
    "symbol": "$"
  },
  {
    "code": "886",
    "name": "Taiwan",
    "path": "../../assets/flags/tw.svg",
    "value": "TW",
    "currencies": "TWD",
    "symbol": "$"
  },
  {
    "code": "255",
    "name": "Tanzania",
    "path": "../../assets/flags/tz.svg",
    "value": "TZ",
    "currencies": "TZS",
    "symbol": "TSh"
  },
  {
    "code": "380",
    "name": "Ukraine",
    "path": "../../assets/flags/ua.svg",
    "value": "UA",
    "currencies": "UAH",
    "symbol": "₴"
  },
  {
    "code": "256",
    "name": "Uganda",
    "path": "../../assets/flags/ug.svg",
    "value": "UG",
    "currencies": "UGX",
    "symbol": "USh"
  },
  {
    "code": "1",
    "name": "United States Minor Outlying Islands",
    "path": "../../assets/flags/um.svg",
    "value": "UM",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "1",
    "name": "United States",
    "path": "../../assets/flags/us.svg",
    "value": "US",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "598",
    "name": "Uruguay",
    "path": "../../assets/flags/uy.svg",
    "value": "UY",
    "currencies": "UYU",
    "symbol": "$"
  },
  {
    "code": "998",
    "name": "Uzbekistan",
    "path": "../../assets/flags/uz.svg",
    "value": "UZ",
    "currencies": "UZS",
    "symbol": "лв"
  },
  {
    "code": "39",
    "name": "Holy See (Vatican City State)",
    "path": "../../assets/flags/va.svg",
    "value": "VA",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "1",
    "name": "Saint Vincent and the Grenadines",
    "path": "../../assets/flags/vc.svg",
    "value": "VC",
    "currencies": "XCD",
    "symbol": "$"
  },
  {
    "code": "58",
    "name": "Venezuela",
    "path": "../../assets/flags/ve.svg",
    "value": "VE",
    "currencies": "VEF",
    "symbol": "Bs"
  },
  {
    "code": "44",
    "name": "British Virgin Islands",
    "path": "../../assets/flags/vg.svg",
    "value": "VG",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "1",
    "name": "U.S. Virgin Islands",
    "path": "../../assets/flags/vi.svg",
    "value": "VI",
    "currencies": "USD",
    "symbol": "$"
  },
  {
    "code": "84",
    "name": "Vietnam",
    "path": "../../assets/flags/vn.svg",
    "value": "VN",
    "currencies": "VND",
    "symbol": "₫"
  },
  {
    "code": "678",
    "name": "Vanuatu",
    "path": "../../assets/flags/vu.svg",
    "value": "VU",
    "currencies": "VUV",
    "symbol": "VT"
  },
  {
    "code": "681",
    "name": "Wallis and Futuna",
    "path": "../../assets/flags/wf.svg",
    "value": "WF",
    "currencies": "XPF",
    "symbol": "₣"
  },
  {
    "code": "685",
    "name": "Samoa",
    "path": "../../assets/flags/ws.svg",
    "value": "WS",
    "currencies": "WST",
    "symbol": "SAT"
  },
  {
    "code": "967",
    "name": "Yemen",
    "path": "../../assets/flags/ye.svg",
    "value": "YE",
    "currencies": "YER",
    "symbol": "﷼"
  },
  {
    "code": "262",
    "name": "Mayotte",
    "path": "../../assets/flags/yt.svg",
    "value": "YT",
    "currencies": "EUR",
    "symbol": "€"
  },
  {
    "code": "27",
    "name": "South Africa",
    "path": "../../assets/flags/za.svg",
    "value": "ZA",
    "currencies": "ZAR",
    "symbol": "R"
  },
  {
    "code": "260",
    "name": "Zambia",
    "path": "../../assets/flags/zm.svg",
    "value": "ZM",
    "currencies": "ZMW",
    "symbol": "ZK"
  },
  {
    "code": "263",
    "name": "Zimbabwe",
    "path": "../../assets/flags/zw.svg",
    "value": "ZW",
    "currencies": "ZWD",
    "symbol": "Z$"
  }
]

  