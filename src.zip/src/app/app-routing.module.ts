import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'tabs',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'forgotpassword',
    loadChildren: () => import('./pages/forgotpassword/forgotpassword.module').then( m => m.ForgotpasswordPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'welcome',
    loadChildren: () => import('./pages/welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  {
    path: 'landing',
    loadChildren: () => import('./pages/landing/landing.module').then( m => m.LandingPageModule)
  },
  {
    path: 'choose-recipient',
    loadChildren: () => import('./pages/choose-recipient/choose-recipient.module').then( m => m.ChooseRecipientPageModule)
  },
  {
    path: 'add-recipient',
    loadChildren: () => import('./pages/add-recipient/add-recipient.module').then( m => m.AddRecipientPageModule)
  },
  {
    path: 'cashout',
    loadChildren: () => import('./pages/cashout/cashout.module').then( m => m.CashoutPageModule)
  },
  {
    path: 'confirm-transfer',
    loadChildren: () => import('./pages/confirm-transfer/confirm-transfer.module').then( m => m.ConfirmTransferPageModule)
  },
  {
    path: 'transaction-view',
    loadChildren: () => import('./pages/transaction-view/transaction-view.module').then( m => m.TransactionViewPageModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./pages/about/about.module').then( m => m.AboutPageModule)
  },
  {
    path: 'support',
    loadChildren: () => import('./pages/support/support.module').then( m => m.SupportPageModule)
  },  
  // {
  //   path: 'payment',
  //   loadChildren: () => import('./pages/mobile-money/mobile-money.module').then( m => m.MobileMoneyPageModule)
  // },  
  {
    path: 'account',
    loadChildren: () => import('./pages/account/account.module').then( m => m.AccountPageModule)
  },
  // {
  //   path: 'debit-card',
  //   loadChildren: () => import('./pages/debit-card/debit-card.module').then( m => m.DebitCardPageModule)
  // },
  {
    path: 'changepassword',
    loadChildren: () => import('./pages/changepassword/changepassword.module').then( m => m.ChangepasswordPageModule)
  },
  {
    path: 'payment',
    loadChildren: () => import('./pages/payment/payment.module').then( m => m.PaymentPageModule)
  }
  
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
