import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ChooseRecipientPage } from './choose-recipient.page';

describe('ChooseRecipientPage', () => {
  let component: ChooseRecipientPage;
  let fixture: ComponentFixture<ChooseRecipientPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ChooseRecipientPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
