import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-choose-recipient',
  templateUrl: './choose-recipient.page.html',
  styleUrls: ['./choose-recipient.page.scss'],
})
export class ChooseRecipientPage implements OnInit {
  recipients:any
  filteredRecipients:any
  allrecipients:any
  _searchTerm:string = ''

  get searchTerm(){
    return this._searchTerm
  }

  set searchTerm(val:string){
    this._searchTerm = val
    this.filteredRecipients = this.filterSource(val);    
  }

  constructor(private router:Router, private common:CommonService,private transaction:TransactionService, private web: WebService) { }

  ionViewWillEnter(){
    this.getsaverecipient();
  }

  ngOnInit() {
    
  }

  route(page:string){
    this.router.navigate([`/${page}`])
  }


  getsaverecipient(){
    this.web.postData("getsaverecipient",{
      'country_code' : this.transaction.transaction_details['toCountry']
    }).subscribe(
      (res: any) => {          
        if (res.code == 200) {            
          this.allrecipients = res.data;
          this.recipients = [...this.allrecipients]
          this.filteredRecipients = [...this.recipients]           
        }
        else if (res.code == 400) {      
          this.allrecipients = [];
          this.recipients = [...this.allrecipients]
          this.filteredRecipients = [...this.recipients]        
          //  this.common.presentToast(res.message);
        }           
      },
      err => {
        this.common.presentToast("Something went wrong, try again later");
      }
    );
  }
  

  filterSource(value:string){
    if(!value || this.recipients.length === 0) {
      return this.recipients
    }
    return this.recipients.filter((data:any) => this.matchValue(data,value)); 
  }

  matchValue(data:any, value:any) {
    return Object.keys(data).map((key) => {
       return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }




  staticData= [
    {
    name : 'Mounet Christian',
    country_code : '91',
    platform : 'MTN',
    phone : '7305172870',
    profile : 'https://lh3.googleusercontent.com/a/AAcHTteSVs2mvdYi2pPawfuqEtYKd_2l3vaR024FPtuA9w=s96-c'
    },
    {
    name : 'Mounet Nsemel',
    country_code : '90',
    platform : 'Change',
    phone : '7305172870',
    profile : 'https://lh3.googleusercontent.com/a/AAcHTtc8d7V0a8maAQwGrVu55-ssn2JRzA4F-dwGtuK0kKuq=s96-c'
    },
    {
    name : 'Christian',
    country_code : '423',
    platform : 'MTN',
    phone : '7305112870',
    profile : 'https://lh3.googleusercontent.com/a/AAcHTtdvANrMUTX9YzxQtM5AqjAW1EV0LjSjB7l2R9Dq=s96-c'
    },
    {
    name : 'Mounet',
    country_code : '128',
    platform : 'UBA',
    phone : '7305172871',
    profile : 'https://lh3.googleusercontent.com/a/AAcHTteSVs2mvdYi2pPawfuqEtYKd_2l3vaR024FPtuA9w=s96-c'
    },
    {
    name : 'Mounet Christian',
    country_code : '21',
    platform : 'MTN',
    phone : '7305172070',
    profile : 'https://lh3.googleusercontent.com/a/AAcHTtc8d7V0a8maAQwGrVu55-ssn2JRzA4F-dwGtuK0kKuq=s96-c'
    }
    ]

    transfer(recipient: any){      
      console.log(recipient)
      this.transaction.existingRecipient(recipient,recipient['payment_type'])
      console.log("recipient details =>")
      console.log(this.transaction.Recipient)
      if(recipient['payment_type'] == 'Mobile Money'){
      this.router.navigate(['/cashout']);
      }else{
        this.router.navigate(['/confirm-transfer']);
      }
    }
}
