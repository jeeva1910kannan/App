import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChooseRecipientPage } from './choose-recipient.page';

const routes: Routes = [
  {
    path: '',
    component: ChooseRecipientPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChooseRecipientPageRoutingModule {}
