import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TransferhistoryPage } from './transferhistory.page';

describe('TransferhistoryPage', () => {
  let component: TransferhistoryPage;
  let fixture: ComponentFixture<TransferhistoryPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(TransferhistoryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
