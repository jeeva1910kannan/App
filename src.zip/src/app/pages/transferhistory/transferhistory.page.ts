import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, Platform } from '@ionic/angular';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/services/web.service';
import { countryData } from 'src/app/countries';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-transferhistory',
  templateUrl: './transferhistory.page.html',
  styleUrls: ['./transferhistory.page.scss'],
})
export class TransferhistoryPage implements OnInit {
  data: any;
  userdetails: any;
  userid: any;
  time={
'timedif':''
  }
  search={
    'recepientname':''
  }
  

  created_at: any;
  recepientname: any;
  searchdetails: any;
  searchResultFound: boolean = true; // Initialize it as true initially
  
  searchStarted: boolean = false; // Initialize it as false initially
  searchEnded:boolean = true;
  sendmail: any;
  filteredrecipient: any[] = [];
  sendmaildetails: any;
  constructor(private user: UserService,private router:Router, private web: WebService, private alertController: AlertController, private common: CommonService, ) { }

 

  ngOnInit() {
    this.data = JSON.parse(localStorage.getItem('userData') ?? '');
    console.log(this.data, "this.data");
    this.userid = this.data.id;
this.getuserdata();
    



  }

  
  
// filterRecepient(event: any) {
//   const searchTerm = event.target.value.toLowerCase();
//   this.filteredrecipient = this.userdetails.filter((userDetail: { recepientname: string }) =>
//     userDetail.recepientname.toLowerCase().includes(searchTerm)
//   );
// }
filterRecepient(event: any) {
  const searchTerm = event.target.value.toLowerCase();
  if (searchTerm === "") {
    // If the search box is empty, show all recipients
    this.filteredrecipient = [...this.userdetails];
  } else {
    // Filter recipients based on the search term
    this.filteredrecipient = this.userdetails.filter((userDetail: { recepientname: string }) =>
      userDetail.recepientname.toLowerCase().includes(searchTerm)
    );
  }
}


  
  getTimeDifference(created_at: string): string {
    const createdAtTimestamp = new Date(created_at).getTime();
    const currentTimestamp = new Date().getTime();
    const timeDifference = Math.abs(currentTimestamp - createdAtTimestamp);
  
    const millisecondsInSecond = 1000;
    const millisecondsInMinute = 60 * millisecondsInSecond;
    const millisecondsInHour = 60 * millisecondsInMinute;
    const millisecondsInDay = 24 * millisecondsInHour;
  
    if (timeDifference < millisecondsInMinute) {
      return `${Math.floor(timeDifference / millisecondsInSecond)} seconds ago`;
    } else if (timeDifference < millisecondsInHour) {
      return `${Math.floor(timeDifference / millisecondsInMinute)} minutes ago`;
    } else if (timeDifference < millisecondsInDay) {
      return `${Math.floor(timeDifference / millisecondsInHour)} hours ago`;
    } else {
      return `${Math.floor(timeDifference / millisecondsInDay)} days ago`;
    }
  }
 

  sendemail(){
    
    let postData
    postData={
      'user_id':this.userid,
      'email':this.data.email
    }
   
    this.web.postData("sendtransferhistory", postData)
    .subscribe((res: any) => {
      console.log(res);
      if (res.code == 200) {                    
       this.sendmaildetails=res.data
       console.log("this.sendmaildetails",this.sendmaildetails);
       
      
       
      }
      else if (res.code == 400) {        
        this.common.presentToast(res.message);                    
      } 
    
    },
    );
  }
getuserdata(){

    let postData
    postData={
      'user_id':this.userid
    }
   
    this.web.postData("getrecepienttransdetails", postData)
    .subscribe((res: any) => {
      console.log(res);
      if (res.code == 200) {                    
       this.userdetails=res.data
       this.recepientname=this.userdetails[0].recepientname;
       this.created_at=this.userdetails[0].created_at;
       console.log("this.created_at",this.created_at);
       
       this.filteredrecipient = [...this.userdetails];
       console.log("this.filteredrecipient[0].recepientname",this.filteredrecipient[1].recepientname);
       console.log("this.userdetails.created_at",this.userdetails[0].created_at);
      console.log("this.userdetails",this.userdetails);
             
       
      }
      else if (res.code == 400) {        
        this.common.presentToast(res.message);                    
      } 
    
    },
    );
  }

 

  
}
