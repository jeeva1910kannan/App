import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TransferhistoryPageRoutingModule } from './transferhistory-routing.module';

import { TransferhistoryPage } from './transferhistory.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TransferhistoryPageRoutingModule
  ],
  declarations: [TransferhistoryPage]
})
export class TransferhistoryPageModule {}
