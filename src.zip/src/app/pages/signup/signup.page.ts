import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { environment } from 'src/environments/environment';
import axios from 'axios';
import { HttpClient } from '@angular/common/http';
import { countryData } from 'src/app/countries';
import { SignupService } from './signup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {

  baseurl: String = environment.apiurl;
  dnaloader1: boolean = false;

  registerForm = {
    firstName: '',
    lastName: '',
    email: '',
    phonenumber: '',
    password: '',
    cpassword: '',
    countrycode: ''
  }
  countries = countryData
  _searchTerm: string = ''
  selectedCountry!: string
  filteredCountries = [...this.countries]
  userCountry: any
  registerapi: any;
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(private common: CommonService, private router: Router, private web: WebService, private http: HttpClient, private signService: SignupService) { }

  ngOnInit() {

    console.log(this.countries.length)
    this.userCountry = this.countries[0]
    this.selectedCountry = this.userCountry['value']
  }

  get searchTerm() {
    return this._searchTerm
  }

  set searchTerm(val: string) {
    this._searchTerm = val
    this.filteredCountries = this.filterSource(val);
  }

  filterSource(value: string) {
    if (!value || this.countries.length === 0) {
      return this.countries
    }
    return this.countries.filter((data) => this.matchValue(data, value));
  }

  matchValue(data: any, value: any) {
    return Object.keys(data).map((key) => {
      return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }

  isValidEmail(email: string): boolean {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(email);
  }

  setCountry() {
    this.userCountry = this.countries.find((country) => {
      return country['value'] == this.selectedCountry

    })
    console.log(this.userCountry)
    //  this.registerForm['countrycode'] = this.userCountry['code'];

    console.log(this.userCountry['code'], "code")

  }


  register() {
    this.registerForm['countrycode'] = this.userCountry['code'];
    console.log(this.registerForm['countrycode'], "code")
    if (this.registerForm['firstName'].trim() == '') {
      this.common.presentToast('Please enter your First Name.')
    } else if (this.registerForm['lastName'].trim() == '') {
      this.common.presentToast('Please enter your Last Name.')
    } else if ((this.registerForm['email'].trim() == '' && this.registerForm['phonenumber'].trim() == '')) {
      this.common.presentToast('Please enter Email or Mobile Number');
    } else if (this.registerForm['email'].trim() != '' && !this.isValidEmail(this.registerForm['email'])) {
      this.common.presentToast('Please enter a valid Email');
    }
    // else if (this.registerForm['phonenumber'].trim() != '' && !this.common.isValidPhoneNumber(this.registerForm['phonenumber'])) {
    //   console.log(this.registerForm['phonenumber'], "this.registerForm['phonenumber']")
    //   this.common.presentToast('Please enter a valid Phone Number');     

    // }
    else if (this.registerForm['password'].trim() == '') {
      this.common.presentToast('Please enter a Password.')
    } else if (this.registerForm['password'].trim().length < 6) {
      this.common.presentToast('Password should be at least 6 characters long.');
    }
    else if (this.registerForm['cpassword'].trim() == '') {
      this.common.presentToast('Please enter the confirm Password.')
    } else if (this.registerForm['password'] != this.registerForm['cpassword']) {
      this.common.presentToast('Password and Confirm Password do not match.')
    } else if ((this.registerForm['email'].trim() == '')) {
      this.common.presentToast('Please enter Email');
    }
    else {
      console.log("next")
      this.dnaloader1 = true;

      this.web.postData("register_program", this.registerForm)
        .subscribe((res: any) => {
          console.log(res);
          if (res.code == 200) {
            console.log("ii")
            this.dnaloader1 = false;
            this.common.presentToast(res.message);
            const userData = res.data;
            //const data = JSON.parse(userData);
            const dataArray = JSON.parse(userData);
            this.signService.userdata = {
              'userID': dataArray[0].id

            }

            console.log(this.signService.userdata, "this.signService.userdata")
            this.router.navigate(['/register/verification'])
          }

          else if (res.code == 400) {
            this.dnaloader1 = false;
            this.common.presentToast(res.message);
          } else {
            this.dnaloader1 = false;

          }
          //this.common.presentToast("Something went wrong, try again later");
        },
          err => {
            this.dnaloader1 = false;
            this.common.presentToast("Something went wrong, try again later");
          }
        );

    }
  }

  togglePasswordView() {
    this.showPassword = !this.showPassword
  }
  toggleConfirmPasswordView() {
    this.showConfirmPassword = !this.showConfirmPassword
  }
}


