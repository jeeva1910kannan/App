import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  private _userdata:any
  private _forgetdata:any
  constructor() { }

  set userdata(data:any){
    this._userdata = data
  }

  get userdata(){
    return this._userdata
  }
  
}
