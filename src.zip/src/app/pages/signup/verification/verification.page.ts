import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { SignupService } from '../signup.service';
import { IonInput, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.page.html',
  styleUrls: ['./verification.page.scss'],
})
export class VerificationPage implements OnInit {

  @ViewChild('otp1') input1: any;
  @ViewChild('otp2') input2: any;
  @ViewChild('otp3') input3: any;
  @ViewChild('otp4') input4: any;
  @ViewChild('otp5') input5: any;
  @ViewChild('otp6') input6: any;

  dnaloader1: boolean = false;
  data: any
  otpString: string[] = ['', '', '', '', '', '']
  isLoading: boolean = false;

  constructor(private router: Router, private common: CommonService, private web: WebService, private SignService: SignupService, private loadingCtrl: LoadingController) { }

  ngOnInit() {
  }

  ionViewDidEnter() {
    this.data = this.SignService.userdata
    console.log(this.data)

    setTimeout(() => {
      // this.input1.setFocus()
    })
  }

  otpController(event: any, prev: any, next: any, index: number): void | 0 {
    const pattern = /[0-9]/
    // console.log(event)
    let inputChar = String.fromCharCode(event.which ? event.which : event.keyCode)
    console.log(inputChar)
    console.log(!pattern.test(inputChar))
    // if(!pattern.test(inputChar)){
    //   event.preventDefault();
    //   this.otpString[index] = '';
    //   return
    // }
    let value = event.target.value;
    console.log(value.length)
    console.log(prev)
    // console.log(next)

    // console.log(value)
    if (value.length > 1) {
      this.otpString[index] = value
    }
    if (value.length < 1 && prev) {
      console.log(prev)
      prev.setFocus()
    } else if (next && value.length > 0) {
      next.setFocus()
    } else {
      if (next == '') {
        this.verifyOtp()
      } else {
        return 0
      }
    }
  }

  focusNext(event: any, nextInput: IonInput, index: number) {
    const input = event.target.value;
    const regex = /^[0-9]*$/;
    if (!regex.test(input)) {
      this.otpString[index] = '';
    } else {
      if (input.length === 1 && index < 5) {
        nextInput.setFocus();
      }
    }
  }

  backSpace(event: any, prevInput: IonInput, index: number) {
    console.log(event)
    if (event.key === 'Backspace' && event.target.value.length === 0) {
      console.log('in')
      prevInput.setFocus();
      this.otpString[index - 1] = '';
    }
  }



  showLoader(msg: string) {
    if (this.isLoading) this.isLoading = false;
    return this.loadingCtrl.create({
      message: msg,
      spinner: 'bubbles'
    }).then((res) => {
      res.present().then(() => {
        if (!this.isLoading) {
          res.dismiss().then(() => {
            console.log('abort dismissing')
          })
        }
      })
    }).catch(err => {
      this.isLoading = false;
      console.log(err)
    })
  }



  verifyOtp() {



    let timeStamp = new Date();
    let otp = this.otpString;
    const otpdata =
    {
      'userID': this.data['userID'],
      'otp': otp,
    }

    // let otp = this.otpString.join('');
    console.log(this.otpString)
    console.log(otp.length, "otp.length")
    if (otp.length == 6) {
      this.dnaloader1 = true;
      this.web.postData("regotp_verify", otpdata)

        .subscribe((res: any) => {
          console.log(res);
          if (res.code == 200) {
            this.dnaloader1 = false;
            console.log("ii")
            this.common.presentToast(res.message);
            this.router.navigate(['/'])
          }

          else if (res.code == 400) {
            this.dnaloader1 = false;
            this.common.presentToast(res.message);
          }
        },
          err => {
            this.dnaloader1 = false;
            this.common.presentToast("Something went wrong, try again later");
          }
        );


    } else {
      this.common.presentToast('Please enter the OTP')
    }

  }


  resendOTP() {
    this.dnaloader1 = true;
    this.web.postData('/resend_code', {
      'userID': this.data['userID'],

    }).subscribe({
      next: (res) => {

        if (res.code == 200) {
          this.dnaloader1 = false;

          this.common.presentToast('A new OTP has been sent to your registered email address.')

          this.otpString = ['', '', '', '', '', '']
        } else {
          this.dnaloader1 = false;
          this.common.presentToast('Something went wrong')
        }
      },
      error: (err) => {
        this.dnaloader1 = false;
        this.common.presentToast("Something went wrong, try again later");
        console.log(err)
      }
    })
  }


  hideLoader() {
    if (!this.isLoading) this.isLoading = true;
    return this.loadingCtrl.dismiss()
      .then(() => console.log('dismissed'))
      .catch((err) => console.log(err))
  }

  joinOtp(otp: any) {
    if (!otp || otp == '') return 0
    const newOtp = otp.join('');
    return newOtp
  }


  onOtpChange(event: any) {
    this.otpString = event;
  }

}
