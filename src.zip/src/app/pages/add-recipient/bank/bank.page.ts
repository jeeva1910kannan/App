import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonSelect, ModalController } from '@ionic/angular';
import { CommonService } from 'src/app/services/common.service';
import { CountryModalComponent } from '../country-modal/country-modal.component';
import { countryData } from 'src/app/countries';
import { Router } from '@angular/router';
import { TransactionService } from 'src/app/services/transaction.service';
import { WebService } from 'src/app/services/web.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.page.html',
  styleUrls: ['./bank.page.scss'],
})
export class BankPage implements OnInit {
  @ViewChild('mySelect', { static: false }) selectRef!: IonSelect;

  recipientData = {
    'fullname' : '',
    'phonenumber' : '',
    'acc_number' : '',
    'c_acc_number' : '',
    'bank_name' : ''
  }

  recipientCountry:any
  email:any;
  datauser: any;
  countries = [...countryData]

  constructor(private common:CommonService, private modalController:ModalController,private router:Router,private transaction:TransactionService, private web: WebService, private alertController:AlertController, private user:UserService) { }

  ionViewWillEnter(){
    // this.recipientCountry = this.countries[0]
    this.recipientCountry = this.user.countryFromCountryCode(this.transaction.transaction_details.toCountry)
    console.log(this.recipientCountry)
  }

  ngOnInit() {

    this.datauser = JSON.parse(localStorage.getItem('userData') ?? '');
    console.log(this.datauser, "this.data")
    this.email = this.datauser.email;
  }

  async presentModal() {
    const modal = await this.modalController.create({
      component: CountryModalComponent,
      backdropDismiss: false,
      componentProps: {
        'recipientCountry' : this.recipientCountry['value']
      }
    });
    modal.onDidDismiss().then((data) => {
      if(data['role'] == 'save'){
        this.recipientCountry = data['data']
      }else{
        console.log(data['role'])
      }
    });
    return await modal.present();
  }

  next(){
    if(this.recipientData['fullname'].trim() == ''){
      this.common.presentToast("Please enter the recipient's Full name")
    }else if(this.recipientData['phonenumber'].trim() == ''){
      this.common.presentToast("Please enter the recipient's Phone number")
    }else if(!this.common.isValidPhoneNumber(this.recipientData['phonenumber'])){
      this.common.presentToast("Please enter the valid Phone number")
    }else if(this.recipientData['bank_name'] == ''){
      this.common.presentToast("Please select a bank")
    }else if(this.recipientData['acc_number'].trim() == ''){
      this.common.presentToast("Please enter the recipient's account number")
    }else if(!this.common.isValidAccountNumber(this.recipientData['acc_number'])){
      this.common.presentToast("Please enter valid recipient's account number")
    }else if(this.recipientData['c_acc_number'].trim() == ''){
      this.common.presentToast("Please confirm the recipient's account number")
    }else if(this.recipientData['c_acc_number'] != this.recipientData['acc_number']){
      this.common.presentToast("Confirm recipient's account number doesn't match")
    }else if(!this.common.isValidAccountNumber(this.recipientData['c_acc_number'])){
      this.common.presentToast("Please enter valid confirm recipient's account number")
    }
    else{
      this.common.presentLoading()
      this.transaction.Recipient.recipient_name = this.recipientData['fullname'];
      this.transaction.Recipient.phone = this.recipientData['phonenumber'];
      this.transaction.Recipient.bank_name = this.recipientData['bank_name'];
      this.transaction.Recipient.bank_acc_number = this.recipientData['acc_number'];
      this.transaction.Recipient.country_code = this.recipientCountry['code']

      let data = {
        ...this.transaction.Recipient,
        'email' : this.email  
      }      
      
      this.web.postData("bank", data).subscribe((res: any) => {          
        if (res.code == 200) {            
          this.common.presentToast(res.message);
          this.router.navigate(['/confirm-transfer'])
        }
        else if (res.code == 400) {
          this.common.presentToast(res.message);
        }       
        this.common.closeLoading()    
      },
      err => {           
        this.common.presentToast("Something went wrong, try again later");
        this.common.closeLoading()
        }
      );      
    }

  }

  openSelect() {
    this.selectRef.open()
  }

  async close() {
    const alert = await this.alertController.create({
      header: 'Cancel Transaction',
      message : 'Are you sure you want to cancel the transaction?',
      cssClass : 'cancel-transaction',
      backdropDismiss : false,
      mode : 'md',      
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          handler: () => {
            this.router.navigate(['/landing'])
          }
        }
      ]
    });
  
    await alert.present();
  }

}
