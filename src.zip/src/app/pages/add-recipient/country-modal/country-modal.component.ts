import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { countryData } from 'src/app/countries';

@Component({
  selector: 'app-country-modal',
  templateUrl: './country-modal.component.html',
  styleUrls: ['./country-modal.component.scss'],
})
export class CountryModalComponent  implements OnInit {
  recipientCountry:any
  selectedCountry!:string  
  _searchTerm:string = ''
  countries = countryData
  filteredCountries = [...this.countries]
  userCountry:any

  get searchTerm(){
    return this._searchTerm
  }

  set searchTerm(val:string){
    this._searchTerm = val
    this.filteredCountries = this.filterSource(val);    
  }
  constructor(private modalController:ModalController,private activatedRoute:ActivatedRoute) {
    
   }

  ionViewWillEnter(){
    console.log('here => ' + this.recipientCountry)
    this.selectedCountry = this.recipientCountry
    console.log(this.selectedCountry)
  }

  ngOnInit() {}

  dismiss() {
    this.modalController.dismiss(null,'close');
  }

  filterSource(value:string){
    if(!value || this.countries.length === 0) {
      return this.countries
    }
    return this.countries.filter((data) => this.matchValue(data,value)); 
  }

  matchValue(data:any, value:any) {
    return Object.keys(data).map((key) => {
       return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }

  save(){
    let data = this.countries.find((country) => {
        return country['value'] == this.selectedCountry
  
      })
    this.modalController.dismiss({
      ...data
    },'save')
  }


}
