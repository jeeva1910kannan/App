import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-add-recipient',
  templateUrl: './add-recipient.page.html',
  styleUrls: ['./add-recipient.page.scss'],
})
export class AddRecipientPage implements OnInit {
  checkboxes = [false,false,false]
  constructor(private router:Router, private common:CommonService,private transaction:TransactionService) { }

  ngOnInit() {
  }

  checked(index:number){
    let newcheckboxes = this.checkboxes.map((x,i) => {    
      return i == index ? true : false    
    })
    this.checkboxes = [...newcheckboxes]
  }

  route(){    
    if(this.checkboxes.includes(true)){
      if(this.checkboxes[0]){
        this.transaction.addNewRecipient('Mobile Money')
        this.router.navigate(['/add-recipient/mobile-money'])
      }
      if(this.checkboxes[1]){
        this.transaction.addNewRecipient('Bank')
        this.router.navigate(['/add-recipient/bank'])
      }
      if(this.checkboxes[2]){
        this.transaction.addNewRecipient('Cash')
        this.router.navigate(['/add-recipient/cash'])
      }
    }else{
      this.common.presentToast("Please select your recipient's payment method");
    }
  }


}
