import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MobileMoneyPage } from './mobile-money.page';

describe('MobileMoneyPage', () => {
  let component: MobileMoneyPage;
  let fixture: ComponentFixture<MobileMoneyPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MobileMoneyPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
