import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { CountryModalComponent } from '../country-modal/country-modal.component';
import { countryData } from 'src/app/countries';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { WebService } from 'src/app/services/web.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-mobile-money',
  templateUrl: './mobile-money.page.html',
  styleUrls: ['./mobile-money.page.scss'],
})
export class MobileMoneyPage implements OnInit {
  recipientData = {
    'phonenumber' : '',
    'fullname' : ''
  }
  recipientCountry:any
  email:any;
  datauser: any;
  countries = [...countryData]
  constructor(private router:Router, private modalController:ModalController,private common:CommonService,private transaction:TransactionService, private web: WebService, private alertController:AlertController,private user:UserService) { }

  ionViewWillEnter(){    
    // this.recipientCountry = this.countries[0]    
    this.recipientCountry = this.user.countryFromCountryCode(this.transaction.transaction_details.toCountry)
  }

  ngOnInit() {
    this.datauser = JSON.parse(localStorage.getItem('userData') ?? '');    
    this.email = this.datauser.email;
  }


  async presentModal() {
    const modal = await this.modalController.create({
      component: CountryModalComponent,
      backdropDismiss: false,
      componentProps: {
        'recipientCountry' : this.recipientCountry['value']
      }
    });
    modal.onDidDismiss().then((data) => {
      if(data['role'] == 'save'){
        this.recipientCountry = data['data']
      }else{
        console.log(data['role'])
      }
    });
    return await modal.present();
  }

  next(){
    if(this.recipientData['fullname'].trim() == ''){
      this.common.presentToast("Please enter the recipient's Full name")
    }else if(this.recipientData['phonenumber'].trim() == ''){
      this.common.presentToast("Please enter the recipient's Phone number")
    }else if(!this.common.isValidPhoneNumber(this.recipientData['phonenumber'])){
      this.common.presentToast("Please enter the valid Phone number")
    }else{
      this.common.presentLoading()
      this.transaction.Recipient.recipient_name = this.recipientData['fullname'];
      this.transaction.Recipient.phone = this.recipientData['phonenumber'];
      this.transaction.Recipient.country_code = this.recipientCountry['code']
      let data = {
        ...this.transaction.Recipient,
        'email' : this.email  
      }            
      this.web.postData("mobile_money", data).subscribe(
        (res: any) => {          
          if (res.code == 200) {                       
            this.common.presentToast(res.message);  
            this.transaction.Recipient.recipient_id = res['data']['id']                     
            this.router.navigate(['/cashout'])            
          }
          else if (res.code == 400) {           
            this.common.presentToast(res.message);
          }       
          this.common.closeLoading()    
        },
        err => {
          console.log(err)           
          this.common.presentToast("Something went wrong, try again later");
          this.common.closeLoading()
        }
      );      
    }

  }

  async close() {
    const alert = await this.alertController.create({
      header: 'Cancel Transaction',
      message : 'Are you sure you want to cancel the transaction?',
      cssClass : 'cancel-transaction',
      backdropDismiss : false,
      mode : 'md',      
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          handler: () => {
            this.router.navigate(['/landing'])
          }
        }
      ]
    });
  
    await alert.present();
  }


}
