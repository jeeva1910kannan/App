import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddRecipientPageRoutingModule } from './add-recipient-routing.module';

import { AddRecipientPage } from './add-recipient.page';
import { CountryModalComponent } from './country-modal/country-modal.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddRecipientPageRoutingModule
  ],
  declarations: [AddRecipientPage,CountryModalComponent]
})
export class AddRecipientPageModule {}
