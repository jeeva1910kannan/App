import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-recipient-address',
  templateUrl: './recipient-address.page.html',
  styleUrls: ['./recipient-address.page.scss'],
})
export class RecipientAddressPage implements OnInit {
  recipientData = {
    'address_one' : '',
    'address_two' : '',
    'city' : '',
    'country' : ''
  }
  recipientDatadetails: any;
  email:any;
  datauser: any;
  constructor(private common:CommonService,private router:Router,private transaction:TransactionService, private web: WebService,private alertController:AlertController) { }

  ngOnInit() {        
    this.datauser = JSON.parse(localStorage.getItem('userData') ?? '');    
    this.email = this.datauser.email;
  }

  next(){
    if(this.recipientData['address_one'].trim() == ''){
      this.common.presentToast("Please enter the recipient's address.")
    }else if(this.recipientData['city'].trim() == ''){
      this.common.presentToast("Please enter the recipient's city or town.")
    }else if(this.recipientData['country'].trim() == ''){
      this.common.presentToast("Please enter the recipient's country.")
    }else{
      this.common.presentLoading()
      this.transaction.Recipient.address_one = this.recipientData['address_one'];
      this.transaction.Recipient.address_two = this.recipientData['address_two'];
      this.transaction.Recipient.city = this.recipientData['city'];
      this.transaction.Recipient.country = this.recipientData['country'];            
            
      let data = {
        ...this.transaction.Recipient,
        'email' : this.email  
      }

      this.web.postData("cash", data).subscribe(
        (res: any) => {        
          if (res.code == 200) {                   
            this.common.presentToast(res.message);   
            this.transaction.Recipient.recipient_id = res['data']['id']                 
            this.router.navigate(['/confirm-transfer'])
          }
          else if (res.code == 400) {         
            this.common.presentToast(res.message);
          }      
          this.common.closeLoading()   
        },
        err => {
          console.log(err)
          this.common.presentToast("Something went wrong, try again later");
          this.common.closeLoading()
        }
      );      
    }
  }

  // close(){
  //   this.alertController.create
  //   this.router.navigate(['/landing'])
  // }

  async close() {
    const alert = await this.alertController.create({
      header: 'Cancel Transaction',
      message : 'Are you sure you want to cancel the transaction?',
      cssClass : 'cancel-transaction',
      backdropDismiss : false,
      mode : 'md',      
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          handler: () => {
            this.router.navigate(['/landing'])
          }
        }
      ]
    });
  
    await alert.present();
  }

}
