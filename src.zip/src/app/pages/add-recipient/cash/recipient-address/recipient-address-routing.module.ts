import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RecipientAddressPage } from './recipient-address.page';

const routes: Routes = [
  {
    path: '',
    component: RecipientAddressPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RecipientAddressPageRoutingModule {}
