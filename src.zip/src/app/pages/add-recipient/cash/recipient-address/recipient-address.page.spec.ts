import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RecipientAddressPage } from './recipient-address.page';

describe('RecipientAddressPage', () => {
  let component: RecipientAddressPage;
  let fixture: ComponentFixture<RecipientAddressPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(RecipientAddressPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
