import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RecipientAddressPageRoutingModule } from './recipient-address-routing.module';

import { RecipientAddressPage } from './recipient-address.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RecipientAddressPageRoutingModule
  ],
  declarations: [RecipientAddressPage]
})
export class RecipientAddressPageModule {}
