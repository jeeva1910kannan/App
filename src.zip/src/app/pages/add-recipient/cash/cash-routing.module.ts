import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CashPage } from './cash.page';

const routes: Routes = [
  {
    path: '',
    component: CashPage
  },
  {
    path: 'recipient-address',
    loadChildren: () => import('./recipient-address/recipient-address.module').then( m => m.RecipientAddressPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CashPageRoutingModule {}
