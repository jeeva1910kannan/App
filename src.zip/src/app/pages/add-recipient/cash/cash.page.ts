import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { CountryModalComponent } from '../country-modal/country-modal.component';
import { countryData } from 'src/app/countries';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { TransactionService } from 'src/app/services/transaction.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-cash',
  templateUrl: './cash.page.html',
  styleUrls: ['./cash.page.scss'],
})
export class CashPage implements OnInit {
  recipientData = {
    'fullname' : '',
    'phonenumber' : '',    
  }

  recipientCountry:any
  countries = [...countryData]

  constructor(private modalController:ModalController,private common:CommonService,private router:Router,private transaction:TransactionService,private alertController:AlertController, private user:UserService) { }

  ionViewWillEnter(){
    // this.recipientCountry = this.countries[0]
    this.recipientCountry = this.user.countryFromCountryCode(this.transaction.transaction_details.toCountry)
  }
  
  ngOnInit() {
  }

  async presentModal() {
    const modal = await this.modalController.create({
      component: CountryModalComponent,
      backdropDismiss: false,
      componentProps: {
        'recipientCountry' : this.recipientCountry['value']
      }
    });
    modal.onDidDismiss().then((data) => {
      if(data['role'] == 'save'){
        this.recipientCountry = data['data']
      }else{
        console.log(data['role'])
      }
    });
    return await modal.present();
  }

  next(){
    console.log(this.recipientData)
    if(this.recipientData['fullname'].trim() == ''){
      this.common.presentToast("Please enter the recipient's Full name")
    }else if(this.recipientData['phonenumber'].trim() == ''){
      this.common.presentToast("Please enter the recipient's Phone number")
    }else if(!this.common.isValidPhoneNumber(this.recipientData['phonenumber'])){
      this.common.presentToast("Please enter the valid Phone number")
    }else{
      this.transaction.Recipient.recipient_name = this.recipientData.fullname
      this.transaction.Recipient.phone = this.recipientData.phonenumber
      this.transaction.Recipient.country_code = this.recipientCountry['code']      
      this.router.navigate(['/add-recipient/cash/recipient-address'])
    }

  }

  async close() {
    const alert = await this.alertController.create({
      header: 'Cancel Transaction',
      message : 'Are you sure you want to cancel the transaction?',
      cssClass : 'cancel-transaction',
      backdropDismiss : false,
      mode : 'md',      
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          handler: () => {
            this.router.navigate(['/landing'])
          }
        }
      ]
    });
  
    await alert.present();
  }
}
