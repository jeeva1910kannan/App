import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddRecipientPage } from './add-recipient.page';

const routes: Routes = [
  {
    path: '',
    component: AddRecipientPage
  },
  {
    path: 'mobile-money',
    loadChildren: () => import('./mobile-money/mobile-money.module').then( m => m.MobileMoneyPageModule)
  },
  {
    path: 'bank',
    loadChildren: () => import('./bank/bank.module').then( m => m.BankPageModule)
  },
  {
    path: 'cash',
    loadChildren: () => import('./cash/cash.module').then( m => m.CashPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddRecipientPageRoutingModule {}
