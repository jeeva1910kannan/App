import { Component, OnInit } from '@angular/core';
import { PdfService } from 'src/app/services/pdf.service';

@Component({
  selector: 'app-transaction-view',
  templateUrl: './transaction-view.page.html',
  styleUrls: ['./transaction-view.page.scss'],
  
})
export class TransactionViewPage implements OnInit {
  recipientname:any
  reciptplatform:any
  recipientphone:any
  constructor(private pdf:PdfService) { }

  ngOnInit() {
  }

  downloadPDF(){
    this.pdf.generatePDF()
  }

}
