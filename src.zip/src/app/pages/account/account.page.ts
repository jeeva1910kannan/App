import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, Platform } from '@ionic/angular';
import { CommonService } from '../../services/common.service';
import { WebService } from 'src/app/services/web.service';
import { log } from 'console';

@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
})
export class AccountPage implements OnInit {
  data: any;
  userdetails: any;
  userid: any;
  edituserdetails: any;
  editMode: boolean = false; 
  editedEmail: string = ''; 
   editdata = {
  'newemail':'',
  'newphone':''
}
  oldemail: any;
  editMode1: boolean = false; 
  oldphone: any;
  sendmaildetails: any;
  constructor(private router: Router, private web: WebService, private alertController: AlertController, private common: CommonService, ) { }

  ngOnInit() {
    this.data = JSON.parse(localStorage.getItem('userData') ?? '');
    console.log(this.data, "this.data");
    this.userid = this.data.id;
    this.oldemail=this.data.email
    this.oldphone=this.data.phone
    console.log(this.data.id, "this.userid ")
    this.getuserdata();
   
   
  }
  navigateToChangePassword() {
    this.router.navigateByUrl('/changepassword');
  }
  async logout() {
    console.log('logout')
    const alert = await this.alertController.create({
      header: 'Logout',
      message : 'Are you sure you want to logout?',
      cssClass : 'logout',
      backdropDismiss : false,
      mode : 'md',    
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, 
        {
          text: 'Yes',
          handler: () => {
            this.router.navigate(['/'])
            localStorage.removeItem('userData')
            this.common.presentToast('You have successfully logged out')
          }
        }
      ]
    });
  
    await alert.present();
  }
  toggleEdit() {
    // Toggle edit mode when the "Edit" button is clicked
    this.editMode = !this.editMode;
    
    if (this.editMode) {
      this.editdata.newemail = this.userdetails.email;
    }
  }
  
  sendemail(){
    
    let postData
    postData={
      'user_id':this.userid,
      'email':this.data.email,

    }
   console.log("this.data.email",this.data.email);
   
    this.web.postData("sendmail", postData)
    .subscribe((res: any) => {
      console.log(res);
      if (res.code == 200) {                    
       this.sendmaildetails=res.data
       console.log("this.sendmaildetails",this.sendmaildetails);
       
       this.common.presentToast("Transfer History has been sent through your email");        
       
      }
      else if (res.code == 400) {        
        this.common.presentToast(res.message);                    
      } 
    
    },
    );
  }
  toggleEdit1() {
    // Toggle edit mode when the "Edit" button is clicked
    this.editMode1 = !this.editMode1;
    
    if (this.editMode1) {
      this.editdata.newphone = this.userdetails.phone;
    }
  }

 
  getuserdata(){

    let postData
    postData={
      'user_id':this.data
    }
   
    this.web.postData("getuserpersonalinfo", postData)
    .subscribe((res: any) => {
      console.log(res);
      if (res.code == 200) {                    
       this.userdetails=res.data
       console.log(this.userdetails.name, "77")
       
       
      }
      else if (res.code == 400) {        
        this.common.presentToast(res.message);                    
      } 
    
    },
    );
  }
  edituserdata(){
    // if(this.oldemail ==this.editdata.newemail){
    //   this.common.presentToast("No Changes made");  
    //   this.editMode = false;
    //   this.editMode1 = false;
    //   this.ngOnInit();
    // }
    
    let postData
    postData={
      'user_id': this.userid,
      'newemail': this.editdata.newemail, 
    }
    console.log("Hiiiiiiiiiiiiiii");
    
    this.web.postData("edituserpersonalinfo", postData)
    .subscribe((res: any) => {
      console.log(res);
      
      if(this.oldemail !==this.editdata.newemail){
      if (res.code == 200) {                    
      
        this.common.presentToast("Your Email Edited Successfully");  
        this.editMode = false;
        this.editMode1 = false;
        this.ngOnInit();
      }
      else if(res.code == 400) {        
        this.common.presentToast(res.message);                    
      } 
  }
  else if (this.oldemail ==this.editdata.newemail) { 
    console.log("this.oldemail ==this.editdata.newemail",this.oldemail ==this.editdata.newemail);
           
    this.common.presentToast("Your Email Edited Successfully");  
    this.editMode = false;
    this.editMode1 = false;
    this.ngOnInit();               
  } 
  else{
    this.common.presentToast("error");
  }
    },
    );
  }

  editphonedata(){

    let postData
    postData={
      'user_id': this.userid,
      'newphone': this.editdata.newphone, 
    }
    console.log("Hiiiiiiiiiiiiiii");
    
    this.web.postData("edituserphoneinfo", postData)
    .subscribe((res: any) => {
      console.log(res);
      if(this.oldphone !==this.editdata.newphone){
      if (res.code == 200) {                    
      
        this.common.presentToast("Your Phone Number Edited Successfully");  
        this.editMode = false;
        this.editMode1 = false;
        this.ngOnInit();
      }
      else if (res.code == 400) {        
        this.common.presentToast(res.message);                    
      } 
    
    }
    else if (this.oldphone ==this.editdata.newphone) { 
  
             
      this.common.presentToast("Your Phone Number Edited Successfully");  
      this.editMode = false;
      this.editMode1 = false;
      this.ngOnInit();               
    } 
    else{
      this.common.presentToast("error");
    }
  }
    );
  }
}
