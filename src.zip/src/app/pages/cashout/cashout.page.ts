import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { UserService } from 'src/app/services/user.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-cashout',
  templateUrl: './cashout.page.html',
  styleUrls: ['./cashout.page.scss'],
})
export class CashoutPage implements OnInit {
  wantPayOut:boolean = false
  cashOutFee!: number
  recipientData:any
  transactionDetails:any

  constructor(private router:Router,private transaction:TransactionService,private user:UserService,private web:WebService, private common: CommonService) { }

  ngOnInit() {
    let userCountry = this.user['userCountry']    
    this.cashOutFee = this.transaction.cashoutFee
    this.recipientData = {...this.transaction.Recipient}
    this.transactionDetails = {...this.transaction.transaction_details}        
    this.getCashout(userCountry) 
  }

  ionViewWillEnter(){      
    this.wantPayOut = this.transaction.Recipient.cashout_fee
    this.cashOutFee = this.transaction.cashoutFee
  }

  getCashout(userCountry:any){
    this.common.presentLoading()
    this.web.cashoutFee(userCountry['currencies']).subscribe(
      (res) => {
        this.common.closeLoading()
        // Check later
        this.cashOutFee = +(res['result'].toFixed(2))
        this.transaction.cashoutFee = this.cashOutFee        
      },
      (err) => {
        this.common.closeLoading()
        this.getCashout(userCountry)
      }
    )
  }
  

  confirmtransfer(){
    let cashOut = this.transaction.Recipient.cashout_fee
    let transaction_details = {...this.transaction._transaction_details}
    let fromAmount = transaction_details['fromAmount']
    let conversion = transaction_details['conversion']  
    
    if(!cashOut && this.wantPayOut){
      this.transaction.Recipient.cashout_fee = this.wantPayOut;  
      this.transaction._transaction_details['fromAmount'] = +((fromAmount + this.cashOutFee).toFixed(2))
      this.transaction._transaction_details['toAmount'] = +((this.transaction._transaction_details['fromAmount'] * conversion).toFixed(2))
    }
    if(cashOut && !this.wantPayOut){
      this.transaction.Recipient.cashout_fee = this.wantPayOut;  
      this.transaction._transaction_details['fromAmount'] = +((fromAmount - this.cashOutFee).toFixed(2))
      this.transaction._transaction_details['toAmount'] = +((this.transaction._transaction_details['fromAmount'] * conversion).toFixed(2))
    }
      

    this.router.navigate(['/confirm-transfer']);
  }

}
