import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { countryData } from 'src/app/countries';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { UserService } from 'src/app/services/user.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.page.html',
  styleUrls: ['./landing.page.scss'],
})
export class LandingPage implements OnInit {
  apiKey = environment.currencyApiKey
  userData:any
  selectedCountry:any
  userCountry:any
  changedCountry:any
  _searchTerm:string = ''
  countries = countryData
  filteredCountries = [...this.countries]
  currency:any;
  userid:any;
  currencyData = {
    fromcurrency : 0,
    tocurrency: 0,    
  }
  finalCurrency = {
    fromcurrency : 0,
    tocurrency: 0
  }
  exchangeRates: any; 
  baseCurrency: string = 'USD'; 
  conversionRates: { [key: string]: number } = {};
  amount: number = 1;
  convertedAmount: number = 0;


  constructor(private user: UserService,private router:Router,private alertController:AlertController,private common:CommonService, private transaction: TransactionService) { }

  ngOnInit() {
   
  }

  get searchTerm(){
    return this._searchTerm
  }

  set searchTerm(val:string){
    this._searchTerm = val
    this.filteredCountries = this.filterSource(val);    
  }

  setCountry(){    
    this.currencyData['fromcurrency'] = 0;
    this.currencyData['tocurrency'] = 0;
    this.selectedCountry = this.countries.find((country) => {
      return country['value'] == this.changedCountry;
    })    
    this.user.selectedCountry = {...this.selectedCountry}
    this.getCurrency();    
  }

  performConversion(ipNo:1 | 2) {       
    if(ipNo == 1){
      if (this.currencyData['fromcurrency']) {
        const fromValue = this.currencyData['fromcurrency'];
        const toValue = fromValue * this.currency; 
        this.currencyData['tocurrency'] = +toValue.toFixed(2); 
        this.finalCurrency['tocurrency'] = toValue;        
      }else{
        this.currencyData['tocurrency'] = 0;
      }
    }else{
      if (this.currencyData['tocurrency']) {
        const toValue = this.currencyData['tocurrency'];
        const fromValue = toValue / this.currency; 
        this.currencyData['fromcurrency'] = +fromValue.toFixed(2);         
      }else{
        this.currencyData['fromcurrency'] = 0;
      }
    }
  }


  getCurrency(){
    let myHeaders = new Headers();
    myHeaders.append("apikey", this.apiKey);
    let requestOptions: RequestInit = {
      method: 'GET',
      redirect: 'follow', 
      headers: myHeaders
    };
    fetch(`https://api.apilayer.com/currency_data/convert?to=${this.selectedCountry['currencies']}&from=${this.userCountry['currencies']}&amount=1`, requestOptions)
    .then(response => response.json()) 
    .then(data => {
      if(data['message'] == 'Invalid authentication credentials'){
        this.currency = 1
      }else{
        this.currency = data.result;      
      }

    })
    .catch(error => console.log('Error:', error));
  }

  

  clearInput(ipNo : 1 | 2) {
    if(ipNo == 1){
      if (this.currencyData['fromcurrency'] === 0) {
        this.currencyData['fromcurrency'] = NaN; // Clear the input field
      }
    }else{
      if (this.currencyData['tocurrency'] === 0) {
        this.currencyData['tocurrency'] = NaN; // Clear the input field
    }
    }
  }
 
  ionViewWillEnter(){      
    let transactionDetails = this.transaction.transaction_details
    this.currencyData['fromcurrency'] = transactionDetails['fromAmount']
    this.currencyData['tocurrency'] = transactionDetails['toAmount']
    this.userCountry = this.user.userCountry
    this.selectedCountry = {...this.user.selectedCountry}
    this.changedCountry = this.selectedCountry['value']    
    this.getCurrency()    
  }

  next(){
    if(this.currencyData['fromcurrency'] == 0){
      this.common.presentToast('Please enter the transaction amount')
    }else{
      console.log(this.currency)
      let transactionData = {
        'fromCountry' : this.userCountry['code'],
        'toCountry' : this.selectedCountry['code'],
        'fromAmount' : this.currencyData['fromcurrency'],
        'toAmount' : this.currencyData['tocurrency'],
        'fromCurrency' : this.userCountry['symbol'],
        'toCurrency' : this.selectedCountry['symbol'],
        'conversion' : this.currency
      } 
      this.transaction.transaction_details = transactionData
      this.transaction.transaction_amount = this.currencyData['fromcurrency']
      this.router.navigate(['/choose-recipient'])
    }
  }


  filterSource(value:string){
    if(!value || this.countries.length === 0) {
      return this.countries
    }
    return this.countries.filter((data) => this.matchValue(data,value)); 
  }

  matchValue(data:any, value:any) {
    return Object.keys(data).map((key) => {
       return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }


  async openPromo() {
    const alert = await this.alertController.create({
      header: 'Enter code',
      message : 'Enter a code to get a bonus credit on your next eligible transfer',
      cssClass : 'promo',
      backdropDismiss : false,
      mode : 'md',
      inputs: [
        {
          name: 'code',
          type: 'text',
          placeholder: 'Promo code'          
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
            if(data.code.trim() == ''){
              this.common.presentToast('Please enter your promo code')
              return false
            }else{              
              return true
            }
          }
        }
      ]
      
    });
  
    await alert.present();
  }

  route(){
    this.router.navigate(['/transaction-view'])
  }




}
