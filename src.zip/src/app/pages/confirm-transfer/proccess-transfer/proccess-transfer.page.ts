import { Component, OnInit } from '@angular/core';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-proccess-transfer',
  templateUrl: './proccess-transfer.page.html',
  styleUrls: ['./proccess-transfer.page.scss'],
})
export class ProccessTransferPage implements OnInit {
  transactionData:any
  recipientData:any
  constructor(private transaction:TransactionService) { }

  ngOnInit() {
    this.transactionData = this.transaction.transaction_details
    this.recipientData = this.transaction.Recipient
    console.log(this.transaction.transaction_details)
    console.log(this.transactionData)
  }



}
