import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProccessTransferPage } from './proccess-transfer.page';

describe('ProccessTransferPage', () => {
  let component: ProccessTransferPage;
  let fixture: ComponentFixture<ProccessTransferPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ProccessTransferPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
