import { Component, OnInit, ViewChild , Renderer2} from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, IonModal, ModalController } from '@ionic/angular';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { UserService } from 'src/app/services/user.service';
import { WebService } from 'src/app/services/web.service';
import { EditTransferComponent } from './edit-transfer/edit-transfer.component';
import { TransactionsApi } from 'transferzero-sdk';
import { ApiClient } from 'transferzero-sdk';
import { AccountValidationApi } from 'transferzero-sdk';
import { AzaFinanceService } from '../../services/aza-finance.service';

@Component({
  selector: 'app-confirm-transfer',
  templateUrl: './confirm-transfer.page.html',
  styleUrls: ['./confirm-transfer.page.scss'],
})

export class ConfirmTransferPage implements OnInit {
  transactionData:any
  recipientData: any;
  recipientname: any;
  reciptplatform: any;
  recipientphone: any;
  mobileMoney:any
  paymentMethod!: 0 | 1
  bank:any  
  userid:any;
  data:any;

  formData = {
    password :''
  }
  @ViewChild(IonModal) modal!: IonModal;
  showPassword: boolean = false;
  constructor(
    private router:Router,
    private common:CommonService,
    public transaction: TransactionService,
    private web: WebService,
    private user:UserService,    
    private alertController: AlertController,
    private modalCtrl: ModalController ,
    private azaFinanceService: AzaFinanceService
    ) { }

  ionViewWillEnter(){
        
  }

  ngOnInit() {     

    this.recipientData  = this.transaction.Recipient
    console.log(this.recipientData)
    this.transactionData = this.transaction.transaction_details     
    console.log(this.transactionData)
    console.log(this.user.userCountry)
    this.data = JSON.parse(localStorage.getItem('userData') ?? '');    
    this.userid = this.data.id;    
    this.mobileMoney = this.user.mobileMoneyAccount;
    this.bank = this.user.bankAccount;
    this.paymentMethod = this.user.currentPaymentMethod;
    
  }

  validateAccount() {
    const accountValidationRequest = {
      bank_account: '12345678',
      bank_code: '050',
      country: 'NG',
      currency: 'NGN',
      method: 'bank'
    };

    this.azaFinanceService.postAccountValidations(accountValidationRequest)
      .subscribe(
        (response) => {
          console.log('Success: ', response);
        },
        (error) => {
          console.error('Error: ', error);
        }
      );
  }
  
  accountvalidation(){
    console.log("Hi payment");
    
    const apiClient = new ApiClient();
apiClient.apiKey = 'SOqo30eh+hmh4EA5v1f8TJNTiIsUS+8tfIuRM5pxUZgYhmoZJoyya32+JayNtzyMk4XsDbComvUUnDHu7AeQwQ==';
apiClient.apiSecret = 'raVLIoeCUUhtGVQ/jM2yvO9B6W1e9/VUyFOUKA9yYj2A/olV7tLUPY+T8xWXaWjZishtDjaNpR0Larws3OyMXg==';
apiClient.basePath = 'https://api-sandbox.transferzero.com/v1';

let apiInstance = new AccountValidationApi(apiClient);
console.log("apiInstance",apiInstance);

let accountValidationRequest ={
  "bank_account": "12345678",
  "bank_code": "050",
  "country": "NG",
  "currency": "NGN",
  "method": "bank"
}
apiInstance.postAccountValidations(accountValidationRequest).then((data: string) => {
  console.log("entered");
  
  console.log('API called successfully. Returned data: ' + data);
}, (error: { isValidationError: any; getResponseObject: () => any; }) => {
  if (error.isValidationError) {
    console.log("payment if");
    
    let result = error.getResponseObject();
    console.log(result);
    console.error("WARN: Validation error occurred when calling the endpoint");
  } else {
    console.log("payment else");
    
    console.error("Exception when calling AccountValidationApi#postAccountValidations");
    throw error;
  }
});
  }
  togglePasswordView() {
    this.showPassword = !this.showPassword
  }

  forgotpage(){
    this.router.navigate(['/forgotpassword']);
    this.formData['password'] = "";
    this.modal.dismiss(null, 'cancel');
  }

  cancel(){   
    this.modal.dismiss(null, 'cancel');
    this.formData['password'] = "";
  }

  confirmpassword(){
    if(this.formData['password'].trim() == ''){
      this.common.presentToast('Please enter your password');
    }else{
      let postData
      postData = {
        'password' : this.formData['password'],
        'userid' : this.userid           
      }           
      this.common.presentLoadingconfirm();
      this.web.postData("checkpassword", postData)
      .subscribe((res: any) => {
        console.log(res);
        if (res.code == 200) {                    
          this.common.presentToast('Your transaction is now being processed.');  
          this.common.closeLoadingconfirm()
          // this.router.navigate(['/confirm-transfer/proccess-transfer'])        
          this.modal.dismiss(null, 'cancel');
          this.formData['password'] = "";   
          this.saveTransaction()       
         
        }
        else if (res.code == 400) {        
          this.common.presentToast(res.message);   
          this.common.closeLoadingconfirm()                 
        } 
        
      },
        err => {
          this.common.closeLoadingconfirm()
          this.common.presentToast("Something went wrong, try again later");         
        }
      );

  }

  }

  saveTransaction(){
    this.common.presentLoading()
    let paymentAccount = this.paymentMethod == 0 ? this.bank : this.mobileMoney  
    let paymentMethod =  this.paymentMethod == 0 ? 'Bank' : 'Mobile Money'  
    this.web.postData('create_transaction',{
      'recepient_data' : this.recipientData,
      'transaction_details' : this.transactionData,
      'payment_method' : paymentMethod,
      'payment_account' : paymentAccount,
      'user_id' : this.userid,      
    }).subscribe((res) => {
      this.common.closeLoading()
      if(res['status'] == '200'){        
        this.router.navigate(['/confirm-transfer/proccess-transfer'])   
      }
    } , (err) => {
      this.common.closeLoading()
      this.common.presentToast('Something went wrong. Please try again.')
    })
  }
transactionapi(){
  const apiClient = new ApiClient();
apiClient.apiKey = 'SOqo30eh+hmh4EA5v1f8TJNTiIsUS+8tfIuRM5pxUZgYhmoZJoyya32+JayNtzyMk4XsDbComvUUnDHu7AeQwQ==';
apiClient.apiSecret = 'raVLIoeCUUhtGVQ/jM2yvO9B6W1e9/VUyFOUKA9yYj2A/olV7tLUPY+T8xWXaWjZishtDjaNpR0Larws3OyMXg==';
apiClient.basePath = 'https://api-sandbox.transferzero.com/v1';
let transactionID = '65445678997644';
let apiInstance = new TransactionsApi(apiClient);

apiInstance.getTransaction(transactionID).then((data: string) => {
  console.log('API called successfully. Returned data: ' + data);
}, (error: { isValidationError: any; getResponseObject: () => any; }) => {
  if (error.isValidationError) {
    let result = error.getResponseObject();
    console.log(result);
    console.error("WARN: Validation error occurred when calling the endpoint");
  } else {
    console.error("Exception when calling TransactionsApi#getTransaction");
    throw error;
  }
});
}
  async openPromo() {
    const alert = await this.alertController.create({
      header: 'Enter code',
      message : 'Enter a code to get a bonus credit on your next eligible transfer',
      cssClass : 'promo',
      backdropDismiss : false,
      mode : 'md',
      inputs: [
        {
          name: 'code',
          type: 'text',
          placeholder: 'Promo code'          
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data:any) => {
            if(data.code.trim() == ''){
              this.common.presentToast('Please enter your promo code')
              return false
            }else{
              // promo API here
              return true
            }
          }
        }
      ]
    });
  
    await alert.present();
  }

  route(edit:string, data=null){
    console.log(edit)
    if (edit == 'recipient') this.router.navigate(['/choose-recipient'])
    else this.router.navigate(['/confirm-transfer/edit-transfer', edit])     
  }


  months = [
    'January', 'February', 'March', 'April',
    'May', 'June', 'July', 'August',
    'September', 'October', 'November', 'December'
  ];

  get expiryDate(){
    let expiry = this.bank['account_expiration_date'];
    let month = +expiry.slice(0,2)
    return `${this.months[--month]} 20${expiry.slice(-2)}`
  }


  async openModal(edit:string) {
    const modal = await this.modalCtrl.create({
      component: EditTransferComponent,
      componentProps : {
        'edit' : edit
      },
      initialBreakpoint : edit  == 'recipient' ? 1 : 0.50
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();    
    if (role === 'save') {
      this.paymentMethod = this.user.currentPaymentMethod;
    }
  }
  

}
