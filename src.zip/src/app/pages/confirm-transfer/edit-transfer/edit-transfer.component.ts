import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { CommonService } from 'src/app/services/common.service';
import { TransactionService } from 'src/app/services/transaction.service';
import { UserService } from 'src/app/services/user.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-edit-transfer',
  templateUrl: './edit-transfer.component.html',
  styleUrls: ['./edit-transfer.component.scss'],
})
export class EditTransferComponent  implements OnInit {

  userCountry:any
  recipientCountry:any
  currency!:number
  transactionDetails:any
  recipientData:any
  edit!:string  
  mobileMoney:any
  bank:any
  currentPayment!: 0 | 1


  filteredRecipients:any
  recipients:any
  allrecipients:any
  _searchTerm:string = ''
  paymentMethod!:string;

  get searchTerm(){
    return this._searchTerm
  }

  set searchTerm(val:string){
    this._searchTerm = val
    this.filteredRecipients = this.filterSource(val);    
  }

  constructor(private user: UserService,private transaction:TransactionService,private modalCtrl:ModalController, private web:WebService, private common:CommonService,private router: Router) { }

  ngOnInit() {   
    this.recipientData = {...this.transaction.Recipient }
    if(this.edit == 'amount'){
      this.transactionDetails = {...this.transaction.transaction_details}      
      this.userCountry = this.user.countryFromCountryCode(237) 
      this.recipientCountry = this.user.countryFromCountryCode(this.recipientData['country_code'])    
      this.currency = this.transactionDetails['conversion']  
    }

    if(this.edit == 'payment'){
      let mobile_money = {...this.user.mobileMoneyAccount}
      let bank = {...this.user.bankAccount}
      this.mobileMoney = mobile_money['mobile_money_name'] ? mobile_money : null
      this.bank = bank['account_name'] ? bank : null
      this.currentPayment = this.user.currentPaymentMethod
    }

    if(this.edit == 'recipient'){
      console.log(this.recipientData)
      this.paymentMethod = this.recipientData['banking_method']
      // this.getsaverecipient()
    }
    
    
  }

  save(recipient:any = null){
    if(this.edit == 'amount'){
      this.transaction.transaction_details = this.transactionDetails
    }
    if(this.edit == 'payment'){
      this.user.currentPaymentMethod = this.currentPayment
    }    
    if(this.edit == 'recipient'){
      this.transaction.existingRecipient(recipient,recipient?.payment_type)
    }
    return this.modalCtrl.dismiss(null, 'save');
  }

  cancel(){    
      return this.modalCtrl.dismiss(null, 'cancel');    
  }

  

  clearInput(ipNo : 1 | 2) {
    if(ipNo == 1){
      if (this.transactionDetails['fromAmount'] === 0) {
        this.transactionDetails['fromAmount'] = NaN; // Clear the input field
      }
    }else{
      if (this.transactionDetails['toAmount'] === 0) {
        this.transactionDetails['toAmount'] = NaN; // Clear the input field
    }
    }
  }


  performConversion(ipNo:1 | 2) {   
    console.log('enter')
    if(ipNo == 1){
      if (this.transactionDetails['fromAmount']) {
        const fromValue = this.transactionDetails['fromAmount'];
        const toValue = fromValue * this.currency; 
        this.transactionDetails['toAmount'] = +(toValue.toFixed(2)); 
        console.log(this.transactionDetails['toAmount'])
      }else{
        this.transactionDetails['toAmount'] = 0;
      }
    }else{
      if (this.transactionDetails['toAmount']) {
        const toValue = this.transactionDetails['toAmount'];
        const fromValue = toValue / this.currency; 
        this.transactionDetails['fromAmount'] = +(fromValue.toFixed(2)); 
        console.log(this.transactionDetails['fromAmount'])
      }else{
        this.transactionDetails['fromAmount'] = 0;
      }
    }
    console.log(this.transactionDetails['fromAmount'])
    console.log(this.transactionDetails['toAmount'])
  }

  togglePayment(value: 1 | 0){    
    this.currentPayment = value
  }

  months = [
    'January', 'February', 'March', 'April',
    'May', 'June', 'July', 'August',
    'September', 'October', 'November', 'December'
  ];

  get expiryDate(){
    let expiry = this.bank['account_expiration_date'];
    let month = +expiry.slice(0,2)
    return `${this.months[--month]} 20${expiry.slice(-2)}`
  }

  filterSource(value:string){
    if(!value || this.recipients.length === 0) {
      return this.recipients
    }
    return this.recipients.filter((data:any) => this.matchValue(data,value)); 
  }

  matchValue(data:any, value:any) {
    return Object.keys(data).map((key) => {
       return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }


  getsaverecipient(){
    this.common.presentLoading()
    this.web.postData("getfilteredrecipient",{
      'country_code' : this.transaction.transaction_details['toCountry'],
      'type' : this.paymentMethod 
    }).subscribe(
      (res: any) => {          
        if (res.code == 200) {            
          this.allrecipients = res.data;
          this.recipients = [...this.allrecipients]
          this.filteredRecipients = [...this.recipients]           
        }
        else if (res.code == 400) {      
          this.allrecipients = [];
          this.recipients = [...this.allrecipients]
          this.filteredRecipients = [...this.recipients]        
          //  this.common.presentToast(res.message);
        }      
        this.common.closeLoading()     
      },
      err => {
        this.common.presentToast("Something went wrong, try again later");
        this.common.closeLoading()     
      }
    );
  }

  route(){
    
    console.log(this.paymentMethod)
    if(this.paymentMethod == 'Mobile Money') this.router.navigate(['/add-recipient/mobile-money']);
    if(this.paymentMethod == 'Bank') this.router.navigate(['/add-recipient/bank']);
    if(this.paymentMethod == 'Cash') this.router.navigate(['/add-recipient/cash']);
    this.cancel()
  }


 
}
