// src/pages/confirm-transfer/transferzero-sdk.d.ts

declare module 'transferzero-sdk';
