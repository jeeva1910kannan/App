import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfirmTransferPage } from './confirm-transfer.page';

const routes: Routes = [
  {
    path: '',
    component: ConfirmTransferPage
  },
  {
    path: 'proccess-transfer',
    loadChildren: () => import('./proccess-transfer/proccess-transfer.module').then( m => m.ProccessTransferPageModule)
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConfirmTransferPageRoutingModule {}
