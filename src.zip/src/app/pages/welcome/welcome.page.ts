import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { countryData } from 'src/app/countries';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
})
export class WelcomePage implements OnInit {

  countries = countryData

  filteredCountries = [...this.countries];

  constructor(private user: UserService,private router:Router) { }

  filterCountries(event: any) {
    const searchTerm = event.target.value.toLowerCase();
    this.filteredCountries = this.countries.filter(country =>
      country.name.toLowerCase().includes(searchTerm)
    );
  }

  selectCountry(country:any){
    this.user.selectedCountry = country
    this.router.navigate(['/landing'])
  }

  ngOnInit() {
    console.log(this.filteredCountries, 'filterCountries')
  }

}
