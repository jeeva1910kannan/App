import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PaymentPage } from './payment.page';

const routes: Routes = [
  {
    path: '',
    component: PaymentPage
  },
  {
    path: 'mobile-money/:action',
    loadChildren: () => import('./mobile-money/mobile-money.module').then( m => m.MobileMoneyPageModule)
  },
  {
    path: 'debit-card/:action',
    loadChildren: () => import('./debit-card/debit-card.module').then( m => m.DebitCardPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PaymentPageRoutingModule {}
