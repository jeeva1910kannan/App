import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { UserService } from 'src/app/services/user.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-mobile-money',
  templateUrl: './mobile-money.page.html',
  styleUrls: ['./mobile-money.page.scss'],
})
export class MobileMoneyPage implements OnInit {  
  action!: 'add' | 'edit'
  userCountry:any
  userId!:number
  mobileMoney = {
    'mobile_money_name' : '',
    'mobile_money_number' : ''
  }
  constructor(private web:WebService, private user:UserService,private common: CommonService, private activatedRoute:ActivatedRoute, private _location:Location) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      if(params['action']){
        this.action = params['action']
      }
    })
    if(this.action == 'edit'){
      this.mobileMoney = this.user.mobileMoneyAccount
    }
    let user = JSON.parse(localStorage.getItem('userData') ?? '')
    this.userId = user['id']
    this.userCountry = this.user.countryFromCountryCode(user['country_code'])
  }

  save(){
    if(this.mobileMoney['mobile_money_name'].trim() == ''){
      this.common.presentToast('Please enter your mobile money name');    
    }else if (this.mobileMoney['mobile_money_number'].trim() == '') {
      this.common.presentToast('Please enter your mobile money number');      
    }else if (!this.common.isValidPhoneNumber(this.mobileMoney['mobile_money_number'])) {
     this.common.presentToast('Please enter a valid mobile money Number');     
    }else{
      this.common.presentLoading()
      this.web.postData('add_payment',{
        ...this.mobileMoney,
        'user_id' : this.userId,
        'type' : "Mobile Money"
      }).subscribe(
        (res:any) => {
          this.common.presentToast(res['message']);
          if(res['status'] == '200'){
            localStorage.setItem('userData',JSON.stringify(res['user_data']))    
            console.log(localStorage.getItem('userData'))            
          }
          this._location.back()
          this.common.closeLoading()
        },
        (err) =>{
          this.common.presentToast("Something went wrong, try again later")
          this.common.closeLoading()
        }
      )
    }  
  }

}
