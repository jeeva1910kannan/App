import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { CommonService } from 'src/app/services/common.service';
import { UserService } from 'src/app/services/user.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.page.html',
  styleUrls: ['./payment.page.scss'],
})
export class PaymentPage implements OnInit {
  userId:any
  mobileMoney:any
  bank:any
  constructor(private router:Router,private user:UserService, private alertController:AlertController,private common:CommonService,private web:WebService) { }

  ngOnInit() {
  }

  ionViewWillEnter(){
    this.getData()
  }

  getData(){
    this.userId = this.user.user['id']
    let paymentMethods = this.user.paymentMethods
    this.bank = paymentMethods[0]['account_number'] ? paymentMethods[0] : null
    this.mobileMoney = paymentMethods[1]['mobile_money_number'] ? paymentMethods[1] : null
  }

  route(page: string,action:string = 'edit'){
    this.router.navigate([`/payment/${page}`,action])
  }

  months = [
    'January', 'February', 'March', 'April',
    'May', 'June', 'July', 'August',
    'September', 'October', 'November', 'December'
  ];

  get expiryDate(){
    let expiry = this.bank['account_expiration_date'];
    let month = +expiry.slice(0,2)
    return `${this.months[--month]} 20${expiry.slice(-2)}`
  }


  async deletePopup(account: 'Mobile Money' | 'Bank') {
    let whichAccount = account
    const alert = await this.alertController.create({
      header: 'Delete payment account',
      message : `Are you sure you want to delete your ${account == 'Bank' ? 'Bank' : 'Mobile Money'} account?`,
      cssClass : 'promo',
      backdropDismiss : false,
      mode : 'md',      
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data:any) => {
            this.deleteAccount(whichAccount)
          }
        }
      ]
    });
  
    await alert.present();
  }

  deleteAccount(account:string){
    this.common.presentLoading()
    this.web.postData('delete_payment',{
      user_id : this.userId,
      type : account
    }).subscribe(
      (res) => {
        this.common.closeLoading()
        this.common.presentToast(res['message'])
        if(res['status'] == '200'){
          localStorage.setItem('userData',JSON.stringify(res['user_data']))
          this.getData()
        }
        
      },
      (err) => {
        console.log(err)
        this.common.closeLoading();
        this.common.presentToast('Something went wrong. Please try again')
      }
    )
  }





}
