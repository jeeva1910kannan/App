import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebitCardPage } from './debit-card.page';

describe('DebitCardPage', () => {
  let component: DebitCardPage;
  let fixture: ComponentFixture<DebitCardPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(DebitCardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
