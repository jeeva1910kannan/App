import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DebitCardPage } from './debit-card.page';

const routes: Routes = [
  {
    path: '',
    component: DebitCardPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DebitCardPageRoutingModule {}
