import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { UserService } from 'src/app/services/user.service';
import { WebService } from 'src/app/services/web.service';

@Component({
  selector: 'app-debit-card',
  templateUrl: './debit-card.page.html',
  styleUrls: ['./debit-card.page.scss'],
})
export class DebitCardPage implements OnInit {
  action!: 'edit' | 'add'
  userId!:number  
  bankDetails = {
    account_name : '',
    account_number : '',
    account_expiration_date : '',
    account_cvv : ''
  }
  selectedDate:any
  today = new Date().toISOString();
  showPicker = false

  dateChanged(date:any){        
    let createdDate = new Date(date)    
    let month = createdDate.getMonth() + 1
    this.bankDetails['account_expiration_date'] = `${month < 10 ? '0' + month : month }/${createdDate.getFullYear().toString().slice(-2)}`
  }

  constructor(private common:CommonService,private web:WebService,private user:UserService,private activatedRoute: ActivatedRoute,private _location:Location) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      if(params['action']){
        this.action = params['action']
      }
    })
    if(this.action == 'edit'){
      this.bankDetails = this.user.bankAccount
      let expiryDate = this.bankDetails.account_expiration_date;
      this.selectedDate = new Date(+(20+expiryDate.slice(-2)),+expiryDate.slice(0,2)).toISOString()
      console.log(this.selectedDate)
      console.log(this.today)
    }else{
      this.selectedDate = this.today
    }
    let user = JSON.parse(localStorage.getItem('userData') ?? '')
    this.userId = user['id']
    
  }

  


  save(){
    if(this.bankDetails['account_name'].trim() == ''){
      this.common.presentToast('Please enter your legal name')
    }else if(this.bankDetails['account_number'].trim() == ''){
      this.common.presentToast('Please enter your card number')
    }else if(!this.common.isValidPhoneNumber(this.bankDetails['account_number'])){
      this.common.presentToast('Please enter valid card number')
    }else if(this.bankDetails['account_expiration_date'].trim() == ''){
      this.common.presentToast('Please select your card\'s expiration date')
    }else if(this.bankDetails['account_cvv'].trim() == ''){
      this.common.presentToast('Please enter your card\'s CVV number')
    }else if(this.bankDetails['account_cvv'].length != 3 || !this.common.isValidPhoneNumber(this.bankDetails['account_cvv'])){
      this.common.presentToast('Please enter valid CVV number')
    }else{
      this.common.presentLoading()
      this.web.postData('add_payment',{
        ...this.bankDetails,
        'user_id' : this.userId,
        'type' : "Bank"
      }).subscribe(
        (res:any) => {
          this.common.presentToast(res['message']);
          console.log(res['message'])
          this._location.back()
          if(res['status'] == '200'){
            localStorage.setItem('userData',JSON.stringify(res['user_data']))    
            console.log(localStorage.getItem('userData'))
            
          }
          this.common.closeLoading()
        },
        (err) =>{
          this.common.presentToast("Something went wrong, try again later")
          this.common.closeLoading()
        }
      )
    }
      
    
  }

}
