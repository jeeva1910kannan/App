import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DebitCardPageRoutingModule } from './debit-card-routing.module';

import { DebitCardPage } from './debit-card.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DebitCardPageRoutingModule
  ],
  declarations: []
})
export class DebitCardPageModule {}
