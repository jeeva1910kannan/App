import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { countryData } from 'src/app/countries';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginData = {
    email : '',
    phonenumber: '',
    password :''
  }

  showPassword:boolean = false
  selectedCountry!:string  
  _searchTerm:string = ''
  countries = countryData
  filteredCountries = [...this.countries]
  userCountry:any

  get searchTerm(){
    return this._searchTerm
  }

  set searchTerm(val:string){
    this._searchTerm = val
    this.filteredCountries = this.filterSource(val);    
  }
  constructor(private common:CommonService, private web: WebService, private router:Router,private user:UserService) { }

  setCountry(){
    this.userCountry = this.countries.find((country) => {
      return country['value'] == this.selectedCountry
    })
    console.log(this.userCountry)
  }

  ngOnInit() {
    console.log(this.countries.length)
    this.userCountry = this.countries[0]  
    this.selectedCountry = this.userCountry['value']
  }

  login(){ 

    if((this.loginData['email'].trim() == '' && this.loginData['phonenumber'] == '') || (this.loginData['email'].trim() != '' && this.loginData['phonenumber'] != '')){
      this.common.presentToast('Please enter Email or Phone Number');
    }else if (this.loginData['email'].trim() != '' && !this.common.isValidEmail(this.loginData['email'])) {
       this.common.presentToast('Please enter a valid Email');      
    }else if (this.loginData['phonenumber'].trim() != '' && !this.common.isValidPhoneNumber(this.loginData['phonenumber'])) {
      this.common.presentToast('Please enter a valid Phone Number');     
   }  
    else if(this.loginData['password'].trim() == ''){
      this.common.presentToast('Please enter your password');
    }else{
      this.common.presentLoading()
      let postData
      if(this.loginData['email'].trim() == ''){
        postData = {
          'phone' : this.loginData['phonenumber'],
          'country_code' : this.userCountry['code'],
          'login_with' : 'phone'
        }
      }else{
        postData = {
          'email' : this.loginData['email'],
          'login_with' : 'email'          
        }
      }
      postData = {
        ...postData,
        'password' : this.loginData['password']
      } 
      this.web.postData('login',{...postData}).subscribe(        
        (data) => {
          this.common.closeLoading()
          this.common.presentToast(data['message'])
          localStorage.setItem('userData',JSON.stringify(data['user']))
          this.user.userData = data['user']
          console.log(data)
          this.router.navigate(['/welcome'])                    
        },
        (err) => {          
          this.common.closeLoading()
          this.common.presentToast(err['error']['message'])
        }
      )
    }
  }


  togglePassword(){
    this.showPassword = !this.showPassword
  }

  filterSource(value:string){
    if(!value || this.countries.length === 0) {
      return this.countries
    }
    return this.countries.filter((data) => this.matchValue(data,value)); 
  }

  matchValue(data:any, value:any) {
    return Object.keys(data).map((key) => {
       return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }


  


  // test(){
  //   this.http.post("login",{
  //     'email' : 'contact@creativtrading.com',
  //     'password' : 'Host124'
  //   }).subscribe(
  //     (res: any) => {
  //      console.log(res,"res: any")
  //   },
  //     (error) => {
  //     console.error('Error fetching data:', error);
  //     }
  //     ); 
  // }

}
