import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { ForgetService } from '../forgotpassword/forget.service';
import { log } from 'console';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.page.html',
  styleUrls: ['./changepassword.page.scss'],
})
export class ChangepasswordPage implements OnInit {
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;
  showConfirmPassword1: boolean = false;
  user:any
  userid:any;
  data:any;
  changepassword = {
    'curpassword' : '',
    'newpassword' : '',
    'confonewpassword' : ''
  }
  constructor(private common:CommonService,private web:WebService,private router:Router,private forgetService:ForgetService) { }

getunserid(){
  this.user = {...this.forgetService.user}
}
  ngOnInit() {
    this.data = JSON.parse(localStorage.getItem('userData') ?? '');
    console.log(this.data, "this.data")
    this.userid = this.data.id;
    console.log(this.data.id, "this.userid ")
  }
  togglePasswordView() {
    this.showPassword = !this.showPassword
  }
  toggleConfirmPasswordView() {
    this.showConfirmPassword = !this.showConfirmPassword
  }
  toggleConfirmPasswordView1() {
    this.showConfirmPassword1 = !this.showConfirmPassword1
  }
  submit(){
    if(this.changepassword['curpassword'].trim() == ''){
      this.common.presentToast('Please enter your Current Password')
    }
    else if(this.changepassword['newpassword'].trim() == ''){
      this.common.presentToast('Please enter your New Password')
    }
    else if(this.changepassword['confonewpassword'].trim() == ''){
      this.common.presentToast('Please enter your Confirmation Password')
    }
    else if(this.changepassword['newpassword'] != this.changepassword['confonewpassword']){
      this.common.presentToast('Passwords mismatched. Please try again.')
    }else{
      this.common.presentLoading()
      let postData = {
        'userid' : this.userid,
        'curpassword' : this.changepassword['curpassword'],
        'newpassword' : this.changepassword['confonewpassword']
      }
      console.log("postData",postData);
      
      this.web.postData('change_password',{
        ...postData
      }).subscribe(
        (data) => {
          this.common.closeLoading()
          this.common.presentToast(data['message'])
          if(data['status'] == 200){
            this.router.navigate(['/account'])
          }
        },
        (err) => {
          this.common.closeLoading()
          this.common.presentToast(err['error']['message'])
        }
      )
    }
  }

}
