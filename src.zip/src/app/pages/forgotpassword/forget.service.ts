import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ForgetService {
  private _user:any
  forgetWith!:string

  get user(){
    return this._user
  }
  set user(data){
    this._user = data
  }
  constructor() { }


}
