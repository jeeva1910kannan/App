import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ForgetService } from '../forget.service';
import { WebService } from 'src/app/services/web.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.page.html',
  styleUrls: ['./verification.page.scss'],
})
export class VerificationPage implements OnInit {
  user:any
  otpString:string = ''
  constructor(private router:Router,private forgetService:ForgetService,private web:WebService,private common:CommonService) { }

  ngOnInit(): void {
    
  }

  ionViewWillEnter() {
    console.log(this.forgetService.user)
    if(!this.forgetService.user){
      this.router.navigate(['/forgotpassword'])
    }else{
      this.user = {...this.forgetService.user}
      console.log(this.user)
    }
  }

  verify(){
    if(this.otpString.trim().length != 6){
      this.common.presentToast('Please enter the OTP')
    }else{
      this.common.presentLoading()
      console.log(this.user)
      console.log(this.user['id'])
      let postData = {
        'user_id' : this.user['id'],
        'otp' : this.otpString
      }
      this.web.postData('verify_otp',{
        ...postData
      }).subscribe(
        (data) => {
          console.log(data)    
          this.common.closeLoading()
          this.common.presentToast(data['message'])                
          if(data['status'] == '200'){
            this.router.navigate(['/forgotpassword/reset-password'])
          }
        },
        (err) => {
          this.common.closeLoading()
          this.common.presentToast(err['error']['message'])
        }
      )
    }
  }

  resendOTP(){
    this.common.presentLoading()
    let postData;
    if(this.forgetService.forgetWith == 'phone'){
      postData = {
        user_id : this.user['id'],
        forget_with : 'phone',
        phone : this.user['phone']       
      }
    }else{
      postData = {
        forget_with : 'email',
        user_id : this.user['id'],
        email : this.user['email']       
      }
    }
    this.web.postData('resend_otp',{
      ...postData
    }).subscribe(
      (data) => {
        this.common.closeLoading()
        console.log('data')
        this.common.presentToast(data['message'])        
      },
      (err) => {
        this.common.closeLoading()
        this.common.presentToast(err['error']['message'])
      }
    )
  }

  onOtpChange(event: any) {
    this.otpString = event;
  }

}
