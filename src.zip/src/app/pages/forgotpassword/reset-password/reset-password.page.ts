import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { ForgetService } from '../forget.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
})
export class ResetPasswordPage implements OnInit {
  user:any
  showPassword:boolean = false
  showCpassword:boolean = false
  reset = {
    'password' : '',
    'cpassword' : ''
  }
  constructor(private common:CommonService,private web:WebService,private router:Router,private forgetService:ForgetService) { }

  ngOnInit() {

  }

  ionViewWillEnter(){
    if(!this.forgetService.user){
      this.router.navigate(['/forgotpassword'])
    }else{
      this.user = {...this.forgetService.user}
    }
  }

  submit(){
    if(this.reset['password'].trim() == ''){
      this.common.presentToast('Please enter the new password')
    }else if(this.reset['cpassword'].trim() == ''){
      this.common.presentToast('Please enter the confirmation password')
    }else if(this.reset['password'] != this.reset['cpassword']){
      this.common.presentToast('Passwords mismatched. Please try again.')
    }else{
      this.common.presentLoading()
      let postData = {
        'user_id' : this.user['id'],
        'password' : this.reset['password']
      }
      this.web.postData('reset_password',{
        ...postData
      }).subscribe(
        (data) => {
          this.common.closeLoading()
          this.common.presentToast(data['message'])
          if(data['status'] == 200){
            this.router.navigate(['/'])
          }
        },
        (err) => {
          this.common.closeLoading()
          this.common.presentToast(err['error']['message'])
        }
      )
    }
  }

  togglePassword(){
    this.showPassword = !this.showPassword
    console.log(this.showPassword)
  }

  toggleCpassword(){
    this.showCpassword = !this.showCpassword
    console.log(this.showCpassword)
  }


}
