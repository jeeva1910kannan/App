import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { WebService } from 'src/app/services/web.service';
import { countryData } from 'src/app/countries';
import { ForgetService } from './forget.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.page.html',
  styleUrls: ['./forgotpassword.page.scss'],
})
export class ForgotpasswordPage implements OnInit {

  forgotForm = {
    email : '',
    phonenumber : '',
  }

  selectedCountry!:string  
  _searchTerm:string = ''
  countries = countryData
  filteredCountries = [...this.countries]
  userCountry:any

  get searchTerm(){
    return this._searchTerm
  }

  set searchTerm(val:string){
    this._searchTerm = val
    this.filteredCountries = this.filterSource(val);    
  }

  constructor(private common:CommonService, private router:Router,private web:WebService, private forgetService:ForgetService) { }

  ngOnInit() {
    this.userCountry = this.countries[0] 
    this.selectedCountry = this.userCountry['value']
  }

  setCountry(){
    this.userCountry = this.countries.find((country) => {
      return country['value'] == this.selectedCountry
    })
    console.log(this.userCountry)
  }

 

  submit(){ 

    if((this.forgotForm['email'].trim() == '' && this.forgotForm['phonenumber'] == '') || (this.forgotForm['email'].trim() != '' && this.forgotForm['phonenumber'].trim() != '')){
      this.common.presentToast('Please enter Email or Phone Number');
    }else if (this.forgotForm['email'].trim() != '' && !this.common.isValidEmail(this.forgotForm['email'])) {
       this.common.presentToast('Please enter a valid Email');
      
    }else if (this.forgotForm['phonenumber'].trim() != '' && !this.common.isValidPhoneNumber(this.forgotForm['phonenumber'])) {
      this.common.presentToast('Please enter a valid Phone Number');     
   }  
    
    // else if (this.forgotForm['phonenumber'] !== '') {
    //   console.log("next")
    // }
    
   else{
    this.common.presentLoading()
    let postData
      if(this.forgotForm['email'].trim() == ''){
        postData = {
          'phone' : this.forgotForm['phonenumber'],
          'country_code' : this.userCountry['code'],
          'forget_with' : 'phone'
        }
      }else{
        postData = {
          'email' : this.forgotForm['email'],
          'forget_with' : 'email'          
        }
      }      
    this.web.postData('forget_password',{
      ...postData
    }).subscribe(
      (data) => {     
        this.common.closeLoading()
        this.common.presentToast(data['message'])   
        if(data['status'] == 200){
          this.forgetService.user = data['user'][0]        
          this.forgetService.forgetWith = data['forget_with']
          this.router.navigate(['/forgotpassword/verification'])
        }
      },
      (err) => {
        this.common.closeLoading()
        this.common.presentToast(err['error']['message'])
      }
    )
      
    }
  }

  filterSource(value:string){
    if(!value || this.countries.length === 0) {
      return this.countries
    }
    return this.countries.filter((data) => this.matchValue(data,value)); 
  }

  matchValue(data:any, value:any) {
    return Object.keys(data).map((key) => {
       return new RegExp(value, 'gi').test(data[key]);
    }).some(result => result);
  }

}
