import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from './services/common.service';
import { AlertController, Platform } from '@ionic/angular';
import { Location } from '@angular/common';

declare var navigator: { [x: string]: { exitApp: () => void; }; };

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    private router: Router,
    private common: CommonService, 
    private alertController: AlertController,
    private platform: Platform,
    private location: Location
  ) {
    this.router.navigate([localStorage.getItem('userData') ? '/landing' : '/'])  
    // this.router.navigate(['/confirm-transfer/edit-transfer','payment'])
    platform.ready().then(() => {      
      this.backfunction();
    });
      
  }

  get getUserName(){
    if(localStorage.getItem('userData')){
      let user = JSON.parse(localStorage.getItem('userData') ?? '');
      return user?.name ?? ''
    }else{
      return ''
    }
  }

  get getUserData(){    
    if(localStorage.getItem('userData')){
      let user = JSON.parse(localStorage.getItem('userData') ?? '')
      if(user?.phone){
        return `+${user.country_code} ${user.phone}`
      }else{
        return user.email
      }
    }else{
      return ''
    }
  }

  public pages = [    
    { title: 'Account', url: '/account', icon: 'person-circle', function:"contact()" },
    { title: 'Transfer History', url: '/transfer-history', icon: 'file-tray-full', function:"contact()" },
    { title: 'Payment', url: '/payment', icon: 'card', function:"contact()" },
    { title: 'Support', url: '/support', icon: 'mail', function:"contact()" },
    { title: 'About', url: '/about', icon: 'information-circle', function:"about()" },        
  ];


home(){

}

contact(){

}

about(){
  console.log('enter')
  this.router.navigate(['/about'])
}

async logout() {
  console.log('logout')
  const alert = await this.alertController.create({
    header: 'Logout',
    message : 'Are you sure you want to logout?',
    cssClass : 'logout',
    backdropDismiss : false,
    mode : 'md',    
    buttons: [
      {
        text: 'No',
        role: 'cancel',
        cssClass: 'secondary',
        handler: () => {
          console.log('Confirm Cancel');
        }
      }, 
      {
        text: 'Yes',
        handler: () => {
          this.router.navigate(['/'])
          localStorage.removeItem('userData')
          this.common.presentToast('You have successfully logged out')
        }
      }
    ]
  });

  await alert.present();
}



backfunction()
  {
    this.platform.backButton.subscribeWithPriority(10, (processNextHandler:any) => {
      console.log('Back press handler!');
      if (this.location.isCurrentPathEqualTo('/landing') || this.location.isCurrentPathEqualTo('/') || this.location.isCurrentPathEqualTo('/welcome')) {                
        this.showExitConfirm();
        processNextHandler();
       }else {        
        console.log('Navigate to back page');
        this.location.back();
      }
    });

    this.platform.backButton.subscribeWithPriority(5, () => {
      console.log('Handler called to force close!');
      this.alertController.getTop().then((r) => {
        if (r) {
          navigator['app'].exitApp();
        }
      }).catch(e => {
        console.log(e);
      })
    });
  }

showExitConfirm() {
  this.alertController.create({
    header: 'Exit',
    message: 'Do you want to exit the application?',
    backdropDismiss: false,
    cssClass : 'exit',
    buttons: [{
      text: 'No',
      role: 'cancel',
      handler: () => {
        console.log('Application exit prevented!');
      }
    }, {
      text: 'Yes',
      handler: () => {
        navigator['app'].exitApp();
      }
    }]
  })
    .then(alert => {
      alert.present();
    });
}



}
