export const environment = {
  production: true,
  apiurl:"https://zerosoft.in/dev/moneydigo.com/public/index.php/api/",
  currencyApiKey : 'uIPTC0dk7B7Ra15qU4DrE2BexUsWdZCV'
};
